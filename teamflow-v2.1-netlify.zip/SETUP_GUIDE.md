# Actuary TeamFlow — Setup and Release Guide

## Architecture

- `public/` contains the vanilla JavaScript application, split into ordered browser modules and a shared stylesheet.
- `netlify/functions/` contains authenticated Netlify Functions for sign-in, work, team, reports, reminders, and activity history.
- Netlify Blobs remains the storage layer. Each work item and member is stored separately with a version number; supporting collections remain versioned records.
- `scripts/migrate-data.js` defaults to a read-only dry run. Production migration is a separate, explicitly authorized operation.

Netlify Blobs conditional writes protect each versioned record and collection with an ETag precondition. Conflicting edits return HTTP 409. Blobs does not provide transactions spanning multiple keys; request resolution and recurring completion use durable retry markers to recover partial saves.

## Local development

Use Node.js 22 or later.

```bash
npm ci
npm run build
npm test
```

For a layout preview with fictional, memory-only data, run the fixture server:

```bash
npm run preview:fixture
```

Open `http://127.0.0.1:8890`. This server binds only to loopback, uses fictional in-memory data and the actual work/team/reminder handlers with simulated sessions. It does not exercise real login, SMTP delivery, or Netlify Blobs infrastructure. For role checks, open `/fixture-login?user=1` (Admin), `2` (Manager), `3` or `4` (Member), or `5` (Board).

For API development, use a dedicated non-production Netlify site. Provide that site’s Blobs credentials and a one-time bootstrap token in the shell before starting Netlify Dev:

```powershell
$env:ADMIN_BOOTSTRAP_TOKEN = 'your-local-only-token'
$env:NETLIFY_SITE_ID = 'your-staging-site-id'
$env:NETLIFY_TOKEN = 'your-staging-site-token'
$env:APP_ORIGINS = 'http://localhost:8888,http://127.0.0.1:8888'
$env:APP_URL = 'http://localhost:8888'
npm run dev
```

Open `http://localhost:8888/?setup=1` and create a staging administrator. The API connects to the staging site’s Netlify Blobs store. Account setup and password reset use Admin-generated links; no SMTP configuration is required. Do not use production credentials or production Blobs while rehearsing.

## Netlify environment variables

Set secrets in the Netlify site environment settings. Do not commit them or place them in `netlify.toml`.

| Variable | Purpose |
|---|---|
| `APP_URL` | Canonical site URL used in account links |
| `APP_ORIGINS` | Comma-separated exact allowed origins, including the site and intended preview URLs |
| `TEAM_TIME_ZONE` | Team reporting timezone; defaults to `Asia/Bangkok` |
| `ADMIN_BOOTSTRAP_TOKEN` | One-time administrator setup token; remove after setup |
| `NETLIFY_SITE_ID`, `NETLIFY_TOKEN` | Staging Project ID and private Netlify access token for Blobs in Lambda-compatible functions; include Functions scope |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE` | Optional email/digest settings; not needed for account links |
| `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM` | Optional email/digest credentials; not needed for account links |
| `DIGEST_API_TOKEN` | Optional bearer token for an external digest reader |
| `NETLIFY_SITE_ID`, `NETLIFY_TOKEN` | Netlify Blobs store access; use a dedicated staging site for local API development |
| `MIGRATION_BACKUP_KEY` | 32-byte key, as 64 hexadecimal characters or base64, for encrypted migration backups |

Keep `TEAM_TIME_ZONE` consistent with the client default in `public/js/core.js` if the team changes from Bangkok time.

## Accounts and access

- Fresh setup: open `/?setup=1` once, create the administrator, then remove `ADMIN_BOOTSTRAP_TOKEN`.
- Existing members: the password-preserving migration converts legacy passwords to scrypt hashes; existing usernames and passwords continue to work. New members receive an Admin-generated setup link valid for 24 hours.
- Password reset: the member contacts Admin. After identity verification, Admin generates and privately shares a reset link. Reset links expire after 30 minutes and work once. SMTP is not used.
- Passwords require at least 6 characters. Passwords are stored as scrypt hashes; sessions use secure, HTTP-only cookies and expire after eight hours. Changing a password expires previous sessions.
- CORS is restricted to exact origins. Add Netlify preview origins explicitly before using preview deployments.

## Data migration rehearsal

Follow `PRODUCTION_DEPLOYMENT.md` for a store with existing accounts. The interactive wrapper verifies the target Project ID and URL, hides credentials, and provides Inspect, Backup, Rehearse, Apply, Finalize, and Restore operations. Start with read-only inspection:

```bash
.\scripts\run-migration.ps1 -Action Inspect
```

Then create an encrypted backup and rehearse using that local encrypted copy:

```bash
.\scripts\run-migration.ps1 -Action Backup
.\scripts\run-migration.ps1 -Action Rehearse
```

Apply is separate from rehearsal. It requires a published maintenance API guard and the exact source fingerprint from the latest inspection. It creates another encrypted backup before writes, preserves passwords as hashes, remaps Admin ID 0 and account references, and verifies imported records. Finalize removes legacy plaintext credentials and expires old sessions; Restore uses the Apply backup to recover during maintenance. Keep the recovery passphrase separately. No live apply, finalize, restore, or deployment has been performed during preparation.

## Reports and capacity

- Weekly reports use Monday through Sunday; completed-work totals filter by completion date.
- Weekly and monthly reports list ongoing work started by the end of the selected period, including unfinished overdue carryover. Phase and progress reflect current status, not a historical snapshot. Both exports include this ongoing-work list.
- Monthly reports show scheduled work overlapping the selected month, plus work created or completed in that month and ongoing carryover. On-time rate uses completed items that have a deadline.
- Annual reports cover January–December of the selected year and include member performance for assignees and PICs. Year navigation updates the report and export together. Ongoing work reflects current status, not a historical snapshot.
- Dates default to `Asia/Bangkok`.
- Capacity is an estimate: effort is spread evenly over scheduled Monday–Friday dates (inclusive), excluding weekends. Work with no scheduled weekdays is flagged and excluded from the forecast until its dates are adjusted; effort is allocated proportionally using member = 1, manager reviewer = 0.4, and PIC = 1.5. PIC takes precedence over role and is included even when not separately assigned. Total estimated effort remains unchanged; duplicates, missing members, and Board accounts do not receive shares. It does not track actual time. Set weekly capacity in Admin or My Profile.

## Release checklist

1. Run `npm ci`, `npm run build`, `npm test`, and `npm audit`.
2. Test on a staging site with fictional data and the intended preview origin list. Account links require APP_URL; optional email features need separate SMTP credentials.
3. Rehearse the encrypted backup and data migration on a copy; verify authentication, roles, reset expiry/single use, report boundaries, mobile layouts, keyboard access, and reduced motion.
4. Review staging behavior and migration results before scheduling a production data migration or deploy.

No production data migration, session invalidation, or deployment was performed as part of this code change.


## Installed PWA window reuse

The service worker registers after the page loads. It caches only the static interface files and an offline reconnect page. Sign-in, work records, feedback, reports, and all API requests remain online-only and are never placed in the service-worker cache. Offline changes are not queued for later submission.

Install from Chrome's menu: Cast, save, and share → Install page as app. The site must be accessible without being redirected to Netlify's private-site access page. Private staging access may prevent another browser profile or device from loading the manifest or service worker. Keep staging access controls until you explicitly choose to change them.

The build gives the service-worker cache a content-derived version. A new worker waits for existing app windows and tabs to close before activating. Close and reopen the app after a deployment; no automatic reload interrupts unsaved edits.

After deploying to staging, verify the manifest and activated worker in browser developer tools, install the app, reload offline to confirm the reconnect page, reconnect, and confirm sign-in and normal saves work. Run Lighthouse against the actual TeamFlow page. No Lighthouse score or installed-device behavior is guaranteed by the build.

The manifest uses `launch_handler.client_mode = navigate-existing`, with app ID and scope `/`. When a supporting browser launches an installed TeamFlow PWA from an in-scope link, it reuses the most recently used app window and navigates it to the clicked URL. If no app window is open, it opens one.

Install the app from the intended site URL using the browser profile that will open links. In Chrome app settings, allow supported links to open in the app. Staging and production URLs are separate installed apps. Browser support and user settings determine whether a clicked link launches the app; this setting does not force ordinary browser tabs or external applications to reuse a window. Navigation reloads the app and may interrupt unsaved edits, so save before opening another link.

Verify after deployment: install the staging app, leave it open, click its HTTPS link from another page, and confirm the existing window is reused. Repeat with the app closed. Manifest updates can take time to reach an existing installation. Installed-window behavior has not been verified as part of this local manifest change.

References: https://developer.chrome.com/docs/capabilities/pwa-navigation-management and https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Manifest/Reference/launch_handler

## Concurrent users (approximately 10)

- Independent sessions keep sign-in, sign-out and reminders separate for each user. Ten simultaneous sign-ins from the same office IP are supported; rate limits still apply.
- Feedback, templates and membership requests merge changes to different entries using conditional writes. Concurrent changes to the same entry return a conflict instead of overwriting it.
- Members can create work and use any template. They are automatically assigned to work they create. The work creator and current PIC can change assignees through Edit or Manage Assignees. Manage Assignees remains available to the creator even after they are removed from the assignee list. Other members cannot change assignees. PIC reassignment remains restricted to Admin/Manager. Assignment updates use version checks and appear in Activity History.
- Members can save new templates and edit only templates they created. The API records immutable creator ownership. Admin/Manager can edit any template and delete templates. Older templates without recorded ownership remain editable only by Admin/Manager; no ownership is guessed from migrated data.
- Work edits use record versions. If two users edit the same work item, the second stale save reports a conflict and keeps its local draft for reconciliation. Different work items can save concurrently.
- Account changes use an atomic `v3:team-directory` blob to protect unique emails/usernames and retain at least one active Admin. Existing legacy/v2 account records are copied into this directory on the first account change, preserving password hashes and versions. Afterwards the directory is authoritative. Back up the store before deployment; reverting to older functions would require restoring or converting this account data, because old functions do not read the new directory. The legacy migration tool refuses to apply over an active directory.
- Background refresh is periodic (about 30 seconds), not live push. Open drafts and pending saves prevent a refresh from replacing edits. The PWA requires an internet connection for shared data and saves.
- Run `node --test tests/concurrency.test.js` for local concurrent API checks using fictional storage. These do not measure live Netlify latency, quotas, SMTP delivery or ten physical devices. Complete that staging acceptance check before production rollout.

## Open work modal updates
A viewing-only work detail dialog checks for changes when opened and during the normal 30-second refresh cycle, while the page is visible. Saved changes refresh its contents and preserve scroll position and expanded activity history. A draft, active save, edit form or request action blocks replacement and displays an update notice instead. Keyboard focus and text selection are restored when the corresponding control remains available. Deletion closes an untouched detail dialog with a notice; edited dialogs retain their draft. Temporary refresh failure displays a stale-data notice and later polling retries. Work save version conflicts remain enforced.

## Conflict review and sync status
On a conflicting work, account, template, feedback or membership-request collection save, select **Review conflict** in the save status. The comparison shows your local changes and the latest saved version. Independent field changes are combined; choose which version to keep for every field changed by both users. Notes, files, task checklists and other nested lists are selected as complete fields. Collection entries are selected as whole entries. **Save reviewed version** retries with the newly read version; another intervening change still returns a conflict. **Use latest saved** confirms before discarding local changes to that record. **Keep draft / Close** leaves the original edits intact. Deletion is reconfirmed against the latest version. A removed record is not restored automatically, and duplicate account identifiers must be corrected in the original form.

The header shows Online, Connection lost, Server unavailable or Refresh paused — edits kept, plus the time of the last successful shared-data refresh. The timestamp refers to applied shared data, not merely a successful request. Reconnecting triggers a refresh; drafts remain protected. Shared changes are polled every 30 seconds while the page is visible. The comparison and sync status do not provide live push updates.

## Windows and shared folder links
File/folder links accept HTTPS URLs, absolute Windows drive paths (for example O:\folder) and network paths (\\server\share\folder or //server/share/folder), independently of the selected document/folder type. Windows/network paths display Copy Path; paste the copied value into File Explorer. The app stores a reference, not the file contents. Each user needs access to the share and matching drive mappings; use the actual UNC share path for consistent references across PCs. Invalid locations are checked before adding a local record. Server validation messages are displayed directly instead of being mislabeled as connection failures.

## HTTP links
HTTP and HTTPS URLs are accepted for all link categories and use Open in a new tab. Windows drive paths and network paths continue to use Copy Path. Client and server share the same location validation; other URL schemes are rejected.

## Email-free account setup
1. Set APP_URL in Netlify, scoped to Functions, to the exact intended HTTPS site address. For staging use https://actuaryteamflow-staging.netlify.app. Redeploy after changing it.
2. Admin creates a member with name, unique username and role. Email is optional. Existing accounts and passwords remain valid.
3. The saved member opens in Edit Member. Select Generate Setup Link, confirm replacing older links, then Copy Link and share it privately with that member. Link expires after 24 hours and works once.
4. Member opens the link and sets their own password (minimum 6 characters). Sign in supports username; an optional email can still be used.
5. Forgot password directs the member to Admin. After verifying identity, Admin selects Generate Reset Link for the active account. Reset links expire after 30 minutes and work once. Existing sessions become invalid when the password is successfully reset.

The links use random tokens; only token hashes are persisted. A per-member pointer makes a newly generated setup/reset link invalidate previous links, including legacy links for that member. Conditional consumption prevents using a link twice. Password-generation checks invalidate links after a password change. Generation is Admin-only and rate-limited to 30 attempts per hour per Admin/IP. Tokens appear only in the immediate Admin response/dialog, are not stored in browser local storage, and are removed from the recipient address bar before further API calls. Closing the Admin dialog removes the displayed link; generating a replacement is the way to recover it. Save any member edits before generating a link.

This workflow does not send email or external messages. Share links directly with the intended member through your chosen private channel. Optional email/digest features remain separate.
