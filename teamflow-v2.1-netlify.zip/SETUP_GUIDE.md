# Actuary TeamFlow — Setup and Release Guide

## Architecture

- `public/` contains the vanilla JavaScript application, split into ordered browser modules and a shared stylesheet.
- `netlify/functions/` contains authenticated Netlify Functions for sign-in, work, team, reports, reminders, and activity history.
- Netlify Blobs remains the storage layer. Each work item and member is stored separately with a version number; supporting collections remain versioned records.
- `scripts/migrate-data.js` defaults to a read-only dry run. Production migration is a separate, explicitly authorized operation.

Netlify Blobs conditional writes protect each versioned record and collection with an ETag precondition. Conflicting edits return HTTP 409. Blobs does not provide transactions spanning multiple keys; request resolution and recurring completion use durable retry markers to recover partial saves.

## Local development

Use Node.js 22 or later.

```bash
npm ci
npm run build
npm test
```

For a layout preview with fictional, memory-only data, run the fixture server:

```bash
npm run preview:fixture
```

Open `http://127.0.0.1:8890`. This server binds only to loopback, uses fictional in-memory data and the actual work/team/reminder handlers with simulated sessions. It does not exercise real login, SMTP delivery, or Netlify Blobs infrastructure. For role checks, open `/fixture-login?user=1` (Admin), `2` (Manager), `3` or `4` (Member), or `5` (Board).

For API development, use a dedicated non-production Netlify site. Provide that site’s Blobs credentials and a one-time bootstrap token in the shell before starting Netlify Dev:

```powershell
$env:ADMIN_BOOTSTRAP_TOKEN = 'your-local-only-token'
$env:NETLIFY_SITE_ID = 'your-staging-site-id'
$env:NETLIFY_TOKEN = 'your-staging-site-token'
$env:APP_ORIGINS = 'http://localhost:8888,http://127.0.0.1:8888'
$env:APP_URL = 'http://localhost:8888'
npm run dev
```

Open `http://localhost:8888/?setup=1` and create a staging administrator. The API connects to the staging site’s Netlify Blobs store. For invitation and reset email tests, configure SMTP with a test mail account. Do not use production credentials or production Blobs while rehearsing.

## Netlify environment variables

Set secrets in the Netlify site environment settings. Do not commit them or place them in `netlify.toml`.

| Variable | Purpose |
|---|---|
| `APP_URL` | Canonical site URL used in account links |
| `APP_ORIGINS` | Comma-separated exact allowed origins, including the site and intended preview URLs |
| `TEAM_TIME_ZONE` | Team reporting timezone; defaults to `Asia/Bangkok` |
| `ADMIN_BOOTSTRAP_TOKEN` | One-time administrator setup token; remove after setup |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE` | SMTP server settings |
| `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM` | SMTP credentials and sender address |
| `DIGEST_API_TOKEN` | Optional bearer token for an external digest reader |
| `NETLIFY_SITE_ID`, `NETLIFY_TOKEN` | Netlify Blobs store access; use a dedicated staging site for local API development |
| `MIGRATION_BACKUP_KEY` | 32-byte key, as 64 hexadecimal characters or base64, for encrypted migration backups |

Keep `TEAM_TIME_ZONE` consistent with the client default in `public/js/core.js` if the team changes from Bangkok time.

## Accounts and access

- Fresh setup: open `/?setup=1` once, create the administrator, then remove `ADMIN_BOOTSTRAP_TOKEN`.
- Existing members: after data migration, the administrator sends each member a one-time invitation from Admin. The link expires after 24 hours.
- Password reset: the member enters their team email on the sign-in screen. Reset links expire after 30 minutes and work once. Configure SMTP before enabling account setup.
- Passwords require at least 12 characters. Passwords are stored as scrypt hashes; sessions use secure, HTTP-only cookies and expire after eight hours. Changing a password expires previous sessions.
- CORS is restricted to exact origins. Add Netlify preview origins explicitly before using preview deployments.

## Data migration rehearsal

Run a dry run against a disposable Netlify site or copied release first:

```bash
npm run migrate:data
```

The dry run reports the legacy record counts and makes no writes. Before an approved rehearsal apply, set staging-only `NETLIFY_SITE_ID`, `NETLIFY_TOKEN`, and a unique `MIGRATION_BACKUP_KEY`, then run:

```bash
node scripts/migrate-data.js --apply
```

The script writes an encrypted local backup, imports members and work as versioned records, verifies the import, invalidates old sessions and reset links, then removes the legacy `team` and `works` keys. Keep the backup key separately so the encrypted backup can be recovered. **Do not point this command at production until migration, account reset, and release have been explicitly approved.**

## Reports and capacity

- Weekly reports use Monday through Sunday; completed-work totals filter by completion date.
- Weekly and monthly reports list ongoing work started by the end of the selected period, including unfinished overdue carryover. Phase and progress reflect current status, not a historical snapshot. Both exports include this ongoing-work list.
- Monthly reports show scheduled work overlapping the selected month, plus work created or completed in that month and ongoing carryover. On-time rate uses completed items that have a deadline.
- Annual reports cover January–December of the selected year and include member performance for assignees and PICs. Year navigation updates the report and export together. Ongoing work reflects current status, not a historical snapshot.
- Dates default to `Asia/Bangkok`.
- Capacity is an estimate: effort is spread evenly over scheduled Monday–Friday dates (inclusive), excluding weekends. Work with no scheduled weekdays is flagged and excluded from the forecast until its dates are adjusted; effort is allocated proportionally using member = 1, manager reviewer = 0.4, and PIC = 1.5. PIC takes precedence over role and is included even when not separately assigned. Total estimated effort remains unchanged; duplicates, missing members, and Board accounts do not receive shares. It does not track actual time. Set weekly capacity in Admin or My Profile.

## Release checklist

1. Run `npm ci`, `npm run build`, `npm test`, and `npm audit`.
2. Test on a staging site with fictional data, SMTP test credentials, and the intended preview origin list.
3. Rehearse the encrypted backup and data migration on a copy; verify authentication, roles, reset expiry/single use, report boundaries, mobile layouts, keyboard access, and reduced motion.
4. Review staging behavior and migration results before scheduling a production data migration or deploy.

No production data migration, session invalidation, or deployment was performed as part of this code change.


## Installed PWA window reuse

The manifest uses `launch_handler.client_mode = navigate-existing`, with app ID and scope `/`. When a supporting browser launches an installed TeamFlow PWA from an in-scope link, it reuses the most recently used app window and navigates it to the clicked URL. If no app window is open, it opens one.

Install the app from the intended site URL using the browser profile that will open links. In Chrome app settings, allow supported links to open in the app. Staging and production URLs are separate installed apps. Browser support and user settings determine whether a clicked link launches the app; this setting does not force ordinary browser tabs or external applications to reuse a window. Navigation reloads the app and may interrupt unsaved edits, so save before opening another link.

Verify after deployment: install the staging app, leave it open, click its HTTPS link from another page, and confirm the existing window is reused. Repeat with the app closed. Manifest updates can take time to reach an existing installation. Installed-window behavior has not been verified as part of this local manifest change.

References: https://developer.chrome.com/docs/capabilities/pwa-navigation-management and https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Manifest/Reference/launch_handler
