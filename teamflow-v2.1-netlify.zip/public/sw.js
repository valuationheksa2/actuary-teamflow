'use strict';

const CACHE_NAME = 'teamflow-shell-v21-04ad3b0d419f2a65';
const ASSETS = [
  '/offline.html', '/css/app.min.css', '/manifest.json',
  '/icon-192.png', '/icon-512.png', '/favicon.ico',
  '/js/domain.min.js', '/js/core.min.js', '/js/work.min.js', '/js/reports.min.js', '/js/meetings.min.js', '/js/absences.min.js', '/js/tutorials.min.js',
  '/js/admin.min.js', '/js/ui.min.js', '/js/collaboration.min.js', '/js/startup.min.js',
];
const assetPaths = new Set(ASSETS);

function cacheable(response) {
  return response.ok && !response.redirected
    && new URL(response.url).origin === self.location.origin;
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    for (const asset of ASSETS) {
      const response = await fetch(new Request(asset, { cache: 'reload' }));
      // Private staging redirects must never become cached app assets.
      if (!cacheable(response)) throw new Error('App asset unavailable: ' + asset);
      await cache.put(asset, response);
    }
  })());
  // Updates wait for open app windows to close, preserving unsaved work.
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('teamflow-shell-')
      && name !== CACHE_NAME).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  // Authentication, API responses, mutations and third-party resources are online only.
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/.netlify/')) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try { return await fetch(request); }
      catch {
        return await caches.match('/offline.html', { cacheName: CACHE_NAME })
          || new Response('You are offline. Reconnect to use TeamFlow.', {
            status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' },
          });
      }
    })());
    return;
  }
  if (!assetPaths.has(url.pathname) || url.search) return;
  event.respondWith((async () => {
    try {
      const response = await fetch(request);
      if (cacheable(response)) {
        try {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(url.pathname, response.clone());
        } catch { /* Storage quota failures must not block a successful online request. */ }
      }
      return response;
    } catch {
      const cached = await caches.match(url.pathname, { cacheName: CACHE_NAME });
      if (cached) return cached;
      throw new Error('App asset unavailable offline.');
    }
  })());
});

// The page asks a waiting update to take over once the person chooses Reload.
self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

// Server alerts (web push) arrive even when no TeamFlow window is open.
self.addEventListener('push', event => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch { payload = { body: event.data?.text() || '' }; }
  event.waitUntil(self.registration.showNotification(String(payload.title || 'TeamFlow'), {
    body: String(payload.body || ''), tag: payload.tag ? String(payload.tag) : undefined, renotify: Boolean(payload.tag),
    icon: '/icon-192.png', badge: '/icon-192.png', data: { workId: payload.workId ?? null, meetingId: payload.meetingId ?? null },
  }));
});

// Selecting a notification focuses an open TeamFlow window, or opens one, at the related work item.
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const workId = event.notification.data?.workId ?? null, meetingId = event.notification.data?.meetingId ?? null;
  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const client = windows.find(item => new URL(item.url).origin === self.location.origin);
    if (client) {
      await client.focus();
      if (workId != null) client.postMessage({ type: 'teamflow-open-work', workId });
      if (meetingId != null) client.postMessage({ type: 'teamflow-open-meeting', meetingId });
      return;
    }
    await self.clients.openWindow(workId != null ? '/?work=' + encodeURIComponent(workId) : meetingId != null ? '/?meeting=' + encodeURIComponent(meetingId) : '/');
  })());
});
