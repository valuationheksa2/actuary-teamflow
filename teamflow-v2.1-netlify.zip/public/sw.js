'use strict';

const CACHE_NAME = 'teamflow-shell-v21-4188acb630e88cba';
const ASSETS = [
  '/offline.html', '/css/app.css', '/manifest.json',
  '/icon-192.png', '/icon-512.png', '/favicon.ico',
  '/js/domain.js', '/js/core.js', '/js/work.js', '/js/reports.js',
  '/js/admin.js', '/js/ui.js', '/js/collaboration.js', '/js/startup.js',
];
const assetPaths = new Set(ASSETS);

function cacheable(response) {
  return response.ok && !response.redirected
    && new URL(response.url).origin === self.location.origin;
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    for (const asset of ASSETS) {
      const response = await fetch(new Request(asset, { cache: 'reload' }));
      // Private staging redirects must never become cached app assets.
      if (!cacheable(response)) throw new Error('App asset unavailable: ' + asset);
      await cache.put(asset, response);
    }
  })());
  // Updates wait for open app windows to close, preserving unsaved work.
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter(name => name.startsWith('teamflow-shell-')
      && name !== CACHE_NAME).map(name => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  // Authentication, API responses, mutations and third-party resources are online only.
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/.netlify/')) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try { return await fetch(request); }
      catch {
        return await caches.match('/offline.html', { cacheName: CACHE_NAME })
          || new Response('You are offline. Reconnect to use TeamFlow.', {
            status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' },
          });
      }
    })());
    return;
  }
  if (!assetPaths.has(url.pathname) || url.search) return;
  event.respondWith((async () => {
    try {
      const response = await fetch(request);
      if (cacheable(response)) {
        try {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(url.pathname, response.clone());
        } catch { /* Storage quota failures must not block a successful online request. */ }
      }
      return response;
    } catch {
      const cached = await caches.match(url.pathname, { cacheName: CACHE_NAME });
      if (cached) return cached;
      throw new Error('App asset unavailable offline.');
    }
  })());
});
