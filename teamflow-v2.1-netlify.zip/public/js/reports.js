// ============================================================
// AUDIT
// ============================================================
const canSeeBottlenecks=()=>['admin','manager','board'].includes(currentUser?.role);
let bottleneckDays=90,teamPerformance=null;
const PERFORMANCE_PERIODS=[[30,'Last 30 days'],[90,'Last 90 days'],[365,'Last 12 months']];
const percentText=value=>value==null?'—':`${Math.round(value*100)}%`;
const daysText=value=>value==null?'—':TeamFlowDomain.formatDays(value);
function renderBottleneckAudit(){
  setTimeout(loadBottlenecks,0);
  return`<div class="card"><div class="card-header" style="flex-wrap:wrap;gap:10px;"><div class="card-title">Team Performance</div><div style="display:flex;gap:8px;align-items:center;"><select id="bottleneck-days" aria-label="Period" style="width:auto;" onchange="bottleneckDays=Number(this.value);loadBottlenecks();">${PERFORMANCE_PERIODS.map(([value,label])=>`<option value="${value}" ${value===bottleneckDays?'selected':''}>${label}</option>`).join('')}</select><button type="button" class="btn btn-ghost btn-sm" onclick="exportTeamPerformancePDF()"><svg class="ui-icon" aria-hidden="true"><use href="#i-file"/></svg> Export PDF</button></div></div><div id="bottleneck-body" style="font-size:13px;color:var(--text3);">Loading…</div></div>`;
}
async function loadBottlenecks(){
  const target=document.getElementById('bottleneck-body');if(!target)return;
  target.textContent='Loading…';teamPerformance=null;
  try{
    const result=await apiGet(`activity?bottlenecks=1&days=${bottleneckDays}`);
    if(document.getElementById('bottleneck-body')!==target)return;
    teamPerformance=result;target.innerHTML=bottleneckHtml(result);target.style.color='var(--text)';
  }catch{target.textContent='Team performance is not available right now.';}
}
const hasEnoughToCompare=summary=>Boolean(summary)&&summary.analyzed>=3;
function performanceSummaryText(result){
  const {current,previous}=result,parts=[];
  if(current.analyzed){
    const top=current.phases.reduce((best,phase)=>phase.days>best.days?phase:best,current.phases[0]);
    const before=hasEnoughToCompare(previous)?previous.phases.find(phase=>phase.name===top.name):null;
    parts.push(`${top.name} took the most time, at ${percentText(top.share)}${before?`, ${top.share>=before.share?'up':'down'} from ${percentText(before.share)} in the previous period`:''}.`);
  }
  if(current.delivery.rate!=null)parts.push(`${percentText(current.delivery.rate)} of completed work met its deadline.`);
  if(current.averageReviewWait!=null)parts.push(`Work waited ${daysText(current.averageReviewWait)} on average for a review decision.`);
  return parts.join(' ');
}
function performanceCoverageText(current){
  const left=current.completed-current.analyzed;
  return`${current.completed} completed item${current.completed===1?'':'s'} in this period. Phase and review figures use the ${current.analyzed} with a full timeline${left?`; ${left} left out because phase moves weren’t recorded in detail or happened all at once`:''}. Delivery and effort use all of them. Days leave out weekends.`;
}
const PERFORMANCE_CAUTION='Too few items to draw conclusions yet. Figures will firm up as more work completes with detailed history.';
function performanceKpis(result){
  const {current,previous}=result,compare=hasEnoughToCompare(previous)?previous:null;
  return[
    ['On-time delivery',percentText(current.delivery.rate),compare?percentText(compare.delivery.rate):null],
    ['Average days late',daysText(current.delivery.averageDaysLate),compare?daysText(compare.delivery.averageDaysLate):null],
    ['Actual vs estimated hours',current.effort.variance==null?'—':`${current.effort.variance>0?'+':''}${Math.round(current.effort.variance*100)}%`,compare&&compare.effort.variance!=null?`${compare.effort.variance>0?'+':''}${Math.round(compare.effort.variance*100)}%`:null],
    ['Average time, start to finish',daysText(current.averageTotalDays),compare?daysText(compare.averageTotalDays):null],
    ['Wait for review decision',daysText(current.averageReviewWait),compare?daysText(compare.averageReviewWait):null],
    ['Approved first time',percentText(current.firstTime.rate),compare?percentText(compare.firstTime.rate):null],
    ['Went back from Review',current.knownCount?percentText(current.reworked/current.knownCount):'—',compare&&compare.knownCount?percentText(compare.reworked/compare.knownCount):null],
    ['PIC self-reviews',String(current.selfReviewed),compare?String(compare.selfReviewed):null],
  ];
}
function performanceGroupRows(title,groups,labelOf=name=>name){
  if(!groups.length)return'';
  return`<div class="perf-subhead">${title}</div><div class="perf-table-wrap"><table class="perf-table"><thead><tr><th>Group</th><th>Items</th><th>Planning</th><th>Executing</th><th>Review</th><th>Finalize</th><th>Total</th><th>Slowest</th></tr></thead><tbody>${groups.map(group=>`<tr class="${group.count<3?'few':''}"><td>${escapeHtml(labelOf(group.name))}${group.count<3?' <span class="perf-note">few items</span>':''}</td><td>${group.count}</td>${group.phases.map(days=>`<td>${daysText(days)}</td>`).join('')}<td>${daysText(group.total)}</td><td>${escapeHtml(group.slowest)}</td></tr>`).join('')}</tbody></table></div>`;
}
function workTypeLabel(value){return WORK_TYPES.find(type=>type.value===value)?.label||value;}
function bottleneckHtml(result){
  const {current,previous,people}=result;
  if(!current.completed)return'<div class="empty-state" style="padding:32px 20px;"><p>No work completed in this period.</p></div>';
  const caution=current.analyzed<5?`<div class="perf-caution">${PERFORMANCE_CAUTION}</div>`:'';
  const summary=performanceSummaryText(result);
  const top=current.phases.reduce((best,phase)=>phase.days>best.days?phase:best,current.phases[0]);
  const bars=current.analyzed?current.phases.map(phase=>{const flagged=phase.name===top.name&&(top.name==='Executing'?top.share>=0.7:top.share>=0.35);return`<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;"><span style="width:64px;flex:none;font-size:12px;font-weight:${flagged?700:500};color:${flagged?'var(--red)':'var(--text2)'};">${escapeHtml(phase.name)}</span><div class="perf-bar" style="flex:1;margin-top:0;"><div class="perf-bar-fill" style="width:${Math.round(phase.share*100)}%;background:${flagged?'var(--red)':'var(--primary)'};"></div></div><span style="width:82px;flex:none;text-align:right;font-size:12px;color:var(--text2);">${daysText(phase.days)} · ${percentText(phase.share)}</span></div>`;}).join(''):'';
  const compared=hasEnoughToCompare(previous);
  const kpis=`<div class="perf-kpis">${performanceKpis(result).map(([label,value,before])=>`<div class="perf-kpi"><div class="perf-kpi-val">${value}</div><div class="perf-kpi-label">${label}</div>${before!=null?`<div class="perf-kpi-before">Previous: ${before}</div>`:''}</div>`).join('')}</div>${compared?'':'<div class="perf-note" style="margin-top:8px;">Not enough earlier history to compare with the previous period yet.</div>'}`;
  const breakdowns=performanceGroupRows('By work type',current.breakdowns.workType,workTypeLabel)+performanceGroupRows('By priority',current.breakdowns.priority)+performanceGroupRows('By tag',current.breakdowns.tag);
  const waits=current.longestWaits.length?`<div class="perf-subhead">Longest review waits</div>${current.longestWaits.map(item=>`<div class="digest-row meeting-row" role="button" tabindex="0" onclick="openWorkDetail(${Number(item.id)})"><span style="flex:1 1 180px;min-width:0;overflow-wrap:anywhere;">${escapeHtml(item.title)}</span><span style="font-size:12px;color:var(--text2);">${daysText(item.days)}${item.rounds>1?` average over ${item.rounds} rounds`:''}</span></div>`).join('')}`:'';
  const slowest=current.slowest.length?`<div class="perf-subhead">Longest-running items</div><div class="perf-table-wrap"><table class="perf-table"><thead><tr><th>Work</th><th>Planning</th><th>Executing</th><th>Review</th><th>Finalize</th><th>Total</th></tr></thead><tbody>${current.slowest.map(item=>`<tr class="perf-link" role="button" tabindex="0" onclick="openWorkDetail(${Number(item.id)})"><td>${escapeHtml(item.title)}</td>${item.phases.map((days,index)=>`<td class="${PHASES[index]===item.bottleneck?'perf-hot':''}">${daysText(days)}</td>`).join('')}<td>${daysText(item.days)}</td></tr>`).join('')}</tbody></table></div>`:'';
  const personal=people?`<div class="perf-admin"><div class="perf-subhead" style="margin-top:0;">By person <span class="perf-note">Visible to administrators only, and not included in the PDF</span></div><div class="perf-note" style="margin-bottom:8px;">These come from when people clicked, and a slow item can have many causes. Use them to start a conversation, not to assess anyone.</div>${people.pics.length?`<div class="perf-table-wrap"><table class="perf-table"><thead><tr><th>PIC</th><th>Completed</th><th>On time</th><th>Average start to finish</th><th>Went back</th></tr></thead><tbody>${people.pics.map(pic=>`<tr><td>${escapeHtml(pic.name)}</td><td>${pic.completed}</td><td>${percentText(pic.onTimeRate)}</td><td>${daysText(pic.averageDays)}</td><td>${pic.rework}</td></tr>`).join('')}</tbody></table></div>`:''}${people.reviewers.length?`<div class="perf-table-wrap" style="margin-top:10px;"><table class="perf-table"><thead><tr><th>Reviewer</th><th>Decisions</th><th>Average wait</th><th>Sent back</th></tr></thead><tbody>${people.reviewers.map(reviewer=>`<tr><td>${escapeHtml(reviewer.name)}</td><td>${reviewer.decisions}</td><td>${daysText(reviewer.averageWait)}</td><td>${reviewer.sentBack}</td></tr>`).join('')}</tbody></table></div>`:''}</div>`:'';
  return`${summary?`<div class="perf-summary">${escapeHtml(summary)}</div>`:''}<div class="perf-note" style="margin-bottom:12px;">${escapeHtml(performanceCoverageText(current))}</div>${caution}${bars}${kpis}${breakdowns}${waits}${slowest}${personal}`;
}
// The PDF leaves out the by-person figures because it's easily shared onward.
function exportTeamPerformancePDF(){
  if(!teamPerformance){showToast('Team performance is still loading.','info');return;}
  const {current,period}=teamPerformance,label=PERFORMANCE_PERIODS.find(([value])=>value===bottleneckDays)?.[1]||'';
  const table=(headers,rows)=>`<table><thead><tr>${headers.map(header=>`<th>${header}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table>`;
  const groups=(title,list,labelOf=name=>name)=>list.length?`<h2>${title}</h2>${table(['Group','Items','Planning','Executing','Review','Finalize','Total','Slowest'],list.map(group=>`<tr><td>${escapeHtml(labelOf(group.name))}${group.count<3?' (few items)':''}</td><td>${group.count}</td>${group.phases.map(days=>`<td>${daysText(days)}</td>`).join('')}<td>${daysText(group.total)}</td><td>${escapeHtml(group.slowest)}</td></tr>`))}`:'';
  const html=`<p>Period: ${escapeHtml(TeamFlowDomain.formatRange({start:period.from,end:period.to}))}</p><p><strong>${escapeHtml(performanceSummaryText(teamPerformance))}</strong></p><p>${escapeHtml(performanceCoverageText(current))}</p>${current.analyzed<5?`<p>${PERFORMANCE_CAUTION}</p>`:''}
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">${performanceKpis(teamPerformance).map(([name,value,before])=>`<div class="stat"><div class="stat-val">${value}</div><div class="stat-label">${name}${before!=null?`<br>Previous: ${before}`:''}</div></div>`).join('')}</div>
    ${current.analyzed?`<h2>Average time per phase</h2>${table(['Phase','Average','Share'],current.phases.map(phase=>`<tr><td>${escapeHtml(phase.name)}</td><td>${daysText(phase.days)}</td><td>${percentText(phase.share)}</td></tr>`))}`:''}
    ${groups('By work type',current.breakdowns.workType,workTypeLabel)}${groups('By priority',current.breakdowns.priority)}${groups('By tag',current.breakdowns.tag)}
    ${current.longestWaits.length?`<h2>Longest review waits</h2>${table(['Work','Average wait','Rounds'],current.longestWaits.map(item=>`<tr><td>${escapeHtml(item.title)}</td><td>${daysText(item.days)}</td><td>${item.rounds}</td></tr>`))}`:''}
    ${current.slowest.length?`<h2>Longest-running items</h2>${table(['Work','Planning','Executing','Review','Finalize','Total'],current.slowest.map(item=>`<tr><td>${escapeHtml(item.title)}</td>${item.phases.map(days=>`<td>${daysText(days)}</td>`).join('')}<td>${daysText(item.days)}</td></tr>`))}`:''}
    <p>Indicative only: figures come from when work was moved in TeamFlow, not from time actually spent.</p>`;
  exportToPDF(`Team Performance — ${label}`,html);
}
function renderAudit(){
  const tabs=[['weekly','Weekly Report'],['monthly','Monthly Report'],['annual','Annual Report'],...(canSeeBottlenecks()?[['bottlenecks','Performance']]:[])];
  const renderers={weekly:renderWeeklyAudit,monthly:renderMonthlyAudit,annual:renderAnnualAudit,bottlenecks:renderBottleneckAudit};
  if(selectedAuditTab==='bottlenecks'&&!canSeeBottlenecks())selectedAuditTab='weekly';
  document.getElementById('content').innerHTML=`<div class="tabs" role="tablist" aria-label="Report period">${tabs.map(([id,label])=>`<div class="tab ${selectedAuditTab===id?'active':''}" role="tab" tabindex="0" aria-selected="${selectedAuditTab===id}" onclick="switchAuditTab('${id}',this)">${label}</div>`).join('')}</div><div id="audit-content">${renderers[selectedAuditTab]()}</div>`;
}
function switchAuditTab(tab,el){
  const renderers={weekly:renderWeeklyAudit,monthly:renderMonthlyAudit,annual:renderAnnualAudit,bottlenecks:renderBottleneckAudit};
  if(!renderers[tab])return;
  selectedAuditTab=tab;
  document.querySelectorAll('.tab').forEach(item=>{item.classList.remove('active');item.setAttribute('aria-selected','false');});
  el.classList.add('active');el.setAttribute('aria-selected','true');
  const target=document.getElementById('audit-content');if(target)target.innerHTML=renderers[tab]();
}
function annualReportRange(){return TeamFlowDomain.yearRange(Number(todayStr.slice(0,4))+reportYearOffset);}
function moveReportYear(offset){reportYearOffset+=offset;const target=document.getElementById('audit-content');if(target)target.innerHTML=renderAnnualAudit();}
function reportNav(range,label,previous,next){return`<div class="report-period-controls"><button type="button" class="btn btn-ghost report-period-nav" aria-label="Previous ${label.toLowerCase()}" onclick="${previous}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 5-7 7 7 7"/></svg></button><strong class="report-period-label">${TeamFlowDomain.formatRange(range)}</strong><button type="button" class="btn btn-ghost report-period-nav" aria-label="Next ${label.toLowerCase()}" onclick="${next}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button></div>`;}
function moveReportWeek(offset){reportWeekOffset+=offset;const target=document.getElementById('audit-content');if(target)target.innerHTML=renderWeeklyAudit();}
function moveReportMonth(offset){reportMonthOffset+=offset;const target=document.getElementById('audit-content');if(target)target.innerHTML=renderMonthlyAudit();}
function reportRate(completed){const eligible=completed.filter(work=>work.completedDate&&work.deadline);const onTime=eligible.filter(work=>work.completedDate<=work.deadline);const late=eligible.filter(work=>work.completedDate>work.deadline);return{eligible,onTime,late,pct:eligible.length?Math.round(onTime.length/eligible.length*100):0};}
function reportOngoingWorks(range) {
  return works.filter(work => TeamFlowDomain.reportOngoing(work, range))
    .sort((a, b) => String(a.deadline || '9999-12-31').localeCompare(String(b.deadline || '9999-12-31')) || String(a.title).localeCompare(String(b.title)));
}
function reportDeadlineChip(work,range){
  if(!work.deadline)return '';
  const deadline=TeamFlowDomain.parseDateKey(work.deadline),end=TeamFlowDomain.parseDateKey(TeamFlowDomain.reportAsOf(range,todayStr));
  if(!deadline||!end)return '';
  const days=Math.round((deadline-end)/86400000);
  const label=days<0?`${Math.abs(days)}d overdue`:days===0?'Due today':`${days}d left`;
  return `<span class="badge ${days<0?'badge-overdue':days<=3?'badge-review':'badge-done'}">${label}</span>`;
}
// Effort comparison only uses completed work that has actual hours recorded, so missing entries don't skew the variance.
function formatHours(value){return `${Math.round(Number(value||0)*10)/10} h`;}
function effortSummary(done){
  const recorded=done.filter(work=>work.actualHours!=null&&Number.isFinite(Number(work.actualHours)));
  const estimated=recorded.reduce((sum,work)=>sum+Number(work.estimatedHours||0),0),actual=recorded.reduce((sum,work)=>sum+Number(work.actualHours),0);
  return{recorded:recorded.length,total:done.length,estimated,actual,variance:estimated?Math.round((actual-estimated)/estimated*100):null};
}
function effortVarianceText(summary){return summary.variance==null?'':`${summary.variance>0?'+':''}${summary.variance}% vs estimate`;}
function effortSummaryHtml(done){
  const summary=effortSummary(done);
  if(!summary.total)return'';
  if(!summary.recorded)return'<span class="report-effort">No actual hours recorded</span>';
  const color=summary.variance==null?'var(--text3)':summary.variance>10?'var(--red)':summary.variance<-10?'var(--green)':'var(--text2)';
  return`<span class="report-effort" title="Totals for ${summary.recorded} of ${summary.total} completed items with actual hours"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> Actual ${formatHours(summary.actual)} · Estimated ${formatHours(summary.estimated)}${summary.variance==null?'':` · <strong style="color:${color};">${effortVarianceText(summary)}</strong>`}</span>`;
}
function workEffortHtml(work){return work.actualHours!=null?`<span class="report-work-effort" title="Actual / estimated hours"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> ${formatHours(work.actualHours).replace(' h','')} / ${formatHours(work.estimatedHours)}</span>`:`<span class="report-work-effort" title="Estimated hours"><svg class="ui-icon" aria-hidden="true"><use href="#i-clock"/></svg> ${formatHours(work.estimatedHours)} est.</span>`;}
function effortSummaryText(done){
  const summary=effortSummary(done);
  if(!summary.total)return'';
  if(!summary.recorded)return'<p>Effort: no actual hours recorded for completed work in this period.</p>';
  return`<p>Effort for ${summary.recorded} of ${summary.total} completed items with actual hours: actual ${formatHours(summary.actual)}, estimated ${formatHours(summary.estimated)}${summary.variance==null?'':` (${effortVarianceText(summary)})`}.</p>`;
}
function effortCells(work){return`<td>${formatHours(work.estimatedHours)}</td><td>${work.actualHours!=null?formatHours(work.actualHours):'—'}</td>`;}
function memberActualHours(member,completed){return completed.reduce((sum,work)=>work.actualHours!=null?sum+(TeamFlowDomain.allocateEffortByMember(work,TEAM,work.actualHours)[String(member.id)]||0):sum,0);}
function renderReportOngoing(ongoing, range, exportAction) {
  const rows = ongoing.map(work => {
    const historical=work.status!=='ongoing';
    const phase=historical?'Completed':PHASES[Number(work.phase)]||PHASES[0];
    return `<div class="digest-row report-work-row" role="button" tabindex="0" onclick="openWorkDetail(${Number(work.id)})"><div class="report-work-main"><span class="badge badge-${historical?'done':phase.toLowerCase()}">${historical?'Completed '+fmt(work.completedDate):escapeHtml(phase)}</span><span class="report-work-title">${escapeHtml(work.title)}</span></div><span class="report-work-progress">${historical?'100% progress':phaseProgress(work)+'% progress'}</span>${assigneesHtml(work.assignees || [])}<span class="report-work-deadline">${work.deadline ? `Due ${fmt(work.deadline)} · ${historical?'':reportDeadlineChip(work,range)}` : 'No deadline'}</span></div>`;
  }).join('');
  return `<div class="card" style="margin-bottom:16px;"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-sync"/></svg> Ongoing Work (${ongoing.length})</div></div>${rows || '<div class="empty-state"><p>No ongoing work in this period.</p></div>'}</div>`;
}
function reportOngoingTable(ongoing, range) {
  const rows = ongoing.map(work => `<tr><td>${escapeHtml(work.title)}</td><td>${work.status==='done'?'Completed '+escapeHtml(fmt(work.completedDate)):escapeHtml(PHASES[Number(work.phase)]||PHASES[0])}</td><td>${work.status==='done'?'100%':phaseProgress(work)+'%'}</td><td>${work.deadline ? fmt(work.deadline) : 'No deadline'}</td><td>${(work.assignees || []).map(id => escapeHtml(getMember(id)?.name || '')).filter(Boolean).join(', ') || 'Unassigned'}</td></tr>`).join('');
  return `<h2>Ongoing work (${ongoing.length})</h2><table><thead><tr><th>Work</th><th>Phase</th><th>Progress</th><th>Deadline</th><th>Assignees</th></tr></thead><tbody>${rows || '<tr><td colspan="5">No ongoing work in this period.</td></tr>'}</tbody></table>`;
}
function renderWeeklyAudit(){
  const range=TeamFlowDomain.weekRange(todayStr,reportWeekOffset),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done),color=rate.pct>=80?'var(--green)':rate.pct>=60?'var(--yellow)':'var(--red)';
  const rows=done.slice().sort((a,b)=>String(b.completedDate).localeCompare(String(a.completedDate))).map(work=>`<div class="digest-row" role="button" tabindex="0" onclick="openWorkDetail(${Number(work.id)})"><span class="badge ${rate.late.includes(work)?'badge-overdue':work.deadline?'badge-done':'badge-upcoming'}">${!work.deadline?'No deadline':rate.late.includes(work)?'Late':'On time'}</span><span style="flex:1;min-width:0;font-size:13px;">${escapeHtml(work.title)}</span>${assigneesHtml(work.assignees||[])}${workEffortHtml(work)}${reviewSignOffHtml(work)}<span style="font-size:12px;color:var(--text3);">Completed ${fmt(work.completedDate)}</span></div>`).join('');
  return`<div class="report-header"><div><div class="report-title-row"><div style="font-size:16px;font-weight:700;"><svg class="ui-icon" aria-hidden="true"><use href="#i-chart"/></svg> Weekly Report</div>${reportNav(range,'Monday–Sunday','moveReportWeek(-1)','moveReportWeek(1)')}<button type="button" class="btn btn-ghost btn-sm" onclick="exportWeeklyReportPDF()"><svg class="ui-icon" aria-hidden="true"><use href="#i-file"/></svg> Export PDF</button></div></div><div class="report-kpi-grid"><div class="report-kpi"><div class="report-kpi-val">${done.length}</div><div class="report-kpi-label">Completed</div></div><div class="report-kpi"><div class="report-kpi-val">${ongoing.length}</div><div class="report-kpi-label">Ongoing</div></div><div class="report-kpi"><div class="report-kpi-val"${rate.late.length?' style="color:var(--red);"':''}>${rate.late.length}</div><div class="report-kpi-label">Late</div></div><div class="report-kpi"><div class="report-kpi-val"${rate.pct<60?' style="color:var(--red);"':''}>${rate.pct}%</div><div class="report-kpi-label">On-time rate</div></div></div></div>${renderReportOngoing(ongoing,range,'exportWeeklyReportPDF')}<div class="card" style="margin-bottom:16px;"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Completed Work (${done.length})</div>${effortSummaryHtml(done)}</div>${rows||'<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-inbox"/></svg></div><p>No work completed in this week.</p></div>'}</div>`;
}
function sortedCompletedWorks(done){return done.slice().sort((a,b)=>String(b.completedDate).localeCompare(String(a.completedDate))||String(a.title).localeCompare(String(b.title)));}
function latestApproval(work){return (work.reviews||[]).filter(review=>review.decision==='approved').pop()||null;}
function reviewSignOffText(work){
  const review=latestApproval(work);
  if(!review)return'—';
  const sentBack=(work.reviews||[]).filter(item=>item.decision==='sent_back').length;
  return`Approved by ${review.actorName}${review.selfReview?' (PIC self-review)':''}, ${fmt(review.date)}${review.comment?`: ${review.comment}`:''}${sentBack?` · Sent back ${sentBack}x`:''}`;
}
function reviewSignOffHtml(work){
  const review=latestApproval(work);
  if(!review)return'';
  return`<span class="report-work-effort" title="${escapeHtml(reviewSignOffText(work))}">${review?`<svg class="ui-icon" aria-hidden="true"><use href="#i-check"/></svg> ${escapeHtml(review.actorName)}${review.selfReview?' · self-review':''}`:''}</span>`;
}
function reportCompletionLabel(work,rate){return !work.deadline?'No deadline':rate.late.includes(work)?'Late':'On time';}
function renderReportCompleted(done,rate){
  const rows=sortedCompletedWorks(done).map(work=>`<div class="digest-row" role="button" tabindex="0" onclick="openWorkDetail(${Number(work.id)})"><span class="badge ${rate.late.includes(work)?'badge-overdue':work.deadline?'badge-done':'badge-upcoming'}">${reportCompletionLabel(work,rate)}</span><span style="flex:1;min-width:0;overflow-wrap:anywhere;">${escapeHtml(work.title)}</span>${assigneesHtml(work.assignees||[])}${workEffortHtml(work)}${reviewSignOffHtml(work)}<span style="font-size:12px;color:var(--text3);">Completed ${fmt(work.completedDate)}</span></div>`).join('');
  return `<div class="card" style="margin-bottom:16px;"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Completed Work (${done.length})</div>${effortSummaryHtml(done)}</div>${rows||'<div class="empty-state"><p>No work completed in this month.</p></div>'}</div>`;
}
function reportCompletedTable(done,rate){
  const rows=sortedCompletedWorks(done).map(work=>`<tr><td>${escapeHtml(work.title)}</td><td>${escapeHtml(work.priority||'')}</td><td>${(work.assignees||[]).map(id=>escapeHtml(getMember(id)?.name||'')).filter(Boolean).join(', ')||'Unassigned'}</td><td>${work.deadline?fmt(work.deadline):'No deadline'}</td><td>${fmt(work.completedDate)}</td>${effortCells(work)}<td>${reportCompletionLabel(work,rate)}</td><td>${escapeHtml(reviewSignOffText(work))}</td></tr>`).join('');
  return `<h2>Completed work (${done.length})</h2>${effortSummaryText(done)}<table><thead><tr><th>Work</th><th>Priority</th><th>Assignees</th><th>Deadline</th><th>Completed</th><th>Est. hours</th><th>Actual hours</th><th>Status</th><th>Review sign-off</th></tr></thead><tbody>${rows||'<tr><td colspan="9">No work completed in this month.</td></tr>'}</tbody></table>`;
}
function renderMonthlyAudit(){
  const month=TeamFlowDomain.shiftMonth(new Date(`${todayStr}T00:00:00Z`).getUTCFullYear(),new Date(`${todayStr}T00:00:00Z`).getUTCMonth(),reportMonthOffset),range=TeamFlowDomain.monthRange(month.year,month.month),periodWorks=works.filter(work=>TeamFlowDomain.reportInMonth(work,range)),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done),color=rate.pct>=80?'var(--green)':rate.pct>=60?'var(--yellow)':'var(--red)';
  const priorities=PRIORITIES.map(priority=>{const count=periodWorks.filter(work=>work.priority===priority).length,pct=periodWorks.length?Math.round(count/periodWorks.length*100):0,color=priority==='High'?'var(--red)':priority==='Medium'?'var(--yellow)':'var(--green)';return`<div style="margin-bottom:12px;"><div style="display:flex;justify-content:space-between;"><span>${priority} priority</span><strong>${count}</strong></div><div class="perf-bar"><div class="perf-bar-fill" style="width:${pct}%;background:${color};"></div></div></div>`;}).join('');
  const tagCounts={};periodWorks.forEach(work=>(work.tags||[]).forEach(tag=>tagCounts[tag]=(tagCounts[tag]||0)+1));
  const tags=Object.entries(tagCounts).sort((a,b)=>b[1]-a[1]).map(([tag,count])=>`<div class="report-tag-item"><span>${escapeHtml(tag)}</span><strong>${count}</strong></div>`).join('')||'<div style="font-size:12px;color:var(--text3);">No tagged work in this period.</div>';
  return`<div class="report-header"><div><div class="report-title-row"><div style="font-size:16px;font-weight:700;"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> Monthly Report</div>${reportNav(range,'Month','moveReportMonth(-1)','moveReportMonth(1)')}<button type="button" class="btn btn-ghost btn-sm" onclick="exportMonthlyReportPDF()"><svg class="ui-icon" aria-hidden="true"><use href="#i-file"/></svg> Export PDF</button></div></div><div class="report-kpi-grid"><div class="report-kpi"><div class="report-kpi-val">${periodWorks.length}</div><div class="report-kpi-label">Work in period</div></div><div class="report-kpi"><div class="report-kpi-val">${done.length}</div><div class="report-kpi-label">Completed</div></div><div class="report-kpi"><div class="report-kpi-val">${ongoing.length}</div><div class="report-kpi-label">Ongoing</div></div><div class="report-kpi"><div class="report-kpi-val"${rate.pct<60?' style="color:var(--red);"':''}>${rate.pct}%</div><div class="report-kpi-label">On-time rate</div></div></div></div>${renderReportOngoing(ongoing,range,'exportMonthlyReportPDF')}${renderReportCompleted(done,rate)}<div class="grid-2"><div class="card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-chart"/></svg> Work by Priority</div></div>${priorities}</div><div class="card report-tag-card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-tag"/></svg> Work by Tag</div></div><div class="report-tag-grid">${tags}</div></div></div>`;
}
function renderAnnualAudit(){
  const range=annualReportRange(),periodWorks=works.filter(work=>TeamFlowDomain.reportInMonth(work,range)),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done),color=rate.pct>=80?'var(--green)':rate.pct>=60?'var(--yellow)':'var(--red)';
  const priorities=PRIORITIES.map(priority=>{const count=periodWorks.filter(work=>work.priority===priority).length,pct=periodWorks.length?Math.round(count/periodWorks.length*100):0,color=priority==='High'?'var(--red)':priority==='Medium'?'var(--yellow)':'var(--green)';return`<div style="margin-bottom:12px;"><div style="display:flex;justify-content:space-between;"><span>${priority} priority</span><strong>${count}</strong></div><div class="perf-bar"><div class="perf-bar-fill" style="width:${pct}%;background:${color};"></div></div></div>`;}).join('');
  const tagCounts={};periodWorks.forEach(work=>(work.tags||[]).forEach(tag=>tagCounts[tag]=(tagCounts[tag]||0)+1));
  const tags=Object.entries(tagCounts).sort((a,b)=>b[1]-a[1]).map(([tag,count])=>`<div class="report-tag-item"><span>${escapeHtml(tag)}</span><strong>${count}</strong></div>`).join('')||'<div style="font-size:12px;color:var(--text3);">No tagged work in this period.</div>';
  return`<div class="report-header"><div><div class="report-title-row"><div style="font-size:16px;font-weight:700;"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> Annual Report</div>${reportNav(range,'Year','moveReportYear(-1)','moveReportYear(1)')}<button type="button" class="btn btn-ghost btn-sm" onclick="exportAnnualReportPDF()"><svg class="ui-icon" aria-hidden="true"><use href="#i-file"/></svg> Export PDF</button></div></div><div class="report-kpi-grid"><div class="report-kpi"><div class="report-kpi-val">${periodWorks.length}</div><div class="report-kpi-label">Work in period</div></div><div class="report-kpi"><div class="report-kpi-val">${done.length}</div><div class="report-kpi-label">Completed</div></div><div class="report-kpi"><div class="report-kpi-val">${ongoing.length}</div><div class="report-kpi-label">Ongoing</div></div><div class="report-kpi"><div class="report-kpi-val"${rate.pct<60?' style="color:var(--red);"':''}>${rate.pct}%</div><div class="report-kpi-label">On-time rate</div></div></div></div>${renderReportOngoing(ongoing,range,'exportAnnualReportPDF')}<div class="grid-2"><div class="card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-chart"/></svg> Work by Priority</div></div>${priorities}</div><div class="card report-tag-card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-tag"/></svg> Work by Tag</div></div><div class="report-tag-grid">${tags}</div></div></div><div class="card" style="margin-top:16px;"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Completed this year (${done.length})</div>${effortSummaryHtml(done)}</div>${done.map(work=>`<div class="digest-row" role="button" tabindex="0" onclick="openWorkDetail(${Number(work.id)})"><span class="badge ${rate.late.includes(work)?'badge-overdue':work.deadline?'badge-done':'badge-upcoming'}">${!work.deadline?'No deadline':rate.late.includes(work)?'Late':'On time'}</span><span style="flex:1;">${escapeHtml(work.title)}</span>${workEffortHtml(work)}<span style="font-size:12px;color:var(--text3);">${fmt(work.completedDate)}</span></div>`).join('')||'<div class="empty-state"><p>No work completed in this year.</p></div>'}</div>${renderMemberPerf(range)}`;
}
function renderMemberPerf(range=annualReportRange()){
  return`<div class="card" style="margin-top:16px;"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-users"/></svg> Member Performance · ${range.start.slice(0,4)}</div></div>${TEAM.filter(member=>['member','manager'].includes(member.role)).map(member=>{const assigned=works.filter(work=>((work.assignees||[]).some(id=>String(id)===String(member.id))||String(work.pic)===String(member.id))&&TeamFlowDomain.reportInMonth(work,range)),completed=assigned.filter(work=>TeamFlowDomain.reportCompletion(work,range)),rate=reportRate(completed),color=rate.pct>=80?'var(--green)':rate.pct>=60?'var(--yellow)':'var(--red)',ongoing=assigned.filter(work=>TeamFlowDomain.reportOngoing(work,range));return`<div class="member-perf-row">${avatarHtml(member,40)}<div style="flex:1;min-width:0;"><div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;"><span style="font-size:13px;font-weight:700;">${escapeHtml(member.name)}</span>${roleBadge(member.role)}</div><div style="display:flex;gap:16px;margin-bottom:6px;flex-wrap:wrap;"><span style="font-size:12px;color:var(--text3);"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg> ${assigned.length} assigned</span><span style="font-size:12px;color:var(--green);"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> ${completed.length} done</span><span style="font-size:12px;color:var(--primary-light);"><svg class="ui-icon" aria-hidden="true"><use href="#i-sync"/></svg> ${ongoing.length} ongoing</span><span style="font-size:12px;color:var(--text2);" title="This person's share of actual hours on completed work"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> ${formatHours(memberActualHours(member,completed))} actual</span></div><div style="display:flex;align-items:center;gap:10px;"><div class="perf-bar" style="flex:1;"><div class="perf-bar-fill" style="width:${rate.pct}%;background:${color};"></div></div><span style="font-size:13px;font-weight:700;color:${color};min-width:40px;">${rate.eligible.length?rate.pct+'%':'N/A'}</span></div><div style="font-size:11px;color:var(--text3);margin-top:2px;">On-time delivery rate</div></div></div>`;}).join('')}</div>`;
}
function renderTeam(){let html=`<div class="team-layout"><div class="team-grid">`;membersInRoleOrder().filter(m=>m.role!=='admin').forEach(m=>{const assigned=works.filter(w=>w.assignees.includes(m.id)&&w.status==='ongoing').sort((a,b)=>String(a.deadline||'9999').localeCompare(String(b.deadline||'9999'))),done=works.filter(w=>w.assignees.includes(m.id)&&w.status==='done');html+=`<div class="card team-card is-clickable" role="button" tabindex="0" aria-label="Open ${escapeHtml(m.name)}’s profile" onclick="if(!event.target.closest('.team-more-btn'))openMemberProfile(${Number(m.id)})" onkeydown="if((event.key==='Enter'||event.key===' ')&&event.target===this){event.preventDefault();openMemberProfile(${Number(m.id)});}"><div class="team-member-header"><span class="presence-wrap">${avatarHtml(m,48)}<i class="presence-dot" data-presence="${m.id}"></i></span><div class="team-member-identity"><div class="team-member-name-row"><div class="team-member-name">${escapeHtml(m.name)}</div>${roleBadge(m.role)}</div><div class="team-member-seen" data-seen="${m.id}"></div></div></div><div class="team-card-stats" style="margin-bottom:14px;"><div style="text-align:center;padding:10px;background:var(--bg3);border-radius:8px;"><div style="font-size:22px;font-weight:700;color:var(--primary-light);">${assigned.length}</div><div style="font-size:11px;color:var(--text3);">Ongoing</div></div><div style="text-align:center;padding:10px;background:var(--bg3);border-radius:8px;"><div style="font-size:22px;font-weight:700;color:var(--green);">${done.length}</div><div style="font-size:11px;color:var(--text3);">Completed</div></div></div><div style="font-size:12px;color:var(--text3);margin-bottom:6px;font-weight:700;">CURRENT PROJECTS</div>${assigned.length?assigned.map((w,i)=>(i===4?`<div class="team-more" hidden>`:'')+`<div style="font-size:12px;padding:5px 0;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:6px;"><span class="badge badge-${PHASES[w.phase].toLowerCase()}" style="font-size:11px;padding:2px 6px;">${PHASES[w.phase]}</span><span class="team-project-title">${escapeHtml(w.title)}</span></div>`).join('')+(assigned.length>4?`</div><button type="button" class="team-more-btn" onclick="toggleTeamMore(this,${assigned.length-4})">+${assigned.length-4} more</button>`:''):'<div style="font-size:12px;color:var(--text3);">No active projects</div>'}</div>`;});html+=`</div></div>`;document.getElementById('content').innerHTML=html;paintPresence();if(!teamPresence)checkWorkspaceRevision().catch(()=>{});}
function toggleTeamMore(button,count){const more=button.previousElementSibling,open=more.hidden;more.hidden=!open;button.textContent=open?'Show less':`+${count} more`;}

// ============================================================

// Member profile: who they are, what they carry now, how recent work went, and when they are away.
function openMemberProfile(id){
  const m=TEAM.find(x=>String(x.id)===String(id));if(!m)return;
  const mine=works.filter(w=>(w.assignees||[]).includes(m.id));
  const ongoing=mine.filter(w=>w.status==='ongoing').sort((a,b)=>String(a.deadline||'9999').localeCompare(String(b.deadline||'9999')));
  const upcoming=mine.filter(w=>w.status==='upcoming').sort((a,b)=>String(a.startDate||'').localeCompare(String(b.startDate||'')));
  const since=TeamFlowDomain.addDays(todayStr,-365);
  const done=mine.filter(w=>w.status==='done'&&w.completedDate).sort((a,b)=>String(b.completedDate).localeCompare(String(a.completedDate)));
  const recent=done.filter(w=>w.completedDate>since&&w.deadline),onTime=recent.filter(w=>w.completedDate<=w.deadline).length;
  const rate=recent.length?Math.round(onTime/recent.length*100)+'%':'—';
  const overdue=ongoing.filter(w=>w.deadline&&w.deadline<todayStr).length;
  const asPic=ongoing.filter(w=>String(w.pic)===String(m.id)).length;
  const leave=(typeof absences!=='undefined'?absences:[]).filter(a=>a.type==='leave'&&String(a.memberId)===String(m.id)&&a.endDate>=todayStr).sort((a,b)=>a.startDate.localeCompare(b.startDate));
  // Upcoming work may not have a phase yet and completed work sits past the last phase.
  const phaseTag=w=>{const name=w.status==='done'?'Done':PHASES[w.phase]||PHASES[0];return`<span class="badge badge-${name.toLowerCase()}">${name}</span>`;};
  const row=(w,extra)=>`<button type="button" class="mp-row" onclick="openWorkDetail(${Number(w.id)})">${phaseTag(w)}<span class="mp-row-title">${escapeHtml(w.title)}</span>${String(w.pic)===String(m.id)?'<em class="mp-pic">PIC</em>':''}<small>${extra}</small></button>`;
  const section=(title,body)=>`<div class="mp-section"><h3>${title}</h3>${body}</div>`;
  const stat=(value,label,tone)=>`<div class="mp-stat"><strong${tone?` class="${tone}"`:''}>${value}</strong><span>${label}</span></div>`;
  const body=`<div class="mp-head"><span class="presence-wrap">${avatarHtml(m,56)}<i class="presence-dot" data-presence="${m.id}"></i></span><div><div class="mp-name">${escapeHtml(m.name)} ${roleBadge(m.role)}</div><div class="team-member-seen" data-seen="${m.id}"></div>${m.email?`<a class="mp-email" href="mailto:${escapeHtml(m.email)}">${escapeHtml(m.email)}</a>`:''}</div></div>
    <div class="mp-stats">${stat(ongoing.length,'Ongoing')}${stat(asPic,'As PIC')}${stat(overdue,'Overdue',overdue?'is-red':'')}${stat(rate,'On time · 12 months')}</div>
    ${section('Current work',ongoing.length?ongoing.map(w=>row(w,w.deadline?(w.deadline<todayStr?`<b class="is-red">Overdue · ${fmt(w.deadline)}</b>`:'Due '+fmt(w.deadline)):'')).join(''):'<p class="mp-empty">No ongoing work.</p>')}
    ${upcoming.length?section('Starting soon',upcoming.slice(0,5).map(w=>row(w,'Starts '+fmt(w.startDate))).join('')):''}
    ${section('Leave',leave.length?leave.map(a=>`<div class="mp-leave">${fmt(a.startDate)}${a.endDate!==a.startDate?' – '+fmt(a.endDate):''}${a.label?` · ${escapeHtml(a.label)}`:''}</div>`).join(''):'<p class="mp-empty">No upcoming leave.</p>')}
    ${section('Recently completed',done.length?done.slice(0,5).map(w=>row(w,w.completedDate<=w.deadline?'On time · '+fmt(w.completedDate):`<b class="is-red">Late · ${fmt(w.completedDate)}</b>`)).join(''):'<p class="mp-empty">Nothing completed yet.</p>')}`;
  const modalBody=document.getElementById('modal-body');delete modalBody.dataset.detailWorkId;delete modalBody.dataset.detailMeetingId;
  document.getElementById('modal-title').textContent='Team member';
  modalBody.innerHTML=body;
  document.getElementById('modal-footer').innerHTML='<button class="btn btn-ghost" onclick="closeModal()">Close</button>';
  document.getElementById('modal-overlay').style.display='flex';
  document.getElementById('modal-body').scrollTop=0;
  paintPresence();
}
