'use strict';
// Meetings are their own records with an optional link to work, so they survive when linked work is completed or deleted.
let meetings=[],meetingsTab='upcoming',pendingMeetingId=null;
const meetingPages={upcoming:1,past:1},MEETING_PAGE_SIZE=10;
const dismissedMeetingBanners=new Set();
const MEETING_DURATIONS=[15,30,45,60,90,120,180,240];

function setMeetings(items){
  const next=Array.isArray(items)?items:[],changed=JSON.stringify(next)!==JSON.stringify(meetings);
  meetings=next;
  updateMeetingBanner();
  if(!changed||!currentUser)return;
  if(currentPage==='meetings')renderMeetingsList();
  const today=document.getElementById('today-meetings');if(today)today.outerHTML=todayMeetingsHtml();
}
async function loadMeetings(){
  try{const result=await apiGet('meetings');setMeetings(result.items);}catch{}
}
function replaceMeeting(saved){
  const exists=meetings.some(item=>item.id===saved.id);
  setMeetings(exists?meetings.map(item=>item.id===saved.id?saved:item):[...meetings,saved]);
}
const meetingAttendeeIds=meeting=>[...new Set([meeting.organizerId,...(meeting.attendees||[])].filter(id=>id!=null).map(String))];
const isMyMeeting=meeting=>Boolean(currentUser)&&meetingAttendeeIds(meeting).includes(String(currentUser.id));
const canManageMeeting=meeting=>Boolean(currentUser)&&(currentUser.role==='admin'||String(meeting.organizerId)===String(currentUser.id));
const canCreateMeeting=()=>Boolean(currentUser)&&['admin','manager','member'].includes(currentUser.role);
const meetingEndMs=meeting=>Date.parse(meeting.startsAt)+Number(meeting.durationMinutes||0)*60000;
const meetingIsPast=meeting=>meeting.status==='cancelled'||meetingEndMs(meeting)<Date.now();
function meetingEndTime(meeting){
  const [hour,minute]=String(meeting.startTime).split(':').map(Number),total=(hour*60+minute+Number(meeting.durationMinutes||0))%1440;
  return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
}
function meetingDayLabel(date){
  const today=TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE);
  if(date===today)return'Today';
  if(date===TeamFlowDomain.addDays(today,1))return'Tomorrow';
  return new Intl.DateTimeFormat('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}).format(TeamFlowDomain.parseDateKey(date));
}
function meetingStartHint(meeting){
  if(meeting.status==='cancelled')return'<span style="color:var(--red);font-weight:600;">Cancelled</span>';
  const minutes=Math.round((Date.parse(meeting.startsAt)-Date.now())/60000);
  if(minutes<=0&&meetingEndMs(meeting)>=Date.now())return'<span style="color:var(--red);font-weight:600;">Happening now</span>';
  return minutes>0&&minutes<60?`<span style="color:var(--primary);font-weight:600;">In ${minutes} min</span>`:'';
}
// Same tile layout as Today's Meetings on the dashboard, with the fuller details a list needs.
function meetingRowHtml(meeting,{showDay=false}={}){
  const cancelled=meeting.status==='cancelled',linked=(meeting.linkedWorkIds||[]).map(id=>works.find(work=>work.id===id)).filter(Boolean);
  const people=meetingAttendeeIds(meeting).map(value=>TEAM.find(member=>String(member.id)===value)).filter(Boolean);
  const day=new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',timeZone:'UTC'}).format(TeamFlowDomain.parseDateKey(meeting.date));
  const tile=showDay?`<strong>${escapeHtml(day)}</strong><span>${escapeHtml(meeting.startTime)}</span>`:`<strong>${escapeHtml(meeting.startTime)}</strong><span>${Number(meeting.durationMinutes)} min</span>`;
  const when=[meetingStartHint(meeting),meeting.location?escapeHtml(meeting.location):'',`Until ${escapeHtml(meetingEndTime(meeting))}`,`Organized by ${escapeHtml(meeting.organizerName||'')}`].filter(Boolean).join(' · ');
  const link=linked.length===1?`Linked: ${escapeHtml(linked[0].title)}`:linked.length?`Linked: ${linked.length} work items`:'';
  const extra=[`${meetingAttendeeIds(meeting).length} attendee${meetingAttendeeIds(meeting).length===1?'':'s'}`,link,meeting.minutes?'Has minutes':'',(meeting.files||[]).length?`${meeting.files.length} file${meeting.files.length===1?'':'s'}`:''].filter(Boolean).join(' · ');
  const extraPeople=people.length-4;
  return`<div class="focus-row" role="button" tabindex="0" onclick="openMeetingDetail(${Number(meeting.id)})"><div class="focus-tile ${cancelled?'':'meeting'}"><strong></strong></div><div class="focus-main"><div class="focus-title" style="${cancelled?'text-decoration:line-through;':''}">${escapeHtml(meeting.title)}</div><div class="focus-sub">${when}</div><div class="focus-sub">${extra}</div></div><div class="meeting-people">${assigneesHtml(people.slice(0,4).map(member=>member.id))}${extraPeople>0?`<span>+${extraPeople}</span>`:''}</div><svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></div>`.replace('<strong></strong>',tile);
}
function renderMeetings(){
  const c=document.getElementById('content');
  c.innerHTML=`<div class="tabs" role="tablist" aria-label="Meeting period">${[['upcoming','Upcoming'],['past','Past']].map(([id,label])=>`<div class="tab ${meetingsTab===id?'active':''}" role="tab" tabindex="0" aria-selected="${meetingsTab===id}" onclick="switchMeetingsTab('${id}')">${label}</div>`).join('')}</div><div id="meetings-list"></div>`;
  renderMeetingsList();
  loadMeetings();
}
function switchMeetingsTab(tab){meetingsTab=tab;renderMeetings();}
function meetingPagerHtml(tab,total){
  const totalPages=Math.max(1,Math.ceil(total/MEETING_PAGE_SIZE)),page=meetingPages[tab],start=(page-1)*MEETING_PAGE_SIZE;
  return`<nav class="history-pagination" aria-label="${tab==='past'?'Past':'Upcoming'} meeting pages"><span role="status">Showing ${start+1}–${Math.min(start+MEETING_PAGE_SIZE,total)} of ${total}</span><div class="history-page-controls"><button type="button" class="btn btn-ghost btn-sm" onclick="changeMeetingPage(${page-1})" ${page===1?'disabled':''} aria-label="Previous meeting page">Previous</button><span>Page ${page} of ${totalPages}</span><button type="button" class="btn btn-ghost btn-sm" onclick="changeMeetingPage(${page+1})" ${page===totalPages?'disabled':''} aria-label="Next meeting page">Next</button></div></nav>`;
}
function changeMeetingPage(page){
  meetingPages[meetingsTab]=Math.max(1,page);
  renderMeetingsList();
  document.getElementById('meetings-list')?.scrollIntoView({block:'start'});
}
function renderMeetingsList(){
  const target=document.getElementById('meetings-list');if(!target)return;
  const empty=text=>`<div class="card"><div class="empty-state" style="padding:32px 20px;"><p>${text}</p></div></div>`;
  const past=meetingsTab==='past';
  const list=meetings.filter(meeting=>meetingIsPast(meeting)===past).sort((a,b)=>past?String(b.startsAt).localeCompare(String(a.startsAt)):String(a.startsAt).localeCompare(String(b.startsAt)));
  if(!list.length){meetingPages[meetingsTab]=1;target.innerHTML=empty(past?'No past meetings yet.':'No meetings scheduled.');return;}
  // A meeting can move between tabs or be removed, so keep the page within range.
  meetingPages[meetingsTab]=Math.min(Math.max(1,Math.ceil(list.length/MEETING_PAGE_SIZE)),meetingPages[meetingsTab]);
  const start=(meetingPages[meetingsTab]-1)*MEETING_PAGE_SIZE,shown=list.slice(start,start+MEETING_PAGE_SIZE);
  const rows=past?shown.map(meeting=>meetingRowHtml(meeting,{showDay:true})).join(''):[...new Set(shown.map(meeting=>meeting.date))].map(day=>`<div class="meeting-day">${escapeHtml(meetingDayLabel(day))}</div>${shown.filter(meeting=>meeting.date===day).map(meeting=>meetingRowHtml(meeting)).join('')}`).join('');
  target.innerHTML=`<div class="card">${rows}${meetingPagerHtml(meetingsTab,list.length)}</div>`;
}
function meetingLocationHtml(location){
  const text=String(location||'');
  if(/^https?:\/\/\S+$/i.test(text))return`<a href="${escapeHtml(text)}" target="_blank" rel="noopener noreferrer">${escapeHtml(text)}</a>`;
  return escapeHtml(text);
}
function showMeetingModal(title,body,footer){
  const modalBody=document.getElementById('modal-body');
  delete modalBody.dataset.detailWorkId;
  document.getElementById('modal-title').textContent=title;
  modalBody.innerHTML=body;
  document.getElementById('modal-footer').innerHTML=footer;
  document.getElementById('modal-overlay').style.display='flex';
  document.querySelector('#modal-overlay .modal').scrollTop=0;
}
function openMeetingDetail(id){
  const meeting=meetings.find(item=>item.id===id);if(!meeting){showToast('That meeting is no longer available.','info');return;}
  const cancelled=meeting.status==='cancelled',canWrite=!cancelled&&currentUser.role!=='board'&&(currentUser.role==='admin'||isMyMeeting(meeting));
  const people=meetingAttendeeIds(meeting).map(value=>{const member=TEAM.find(row=>String(row.id)===value);return`<span style="display:inline-flex;align-items:center;gap:6px;font-size:13px;">${member?avatarHtml(member,22):''}${escapeHtml(member?.name||'Former member')}${value===String(meeting.organizerId)?' <span style="color:var(--text3);">(organizer)</span>':''}</span>`;}).join('');
  const linked=(meeting.linkedWorkIds||[]).map(workId=>works.find(work=>work.id===workId)).filter(Boolean);
  const when=`${meetingDayLabel(meeting.date)} · ${escapeHtml(meeting.startTime)} – ${escapeHtml(meetingEndTime(meeting))}`;
  const minutes=canWrite?`<textarea id="meeting-minutes" maxlength="10000" placeholder="What was discussed and decided..." style="margin-bottom:8px;">${escapeHtml(meeting.minutes||'')}</textarea><button type="button" class="btn btn-primary btn-sm" onclick="saveMeetingMinutes(${Number(id)})">Save Minutes</button>`:`<div style="font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere;color:${meeting.minutes?'var(--text)':'var(--text3)'};">${meeting.minutes?escapeHtml(meeting.minutes):'No minutes yet.'}</div>`;
  const body=`${cancelled?`<div class="meeting-notice">Cancelled by ${escapeHtml(meeting.cancelledBy||'the organizer')}.</div>`:''}
    <div class="detail-section"><div style="font-size:13px;font-weight:600;">${when}</div>${meeting.location?`<div style="font-size:13px;color:var(--text2);margin-top:4px;overflow-wrap:anywhere;">${meetingLocationHtml(meeting.location)}</div>`:''}</div>
    <div class="detail-section"><div class="detail-section-title">Attendees</div><div style="display:flex;flex-wrap:wrap;gap:8px 16px;">${people}</div></div>
    ${linked.length?`<div class="detail-section"><div class="detail-section-title">Linked Work</div>${linked.map(work=>`<div class="digest-row" role="button" tabindex="0" onclick="openWorkDetail(${Number(work.id)})"><span style="flex:1;min-width:0;overflow-wrap:anywhere;">${escapeHtml(work.title)}</span><svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></div>`).join('')}</div>`:''}
    <div class="detail-section"><div class="detail-section-title">Agenda</div><div style="font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere;color:${meeting.agenda?'var(--text)':'var(--text3)'};">${meeting.agenda?escapeHtml(meeting.agenda):'No agenda added.'}</div></div>
    <div class="detail-section"><div class="detail-section-title">Linked Files &amp; Folders</div>${(meeting.files||[]).map((file,index)=>linkedFileHtml(file,id,index,canWrite,`removeMeetingFile(${Number(id)},${Number(index)})`)).join('')||'<div style="font-size:13px;color:var(--text3);">No files linked yet.</div>'}${canWrite?`<button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="openAddMeetingFile(${Number(id)})">+ Add File / Folder Link</button>`:''}</div>
    <div class="detail-section"><div class="detail-section-title">Minutes</div>${minutes}${meeting.minutesBy?`<div style="font-size:11px;color:var(--text3);margin-top:6px;">Last saved by ${escapeHtml(meeting.minutesBy)}</div>`:''}</div>${meetingActionsHtml(meeting,canWrite)}`;
  let footer='';
  if(!cancelled&&!meetingIsPast(meeting))footer+=`<button type="button" class="btn btn-ghost" onclick="downloadMeetingCalendar(${Number(id)})">Add to Calendar</button>`;
  if(!cancelled&&canManageMeeting(meeting)){
    footer+=`<button type="button" class="btn btn-ghost" onclick="openMeetingForm(${Number(id)})"><svg class="ui-icon" aria-hidden="true"><use href="#i-pencil"/></svg> Edit</button>`;
    if(!meetingIsPast(meeting))footer+=`<button type="button" class="btn btn-danger" onclick="cancelMeeting(${Number(id)})">Cancel Meeting</button>`;
  }
  footer+='<button type="button" class="btn btn-ghost" onclick="closeModal()">Close</button>';
  showMeetingModal(meeting.title,body,footer);
  document.getElementById('modal-body').dataset.detailMeetingId=String(id);
}
function openMeetingForm(id=null,{workId=null}={}){
  if(!canCreateMeeting()){showToast('Your account cannot create meetings.','error');return;}
  const meeting=id==null?null:meetings.find(item=>item.id===id);
  if(id!=null&&!meeting)return;
  if(!meeting)pendingMeetingId=pendingMeetingId||newRecordId();
  const now=new Date(),nextHour=Math.min(23,Number(new Intl.DateTimeFormat('en-GB',{hour:'2-digit',hour12:false,timeZone:TEAM_TIME_ZONE}).format(now))+1);
  const src=meeting||{date:TeamFlowDomain.dateKeyInZone(now,TEAM_TIME_ZONE),startTime:`${String(nextHour).padStart(2,'0')}:00`,durationMinutes:60,attendees:[currentUser.id],linkedWorkIds:workId?[workId]:[]};
  const people=TEAM.filter(member=>member.active!==false||(src.attendees||[]).includes(member.id));
  const selected=member=>(src.attendees||[]).includes(member.id);
  const options=works.filter(work=>work.status!=='done'||(src.linkedWorkIds||[]).includes(work.id)).sort((a,b)=>String(a.title).localeCompare(String(b.title)));
  const durations=[...new Set([...MEETING_DURATIONS,Number(src.durationMinutes)])].sort((a,b)=>a-b);
  const body=`<div class="form-group"><label class="form-label" for="mf-title">Title</label><input id="mf-title" maxlength="200" value="${escapeHtml(src.title||'')}" placeholder="e.g. IFRS 17 results review"></div>
    <div class="form-group"><label class="form-label" for="mf-agenda">Agenda</label><textarea id="mf-agenda" maxlength="5000" placeholder="What the meeting will cover...">${escapeHtml(src.agenda||'')}</textarea></div>
    <div class="form-row"><div class="form-group"><label class="form-label" for="mf-date">Date</label><input id="mf-date" type="date" value="${escapeHtml(src.date)}"></div>
    <div class="form-group"><label class="form-label" for="mf-time">Start time (Jakarta GMT +7)</label><input id="mf-time" type="time" value="${escapeHtml(src.startTime)}"></div></div>
    <div class="form-row"><div class="form-group"><label class="form-label" for="mf-duration">Duration</label><select id="mf-duration">${durations.map(minutes=>`<option value="${minutes}" ${minutes===Number(src.durationMinutes)?'selected':''}>${minutes<60?minutes+' min':(minutes/60)+' h'}</option>`).join('')}</select></div>
    <div class="form-group"><label class="form-label" for="mf-location">Room or link</label><input id="mf-location" maxlength="300" value="${escapeHtml(src.location||'')}" placeholder="Room 3B or https://..."></div></div>
    <div class="form-group"><label class="form-label">Attendees</label><div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:6px;" id="member-chips" data-readonly="false">${people.map(member=>`<div class="member-chip ${selected(member)?'selected':''}" role="checkbox" aria-checked="${selected(member)}" tabindex="0" onclick="toggleMember(${Number(member.id)})" data-id="${Number(member.id)}">${avatarHtml(member,20)} ${escapeHtml(member.name)}</div>`).join('')}</div></div>
    <div class="form-group"><label class="form-label" for="mf-work-search">Linked work (optional)</label><input id="mf-work-search" type="search" placeholder="Search work..." autocomplete="off" oninput="filterMeetingWorks(this.value)" style="margin-bottom:8px;"><div class="meeting-work-list">${options.map(work=>`<label class="meeting-work-option"><input type="checkbox" class="mf-work" value="${Number(work.id)}" ${(src.linkedWorkIds||[]).includes(work.id)?'checked':''}> <span>${escapeHtml(work.title)}</span></label>`).join('')||'<span style="font-size:12px;color:var(--text3);">No open work to link.</span>'}<div id="mf-work-empty" style="display:none;font-size:12px;color:var(--text3);padding:4px 0;">No matching work.</div></div></div>`;
  const footer=`<button type="button" class="btn btn-primary" onclick="saveMeeting(${meeting?Number(id):'null'})">${meeting?'Save Changes':'Schedule Meeting'}</button><button type="button" class="btn btn-ghost" onclick="${meeting?`openMeetingDetail(${Number(id)})`:'closeModal()'}">Cancel</button>`;
  showMeetingModal(meeting?'Edit Meeting':'New Meeting',body,footer);
  document.getElementById('mf-title').focus();
}
// Ticked items stay visible while searching, so a selection is never hidden.
function filterMeetingWorks(value){
  const query=String(value||'').trim().toLowerCase();let shown=0;
  document.querySelectorAll('.meeting-work-option').forEach(option=>{
    const visible=!query||option.querySelector('input').checked||option.textContent.toLowerCase().includes(query);
    option.style.display=visible?'':'none';if(visible)shown+=1;
  });
  document.getElementById('mf-work-empty').style.display=shown?'none':'';
}
async function saveMeeting(id){
  const title=document.getElementById('mf-title').value.trim(),date=document.getElementById('mf-date').value,startTime=document.getElementById('mf-time').value;
  if(!title){showToast('Meeting title is required.','error');return;}
  if(!date||!startTime){showToast('Choose a date and start time.','error');return;}
  const attendees=getSelectedMembers();
  if(!attendees.length){showToast('Choose at least one attendee.','error');return;}
  const current=id==null?null:meetings.find(item=>item.id===id);
  const payload={id:current?.id??pendingMeetingId,title,date,startTime,durationMinutes:Number(document.getElementById('mf-duration').value),location:document.getElementById('mf-location').value.trim(),agenda:document.getElementById('mf-agenda').value.trim(),attendees,linkedWorkIds:[...document.querySelectorAll('.mf-work:checked')].map(input=>Number(input.value))};
  const finish=setButtonBusy(document.activeElement);
  try{
    const result=await sendJson('meetings',{operation:'upsert',meeting:payload,expectedVersion:current?.version??0});
    if(!current)pendingMeetingId=null;
    replaceMeeting(result.meeting);
    showToast(current?'Meeting updated.':'Meeting scheduled.','success');
    openMeetingDetail(result.meeting.id);
  }catch(error){showToast(error.message,'error');}
  finally{finish();}
}
async function saveMeetingMinutes(id){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return;
  const finish=setButtonBusy(document.activeElement);
  try{
    const result=await sendJson('meetings',{operation:'minutes',id,minutes:document.getElementById('meeting-minutes').value,expectedVersion:meeting.version});
    replaceMeeting(result.meeting);showToast('Minutes saved.','success');openMeetingDetail(id);
  }catch(error){showToast(error.message,'error');}
  finally{finish();}
}
async function cancelMeeting(id){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return;
  if(!await appConfirm(`Cancel "${meeting.title}"? Attendees will be notified.`))return;
  try{
    const result=await sendJson('meetings',{operation:'cancel',id,expectedVersion:meeting.version});
    replaceMeeting(result.meeting);showToast('Meeting cancelled.','info');openMeetingDetail(id);
  }catch(error){showToast(error.message,'error');}
}
function downloadMeetingCalendar(id){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return;
  const url=URL.createObjectURL(new Blob([TeamFlowDomain.meetingIcs(meeting)],{type:'text/calendar;charset=utf-8'}));
  const link=document.createElement('a');link.href=url;link.download=`${String(meeting.title).replace(/[^a-z0-9]+/gi,'-').replace(/^-|-$/g,'').slice(0,60)||'meeting'}.ics`;
  document.body.append(link);link.click();link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),10000);
}
// Action points from a meeting. Each can become a work item, which then links back to the meeting.
let pendingActionLink=null;
function meetingActionsHtml(meeting,canWrite){
  const actions=meeting.actions||[];
  const people=meetingAttendeeIds(meeting).map(value=>TEAM.find(member=>String(member.id)===value)).filter(member=>member&&member.role!=='board');
  const rows=actions.map(action=>{
    const owner=TEAM.find(member=>String(member.id)===String(action.ownerId)),work=works.find(item=>item.id===action.workId);
    return`<div class="digest-row"><span style="flex:1 1 180px;min-width:0;overflow-wrap:anywhere;">${escapeHtml(action.text)}<br><span style="font-size:12px;color:var(--text3);">${owner?escapeHtml(owner.name):'No owner'}${action.workId&&!work?' · Linked work no longer available':''}</span></span>${work?`<button type="button" class="btn btn-ghost btn-sm" onclick="openWorkDetail(${Number(work.id)})">Open Work</button>`:canWrite&&canCreateWork()&&!action.workId?`<button type="button" class="btn btn-ghost btn-sm" onclick="createWorkFromAction(${Number(meeting.id)},${Number(action.id)})">Create Work</button>`:''}${canWrite?`<button type="button" class="btn btn-ghost btn-sm" aria-label="Remove action point" onclick="removeMeetingAction(${Number(meeting.id)},${Number(action.id)})">Remove</button>`:''}</div>`;
  }).join('');
  const form=canWrite?`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;"><input id="ma-text" maxlength="500" placeholder="Add an action point..." style="flex:1 1 200px;"><select id="ma-owner" aria-label="Owner" style="flex:0 1 170px;"><option value="">No owner</option>${people.map(member=>`<option value="${Number(member.id)}">${escapeHtml(member.name)}</option>`).join('')}</select><button type="button" class="btn btn-primary btn-sm" onclick="addMeetingAction(${Number(meeting.id)})">Add</button></div>`:'';
  if(!rows&&!canWrite)return'';
  return`<div class="detail-section"><div class="detail-section-title">Action Points</div>${rows||'<div style="font-size:13px;color:var(--text3);">No action points yet.</div>'}${form}</div>`;
}
async function saveMeetingActions(id,actions){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return false;
  try{
    const result=await sendJson('meetings',{operation:'actions',id,actions,expectedVersion:meeting.version});
    replaceMeeting(result.meeting);return true;
  }catch(error){showToast(error.message,'error');return false;}
}
async function addMeetingAction(id){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return;
  const text=document.getElementById('ma-text').value.trim(),owner=document.getElementById('ma-owner').value;
  if(!text){showToast('Enter an action point.','error');return;}
  const added={id:newRecordId(),text,ownerId:owner?Number(owner):null,workId:null};
  if(await saveMeetingActions(id,[...(meeting.actions||[]),added]))openMeetingDetail(id);
}
async function removeMeetingAction(id,actionId){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return;
  if(await saveMeetingActions(id,(meeting.actions||[]).filter(action=>action.id!==actionId)))openMeetingDetail(id);
}
function createWorkFromAction(id,actionId){
  const meeting=meetings.find(item=>item.id===id),action=meeting?.actions?.find(item=>item.id===actionId);if(!action)return;
  delete document.getElementById('modal-body').dataset.detailMeetingId;
  const owner=TEAM.some(member=>member.id===action.ownerId&&member.role!=='admin'&&member.active!==false)?action.ownerId:null;
  openAddWork({title:action.text.slice(0,200),desc:`Action point from the meeting "${meeting.title}" on ${meeting.date}.`,...(owner?{pic:owner,assignees:[owner]}:{})});
  pendingActionLink={meetingId:id,actionId};
  document.querySelector('#modal-overlay .modal').scrollTop=0;
}
// Called once the new work is saved. A failure here leaves the work in place and only the link missing.
async function linkActionToWork(workId){
  if(!pendingActionLink)return;
  const {meetingId,actionId}=pendingActionLink;pendingActionLink=null;
  await loadMeetings();
  const meeting=meetings.find(item=>item.id===meetingId);if(!meeting)return;
  await saveMeetingActions(meetingId,(meeting.actions||[]).map(action=>action.id===actionId?{...action,workId}:action));
}
function openAddMeetingFile(id){
  showMeetingModal('Add File / Folder Link',`<div class="form-group"><label class="form-label" for="file-name">Name *</label><input id="file-name" type="text" maxlength="200" placeholder="e.g. Q3 results pack"></div><div class="form-group"><label class="form-label" for="file-url">URL / Path *</label><input id="file-url" type="text" placeholder="https://... or //fileserver/folder/..."><div class="form-hint">Accepts HTTP/HTTPS links, Windows drive paths and network paths. Windows paths use Copy Path; paste into File Explorer. Drive letters must be mapped on each PC.</div></div><div class="form-group"><label class="form-label" for="file-type">Type</label><select id="file-type">${FILE_TYPES.map(type=>`<option value="${type.type}" data-icon="${FILE_TYPE_ICONS[type.type]}">${type.label}</option>`).join('')}</select></div>`,`<button type="button" class="btn btn-primary" onclick="saveMeetingFile(${Number(id)})">Add Link</button><button type="button" class="btn btn-ghost" onclick="openMeetingDetail(${Number(id)})">Cancel</button>`);
  document.getElementById('file-name').focus();
}
async function saveMeetingFiles(id,files){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return false;
  try{
    const result=await sendJson('meetings',{operation:'files',id,files,expectedVersion:meeting.version});
    replaceMeeting(result.meeting);return true;
  }catch(error){showToast(error.message,'error');return false;}
}
async function saveMeetingFile(id){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return;
  const name=document.getElementById('file-name').value.trim(),url=document.getElementById('file-url').value.trim(),type=document.getElementById('file-type').value;
  if(!name||!url){showToast('Please fill in all fields.','error');return;}
  if(!TeamFlowDomain.fileLocationKind(url)){showToast('Enter an HTTP or HTTPS link, a Windows drive path, or a network path.','error');return;}
  const finish=setButtonBusy(document.activeElement);
  const saved=await saveMeetingFiles(id,[...(meeting.files||[]),{name,url,type}]);
  finish();
  if(saved){showToast('File link added!','success');openMeetingDetail(id);}
}
async function removeMeetingFile(id,index){
  const meeting=meetings.find(item=>item.id===id);if(!meeting)return;
  if(await saveMeetingFiles(id,(meeting.files||[]).filter((_,position)=>position!==index))){showToast('File removed.','info');openMeetingDetail(id);}
}
function openMeetingFromNotification(id){
  if(!currentUser)return;
  const show=()=>openMeetingDetail(Number(id));
  if(meetings.some(item=>item.id===Number(id)))show();else loadMeetings().then(show);
}
// Work detail: the meetings linked to this work, soonest first, then the most recent past ones.
function workMeetingsHtml(work){
  const linked=meetings.filter(meeting=>(meeting.linkedWorkIds||[]).includes(work.id));
  const upcoming=linked.filter(meeting=>!meetingIsPast(meeting)).sort((a,b)=>String(a.startsAt).localeCompare(String(b.startsAt)));
  const past=linked.filter(meetingIsPast).sort((a,b)=>String(b.startsAt).localeCompare(String(a.startsAt))).slice(0,5);
  const canAdd=canCreateMeeting()&&work.status!=='done';
  if(!linked.length&&!canAdd)return'';
  return`<div class="detail-section"><div class="detail-section-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> Meetings</div>${[...upcoming,...past].map(meeting=>meetingRowHtml(meeting,{showDay:true})).join('')||'<div style="font-size:13px;color:var(--text3);">No meetings linked yet.</div>'}${canAdd?`<button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="openMeetingForm(null,{workId:${Number(work.id)}})">+ Schedule Meeting</button>`:''}</div>`;
}
function todayMeetingsHtml(){
  const today=TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE);
  const mine=meetings.filter(meeting=>meeting.date===today&&meeting.status!=='cancelled'&&isMyMeeting(meeting)&&meetingEndMs(meeting)>=Date.now()).sort((a,b)=>String(a.startsAt).localeCompare(String(b.startsAt)));
  if(!mine.length)return`<div id="today-meetings" class="card focus-card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> Today's Meetings</div><button type="button" class="btn btn-ghost btn-sm" onclick="navigate('meetings')">See all</button></div><div class="focus-empty">No upcoming meetings today.</div></div>`;
  const rows=mine.slice(0,5).map(meeting=>{
    const minutes=Math.round((Date.parse(meeting.startsAt)-Date.now())/60000);
    const when=minutes<=0?'<span style="color:var(--red);font-weight:600;">Happening now</span>':minutes<60?`<span style="color:var(--primary);font-weight:600;">In ${minutes} min</span>`:'';
    const sub=[when,escapeHtml(meeting.location||''),`${meetingAttendeeIds(meeting).length} attendees`].filter(Boolean).join(' · ');
    return`<div class="focus-row" role="button" tabindex="0" onclick="openMeetingDetail(${Number(meeting.id)})"><div class="focus-tile meeting"><strong>${escapeHtml(meeting.startTime)}</strong><span>${Number(meeting.durationMinutes)} min</span></div><div class="focus-main"><div class="focus-title">${escapeHtml(meeting.title)}</div><div class="focus-sub">${sub}</div></div><svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></div>`;
  }).join('');
  return`<div id="today-meetings" class="card focus-card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> Today's Meetings <span class="focus-count">${mine.length}</span></div><button type="button" class="btn btn-ghost btn-sm" onclick="navigate('meetings')">See all</button></div>${rows}</div>`;
}
// A backup to push: shows on any page for attendees, whether or not this device has notifications on.
function updateMeetingBanner(){
  const banner=document.getElementById('meeting-banner');if(!banner)return;
  const now=Date.now();
  const next=currentUser?meetings.filter(meeting=>meeting.status!=='cancelled'&&isMyMeeting(meeting)&&!dismissedMeetingBanners.has(`${meeting.id}:${meeting.startsAt}`)&&Date.parse(meeting.startsAt)-now<=3600000&&now-Date.parse(meeting.startsAt)<=600000).sort((a,b)=>String(a.startsAt).localeCompare(String(b.startsAt)))[0]:null;
  if(!next){banner.style.display='none';banner.innerHTML='';return;}
  const minutes=Math.ceil((Date.parse(next.startsAt)-now)/60000);
  const lead=minutes>0?`Meeting starts in ${minutes} minute${minutes===1?'':'s'}:`:'Meeting has started:';
  banner.innerHTML=`<span style="flex:1;min-width:0;overflow-wrap:anywhere;">${lead} <strong>${escapeHtml(next.title)}</strong>${next.location?` · ${escapeHtml(next.location)}`:''}</span><button type="button" class="btn btn-ghost btn-sm" onclick="openMeetingDetail(${Number(next.id)})">Open</button><button type="button" class="close-btn" aria-label="Dismiss meeting reminder" onclick="dismissMeetingBanner('${Number(next.id)}:${escapeHtml(next.startsAt)}')">✕</button>`;
  banner.style.display='flex';
}
function dismissMeetingBanner(key){dismissedMeetingBanners.add(key);updateMeetingBanner();}
setInterval(()=>{if(currentUser)updateMeetingBanner();},30000);
setInterval(()=>{if(currentUser)loadMeetings();},5*60*1000);
window.addEventListener('focus',()=>{if(currentUser)loadMeetings();});
