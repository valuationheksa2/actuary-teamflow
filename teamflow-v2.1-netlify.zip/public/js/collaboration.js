// Shared-data status and explicit conflict reconciliation.
let lastSyncedAt=null,syncConnection='connected',pendingConflict=null,conflictReview=null;
function updateSyncStatus(state){
  if(state==='synced'){lastSyncedAt=new Date();syncConnection='connected';}
  else syncConnection=state==='connected'&&currentUser&&(draftActive||hasPendingChanges)?'paused':state;
  const el=document.getElementById('sync-status');if(!el)return;
  const labels={connected:'Online',offline:'Connection lost',error:'Server unavailable',paused:'Refresh paused — edits kept'};
  const time=lastSyncedAt?new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(lastSyncedAt):null;
  el.textContent=`${labels[syncConnection]||'Online'} · ${time?'Synced '+time:'Waiting for sync'}`;
  el.dataset.state=syncConnection;el.title='Last successful shared-data refresh. Changes from other users are checked every 30 seconds while the page is visible.';
}
function conflictContext(path,data){
  if(path==='works'&&['upsert','delete','complete'].includes(data.operation)){
    const id=data.work?.id??data.id,base=remoteState.works.find(item=>item.id===id);
    return{kind:'work',id,base:cloneValue(base),mine:cloneValue(data.operation==='delete'?null:data.work||base),operation:data.operation};
  }
  if(path==='team'&&['upsert','delete'].includes(data.operation)){
    const id=data.member?.id??data.id;
    return{kind:'member',id,base:cloneValue(remoteState.team.find(item=>item.id===id)),mine:cloneValue(data.operation==='delete'?null:data.member),operation:data.operation};
  }
  if(path==='works'&&data.operation==='collection')return{kind:'collection',name:data.name,base:cloneValue(data.baseItems||remoteState.collections[data.name]),mine:cloneValue(data.items)};
  return null;
}
function closeConflictReview(){const focus=conflictReview?.previousFocus;document.getElementById('conflict-review-overlay')?.remove();conflictReview=null;if(focus?.isConnected)focus.focus({preventScroll:true});}
function conflictEqual(a,b){return JSON.stringify(a??null)===JSON.stringify(b??null);}
function conflictValue(value){return value===undefined?'Not set':typeof value==='string'?value:JSON.stringify(value,null,2);}
function conflictLabel(key){const labels={desc:'Description',phase:'Phase',phaseChecks:'Task checklists',phaseTasks:'Phase tasks',pic:'Person in charge',assignees:'Assigned members',estimatedHours:'Estimated hours',reminderPreferences:'Reminder preferences'};return labels[key]||key.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase());}
async function openConflictReview(){
  if(!pendingConflict||conflictReview)return;
  const context=cloneValue(pendingConflict),generation=editGeneration,userId=currentUser?.id;
  if(context.kind==='collection')context.mine=cloneValue(context.name==='feedbackItems'?feedbackItems:context.name==='joinRequests'?joinRequests:templates);
  else if(context.operation!=='delete')context.mine=cloneValue((context.kind==='work'?works:TEAM).find(item=>item.id===context.id)||context.mine);
  try{
    const fresh=await apiGet(context.kind==='member'?'team':'works');
    if(!currentUser||currentUser.id!==userId||generation!==editGeneration){showToast('Edits changed while loading. Open Review conflict again.','info');return;}
    const latest=context.kind==='member'?fresh.find(item=>item.id===context.id):context.kind==='work'?fresh.data.find(item=>item.id===context.id):fresh[context.name];
    const index=rows=>Object.fromEntries((rows||[]).map(item=>[String(item.id),item]));
    const base=context.kind==='collection'?index(context.base):context.base||{},mine=context.kind==='collection'?index(context.mine):context.mine||{},remote=context.kind==='collection'?index(latest):latest||{};
    const ignored=new Set(context.kind==='collection'?[]:['id','version','passwordHash','password','authVersion','mustResetPassword','requestResolutions','nextOccurrenceId','createdAt','createdBy','updatedAt','passwordUpdatedAt']);
    const keys=[...new Set([...Object.keys(base),...Object.keys(mine),...Object.keys(remote)])].filter(key=>!ignored.has(key)&&(!conflictEqual(base[key],mine[key])||!conflictEqual(base[key],remote[key])));
    conflictReview={context,latest:cloneValue(latest),version:context.kind==='collection'?fresh.versions[context.name]:latest?.version,generation,keys,choices:{},resolved:{...remote},userId,previousFocus:document.activeElement};
    const deletion=context.kind!=='collection'&&context.mine===null;
    const missing=context.kind!=='collection'&&!latest;
    const html=keys.map((key,i)=>{
      const localChanged=!conflictEqual(base[key],mine[key]),remoteChanged=!conflictEqual(base[key],remote[key]);
      const both=localChanged&&remoteChanged&&!conflictEqual(mine[key],remote[key]);
      const choice=localChanged?'mine':'latest';
      if(!both){conflictReview.choices[key]=choice;if(choice==='mine'){if(mine[key]===undefined)delete conflictReview.resolved[key];else conflictReview.resolved[key]=cloneValue(mine[key]);}}
      return `<tr><th scope="row">${escapeHtml(context.kind==='collection'?`Entry ${key}`:conflictLabel(key))}</th><td><pre>${escapeHtml(conflictValue(mine[key]))}</pre></td><td><pre>${escapeHtml(conflictValue(remote[key]))}</pre></td><td>${both?`<label class="sr-only" for="conflict-choice-${i}">Choose ${escapeHtml(conflictLabel(key))}</label><select id="conflict-choice-${i}" onchange="chooseConflictField(${i},this.value)"><option value="">Choose a version</option><option value="mine">Your edit</option><option value="latest">Latest saved</option></select>`:choice==='mine'?'Your edit':'Latest saved'}</td></tr>`;
    }).join('');
    const overlay=document.createElement('div');overlay.id='conflict-review-overlay';overlay.className='modal-overlay conflict-overlay';overlay.style.display='flex';
    overlay.innerHTML=`<div class="modal conflict-modal" role="dialog" aria-modal="true" aria-labelledby="conflict-title" tabindex="-1"><div class="modal-header"><h2 id="conflict-title" class="modal-title">Review save conflict</h2></div><div class="modal-body"><p>Your draft is kept. Independent field changes are combined. Choose a version for each field changed by both users. Lists such as notes or checklists are selected as a whole.</p>${missing?'<p>This record was removed or this new account has a duplicate identifier. Keep your draft and adjust it; an existing record cannot be restored here.</p>':deletion?'<p>You requested deletion. Review the latest values before retrying deletion.</p>':context.operation==='complete'?'<p>Review the latest work, then retry Mark Complete from the work dialog.</p>':''}<div class="conflict-table-wrap"><table class="conflict-table"><thead><tr><th>Field</th><th>Your edit</th><th>Latest saved</th><th>Keep</th></tr></thead><tbody>${html||'<tr><td colspan="4">No field differences. The latest record version will be used.</td></tr>'}</tbody></table></div><p id="conflict-review-error" role="alert"></p></div><div class="modal-footer"><button class="btn btn-ghost" onclick="closeConflictReview()">Keep draft / Close</button>${!missing?`<button class="btn btn-ghost" onclick="useLatestConflict()">Use latest saved</button>${context.operation!=='complete'?`<button class="btn btn-primary" id="conflict-save" onclick="saveReviewedConflict()">${deletion?'Retry deletion':'Save reviewed version'}</button>`:''}`:''}</div></div>`;
    document.body.appendChild(overlay);overlay.querySelector('.conflict-modal').focus();
  }catch(error){closeConflictReview();showToast('Could not load the latest version. Your draft is kept. Try Review conflict again.','error');}
}
function chooseConflictField(index,choice){
  const review=conflictReview;if(!review)return;const key=review.keys[index];
  if(!['mine','latest'].includes(choice)){delete review.choices[key];return;}
  review.choices[key]=choice;
  const source=review.context.kind==='collection'?Object.fromEntries((choice==='mine'?review.context.mine:review.latest).map(item=>[String(item.id),item])):choice==='mine'?review.context.mine:review.latest;
  if(source?.[key]===undefined)delete review.resolved[key];else review.resolved[key]=cloneValue(source[key]);
}
function applyConflictState(review,useLatest){
  const context=review.context,latest=review.latest;
  if(context.kind==='collection'){
    remoteState.collections[context.name]=cloneValue(latest);remoteState.versions[context.name]=review.version;
    const rows=useLatest?cloneValue(latest):Object.values(review.resolved);
    if(context.name==='feedbackItems')feedbackItems=rows;else if(context.name==='joinRequests')joinRequests=rows;else templates=rows;
  }else{
    const merged=useLatest?cloneValue(latest):context.mine===null?null:{...cloneValue(review.resolved),id:context.id,version:review.version};
    const replace=(rows,item)=>{const next=rows.filter(row=>row.id!==context.id);if(item)next.push(item);return next;};
    if(context.kind==='work'){remoteState.works=replace(remoteState.works,cloneValue(latest));works=replace(works,merged);}
    else{remoteState.team=replace(remoteState.team,cloneValue(latest));TEAM=replace(TEAM,merged);}
  }
  pendingConflict=null;editGeneration++;closeModal();
}
function remainingUnsavedChanges(){return JSON.stringify(works.map(comparableObject))!==JSON.stringify(remoteState.works.map(comparableObject))||JSON.stringify(TEAM.map(comparableObject))!==JSON.stringify(remoteState.team.map(comparableObject))||['joinRequests','templates','feedbackItems'].some(name=>JSON.stringify(name==='joinRequests'?joinRequests:name==='templates'?templates:feedbackItems)!==JSON.stringify(remoteState.collections[name]));}
async function useLatestConflict(){
  const review=conflictReview;if(!review||review.generation!==editGeneration)return;
  if(!await appConfirm('Discard your conflicting changes and use the latest saved version?'))return;
  if(review!==conflictReview||review.generation!==editGeneration||currentUser?.id!==review.userId)return;
  applyConflictState(review,true);closeConflictReview();draftActive=false;hasPendingChanges=remainingUnsavedChanges();setSaveIndicator(hasPendingChanges?'pending':'');navigate(currentPage);updateSyncStatus(hasPendingChanges?'paused':'connected');
}
async function saveReviewedConflict(){
  const review=conflictReview;if(!review)return;
  const error=document.getElementById('conflict-review-error');
  if(review.generation!==editGeneration||currentUser?.id!==review.userId){error.textContent='Your draft changed. Close this comparison and review again.';return;}
  if(review.context.mine!==null&&review.keys.some(key=>!review.choices[key])){error.textContent='Choose a version for every conflicting field.';return;}
  if(review.context.mine===null&&!await appConfirm('Delete the latest saved version of this record?'))return;
  if(review!==conflictReview||review.generation!==editGeneration||currentUser?.id!==review.userId)return;
  applyConflictState(review,false);closeConflictReview();hasPendingChanges=true;draftActive=false;
  if(await saveRequestsNow({button:null})){navigate(currentPage);showToast('Reviewed changes saved.','success');}
}
window.addEventListener('offline',()=>updateSyncStatus('offline'));
window.addEventListener('online',()=>{updateSyncStatus('connected');backgroundSync();});
