'use strict';
// Keep labels and dialog focus consistent across dynamically rendered pages.
function enhanceDynamicForms(){
  document.querySelectorAll('.form-group').forEach(group=>{
    const label=group.querySelector('.form-label'),control=group.querySelector('input,select,textarea');
    if(label&&control?.id&&!label.hasAttribute('for'))label.htmlFor=control.id;
  });
  document.querySelectorAll('[id^="pt-"]').forEach(control=>{if(control.tagName==='INPUT'){const [,phase,index]=control.id.split('-');control.setAttribute('aria-label',`${phase} task ${Number(index)+1}`);}});
  document.getElementById('f-custom-days')?.setAttribute('aria-label','Repeat every number of days');
  document.getElementById('new-note-text')?.setAttribute('aria-label','New work note');
  document.querySelectorAll('.phase-task-editor-header').forEach(header=>{header.setAttribute('role','button');header.tabIndex=0;header.setAttribute('aria-expanded',String(header.nextElementSibling?.style.display!=='none'));});
}
let modalPreviousFocus=null,modalWasOpen=false;
function updateDialogAccessibility(){
  enhanceDynamicForms();
  const overlay=document.getElementById('modal-overlay'),open=overlay.style.display==='flex';
  if(open&&!modalWasOpen){
    modalPreviousFocus=document.activeElement;
    const first=overlay.querySelector('input:not([type="hidden"]),textarea,select')||overlay.querySelector('button');
    first?.focus();
  }
  if(!open&&modalWasOpen&&modalPreviousFocus?.isConnected)modalPreviousFocus.focus();
  modalWasOpen=open;
}
document.getElementById('save-indicator').setAttribute('role','status');
document.getElementById('save-indicator').setAttribute('aria-live','polite');
document.getElementById('toast').setAttribute('role','status');
new MutationObserver(updateDialogAccessibility).observe(document.getElementById('app'),{childList:true,subtree:true});
new MutationObserver(updateDialogAccessibility).observe(document.getElementById('modal-overlay'),{childList:true,subtree:true,attributes:true,attributeFilter:['style']});
document.addEventListener('keydown',event=>{
  if(event.key!=='Tab')return;
  const overlay=document.getElementById('conflict-review-overlay')||document.getElementById('modal-overlay');if(overlay.style.display!=='flex')return;
  const controls=[...overlay.querySelectorAll('button,input,select,textarea,a[href],[tabindex="0"]')].filter(el=>!el.disabled&&el.getClientRects().length);
  const first=controls[0],last=controls[controls.length-1];if(!first)return;
  if(event.shiftKey&&(document.activeElement===first||!overlay.contains(document.activeElement))){event.preventDefault();last.focus();}
  else if(!event.shiftKey&&(document.activeElement===last||!overlay.contains(document.activeElement))){event.preventDefault();first.focus();}
});
boot();

// A new version waits until the person chooses Reload, so unsaved work is never lost to an automatic refresh.
let updateReloading=false;
function showUpdateBanner(registration){
  if(!registration.waiting||document.getElementById('update-banner'))return;
  const banner=document.createElement('div');banner.id='update-banner';banner.className='update-banner';banner.setAttribute('role','status');
  banner.innerHTML='<span>A new version of TeamFlow is available.</span><button type="button" class="btn btn-primary btn-sm">Reload</button><button type="button" class="update-banner-close" aria-label="Dismiss">✕</button>';
  banner.querySelector('.btn').onclick=async()=>{
    if(hasPendingChanges&&!await appConfirm('You have unsaved changes. Reload and update anyway?'))return;
    updateReloading=true;registration.waiting?.postMessage({type:'SKIP_WAITING'});
  };
  banner.querySelector('.update-banner-close').onclick=()=>banner.remove();
  document.body.appendChild(banner);
}
function watchForUpdates(registration){
  showUpdateBanner(registration);
  registration.addEventListener('updatefound',()=>{
    const worker=registration.installing;
    worker?.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)showUpdateBanner(registration);});
  });
  // Long-open tabs check for a new release every 30 minutes.
  setInterval(()=>registration.update().catch(()=>{}),30*60*1000);
}
// Register after initial rendering; installation must not delay sign-in.
if ('serviceWorker' in navigator && window.isSecureContext) {
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(updateReloading)location.reload();});
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js', { scope: '/', updateViaCache: 'none' })
      .then(watchForUpdates)
      .catch(error => console.warn('TeamFlow offline support unavailable:', error.message));
  });
}
