'use strict';
// Keep labels and dialog focus consistent across dynamically rendered pages.
function enhanceDynamicForms(){
  document.querySelectorAll('.form-group').forEach(group=>{
    const label=group.querySelector('.form-label'),control=group.querySelector('input,select,textarea');
    if(label&&control?.id&&!label.hasAttribute('for'))label.htmlFor=control.id;
  });
  document.querySelectorAll('[id^="pt-"]').forEach(control=>{if(control.tagName==='INPUT'){const [,phase,index]=control.id.split('-');control.setAttribute('aria-label',`${phase} task ${Number(index)+1}`);}});
  document.getElementById('f-custom-days')?.setAttribute('aria-label','Repeat every number of days');
  document.getElementById('new-note-text')?.setAttribute('aria-label','New work note');
  document.querySelectorAll('.phase-task-editor-header').forEach(header=>{header.setAttribute('role','button');header.tabIndex=0;header.setAttribute('aria-expanded',String(header.nextElementSibling?.style.display!=='none'));});
}
// Local development preview (127.0.0.1 / localhost): a DEV tag beside the logo, as in ActuarialPro, so it is never mistaken for the live site.
const LOCAL_DEV=['127.0.0.1','localhost','[::1]'].includes(location.hostname);
function showDevBadge(){
  if(!LOCAL_DEV)return;
  document.documentElement.classList.add('is-dev');
  document.querySelectorAll('.sidebar-brand-copy, .login-logo h1').forEach(title=>{
    if(title.querySelector('.dev-tag'))return;
    const tag=document.createElement('span');tag.className='dev-tag';tag.textContent='DEV';tag.title='Local development preview with fictional data, not production';
    title.appendChild(tag);
  });
  // The installed name, app icon and favicon come from the preview server's Dev manifest and icons (scripts/preview-assets).
  document.title='Actuarial TeamFlow Dev';
}
showDevBadge();
// The heavy focus ring is for keyboard users. Browsers also show it after clicks on fields and on elements focused by script.
document.addEventListener('pointerdown',()=>document.documentElement.classList.add('pointer-input'),true);
document.addEventListener('keydown',event=>{if(event.key==='Tab'||event.key.startsWith('Arrow'))document.documentElement.classList.remove('pointer-input');},true);
let modalPreviousFocus=null,modalWasOpen=false;
function updateDialogAccessibility(){
  enhanceDynamicForms();
  const overlay=document.getElementById('modal-overlay'),open=overlay.style.display==='flex';
  if(open&&!modalWasOpen){
    modalPreviousFocus=document.activeElement;
    // Work detail opens at the top: focusing its notes box would scroll Phase Progress out of view.
    const detailBody=document.getElementById('modal-body').dataset;
    if(detailBody.detailWorkId||detailBody.detailMeetingId){
      overlay.querySelector('.close-btn')?.focus({preventScroll:true});
      document.getElementById('modal-body').scrollTop=0;
    }else{
      const first=overlay.querySelector('input:not([type="hidden"]),textarea,select')||overlay.querySelector('button');
      first?.focus();
    }
  }
  if(!open&&modalWasOpen&&modalPreviousFocus?.isConnected)modalPreviousFocus.focus();
  modalWasOpen=open;
}
document.getElementById('save-indicator').setAttribute('role','status');
document.getElementById('save-indicator').setAttribute('aria-live','polite');
document.getElementById('toast').setAttribute('role','status');
new MutationObserver(updateDialogAccessibility).observe(document.getElementById('app'),{childList:true,subtree:true});
new MutationObserver(updateDialogAccessibility).observe(document.getElementById('modal-overlay'),{childList:true,subtree:true,attributes:true,attributeFilter:['style']});
document.addEventListener('keydown',event=>{
  if(event.key!=='Tab')return;
  const overlay=document.getElementById('conflict-review-overlay')||document.getElementById('modal-overlay');if(overlay.style.display!=='flex')return;
  const controls=[...overlay.querySelectorAll('button,input,select,textarea,a[href],[tabindex="0"]')].filter(el=>!el.disabled&&el.getClientRects().length);
  const first=controls[0],last=controls[controls.length-1];if(!first)return;
  if(event.shiftKey&&(document.activeElement===first||!overlay.contains(document.activeElement))){event.preventDefault();last.focus();}
  else if(!event.shiftKey&&(document.activeElement===last||!overlay.contains(document.activeElement))){event.preventDefault();first.focus();}
});
boot();

// A new version waits until the person chooses Reload, so unsaved work is never lost to an automatic refresh.
let updateReloading=false;
function showUpdateBanner(registration){
  if(!registration.waiting||document.getElementById('update-banner'))return;
  const banner=document.createElement('div');banner.id='update-banner';banner.className='update-banner';banner.setAttribute('role','status');
  banner.innerHTML='<span>A new version of TeamFlow is available.</span><button type="button" class="btn btn-primary btn-sm">Reload</button><button type="button" class="update-banner-close" aria-label="Dismiss">✕</button>';
  banner.querySelector('.btn').onclick=async()=>{
    if(hasPendingChanges&&!await appConfirm('You have unsaved changes. Reload and update anyway?'))return;
    updateReloading=true;banner.querySelector('.btn').disabled=true;
    // The new version may already be active (another tab updated it, or it activated on its own); then a plain reload is enough.
    if(!registration.waiting){location.reload();return;}
    registration.waiting.postMessage({type:'SKIP_WAITING'});
    setTimeout(()=>location.reload(),3000);
  };
  banner.querySelector('.update-banner-close').onclick=()=>shrinkAway(banner,()=>banner.remove());
  document.body.appendChild(banner);springIn(banner);
}
function watchForUpdates(registration){
  showUpdateBanner(registration);
  registration.addEventListener('updatefound',()=>{
    const worker=registration.installing;
    worker?.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)showUpdateBanner(registration);});
  });
  // Long-open tabs check for a new release every 30 minutes.
  setInterval(()=>registration.update().catch(()=>{}),30*60*1000);
}
// Register after initial rendering; installation must not delay sign-in.
if ('serviceWorker' in navigator && window.isSecureContext) {
  navigator.serviceWorker.addEventListener('controllerchange',()=>{if(updateReloading)location.reload();});
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js', { scope: '/', updateViaCache: 'none' })
      .then(watchForUpdates)
      .catch(error => console.warn('TeamFlow offline support unavailable:', error.message));
  });
}

// Single lines cut between words are refitted whenever a page draws or changes width.
(()=>{
  const content=document.getElementById('content');
  if(!content||typeof ResizeObserver==='undefined')return;
  let frame=0;
  const schedule=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(fitLineText);};
  new ResizeObserver(schedule).observe(content);
  new MutationObserver(records=>{if(records.some(record=>!record.target.dataset?.fit))schedule();}).observe(content,{childList:true,subtree:true});
})();

// Page entrance (v2.5): cards rise in with a short stagger, dashboard counters count up and chart/capacity bars fill from zero (work-card progress stays still).
// Runs only when a page is first opened, never on the 30-second background refresh.
function animatePageEnter(root){
  if(!root||window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  const ease='cubic-bezier(.16,1,.3,1)';
  [...root.querySelectorAll('.card,.stat-card,.work-item')].filter(el=>!el.parentElement.closest('.card,.work-item')).slice(0,14)
    .forEach((el,i)=>el.animate([{opacity:0,transform:'translateY(18px) scale(.985)'},{opacity:1,transform:'translateY(-2px) scale(1)',offset:.7},{opacity:1,transform:'none'}],{duration:520,delay:40+Math.min(i,10)*45,easing:'cubic-bezier(.22,.9,.36,1)',fill:'backwards'}));
  root.querySelectorAll('.stat-value').forEach(el=>{
    const text=el.textContent.trim(),m=/^(\d+)(%?)$/.exec(text);if(!m||m[1]==='0')return;
    const target=Number(m[1]),suffix=m[2],start=performance.now(),duration=650;el.textContent='0'+suffix;
    const step=now=>{if(!el.isConnected)return;const k=Math.min(1,(now-start)/duration);el.textContent=Math.round(target*(1-Math.pow(1-k,3)))+suffix;if(k<1)requestAnimationFrame(step);else el.textContent=text;};
    requestAnimationFrame(step);
  });
  root.querySelectorAll('.perf-bar-fill,.cap-fill,.cap-over').forEach((el,i)=>{
    el.style.transformOrigin='left center';
    el.animate([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:700,delay:140+Math.min(i,10)*25,easing:ease,fill:'backwards'});
  });
}

// Modals (v2.5): scale in on open; on close a non-interactive copy fades out while the real dialog is already gone.
(()=>{
  const overlay=document.getElementById('modal-overlay');if(!overlay)return;
  const reduce=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const ease='cubic-bezier(.16,1,.3,1)';
  let shown=overlay.style.display==='flex',lastScroll=0,snapshot=null,snapshotScroll=0;
  // A hidden element reports scrollTop 0, so remember the position while the dialog is open.
  overlay.addEventListener('scroll',event=>{if(event.target.id==='modal-body')lastScroll=event.target.scrollTop;},true);
  // closeModal resets the dialog before hiding it, so take the copy used for the closing animation just before it runs.
  if(typeof window.closeModal==='function'){
    const original=window.closeModal;
    window.closeModal=function(...args){
      if(overlay.style.display==='flex'){snapshot=overlay.cloneNode(true);snapshotScroll=document.getElementById('modal-body')?.scrollTop||0;}
      try{return original.apply(this,args);}finally{setTimeout(()=>{snapshot=null;},0);}
    };
  }
  // Opening eases in; closing fades the dialog and its background out together, with one timing and one curve.
  new MutationObserver(()=>{
    const now=overlay.style.display==='flex';
    if(now&&!shown)lastScroll=0;
    if(now&&!shown&&!reduce()){
      overlay.animate([{opacity:0},{opacity:1}],{duration:180,easing:'ease-out'});
      overlay.querySelector('.modal')?.animate([{opacity:0,transform:'translateY(10px) scale(.97)'},{opacity:1,transform:'none'}],{duration:260,easing:ease});
    }else if(!now&&shown&&!reduce()){
      const ghost=snapshot||overlay.cloneNode(true);snapshot=null;ghost.removeAttribute('id');ghost.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));
      ghost.style.display='flex';ghost.style.pointerEvents='none';ghost.setAttribute('aria-hidden','true');ghost.inert=true;
      const scrollTop=snapshotScroll||lastScroll;snapshotScroll=0;
      document.body.appendChild(ghost);const scroller=ghost.querySelector('.modal-body');if(scroller)scroller.scrollTop=scrollTop;
      const tint=getComputedStyle(overlay).backgroundColor,out={duration:200,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'};
      // The background's tint and blur fade (not the layer's opacity, which flickers with backdrop-filter in Chromium) while the dialog fades and settles.
      ghost.animate([{backgroundColor:tint,backdropFilter:'blur(4px)'},{backgroundColor:'rgba(30,60,120,0)',backdropFilter:'blur(0px)'}],out).finished.finally(()=>ghost.remove());
      ghost.querySelector('.modal')?.animate([{opacity:1,transform:'none'},{opacity:0,transform:'translateY(6px) scale(.97)'}],out);
    }
    shown=now;
  }).observe(overlay,{attributes:true,attributeFilter:['style']});
})();
// Character counter for fields marked data-count: appears once 80% of maxlength is used, and turns red at the limit.
(function(){
  const update=field=>{
    const max=Number(field.getAttribute('maxlength'));if(!max)return;
    let counter=field.nextElementSibling;
    if(!counter||!counter.classList.contains('char-count')){counter=document.createElement('div');counter.className='char-count';counter.setAttribute('aria-live','polite');field.insertAdjacentElement('afterend',counter);}
    const used=field.value.length;
    counter.hidden=used<max*0.8;
    counter.classList.toggle('is-full',used>=max);
    counter.textContent=`${used.toLocaleString('en-US')} / ${max.toLocaleString('en-US')}${used>=max?' · limit reached':''}`;
  };
  document.addEventListener('input',event=>{if(event.target.matches?.('[data-count]'))update(event.target);});
  document.addEventListener('focusin',event=>{if(event.target.matches?.('[data-count]'))update(event.target);});
})();

// Sliding highlight for tabs and segmented switches: one pill glides to the selected option with a slight overshoot.
// It works across re-renders (Audit, Meetings and work detail rebuild their tabs): after a tab is chosen, the rebuilt group starts from where the pill was.
(()=>{
  const GROUPS='.tabs,.pf-tabs,.lang-switch',ITEMS=':scope > .tab, :scope > .pf-tab, :scope > .lang-switch-btn',chosen=new Map();let queued=false;
  const keyOf=group=>group.className.split(' ')[0]+'|'+(group.getAttribute('aria-label')||'');
  const apply=(pill,p)=>{pill.style.width=p.w+'px';pill.style.height=p.h+'px';pill.style.transform=`translate(${p.x}px,${p.y}px)`;};
  function place(group){
    if(!group.classList.contains('seg-host'))group.classList.add('seg-host'); // first, so the selected option never draws (and fades) its own background
    if(!group.offsetParent)return;
    const items=[...group.querySelectorAll(ITEMS)],active=items.find(item=>item.classList.contains('active')||item.classList.contains('is-on'));
    if(!active||!active.offsetWidth)return;
    const pos={x:active.offsetLeft,y:active.offsetTop,w:active.offsetWidth,h:active.offsetHeight},key=keyOf(group);
    let pill=group.querySelector(':scope > .seg-pill');
    if(!pill){
      pill=document.createElement('span');pill.className='seg-pill';pill.setAttribute('aria-hidden','true');
      group.prepend(pill);
      const prev=chosen.get(key),start=prev&&prev.n===items.length&&Date.now()-prev.t<1000?prev:pos;chosen.delete(key);
      pill.style.transition='none';apply(pill,start);pill.getBoundingClientRect();pill.style.transition='';
    }
    apply(pill,pos);
  }
  const run=()=>{queued=false;document.querySelectorAll(GROUPS).forEach(place);};
  const schedule=()=>{if(!queued){queued=true;requestAnimationFrame(run);}};
  // Placed in the observer callback itself (before the browser paints), so a rebuilt group shows its pill already in place.
  new MutationObserver(run).observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['class']});
  addEventListener('resize',schedule);
  // Remember where the pill was when a tab is chosen, before the page rebuilds the group.
  document.addEventListener('click',event=>{
    const group=event.target.closest?.(GROUPS),pill=group?.querySelector(':scope > .seg-pill');if(!pill)return;
    const match=/translate\(([-\d.]+)px, ?([-\d.]+)px\)/.exec(pill.style.transform)||[0,0,0];
    chosen.set(keyOf(group),{x:+match[1],y:+match[2],w:pill.offsetWidth,h:pill.offsetHeight,n:group.querySelectorAll(ITEMS).length,t:Date.now()});
  },true);
})();

// ---------------------------------------------------------------------------------------------------------------
// Motion set (v2.5 trial): banners spring in and shrink away, the sidebar highlight slides between pages, phase
// changes animate with a self-drawing check, badges pop when their count changes, and approvals or completed work
// get a small confetti burst. Everything here stops with Reduce motion (system setting or View menu).
const tfReduce=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let tfPointer=null;
document.addEventListener('pointerdown',event=>{tfPointer={x:event.clientX,y:event.clientY};},true);
function springIn(el){
  if(!el||tfReduce())return;
  el.animate([{opacity:0,transform:'translateY(-12px) scale(.96)'},{opacity:1,transform:'translateY(2px) scale(1.01)',offset:.6},{opacity:1,transform:'none'}],{duration:520,easing:'cubic-bezier(.2,.9,.3,1)'});
}
function shrinkAway(el,done){
  if(!el||tfReduce()){done();return;}
  const style=getComputedStyle(el);
  el.style.overflow='hidden';
  el.animate([{opacity:1,transform:'none',height:el.offsetHeight+'px',paddingTop:style.paddingTop,paddingBottom:style.paddingBottom},{opacity:0,transform:'scale(.94)',height:'0px',paddingTop:'0px',paddingBottom:'0px'}],{duration:280,easing:'cubic-bezier(.4,0,.2,1)'})
    .finished.then(()=>{el.style.overflow='';done();},()=>{el.style.overflow='';done();});
}
// Confetti from where you clicked Approve or Complete Work.
function celebrate(){
  if(tfReduce())return;
  const origin=tfPointer||{x:innerWidth/2,y:innerHeight/2},colors=['#2b55a6','#1f9d6b','#f2b13a','#e0577b','#6b8de0','#33b5c4'];
  const layer=document.createElement('div');layer.className='confetti-layer';layer.setAttribute('aria-hidden','true');document.body.appendChild(layer);
  for(let i=0;i<36;i++){
    const bit=document.createElement('i');bit.style.background=colors[i%colors.length];bit.style.left=origin.x+'px';bit.style.top=origin.y+'px';
    if(i%3===0)bit.style.borderRadius='50%';else if(i%3===1){bit.style.width='5px';bit.style.height='13px';}
    layer.appendChild(bit);
    const angle=-Math.PI/2+(Math.random()-.5)*Math.PI*1.2,speed=110+Math.random()*170,dx=Math.cos(angle)*speed,dy=Math.sin(angle)*speed,spin=(Math.random()-.5)*900;
    bit.animate([
      {transform:'translate(-50%,-50%) rotate(0deg) scale(.4)',opacity:1},
      {transform:`translate(calc(-50% + ${dx*.75}px),calc(-50% + ${dy*.75}px)) rotate(${spin*.5}deg) scale(1)`,opacity:1,offset:.4},
      {transform:`translate(calc(-50% + ${dx}px),calc(-50% + ${dy+200}px)) rotate(${spin}deg) scale(.7)`,opacity:0}
    ],{duration:1100+Math.random()*450,easing:'cubic-bezier(.15,.75,.35,1)',fill:'forwards'});
  }
  setTimeout(()=>layer.remove(),1800);
}
(()=>{
  // Meeting reminder banner: spring in when it appears, shrink away when dismissed.
  if(typeof updateMeetingBanner==='function'){
    const original=updateMeetingBanner;
    window.updateMeetingBanner=function(...args){
      const banner=document.getElementById('meeting-banner'),was=banner?.style.display==='flex';
      const result=original.apply(this,args);
      if(banner&&!was&&banner.style.display==='flex')springIn(banner);
      return result;
    };
  }
  if(typeof dismissMeetingBanner==='function'){
    const original=dismissMeetingBanner;
    window.dismissMeetingBanner=function(...args){const banner=document.getElementById('meeting-banner');shrinkAway(banner,()=>original.apply(this,args));};
  }
})();
(()=>{
  // Sidebar: one highlight slides to the page you open.
  const scroller=document.querySelector('#sidebar .sidebar-scroll');if(!scroller)return;
  const pill=document.createElement('div');pill.className='nav-pill';pill.setAttribute('aria-hidden','true');
  scroller.prepend(pill);scroller.classList.add('has-nav-pill');
  // While a section opens or closes, the pill is placed on every frame (no own transition),
  // and clipped to the section body so it shrinks and grows with the menu items around it.
  let placed=false,frame=0,followFrame=0;const moving=new Set();
  const place=()=>{
    const active=scroller.querySelector('.nav-item.active');
    if(!active||!active.offsetWidth){pill.style.opacity='0';return;}
    const box=scroller.getBoundingClientRect(),rect=active.getBoundingClientRect();
    const body=active.closest('.sidebar-section-body'),clip=body?body.getBoundingClientRect():rect;
    const top=Math.max(rect.top,clip.top),height=Math.min(rect.bottom,clip.bottom)-top;
    if(height<=0.5){pill.style.opacity='0';return;}
    if(!placed)pill.style.transition='none';
    pill.style.opacity=moving.size?String(Math.min(1,height/rect.height)):'1';
    pill.style.width=rect.width+'px';pill.style.height=height+'px';
    pill.style.transform=`translate(${rect.left-box.left}px,${top-box.top+scroller.scrollTop}px)`;
    if(!placed){pill.getBoundingClientRect();pill.style.transition='';placed=true;}
  };
  const schedule=()=>{if(moving.size)return;cancelAnimationFrame(frame);frame=requestAnimationFrame(place);};
  const follow=()=>{pill.style.transition='none';place();if(moving.size)followFrame=requestAnimationFrame(follow);else{followFrame=0;pill.getBoundingClientRect();pill.style.transition='';}};
  const isSection=event=>event.target!==pill&&event.target.classList&&event.target.classList.contains('sidebar-section-body')&&event.propertyName==='max-height';
  scroller.addEventListener('transitionrun',event=>{if(!isSection(event))return;moving.add(event.target);cancelAnimationFrame(frame);if(!followFrame)followFrame=requestAnimationFrame(follow);});
  const settle=event=>{if(!isSection(event))return;moving.delete(event.target);if(!moving.size){cancelAnimationFrame(followFrame);followFrame=0;pill.style.transition='none';place();pill.getBoundingClientRect();pill.style.transition='';}};
  scroller.addEventListener('transitionend',settle);scroller.addEventListener('transitioncancel',settle);
  new MutationObserver(schedule).observe(scroller,{subtree:true,attributes:true,attributeFilter:['class']});
  // First placement waits until after the first paint, so it reads a settled layout instead of forcing one during startup.
  addEventListener('resize',schedule);requestAnimationFrame(()=>setTimeout(schedule,0));
})();
(()=>{
  // Number badges pop when their count changes.
  const sidebar=document.getElementById('sidebar');if(!sidebar)return;
  const last=new WeakMap();
  new MutationObserver(records=>{
    const changed=new Set();
    records.forEach(record=>{const node=record.target.nodeType===3?record.target.parentElement:record.target;const badge=node?.closest?.('.nav-badge');if(badge)changed.add(badge);});
    changed.forEach(badge=>{
      const text=badge.textContent.trim(),previous=last.get(badge);last.set(badge,text);
      if(!previous||!text||previous===text||badge.style.display==='none'||tfReduce())return;
      badge.animate([{transform:'scale(1)'},{transform:'scale(1.4)',offset:.3},{transform:'scale(.9)',offset:.65},{transform:'scale(1)'}],{duration:560,easing:'ease-out'});
    });
  }).observe(sidebar,{subtree:true,childList:true,characterData:true});
})();
(()=>{
  // Work detail: when the phase moves on, the line fills, the finished dot pops and its check draws itself.
  // The detail is drawn twice (straight away, then with the saved result), so a rebuild mid-animation continues where it was.
  const body=document.getElementById('modal-body');if(!body)return;
  const seen=new Map();let playing=null;
  const play=(track,from,to,elapsed)=>{
    const steps=[...track.querySelectorAll('.phase-step')],lines=[...track.querySelectorAll('.phase-line')],all=[];
    for(let i=from,n=0;i<to;i++,n++){
      const delay=120+n*260,line=lines[i],dot=steps[i]?.querySelector('.phase-dot'),check=dot?.querySelector('svg');
      if(line){line.style.transformOrigin='left center';all.push(line.animate([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:420,delay:delay+180,easing:'cubic-bezier(.4,0,.2,1)',fill:'backwards'}));}
      if(dot)all.push(dot.animate([{transform:'scale(.5)'},{transform:'scale(1.18)',offset:.55},{transform:'scale(1)'}],{duration:480,delay,easing:'cubic-bezier(.2,.9,.3,1)',fill:'backwards'}));
      if(check)all.push(check.animate([{strokeDasharray:'24',strokeDashoffset:'24'},{strokeDasharray:'24',strokeDashoffset:'0'}],{duration:380,delay:delay+140,easing:'ease-out',fill:'backwards'}));
    }
    const next=steps[to]?.querySelector('.phase-dot.active');
    if(next)all.push(next.animate([{boxShadow:'0 0 0 0 rgba(43,85,166,.45)'},{boxShadow:'0 0 0 12px rgba(43,85,166,0)'}],{duration:900,delay:120+(to-from)*260+300,easing:'ease-out'}));
    all.forEach(animation=>{animation.currentTime=elapsed;});
  };
  new MutationObserver(()=>{
    const id=body.dataset.detailWorkId,track=body.querySelector('.phase-track');
    if(!id||!track||track.dataset.phaseSeen)return;
    track.dataset.phaseSeen='1';
    const done=track.querySelectorAll('.phase-dot.done').length,before=seen.get(id);seen.set(id,done);
    if(tfReduce())return;
    if(before!=null&&done>before){playing={id,from:before,to:done,start:performance.now()};play(track,before,done,0);return;}
    if(playing&&playing.id===id&&playing.to===done&&performance.now()-playing.start<2000)play(track,playing.from,done,performance.now()-playing.start);
    // Going back a phase: the phase you return to pops and pulses.
    if(before!=null&&done<before){const back=track.querySelector('.phase-dot.active');back?.animate([{transform:'scale(.6)'},{transform:'scale(1.15)',offset:.55},{transform:'scale(1)'}],{duration:460,easing:'cubic-bezier(.2,.9,.3,1)'});back?.animate([{boxShadow:'0 0 0 0 rgba(43,85,166,.45)'},{boxShadow:'0 0 0 12px rgba(43,85,166,0)'}],{duration:900,delay:200,easing:'ease-out'});}
  }).observe(body,{childList:true,subtree:true});
})();
(()=>{
  // Progress bars glide from their old value when ticking a task, advancing or going back changes them, in work detail and on work cards.
  // Pages and the detail are rebuilt on each change, so the last value is remembered per work item; a rebuild mid-glide carries on.
  const last=new Map(),moving=new Map();
  const keyOf=fill=>{
    const card=fill.closest('.work-item');
    if(card){const m=/openWorkDetail\((\d+)\)/.exec(card.getAttribute('onclick')||'');return m?'card:'+m[1]:null;}
    const body=fill.closest('#modal-body');return body?.dataset.detailWorkId?'detail:'+body.dataset.detailWorkId:null;
  };
  const glide=(fill,from,to,elapsed)=>{const a=fill.animate([{width:from+'%'},{width:to+'%'}],{duration:650,easing:'cubic-bezier(.22,1,.36,1)'});a.currentTime=elapsed;};
  const scan=()=>{
    document.querySelectorAll('.work-item .progress-fill, #modal-body .progress-fill').forEach(fill=>{
      if(fill.dataset.glideSeen)return;fill.dataset.glideSeen='1';
      const key=keyOf(fill);if(!key)return;
      const to=parseFloat(fill.style.width);if(!Number.isFinite(to))return;
      const from=last.get(key);last.set(key,to);
      if(tfReduce())return;
      const run=moving.get(key),now=performance.now();
      if(from!=null&&from!==to){moving.set(key,{from,to,start:now});glide(fill,from,to,0);}
      else if(run&&run.to===to&&now-run.start<650)glide(fill,run.from,to,now-run.start);
    });
  };
  new MutationObserver(scan).observe(document.body,{childList:true,subtree:true});
})();
