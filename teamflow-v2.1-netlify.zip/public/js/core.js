// ============================================================
// CONFIG — auto-detects Netlify API base URL
// ============================================================
const API = '/api';

// ============================================================
// CONSTANTS
// ============================================================
const PHASES=['Planning','Executing','Review','Finalize'];
const WORK_TYPES=[{value:'regular',label:'Regular'},{value:'adHoc',label:'Ad-hoc'}];
const ROLES=['admin','manager','member','board'];
const RECURRENCE_OPTIONS = [
  { value: '',         label: 'No recurrence' },
  { value: 'weekly',   label: 'Every week' },
  { value: 'biweekly', label: 'Every 2 weeks' },
  { value: 'monthly',  label: 'Every month' },
  { value: 'quarterly',label: 'Every 3 months' },
  { value: 'custom',   label: 'Custom (days)' },
];
const DEFAULT_PHASE_TASKS = {
  Planning:  ['Define scope, objectives & deadline','Identify team members & resources','Create project brief & risk assessment'],
  Executing: ['Assign & begin tasks','Track progress & hold sync meetings','Document updates & blockers'],
  Review:    ['Internal quality check & feedback','Manager reviews deliverables','Approve or request revisions'],
  Finalize:  ['Apply final revisions & sign-off','Deliver / publish output','Archive files & write completion notes'],
};
const PRIORITIES = ['High','Medium','Low'];
const TEAM_TIME_ZONE = 'Asia/Bangkok';
const FILE_TYPES = [
  {icon:'📁',label:'Folder',type:'folder'},
  {icon:'📄',label:'Document',type:'doc'},
  {icon:'📊',label:'Dashboard',type:'dashboard'},
  {icon:'🏢',label:'Workspace',type:'workspace'},
  {icon:'🔗',label:'Internal Link',type:'internal'},
  {icon:'📦',label:'Archive / ZIP',type:'archive'},
  {icon:'🔖',label:'Others',type:'others'},
];

// ============================================================
// STATE — loaded from Netlify Blobs via API
// ============================================================
let TEAM  = [];
let works = [];
let nextId = 1;
let nextMemberId = 1;
let nextTemplateId = 1;
let nextRequestId = 1;
let templates = [];
let joinRequests = [];
let currentUser = null;
let currentPage = 'dashboard';
let saveTimer = null;
let _bgRefreshTimer = null;
let calendarMonth=new Date().getMonth();
let calendarYear=new Date().getFullYear();
let capacityWeekOffset = 0;
let reportWeekOffset = 0;
let reportMonthOffset = 0;
let reportYearOffset = 0;
let selectedAuditTab = "weekly";
let currentSort='deadline_asc';
let feedbackItems=[];
let nextFeedbackId=1;
let _feedbackLoaded=false;
let currentFilters={workType:'',priority:'',phase:'',pic:''};
let remoteState = { works: [], team: [], collections: {}, versions: {} };
let hasPendingChanges = false;
let draftActive = false;
let syncInFlight = false;
let editGeneration = 0;
function newRecordId(){const bytes=new Uint32Array(2);crypto.getRandomValues(bytes);return (bytes[0]&0x1fffff)*4294967296+bytes[1]||newRecordId();}
let writeQueue = Promise.resolve();
let backgroundSyncTimer = null;
let notificationData = { notifications: [], unreadCount: 0, preferences: { reminderDays: [3, 0] } };
let notificationsRequest = null;
function fetchNotifications(){
  if(notificationsRequest)return notificationsRequest;
  const request=apiGet('notifications');notificationsRequest=request;
  request.finally(()=>{if(notificationsRequest===request)notificationsRequest=null;}).catch(()=>{});
  return request;
}

// ── Recurrence helpers ────────────────────────────────────
function getNextDate(deadline, recurrence, customDays) {
  if (!deadline || !recurrence) return '';
  const d = new Date(deadline);
  switch(recurrence) {
    case 'weekly':    d.setDate(d.getDate() + 7);   break;
    case 'biweekly':  d.setDate(d.getDate() + 14);  break;
    case 'monthly':   d.setMonth(d.getMonth() + 1); break;
    case 'quarterly': d.setMonth(d.getMonth() + 3); break;
    case 'custom':    d.setDate(d.getDate() + (parseInt(customDays)||7)); break;
    default: return '';
  }
  return d.toISOString().split('T')[0];
}

function getStartFromDeadline(oldStart, oldDeadline, newDeadline) {
  if (!oldStart || !oldDeadline || !newDeadline) return newDeadline;
  const duration = new Date(oldDeadline) - new Date(oldStart);
  const newStart = new Date(newDeadline);
  newStart.setTime(newStart.getTime() - duration);
  return newStart.toISOString().split('T')[0];
}

function mkPhaseTasks() { const pt={}; PHASES.forEach(p=>{pt[p]=[...DEFAULT_PHASE_TASKS[p]];}); return pt; }
function mkPhaseChecks(pt) { const pc={}; PHASES.forEach(p=>{pc[p]=new Array((pt||DEFAULT_PHASE_TASKS)[p].length).fill(false);}); return pc; }

// ============================================================
// API HELPERS
// ============================================================
function cloneValue(value) { return JSON.parse(JSON.stringify(value ?? null)); }
function comparable(value) { const copy = { ...(value || {}) }; delete copy.version; return JSON.stringify(copy); }
function comparableObject(value) { const copy = { ...(value || {}) }; delete copy.version; return copy; }
function apiFailure(message, status, payload) { const error = new Error(payload?.error || message); error.status = status; return error; }

async function apiRequest(path, options = {}) {
  let r;
  try{r=await fetch(`${API}/${path}`, { credentials: 'same-origin', ...options });}
  catch(error){updateSyncStatus('offline');throw error;}
  let payload = {};
  try { payload = await r.json(); } catch {}
  if (!r.ok){updateSyncStatus(r.status>=500?'error':'connected');throw apiFailure(`${options.method || 'GET'} ${path} failed (${r.status})`, r.status, payload);}
  updateSyncStatus('connected');
  return payload;
}
async function apiGet(path) { return apiRequest(path); }
async function sendJson(path, data, method = 'POST', extraHeaders = {}) {
  const context=typeof conflictContext==='function'?conflictContext(path,data):null;
  try{return await apiRequest(path, { method, headers: { 'Content-Type': 'application/json', ...extraHeaders }, body: JSON.stringify(data) });}
  catch(error){if(error.status===409&&context)pendingConflict=context;throw error;}
}

async function syncWorkBundle(payload) {
  const rows = Array.isArray(payload?.data) ? payload.data : [];
  const currentById = new Map(remoteState.works.map(work => [String(work.id), work]));
  const nextById = new Map(rows.map(work => [String(work.id), work]));
  for (const work of rows) {
    const old = currentById.get(String(work.id));
    if (old && comparable(old) === comparable(work)) continue;
    const result = await sendJson('works', { operation: 'upsert', work: comparableObject(work), expectedVersion: old?.version || 0 });
    Object.assign(work, result.work);
    currentById.set(String(work.id), cloneValue(result.work));
    remoteState.works=[...currentById.values()];
  }
  for (const old of remoteState.works) {
    if (nextById.has(String(old.id))) continue;
    await sendJson('works', { operation: 'delete', id: old.id, expectedVersion: old.version || 1 });
    currentById.delete(String(old.id));
    remoteState.works=[...currentById.values()];
  }
  remoteState.works = [...currentById.values()];
  for (const name of ['joinRequests', 'templates', 'feedbackItems']) {
    if(!Object.hasOwn(payload,name))continue;
    const items = Array.isArray(payload[name]) ? payload[name] : [];
    const baseItems=payload.baseCollections?.[name]||remoteState.collections[name]||[];
    if (JSON.stringify(items) === JSON.stringify(baseItems)) continue;
    const result = await sendJson('works', { operation: 'collection', name, items, baseItems:cloneValue(baseItems), expectedVersion: remoteState.versions[name] || 1 });
    const canonical=result.items||items;
    remoteState.collections[name] = cloneValue(canonical);
    const local=name==='feedbackItems'?feedbackItems:name==='joinRequests'?joinRequests:templates;
    let rebased;
    try{rebased=TeamFlowDomain.mergeCollectionChanges(canonical,items,local);}
    catch(error){error.status=error.statusCode;pendingConflict={kind:'collection',name,base:cloneValue(items),mine:cloneValue(local)};throw error;}
    if(name==='feedbackItems')feedbackItems=cloneValue(rebased);
    else if(name==='joinRequests')joinRequests=cloneValue(rebased);
    else templates=cloneValue(rebased);
    remoteState.versions[name] = result.version;
  }
  return { ok: true };
}

async function syncTeam(rows) {
  const currentById = new Map(remoteState.team.map(member => [String(member.id), member]));
  const nextById = new Map(rows.map(member => [String(member.id), member]));
  for (const member of rows) {
    const old = currentById.get(String(member.id));
    if (old && comparable(old) === comparable(member)) continue;
    const sent=cloneValue(member);
    const result = await sendJson('team', { operation: 'upsert', member: comparableObject(member), expectedVersion: old?.version || 0 });
    Object.assign(member, result.member);
    const local=TEAM.find(item=>String(item.id)===String(member.id));
    if(local&&comparable(local)===comparable(sent))Object.assign(local,result.member);
    currentById.set(String(member.id), cloneValue(result.member));
    remoteState.team=[...currentById.values()];
  }
  for (const old of remoteState.team) {
    if (nextById.has(String(old.id))) continue;
    await sendJson('team', { operation: 'delete', id: old.id, expectedVersion: old.version || 1 });
    currentById.delete(String(old.id));
    remoteState.team=[...currentById.values()];
  }
  remoteState.team = [...currentById.values()];
  return { ok: true };
}

async function apiPost(path, data) {
  if (path === 'works' && data && Array.isArray(data.data)) {
    data=cloneValue(data);
    writeQueue = writeQueue.catch(() => {}).then(() => syncWorkBundle(data));
    return writeQueue;
  }
  if (path === 'team' && Array.isArray(data)) {
    data=cloneValue(data);
    writeQueue = writeQueue.catch(() => {}).then(() => syncTeam(data));
    return writeQueue;
  }
  return sendJson(path, data);
}

// Debounced per-record saves keep local changes when the server reports a conflict.
function scheduleSave(preserveDraft=false){
  hasPendingChanges=true;editGeneration++;setSaveIndicator('saving');
  clearTimeout(saveTimer);saveTimer=setTimeout(()=>saveRequestsNow({preserveDraft,button:null}),300);
}
function beginPageRefresh(root){
  const marker=document.createElement('span');
  marker.className='refresh-status';marker.setAttribute('role','status');marker.textContent='Updating…';
  (root.querySelector('.section-header')||root).appendChild(marker);
  return marker;
}
function setButtonBusy(button){
  if(!button||button.tagName!=='BUTTON'||button.disabled)return ()=>{};
  const text=button.textContent;
  button.disabled=true;button.setAttribute('aria-busy','true');button.textContent='Saving…';
  return ()=>{button.disabled=false;button.removeAttribute('aria-busy');button.textContent=text;};
}
async function saveRequestsNow({preserveDraft=false,button=document.activeElement}={}){
  clearTimeout(saveTimer);
  saveTimer=null;
  hasPendingChanges=true;editGeneration++;
  const generation=editGeneration;
  const keepDraft=preserveDraft&&draftActive;
  const finishButton=setButtonBusy(button);
  setSaveIndicator('saving');
  const payload=cloneValue({data:works,joinRequests,templates,feedbackItems,baseCollections:remoteState.collections}),teamSnapshot=cloneValue(TEAM);
  try{
    await apiPost('works',payload);await apiPost('team',teamSnapshot);
    if(generation===editGeneration){hasPendingChanges=false;draftActive=keepDraft;pendingConflict=null;setSaveIndicator('saved');updateSyncStatus(keepDraft?'paused':'connected');}
    else {setSaveIndicator(saveTimer?'saving':'pending');return false;}
    return true;
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.status===409?'Your edits are kept. Select Review conflict to compare versions.':error.status>=400&&error.status<500?error.message+' Your edits are kept.':'Save failed. Your edits are kept; retry after checking the connection.','error');return false;}
  finally{finishButton();}
}
function setSaveIndicator(state) {
  if(state==='saving'||state==='pending'||state==='conflict')updateSyncStatus('paused');
  const el = document.getElementById('save-indicator');
  if (!el) return;
  if (state === 'saving') { el.className='save-indicator saving'; el.textContent='⏳ Saving…'; }
  else if (state === 'saved') { el.className='save-indicator saved'; el.textContent='✓ Saved'; }
  else if (state === 'pending') { el.className='save-indicator'; el.textContent='Unsaved changes'; }
  else if(state==='conflict'||state==='error'){
    el.className='save-indicator saving';el.textContent=state==='conflict'?'⚠ Save conflict — edits kept':'⚠ Save failed — edits kept';
    if(state==='conflict'&&pendingConflict){const review=document.createElement('button');review.className='btn btn-ghost btn-sm';review.textContent='Review conflict';review.onclick=()=>openConflictReview();el.appendChild(review);}
    if(state==='error'&&hasPendingChanges){
      const retry=document.createElement('button');retry.className='btn btn-ghost btn-sm';retry.textContent='Retry';
      retry.onclick=()=>saveRequestsNow({preserveDraft:true,button:retry});el.appendChild(retry);
    }
  }
  else { el.className='save-indicator'; el.textContent=''; }
  document.querySelectorAll('.work-save-status').forEach(status=>{status.textContent=el.textContent;});
  const modal=document.getElementById('modal-overlay');
  const previous=document.getElementById('modal-conflict-actions');
  if(state==='conflict'&&pendingConflict&&modal?.style.display==='flex'){
    if(!previous){
      const actions=document.createElement('div');actions.id='modal-conflict-actions';actions.className='work-update-notice';
      const text=document.createElement('span');text.textContent='Your edits are kept. Compare them with the latest saved version. ';
      const review=document.createElement('button');review.className='btn btn-ghost btn-sm';review.textContent='Review conflict';review.onclick=()=>openConflictReview();
      actions.appendChild(text);actions.appendChild(review);document.getElementById('modal-body').prepend(actions);
    }
  }else if(state!=='conflict')previous?.remove();
}

// ============================================================
// ── Boot ──────────────────────────────────────────────────
let pendingResetToken = '';

function syncBaseline(teamData, worksData) {
  updateSyncStatus('synced');
  TEAM = Array.isArray(teamData) ? teamData : [];
  works = Array.isArray(worksData?.data) ? worksData.data : [];
  joinRequests = Array.isArray(worksData?.joinRequests) ? worksData.joinRequests : [];
  templates = Array.isArray(worksData?.templates) ? worksData.templates : [];
  feedbackItems = Array.isArray(worksData?.feedbackItems) ? worksData.feedbackItems : [];
  remoteState = {
    works: cloneValue(works), team: cloneValue(TEAM),
    collections: { joinRequests: cloneValue(joinRequests), templates: cloneValue(templates), feedbackItems: cloneValue(feedbackItems) },
    versions: { ...(worksData?.versions || {}) },
  };
  nextMemberId = TEAM.length ? Math.max(...TEAM.map(member => Number(member.id) || 0)) + 1 : 1;
  nextId = works.length ? Math.max(...works.map(work => Number(work.id) || 0)) + 1 : 1;
  nextTemplateId = templates.length ? Math.max(...templates.map(item => Number(item.id) || 0)) + 1 : 1;
  nextRequestId = joinRequests.length ? Math.max(...joinRequests.map(item => Number(item.id) || 0)) + 1 : 1;
  nextFeedbackId = feedbackItems.length ? Math.max(...feedbackItems.map(item => Number(item.id) || 0)) + 1 : 1;
  works.forEach(work => {
    if (!work.workType) work.workType = 'regular';
    if (!Number.isFinite(Number(work.estimatedHours))) work.estimatedHours = 0;
    if (!Array.isArray(work.assignees)) work.assignees = [];
    if (!Array.isArray(work.tags)) work.tags = [];
    if (!Array.isArray(work.files)) work.files = [];
    if (!Array.isArray(work.notes)) work.notes = [];
    if (!work.phaseTasks) work.phaseTasks = mkPhaseTasks();
    if (!work.phaseChecks) work.phaseChecks = mkPhaseChecks(work.phaseTasks);
    work.notes = work.notes.map(note => {
      if (note.authorId) return note;
      const member = TEAM.find(item => item.name === (note.author || note.authorName));
      return { ...note, authorId: member?.id || 0, authorName: note.author || note.authorName || 'Unknown', text: note.text, createdDate: note.date || note.createdDate || todayStr, editedDate: note.editedDate || null };
    });
  });
  TEAM.forEach(member => { if (!Number.isFinite(Number(member.weeklyCapacityHours))) member.weeklyCapacityHours = 40; });
  remoteState.works = cloneValue(works);
  remoteState.team = cloneValue(TEAM);
  remoteState.collections = { joinRequests: cloneValue(joinRequests), templates: cloneValue(templates), feedbackItems: cloneValue(feedbackItems) };
}

async function loadWorkspace(user) {
  clearActiveWorkFilters();
  const [teamData, worksData] = await Promise.all([apiGet('team'), apiGet('works')]);
  syncBaseline(teamData, worksData);
  currentUser = user;
  currentUser = TEAM.find(member => String(member.id) === String(user.id)) || user;
  enterApp(currentUser, savedPage());
}

function savedPage() {
  try { return JSON.parse(localStorage.getItem('teamflow_session') || '{}').page || 'dashboard'; }
  catch { return 'dashboard'; }
}

function enterApp(user, page = 'dashboard') {
  const loginEl = document.getElementById('login-page');
  const appEl = document.getElementById('app');
  if (loginEl) loginEl.style.display = 'none';
  if (appEl) { appEl.style.display = 'flex'; appEl.classList.add('visible'); }
  const avatar = document.getElementById('sb-avatar');
  const name = document.getElementById('sb-name');
  const role = document.getElementById('sb-role');
  if (avatar) updateSidebarAvatar(user);
  if (name) name.textContent = user.name || 'Team member';
  if (role) role.textContent = `${(user.role || 'member').charAt(0).toUpperCase()}${(user.role || 'member').slice(1)}`;
  const adminNav = document.getElementById('admin-nav');
  if (adminNav) adminNav.style.display = user.role === 'admin' ? 'flex' : 'none';
  const day = document.getElementById('topbar-date');
  if (day) day.textContent = new Date().toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Bangkok' });
  const hamburger = document.getElementById('hamburger-btn');
  if (hamburger) hamburger.style.display = window.innerWidth <= 680 ? 'flex' : 'none';
  localStorage.setItem('teamflow_session', JSON.stringify({ page }));
  updateBadges();
  restoreSidebarState();
  navigate(page);
  startBackgroundSync();
}

async function boot() {
  setupKeyboardSupport();
  const loading = document.getElementById('loading-screen');
  const login = document.getElementById('login-page');
  try {
    const params = new URLSearchParams(window.location.search);
    const resetToken = params.get('reset') || params.get('invite');
    if (resetToken) {
      pendingResetToken = resetToken;
      window.history.replaceState({},'',window.location.pathname);
      showAuthPanel('reset');
      if (login) login.style.display = 'flex';
      return;
    }
    if (params.get('setup') === '1') {
      showAuthPanel('bootstrap');
      if (login) login.style.display = 'flex';
      return;
    }
    const { user } = await apiGet('auth/me');
    if (!user) throw apiFailure('Sign in to continue.', 401, {});
    await loadWorkspace(user);
  } catch (error) {
    currentUser = null;
    localStorage.removeItem('teamflow_session');
    const appEl = document.getElementById('app');
    if (appEl) appEl.style.display = 'none';
    if (login) login.style.display = 'flex';
    if (error.status && error.status !== 401) {
      const message = document.getElementById('login-error');
      if (message) { message.textContent = error.message; message.style.display = 'block'; }
    }
  } finally {
    if (loading) loading.style.display = 'none';
  }
}
function setupKeyboardSupport(){
  document.querySelectorAll('.nav-item').forEach(item=>{item.setAttribute('role','button');item.tabIndex=0;});
  document.querySelectorAll('.sidebar-section-header').forEach(item=>{item.setAttribute('role','button');item.tabIndex=0;item.setAttribute('aria-expanded',String(!document.getElementById(item.id.replace('hdr-','sec-'))?.classList.contains('collapsed')));});
  document.addEventListener('keydown',event=>{
    const target=event.target;
    if(event.key==='Escape'&&document.getElementById('modal-overlay')?.style.display==='flex'){closeModal();return;}
    if((event.key==='Enter'||event.key===' ')&&target?.matches('[role="button"], [role="checkbox"], [role="radio"], [role="tab"]')){
      event.preventDefault();target.click();
    }
    if(target?.matches('[role="radio"]')&&['ArrowRight','ArrowDown','ArrowLeft','ArrowUp'].includes(event.key)){
      event.preventDefault();const radios=[...target.parentElement.querySelectorAll('[role="radio"]')],index=radios.indexOf(target),step=['ArrowRight','ArrowDown'].includes(event.key)?1:-1,next=radios[(index+step+radios.length)%radios.length];next.focus();next.click();
    }
  });
}
// ── Background sync every 30s ─────────────────────────────
function hasOpenDraft(){
  const modal=document.getElementById('modal-overlay');
  return Boolean(document.querySelector('.app-dialog[open]')) || draftActive || hasPendingChanges || requestResolutionBusy || reminderSaveBusy || Boolean(document.getElementById('conflict-review-overlay')) || (modal && modal.style.display==='flex');
}
function openWorkModalState(){
  const modal=document.getElementById('modal-overlay'),body=document.getElementById('modal-body');
  if(modal?.style.display!=='flex')return null;
  const id=Number(body?.dataset.detailWorkId),work=works.find(item=>item.id===id);
  if(!work)return null;
  const title=document.getElementById('modal-title').textContent;
  const viewing=title===work.title&&Boolean(document.getElementById(`activity-history-${id}`));
  const editing=['Edit Work','Edit Name & Description','Add File / Folder Link'].includes(title);
  return viewing||editing?{id,viewing}:null;
}
function showWorkUpdateNotice(message){
  const body=document.getElementById('modal-body');
  let notice=document.getElementById('work-update-notice');
  if(!notice){notice=document.createElement('div');notice.id='work-update-notice';notice.className='work-update-notice';notice.setAttribute('role','status');body.prepend(notice);}
  notice.textContent=message;
}
async function backgroundSync() {
  const openWork=openWorkModalState();
  if (!currentUser || document.querySelector('.app-dialog[open]') || document.hidden || document.getElementById('conflict-review-overlay') || (hasOpenDraft()&&!openWork) || syncInFlight){if(currentUser&&(draftActive||hasPendingChanges))updateSyncStatus('paused');return;}
  syncInFlight=true;
  const generation=editGeneration,userId=currentUser.id,page=currentPage;
  try {
    const [teamData, worksData] = await Promise.all([apiGet('team'), apiGet('works')]);
    if(openWork){
      const active=openWorkModalState();
      if(!currentUser||currentUser.id!==userId||!active||active.id!==openWork.id||page!==currentPage)return;
      const latest=worksData.data.find(item=>item.id===active.id),previous=remoteState.works.find(item=>item.id===active.id);
      const workChanged=JSON.stringify(latest)!==JSON.stringify(previous);
      const blocked=Boolean(document.querySelector('.app-dialog[open]'))||!active.viewing||draftActive||hasPendingChanges||requestResolutionBusy||reminderSaveBusy||generation!==editGeneration;
      if(blocked){
        updateSyncStatus('paused');
        if(workChanged)showWorkUpdateNotice(latest?'This work was updated elsewhere. Your edits are kept. Save may require resolving a conflict.':'This work was removed or is no longer accessible. Your edits are kept.');
        return;
      }
      const changed=JSON.stringify(teamData)!==JSON.stringify(remoteState.team)||JSON.stringify(worksData)!==JSON.stringify({data:remoteState.works,...remoteState.collections,versions:remoteState.versions});
      const focused=document.activeElement;
      const modalFocus=focused&&document.getElementById('modal-overlay').contains(focused)?{id:focused.id,action:focused.getAttribute('onclick'),summary:focused.tagName==='SUMMARY',start:focused.selectionStart,end:focused.selectionEnd}:null;
      syncBaseline(teamData,worksData);
      currentUser=TEAM.find(member=>String(member.id)===String(userId))||currentUser;
      if(!latest){closeModal();await navigate(page,{preserveScroll:true});showToast('This work was removed or is no longer accessible.','info');return;}
      if(changed){
        await navigate(page,{preserveScroll:true});
        await openWorkDetail(active.id);
        if(workChanged)showWorkUpdateNotice('Updated with the latest saved changes.');
        if(modalFocus){
          const dialog=document.getElementById('modal-overlay');
          const target=modalFocus.id?document.getElementById(modalFocus.id):modalFocus.action?[...dialog.querySelectorAll('[onclick]')].find(control=>control.getAttribute('onclick')===modalFocus.action):modalFocus.summary?dialog.querySelector('.activity-history summary'):null;
          if(target){target.focus({preventScroll:true});if(typeof modalFocus.start==='number'&&target.setSelectionRange)target.setSelectionRange(modalFocus.start,modalFocus.end);}
        }
      }
      return;
    }
    if(!currentUser||currentUser.id!==userId||hasOpenDraft()||generation!==editGeneration)return;
    const changed=JSON.stringify(teamData)!==JSON.stringify(remoteState.team)||JSON.stringify(worksData.data)!==JSON.stringify(remoteState.works)||JSON.stringify(worksData.versions)!==JSON.stringify(remoteState.versions);
    syncBaseline(teamData, worksData);
    currentUser=TEAM.find(member=>String(member.id)===String(userId))||currentUser;
    if(changed&&page===currentPage)await navigate(page,{preserveScroll:true});
    else updateBadges();
  } catch(error){
    if(error.status===401)await doLogout(true);
    else if(openWork&&openWorkModalState()?.id===openWork.id)showWorkUpdateNotice('Could not check for updates. The last loaded version is shown; checking will resume when the connection returns.');
    else setSaveIndicator('error');
  }
  finally{syncInFlight=false;}
}
function startBackgroundSync() {
  clearInterval(backgroundSyncTimer);
  backgroundSyncTimer = setInterval(backgroundSync, 30000);
}
function stopBackgroundSync() { clearInterval(backgroundSyncTimer); backgroundSyncTimer = null; }

function showAuthPanel(panel) {
  const ids = { login: 'auth-login-form', request: 'auth-request-form', reset: 'auth-reset-form', bootstrap: 'auth-bootstrap-form' };
  Object.entries(ids).forEach(([key, id]) => {
    const element = document.getElementById(id);
    if (element) element.style.display = key === panel ? 'block' : 'none';
  });
  const error = document.getElementById('login-error');
  if (error) error.style.display = 'none';
}

async function requestPasswordReset() {
  showAuthPanel('request');
}

async function completePasswordReset() {
  const password = document.getElementById('reset-password')?.value || '';
  const confirmation = document.getElementById('reset-password-confirm')?.value || '';
  if (password !== confirmation) return showToast('The passwords do not match.', 'error');
  try {
    const result = await sendJson('auth/reset/complete', { token: pendingResetToken, password });
    pendingResetToken = '';
    history.replaceState({}, '', window.location.pathname);
    await loadWorkspace(result.user);
  } catch (error) {
    const message = document.getElementById('login-error');
    if (message) { message.textContent = error.message; message.style.display = 'block'; }
  }
}

async function bootstrapAdministrator() {
  const token = document.getElementById('bootstrap-token')?.value || '';
  const body = {
    name: document.getElementById('bootstrap-name')?.value.trim(),
    email: document.getElementById('bootstrap-email')?.value.trim(),
    password: document.getElementById('bootstrap-password')?.value || '',
  };
  try {
    const result = await sendJson('auth/bootstrap', body, 'POST', { 'X-Bootstrap-Token': token });
    history.replaceState({}, '', window.location.pathname);
    await loadWorkspace(result.user);
  } catch (error) {
    const message = document.getElementById('login-error');
    if (message) { message.textContent = error.message; message.style.display = 'block'; }
  }
}

async function doLogin() {
  const identifier = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const button = document.getElementById('login-submit');
  if (button) button.disabled = true;
  try {
    const result = await sendJson('auth/login', { identifier, password });
    document.getElementById('login-password').value = '';
    await loadWorkspace(result.user);
  } catch (error) {
    const message = document.getElementById('login-error');
    if (message) { message.textContent = error.message; message.style.display = 'block'; }
  } finally {
    if (button) button.disabled = false;
  }
}

async function doLogout(silent = false) {
  if (!silent && hasPendingChanges && !await appConfirm('There are unsaved changes. Sign out anyway?')) return;
  stopBackgroundSync();
  try { await sendJson('auth/logout', {}); } catch {}
  currentUser = null;
  clearActiveWorkFilters();
  closeModal();
  closeConflictReview();pendingConflict=null;lastSyncedAt=null;updateSyncStatus('connected');
  notificationsRequest=null;
  notificationData={notifications:[],unreadCount:0,preferences:{reminderDays:[3,0]}};
  hasPendingChanges = false;
  localStorage.removeItem('teamflow_session');
  const app = document.getElementById('app');
  const login = document.getElementById('login-page');
  if (app) { app.style.display = 'none'; app.classList.remove('visible'); }
  if (login) login.style.display = 'flex';
  showAuthPanel('login');
  const email = document.getElementById('login-email');
  const password = document.getElementById('login-password');
  if (email) email.value = '';
  if (password) password.value = '';
}
// UTILITIES
// ============================================================
const todayStr = TeamFlowDomain.dateKeyInZone(new Date(), TEAM_TIME_ZONE);
const todayDate = new Date(todayStr);
function fmt(d){if(!d)return'—';const date=TeamFlowDomain.parseDateKey(String(d).slice(0,10));return date?new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}).format(date):'—';}
function daysUntil(d){if(!d)return null;return Math.ceil((new Date(d)-todayDate)/86400000);}
function deadlineChip(deadline,status){
  if(status==='done')return'';const d=daysUntil(deadline);if(d===null)return'';
  if(d<0)return`<span class="deadline-chip overdue">⚠ ${Math.abs(d)}d overdue</span>`;
  if(d<=3)return`<span class="deadline-chip soon">⏰ ${d}d left</span>`;
  return`<span class="deadline-chip ok">📅 ${d}d left</span>`;
}
function getMember(id){return TEAM.find(m=>m.id===id);}
function safeProfilePhoto(value){return typeof value==='string'&&value.length<=90000&&/^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]+={0,2}$/.test(value)?value:'';}
function avatarContentHtml(member){const photo=safeProfilePhoto(member?.profilePhoto);return photo?`<img class="profile-avatar-image" src="${photo}" alt="" decoding="async">`:escapeHtml(member?.initials||'');}
function updateSidebarAvatar(member){const element=document.getElementById('sb-avatar');if(!element)return;element.innerHTML=avatarContentHtml(member);element.style.background=/^#[0-9a-f]{6}$/i.test(String(member.color||''))?member.color:'#5c6ef8';}
function avatarHtml(m,size=26){if(!m)return'';const color=/^#[0-9a-f]{6}$/i.test(String(m.color||''))?m.color:'#5c6ef8';return`<div class="assignee-avatar" role="img" style="width:${size}px;height:${size}px;background:${color};color:#fff;font-size:${Math.round(size*0.38)}px;" title="${escapeHtml(m.name)}" aria-label="${escapeHtml(m.name)}">${avatarContentHtml(m)}</div>`;}
function assigneesHtml(ids){return`<div class="assignee-list">${ids.map(id=>{const m=getMember(id);return m?avatarHtml(m):'';}).join('')}</div>`;}
function roleBadge(role){const L={admin:'Admin',manager:'Manager',member:'Member',board:'Board'};return`<span class="badge badge-${Object.hasOwn(L,role)?role:'member'}">${escapeHtml(L[role]||role)}</span>`;}
function workTypeBadge(wt){
  const isAd=wt==='adHoc';
  const c=isAd?'var(--orange)':'var(--primary)';
  const b=isAd?'var(--orange-dim)':'var(--primary-dim)';
  const br=isAd?'2px dashed var(--orange)':'1px solid rgba(59,111,212,0.2)';
  const label=isAd?'Ad-hoc':'Regular';
  return`<span class="badge" style="background:${b};color:${c};border:${br};">${label}</span>`;
}
function phaseProgress(w){let done=0,total=0;PHASES.forEach(p=>{const t=w.phaseTasks[p]||[];const c=w.phaseChecks[p]||[];total+=t.length;done+=c.filter(Boolean).length;});return total?Math.round(done/total*100):0;}
function canManageAssignments(w){return !!currentUser&&!!w&&(['admin','manager'].includes(currentUser.role)||(currentUser.role==='member'&&[w.createdBy,w.pic].some(id=>id!=null&&String(id)===String(currentUser.id))));}
function canEdit(w){
  if(!w)return false;
  if(currentUser.role==='board')return false;
  if(currentUser.role==='admin'||currentUser.role==='manager')return true;
  if(w.pic===currentUser.id)return true;
  if(w.assignees&&w.assignees.includes(currentUser.id))return true;
  return false;
}

function makeInitials(name){return name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);}
function randomColor(){const c=['#5c6ef8','#22c55e','#f59e0b','#ef4444','#a855f7','#06b6d4','#f97316','#ec4899'];return c[Math.floor(Math.random()*c.length)];}

// ============================================================
// NAVIGATION
// ============================================================
let pageRenderGeneration=0;
function capturePageScroll(){
  const elements=new Set([document.scrollingElement]);
  for(let element=document.getElementById('content');element;element=element.parentElement)elements.add(element);
  return [...elements].filter(Boolean).map(element=>({element,top:element.scrollTop,left:element.scrollLeft}));
}
function restorePageScroll(positions){
  positions.forEach(({element,top,left})=>{
    if(!element.isConnected)return;
    const behavior=element.style.scrollBehavior;
    element.style.scrollBehavior='auto';element.scrollTop=top;element.scrollLeft=left;element.style.scrollBehavior=behavior;
  });
}
async function navigate(page,{preserveScroll=false}={}){
  if(page==='notifications')page='daily-digest';
  if((hasPendingChanges||draftActive)&&page!==currentPage&&!await appConfirm('You have unsaved changes. Leave this page?'))return;
  if(page!==currentPage)draftActive=false;
  preserveScroll=preserveScroll&&page===currentPage;
  const scrollPositions=preserveScroll?capturePageScroll():null;
  const renderGeneration=++pageRenderGeneration;
  currentPage=page;
  const titles={dashboard:'Dashboard','daily-digest':'Daily Report',ongoing:'Ongoing Work',upcoming:'Schedule',history:'Work History',audit:'Audit Report',team:'Team Overview',admin:'Admin Panel',templates:'Work Templates',requests:'Join / Leave Requests',changelog:'Changelog',help:'Help & Guide',feedback:'Feedback',capacity:'Capacity',notifications:'Notifications'};
  document.getElementById('topbar-title').textContent=titles[page]||page;
  document.querySelectorAll('.nav-item').forEach(el=>el.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(el=>{if(el.getAttribute('onclick')&&el.getAttribute('onclick').includes(`'${page}'`))el.classList.add('active');});
  document.getElementById('add-work-btn').style.display=(page==='ongoing'||page==='upcoming')&&currentUser&&['admin','manager','member'].includes(currentUser.role)?'flex':'none';
  const tmplNav=document.getElementById('templates-nav');if(tmplNav)tmplNav.style.display=currentUser&&currentUser.role==='board'?'none':'flex';
  const reqNav=document.getElementById('requests-nav');if(reqNav)reqNav.style.display=currentUser&&currentUser.role==='board'?'none':'flex';
  try{ closeMobileMenu(); }catch(e){}
  // Update saved session page
  try {
    const session = localStorage.getItem('teamflow_session');
    if(session && currentUser) {
      const s = JSON.parse(session);
      s.page = page;
      localStorage.setItem('teamflow_session', JSON.stringify(s));
    }
  } catch(e) {}
  const c=document.getElementById('content');if(!preserveScroll)c.innerHTML='';
  c.getAnimations().forEach(animation=>animation.cancel());
  const renders={dashboard:renderDashboard,'daily-digest':renderDailyDigest,ongoing:renderOngoing,upcoming:renderUpcoming,history:renderHistory,audit:renderAudit,team:renderTeam,admin:renderAdmin,templates:renderTemplates,requests:renderRequests,changelog:renderChangelog,help:renderHelp,feedback:renderFeedback,capacity:renderCapacity,notifications:renderNotifications};
  const rendered=renders[page]?(preserveScroll&&['requests','feedback'].includes(page)?renders[page](false):renders[page]()):null;
  updateBadges();
  if(!preserveScroll&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    c.animate([{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'translateY(0)'}],{duration:250,easing:'ease'});
  }
  if(preserveScroll){
    const restore=()=>{if(currentPage===page&&renderGeneration===pageRenderGeneration)restorePageScroll(scrollPositions);};
    restore();
    return Promise.resolve(rendered).then(restore);
  }
  return rendered;
}

// ============================================================
// DASHBOARD
// ============================================================
function showToast(msg,type='info'){const t=document.getElementById('toast');t.textContent=msg;t.className=`show ${type}`;setTimeout(()=>{t.className='';},3000);}
async function updateBadges(){
  document.getElementById('ongoing-badge').textContent=works.filter(w=>w.status==='ongoing').length;
  const ov=getOverdue(),rr=getReviewReady(),db=document.getElementById('digest-badge');
  if(ov.length>0){db.style.display='';db.textContent=ov.length;db.style.background='var(--red)';db.style.color='#fff';}
  else if(rr.length>0){db.style.display='';db.textContent=rr.length;db.style.background='var(--yellow)';db.style.color='#000';}
  else{db.style.display='none';}
  updateRequestsBadge();
  try {
    const userId=currentUser?.id,generation=editGeneration;
    const latest=await fetchNotifications();
    if(currentUser?.id!==userId||generation!==editGeneration)return;
    notificationData=latest;
    ['notification-badge'].forEach(id => {
      const badge = document.getElementById(id);
      if (!badge) return;
      badge.textContent = notificationData.unreadCount || 0;
      badge.style.display = notificationData.unreadCount ? '' : 'none';
    });
  } catch {}
}
function getWorkloadLevel(count){
  const level=count===0?0:count===1?1:count<=3?2:count<=5?3:4;
  const colors=['var(--text3)','var(--green)','#eab308','var(--orange)','var(--red)'];
  return {level,color:colors[level]};
}
function renderDashboard(){
  const hour=new Date().getHours();
  const greeting=hour<12?'Good morning':hour<18?'Good afternoon':'Good evening';
  const ongoing=works.filter(w=>w.status==='ongoing'),done=works.filter(w=>w.status==='done'),upcoming=works.filter(w=>w.status==='upcoming');
  const overdue=getOverdue(),rr=getReviewReady(),onTime=done.filter(w=>w.completedDate&&w.completedDate<=w.deadline);
  let html=`<div class="section-header"><div><div class="section-title">${greeting}, ${escapeHtml(currentUser.name.split(' ')[0])}! 👋</div></div></div>`;
  if(rr.length>0)html+=`<div class="review-banner"><div style="font-size:22px;">🔍</div><div style="flex:1;"><div class="review-banner-title">${rr.length} item${rr.length>1?'s':''} ready for review!</div><div class="review-banner-sub">${rr.map(w=>escapeHtml(w.title)).join(', ')}</div></div><button class="btn btn-ghost btn-sm dashboard-view-action" onclick="navigate('ongoing')">View <svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></button></div>`;
  if(overdue.length>0)html+=`<div class="review-banner" style="background:var(--red-dim);border-color:rgba(239,68,68,0.3);"><div style="font-size:22px;">⚠️</div><div style="flex:1;"><div class="review-banner-title" style="color:var(--red-ink);">${overdue.length} overdue item${overdue.length>1?'s':''}!</div><div class="review-banner-sub">${overdue.map(w=>escapeHtml(w.title)).join(', ')}</div></div><button class="btn btn-ghost btn-sm dashboard-view-action" onclick="navigate('ongoing')">View <svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></button></div>`;
  html+=`<div class="grid-4 dashboard-kpis" style="margin-bottom:20px;">
    <div class="stat-card"><div class="stat-label">Ongoing</div><div class="stat-value" style="color:var(--primary-light);">${ongoing.length}</div><div class="stat-sub">active projects</div></div>
    <div class="stat-card"><div class="stat-label">Upcoming</div><div class="stat-value" style="color:var(--purple);">${upcoming.length}</div><div class="stat-sub">scheduled</div></div>
    <div class="stat-card"><div class="stat-label">Completed</div><div class="stat-value" style="color:var(--green);">${done.length}</div><div class="stat-sub">${onTime.length} on time</div></div>
    <div class="stat-card"><div class="stat-label">Overdue</div><div class="stat-value" style="color:${overdue.length>0?'var(--red)':'var(--green)'};">${overdue.length}</div><div class="stat-sub">${overdue.length===0?'All on track!':'needs attention'}</div></div>
  </div>`;
  const urgent = works.filter(w=>w.status!=='done'&&w.deadline).sort((a,b)=>a.deadline.localeCompare(b.deadline)).slice(0,8);
  html+=`<div class="grid-2 dashboard-panels">
    <div class="card"><div class="card-header"><div class="card-title">🔄 Active Work</div><button class="btn btn-ghost btn-sm" onclick="navigate('ongoing')">See all</button></div>`;
  if(!ongoing.length)html+=`<div class="empty-state"><div class="icon">📭</div><p>No ongoing work</p></div>`;
  [...ongoing].sort((a,b)=>(a.deadline||'9999-12-31').localeCompare(b.deadline||'9999-12-31')||Number(a.id)-Number(b.id)).slice(0,6).forEach(w=>{const prog=phaseProgress(w),days=daysUntil(w.deadline);html+=`<div style="padding:10px 0;border-bottom:1px solid var(--border);cursor:pointer;" onclick="openWorkDetail(${w.id})"><div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;"><span class="badge badge-${PHASES[w.phase].toLowerCase()}">${PHASES[w.phase]}</span><span class="badge badge-priority-${(w.priority||'Medium').toLowerCase()}">${escapeHtml(w.priority||'Medium')}</span><span style="font-size:13px;font-weight:600;flex:1;min-width:0;">${escapeHtml(w.title)}</span>${days<0?'<span style="font-size:11px;color:var(--red);">⚠ Overdue</span>':days<=3?`<span style="font-size:11px;color:var(--yellow-ink);">⏰ ${days}d</span>`:''}</div><div class="progress-bar"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div><div style="display:flex;justify-content:space-between;margin-top:4px;"><span style="font-size:11px;color:var(--text3);">${prog}% complete</span><span style="font-size:11px;color:var(--text3);">Due ${fmt(w.deadline)}</span></div></div>`;});
  html+=`</div>`;
  html+=`<div class="card"><div class="card-header dashboard-phase-header"><div class="card-title">📊 Work by Phase</div><button class="btn btn-ghost btn-sm" onclick="navigate('ongoing')">See all</button></div>`;
  PHASES.forEach((phase,index)=>{
    const count=ongoing.filter(work=>Number(work.phase)===index).length;
    const percent=ongoing.length?Math.round(count/ongoing.length*100):0;
    const color=['var(--primary)','var(--orange)','var(--yellow)','var(--green)'][index];
    html+=`<div style="margin-bottom:14px;"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;"><span class="badge badge-${phase.toLowerCase()}">${phase}</span><span style="font-size:12px;color:var(--text3);"><strong style="color:var(--text);">${count}</strong> item${count!==1?'s':''} · ${percent}%</span></div><div class="perf-bar"><div class="perf-bar-fill" style="width:${percent}%;background:${color};"></div></div></div>`;
  });
  html+=`<div class="card-title dashboard-priority-title">📊 Work by Priority</div>`;
  PRIORITIES.forEach(priority=>{
    const count=ongoing.filter(work=>work.priority===priority).length;
    const percent=ongoing.length?Math.round(count/ongoing.length*100):0;
    const color=priority==='High'?'var(--red)':priority==='Medium'?'var(--yellow)':'var(--green)';
    html+=`<div style="margin-bottom:14px;"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;"><span class="badge badge-priority-${priority.toLowerCase()}">${priority}</span><span style="font-size:12px;color:var(--text3);"><strong style="color:var(--text);">${count}</strong> item${count!==1?'s':''} · ${percent}%</span></div><div class="perf-bar"><div class="perf-bar-fill" style="width:${percent}%;background:${color};"></div></div></div>`;
  });
  html+=`</div>`;
  html+=`<div class="card"><div class="card-header dashboard-due-header"><div class="card-title">📅 Due Soon</div><button class="btn btn-ghost btn-sm" onclick="openDailyNotifications()">Reminders</button></div>`;
  if(!urgent.length)html+=`<div class="empty-state"><div class="icon">🎉</div><p>No upcoming deadlines</p></div>`;
  urgent.forEach(w=>{html+=`<div class="digest-row" onclick="openWorkDetail(${w.id})" style="cursor:pointer;"><span class="badge badge-${w.status==='upcoming'?'upcoming':PHASES[w.phase].toLowerCase()}">${w.status==='upcoming'?'Upcoming':PHASES[w.phase]}</span><span class="badge badge-priority-${(w.priority||'Medium').toLowerCase()}">${escapeHtml(w.priority||'Medium')}</span><span style="flex:1;font-size:13px;min-width:0;">${escapeHtml(w.title)}</span>${deadlineChip(w.deadline,w.status)}<span style="font-size:11px;color:var(--text3);">${fmt(w.deadline)}</span></div>`;});
  html+=`</div>`;
  html+=`<div class="card"><div class="card-header"><div class="card-title">👥 Team Workload</div><button type="button" class="btn btn-ghost btn-sm" onclick="navigate('capacity')">View capacity</button></div>`;
  const workloadTeam=TEAM.filter(m=>['member','manager'].includes(m.role)&&m.active!==false);
  if(!workloadTeam.length)html+=`<div class="empty-state"><p>No active team members</p></div>`;
  workloadTeam.forEach(m=>{
    const load=ongoing.filter(w=>(w.assignees||[]).includes(m.id)).length;
    const {level,color}=getWorkloadLevel(load);
    html+=`<div class="member-perf-row">${avatarHtml(m,32)}<div style="flex:1;min-width:0;"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:6px;"><span style="font-size:13px;font-weight:600;">${escapeHtml(m.name)}</span><span style="font-size:12px;color:var(--text3);">${load} work item${load!==1?'s':''}</span></div><div class="perf-bar" role="meter" aria-label="${escapeHtml(m.name)} ongoing assignments" aria-valuemin="0" aria-valuemax="${Math.max(6,load)}" aria-valuenow="${load}" aria-valuetext="${load} ongoing work items"><div class="perf-bar-fill" style="width:${level*25}%;background:${color};"></div></div></div></div>`;
  });
  html+=`</div></div>`;
  document.getElementById('content').innerHTML=html;
}

// ============================================================

window.addEventListener('focus',()=>backgroundSync());
document.addEventListener('visibilitychange',()=>{if(!document.hidden)backgroundSync();});
function trackDraftInput(event){const el=event.target;if((el.id&&/^(f-|fb-|p-|em-|m-|t-|et-|en-|end-|file-|new-note-text)/.test(el.id))||el.closest?.('.reminder-options')){draftActive=true;editGeneration++;}}
document.addEventListener('input',trackDraftInput);
document.addEventListener('change',trackDraftInput);
window.addEventListener('beforeunload',event=>{if(hasPendingChanges||draftActive){event.preventDefault();event.returnValue='';}});

// App dialogs keep confirmation and text-entry flows inside the application.
let appDialogQueue = Promise.resolve();
function appConfirm(message){return enqueueAppDialog({message});}
function appPrompt(message,value=''){return enqueueAppDialog({message,value,prompt:true});}
function appAlert(message){return enqueueAppDialog({message,alert:true});}
function enqueueAppDialog(options){
  const pending=appDialogQueue.then(()=>showAppDialog(options));
  appDialogQueue=pending.catch(()=>{});
  return pending;
}
function showAppDialog(options){
  return new Promise(resolve=>{
    const previousFocus=document.activeElement,userId=currentUser?.id;
    const destructive=/^(Delete|Remove)\b/i.test(options.message);
    const dialog=document.createElement('dialog');
    dialog.className='app-dialog';
    dialog.setAttribute('aria-labelledby','app-dialog-title');
    dialog.setAttribute('aria-describedby','app-dialog-message');
    dialog.innerHTML='<form method="dialog"><div class="app-dialog-body"><h2 id="app-dialog-title"></h2><p id="app-dialog-message"></p><div class="app-dialog-entry" hidden><label for="app-dialog-input">Template name</label><input id="app-dialog-input" class="app-input" type="text" maxlength="200" autocomplete="off"></div></div><div class="app-dialog-actions"><button type="button" class="btn btn-ghost" data-cancel>Cancel</button><button type="submit" class="btn btn-primary" value="accept" data-accept></button></div></form>';
    dialog.querySelector('h2').textContent=options.prompt?'Save as template':options.alert?'Notice':destructive?'Confirm deletion':'Confirm action';
    dialog.querySelector('p').textContent=options.message;
    const input=dialog.querySelector('input'),cancel=dialog.querySelector('[data-cancel]'),accept=dialog.querySelector('[data-accept]');
    accept.textContent=options.prompt?'Save template':options.alert?'OK':destructive?'Delete':'Continue';
    if(destructive)accept.className='btn app-dialog-danger';
    if(options.prompt){dialog.querySelector('.app-dialog-entry').hidden=false;input.value=options.value;input.required=true;}
    if(options.alert)cancel.hidden=true;
    cancel.addEventListener('click',()=>dialog.close('cancel'));
    dialog.addEventListener('keydown',event=>{if(event.key==='Escape')event.stopPropagation();});
    dialog.querySelector('form').addEventListener('submit',event=>{
      if(options.prompt&&!input.value.trim()){event.preventDefault();input.setCustomValidity('Enter a template name.');input.reportValidity();}
    });
    input.addEventListener('input',()=>input.setCustomValidity(''));
    dialog.addEventListener('close',()=>{
      const accepted=dialog.returnValue==='accept'&&userId===currentUser?.id;
      const result=options.prompt?(accepted?input.value.trim():null):accepted;
      dialog.remove();
      if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});
      resolve(result);
    },{once:true});
    document.body.append(dialog);
    dialog.showModal();
    if(options.prompt){input.focus();input.select();}else(options.alert?accept:cancel).focus();
  });
}