// ============================================================
// CONFIG — auto-detects Netlify API base URL
// ============================================================
const API = '/api';

// ============================================================
// CONSTANTS
// ============================================================
const PHASES=['Planning','Executing','Review','Finalize'];
const WORK_TYPES=[{value:'regular',label:'Regular'},{value:'adHoc',label:'Ad-hoc'}];
const ROLES=['admin','manager','member','board'];
const RECURRENCE_OPTIONS = [
  { value: '',         label: 'No recurrence' },
  { value: 'weekly',   label: 'Every week' },
  { value: 'biweekly', label: 'Every 2 weeks' },
  { value: 'monthly',  label: 'Every month' },
  { value: 'quarterly',label: 'Every 3 months' },
  { value: 'custom',   label: 'Custom (days)' },
];
const DEFAULT_PHASE_TASKS = {
  Planning:  ['Define scope, objectives & deadline','Identify team members & resources','Create project brief & risk assessment'],
  Executing: ['Assign & begin tasks','Track progress & hold sync meetings','Document updates & blockers'],
  Review:    ['Internal quality check & feedback','Manager reviews deliverables','Approve or request revisions'],
  Finalize:  ['Apply final revisions & sign-off','Deliver / publish output','Archive files & write completion notes'],
};
const PRIORITIES = ['High','Medium','Low'];
const TEAM_TIME_ZONE = 'Asia/Bangkok';
const FILE_TYPE_ICONS={folder:'folder',doc:'file',dashboard:'chart',workspace:'briefcase',internal:'paperclip',archive:'box',others:'tag',notes:'note',design:'pen',sheet:'chart',checklist:'check-circle',media:'file'};
function fileTypeIconHtml(type){return`<svg class="ui-icon" aria-hidden="true"><use href="#i-${FILE_TYPE_ICONS[type]||'file'}"/></svg>`;}
const FILE_TYPES = [
  {icon:'📁',label:'Folder',type:'folder'},
  {icon:'📄',label:'Document',type:'doc'},
  {icon:'📊',label:'Dashboard',type:'dashboard'},
  {icon:'🏢',label:'Workspace',type:'workspace'},
  {icon:'🔗',label:'Internal Link',type:'internal'},
  {icon:'📦',label:'Archive / ZIP',type:'archive'},
  {icon:'🔖',label:'Others',type:'others'},
];

// ============================================================
// STATE — loaded from Netlify Blobs via API
// ============================================================
let TEAM  = [];
let works = [];
let nextId = 1;
let nextMemberId = 1;
let nextTemplateId = 1;
let nextRequestId = 1;
let templates = [];
let joinRequests = [];
let currentUser = null;
let currentPage = 'dashboard';
let saveTimer = null;
let _bgRefreshTimer = null;
let calendarMonth=new Date().getMonth();
let calendarYear=new Date().getFullYear();
let capacityWeekOffset = 0;
let reportWeekOffset = 0;
let reportMonthOffset = 0;
let reportYearOffset = 0;
let selectedAuditTab = "weekly";
let currentSort='deadline_asc';
let feedbackItems=[];
let tagOptions=[];
let noteReads={since:new Date().toISOString(),seen:{}};
let nextFeedbackId=1;
let _feedbackLoaded=false;
let currentFilters={workType:'',priority:'',phase:'',pic:''};
let remoteState = { works: [], team: [], collections: {}, versions: {} };
let hasPendingChanges = false;
let draftActive = false;
let syncInFlight = false;
let editGeneration = 0;
function newRecordId(){const bytes=new Uint32Array(2);crypto.getRandomValues(bytes);return (bytes[0]&0x1fffff)*4294967296+bytes[1]||newRecordId();}
let writeQueue = Promise.resolve();
let backgroundSyncTimer = null;
let workspaceRevisionSeen = null;
let workspaceFullSyncAt = 0;
let workspaceSyncDay = '';
let syncFailures = 0, syncRetryAt = 0, lastSyncCheckAt = 0;
let syncChannel = null, syncLeaseKey = '', sharedWorkspaceUpdate = null;
const syncTabId = typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : String(newRecordId());
function releaseSyncLease(){
  if(syncLeaseKey)try{const lease=JSON.parse(localStorage.getItem(syncLeaseKey)||'null');if(lease?.owner===syncTabId)localStorage.removeItem(syncLeaseKey);}catch{}
}
function closeSyncChannel() {
  if (syncLeaseKey) try { const lease=JSON.parse(localStorage.getItem(syncLeaseKey)||'null');if(lease?.owner===syncTabId)localStorage.removeItem(syncLeaseKey); } catch {}
  syncChannel?.close();syncChannel=null;syncLeaseKey='';sharedWorkspaceUpdate=null;
}
function openSyncChannel() {
  closeSyncChannel();
  if (typeof BroadcastChannel !== 'function' || !currentUser) return;
  const scope='teamflow-sync-'+currentUser.id+'-'+(currentUser.authVersion||1);
  syncLeaseKey=scope+'-lease';syncChannel=new BroadcastChannel(scope);
  syncChannel.onmessage=event=>{
    const packet=event.data;
    if(!currentUser||packet?.userId!==currentUser.id||packet.sender===syncTabId||Date.now()-packet.sentAt>30000)return;
    if(!packet.teamData||!packet.worksData)return;
    sharedWorkspaceUpdate=packet;
    backgroundSync({fromBroadcast:true});
  };
}
async function ownsSyncLease() {
  if(!syncChannel||!syncLeaseKey)return true;
  const claim=()=>{
    try {
      const now=Date.now(),lease=JSON.parse(localStorage.getItem(syncLeaseKey)||'null');
      if(lease&&lease.owner!==syncTabId&&lease.expiresAt>now)return false;
      localStorage.setItem(syncLeaseKey,JSON.stringify({owner:syncTabId,expiresAt:now+35000}));
      return JSON.parse(localStorage.getItem(syncLeaseKey)||'null')?.owner===syncTabId;
    } catch {return true;}
  };
  if(typeof navigator!=='undefined'&&navigator.locks?.request)return navigator.locks.request(syncLeaseKey,{mode:'exclusive'},claim);
  return claim();
}
function broadcastWorkspace() {
  if(!syncChannel||!currentUser)return;
  syncChannel.postMessage({sender:syncTabId,userId:currentUser.id,sentAt:Date.now(),revision:workspaceRevisionSeen,
    teamData:remoteState.team,worksData:{data:remoteState.works,...remoteState.collections,versions:remoteState.versions}});
}
const FULL_SYNC_INTERVAL = 5 * 60 * 1000;
async function checkWorkspaceRevision() {
  try {
    const result = await apiGet('works?check=1');
    return typeof result.revision === 'string' ? result.revision : null;
  } catch (error) {
    if (error.status !== 404) throw error;
    return null; // Older endpoints fall back to a full refresh.
  }
}
function rememberWorkspaceRevision(revision) {
  workspaceRevisionSeen = revision;
  workspaceFullSyncAt = Date.now();
  workspaceSyncDay = new Intl.DateTimeFormat('en-CA', { timeZone: TEAM_TIME_ZONE }).format(new Date());
}
// ── Recurrence helpers ────────────────────────────────────
function getNextDate(deadline, recurrence, customDays) {
  if (!deadline || !recurrence) return '';
  const d = new Date(deadline);
  switch(recurrence) {
    case 'weekly':    d.setDate(d.getDate() + 7);   break;
    case 'biweekly':  d.setDate(d.getDate() + 14);  break;
    case 'monthly':   d.setMonth(d.getMonth() + 1); break;
    case 'quarterly': d.setMonth(d.getMonth() + 3); break;
    case 'custom':    d.setDate(d.getDate() + (parseInt(customDays)||7)); break;
    default: return '';
  }
  return d.toISOString().split('T')[0];
}

function getStartFromDeadline(oldStart, oldDeadline, newDeadline) {
  if (!oldStart || !oldDeadline || !newDeadline) return newDeadline;
  const duration = new Date(oldDeadline) - new Date(oldStart);
  const newStart = new Date(newDeadline);
  newStart.setTime(newStart.getTime() - duration);
  return newStart.toISOString().split('T')[0];
}

function mkPhaseTasks() { const pt={}; PHASES.forEach(p=>{pt[p]=[...DEFAULT_PHASE_TASKS[p]];}); return pt; }
function mkPhaseChecks(pt) { const pc={}; PHASES.forEach(p=>{pc[p]=new Array((pt||DEFAULT_PHASE_TASKS)[p].length).fill(false);}); return pc; }

// ============================================================
// API HELPERS
// ============================================================
function cloneValue(value) { return JSON.parse(JSON.stringify(value ?? null)); }
function comparable(value) { const copy = { ...(value || {}) }; delete copy.version; return JSON.stringify(copy); }
function comparableObject(value) { const copy = { ...(value || {}) }; delete copy.version; return copy; }
function apiFailure(message, status, payload) { const error = new Error(payload?.error || message); error.status = status; return error; }

async function apiRequest(path, options = {}) {
  let r;
  try{const read=!options.method||options.method==='GET';const signal=read&&typeof AbortSignal!=='undefined'&&AbortSignal.timeout?AbortSignal.timeout(15000):undefined;r=await fetch(`${API}/${path}`, { credentials: 'same-origin', ...(signal?{signal}:{}), ...options });}
  catch(error){updateSyncStatus('offline');throw error;}
  let payload = {};
  try { payload = await r.json(); } catch {}
  if (!r.ok){updateSyncStatus(r.status>=500?'error':'connected');throw apiFailure(`${options.method || 'GET'} ${path} failed (${r.status})`, r.status, payload);}
  updateSyncStatus('connected');
  return payload;
}
async function apiGet(path) { return apiRequest(path); }
async function sendJson(path, data, method = 'POST', extraHeaders = {}) {
  const context=typeof conflictContext==='function'?conflictContext(path,data):null;
  try{return await apiRequest(path, { method, headers: { 'Content-Type': 'application/json', ...extraHeaders }, body: JSON.stringify(data) });}
  catch(error){if(error.status===409&&context)pendingConflict=context;throw error;}
}

async function syncWorkBundle(payload) {
  const rows = Array.isArray(payload?.data) ? payload.data : [];
  const currentById = new Map(remoteState.works.map(work => [String(work.id), work]));
  const nextById = new Map(rows.map(work => [String(work.id), work]));
  for (const work of rows) {
    const old = currentById.get(String(work.id));
    if (old && comparable(old) === comparable(work)) continue;
    const result = await sendJson('works', { operation: 'upsert', work: comparableObject(work), expectedVersion: old?.version || 0 });
    Object.assign(work, result.work);
    currentById.set(String(work.id), cloneValue(result.work));
    remoteState.works=[...currentById.values()];
  }
  for (const old of remoteState.works) {
    if (nextById.has(String(old.id))) continue;
    await sendJson('works', { operation: 'delete', id: old.id, expectedVersion: old.version || 1 });
    currentById.delete(String(old.id));
    remoteState.works=[...currentById.values()];
  }
  remoteState.works = [...currentById.values()];
  for (const name of ['joinRequests', 'templates', 'feedbackItems', 'tagOptions']) {
    if(!Object.hasOwn(payload,name))continue;
    const items = Array.isArray(payload[name]) ? payload[name] : [];
    const baseItems=payload.baseCollections?.[name]||remoteState.collections[name]||[];
    if (JSON.stringify(items) === JSON.stringify(baseItems)) continue;
    const result = await sendJson('works', { operation: 'collection', name, items, baseItems:cloneValue(baseItems), expectedVersion: remoteState.versions[name] || 1 });
    const canonical=result.items||items;
    remoteState.collections[name] = cloneValue(canonical);
    const local=name==='feedbackItems'?feedbackItems:name==='joinRequests'?joinRequests:name==='tagOptions'?tagOptions:templates;
    let rebased;
    try{rebased=TeamFlowDomain.mergeCollectionChanges(canonical,items,local);}
    catch(error){error.status=error.statusCode;pendingConflict={kind:'collection',name,base:cloneValue(items),mine:cloneValue(local)};throw error;}
    if(name==='feedbackItems')feedbackItems=cloneValue(rebased);
    else if(name==='joinRequests')joinRequests=cloneValue(rebased);
    else if(name==='tagOptions')tagOptions=cloneValue(rebased);
    else templates=cloneValue(rebased);
    remoteState.versions[name] = result.version;
  }
  return { ok: true };
}

async function syncTeam(rows) {
  const currentById = new Map(remoteState.team.map(member => [String(member.id), member]));
  const nextById = new Map(rows.map(member => [String(member.id), member]));
  for (const member of rows) {
    const old = currentById.get(String(member.id));
    if (old && comparable(old) === comparable(member)) continue;
    const sent=cloneValue(member);
    const result = await sendJson('team', { operation: 'upsert', member: comparableObject(member), expectedVersion: old?.version || 0 });
    Object.assign(member, result.member);
    const local=TEAM.find(item=>String(item.id)===String(member.id));
    if(local&&comparable(local)===comparable(sent))Object.assign(local,result.member);
    currentById.set(String(member.id), cloneValue(result.member));
    remoteState.team=[...currentById.values()];
  }
  for (const old of remoteState.team) {
    if (nextById.has(String(old.id))) continue;
    await sendJson('team', { operation: 'delete', id: old.id, expectedVersion: old.version || 1 });
    currentById.delete(String(old.id));
    remoteState.team=[...currentById.values()];
  }
  remoteState.team = [...currentById.values()];
  return { ok: true };
}

async function apiPost(path, data) {
  if (path === 'works' && data && Array.isArray(data.data)) {
    data=cloneValue(data);
    writeQueue = writeQueue.catch(() => {}).then(() => syncWorkBundle(data));
    return writeQueue;
  }
  if (path === 'team' && Array.isArray(data)) {
    data=cloneValue(data);
    writeQueue = writeQueue.catch(() => {}).then(() => syncTeam(data));
    return writeQueue;
  }
  return sendJson(path, data);
}

// Debounced per-record saves keep local changes when the server reports a conflict.
function scheduleSave(preserveDraft=false){
  hasPendingChanges=true;editGeneration++;setSaveIndicator('saving');
  clearTimeout(saveTimer);saveTimer=setTimeout(()=>saveRequestsNow({preserveDraft,button:null}),300);
}
function beginPageRefresh(root){
  const marker=document.createElement('span');
  marker.className='refresh-status';marker.setAttribute('role','status');marker.textContent='Updating…';
  (root.querySelector('.section-header')||root).appendChild(marker);
  return marker;
}
function setButtonBusy(button){
  if(!button||button.tagName!=='BUTTON'||button.disabled)return ()=>{};
  const html=button.innerHTML;
  button.disabled=true;button.setAttribute('aria-busy','true');button.textContent='Saving…';
  return ()=>{button.disabled=false;button.removeAttribute('aria-busy');button.innerHTML=html;};
}
async function saveRequestsNow({preserveDraft=false,button=document.activeElement}={}){
  clearTimeout(saveTimer);
  saveTimer=null;
  hasPendingChanges=true;editGeneration++;
  const generation=editGeneration;
  const keepDraft=preserveDraft&&draftActive;
  const finishButton=setButtonBusy(button);
  setSaveIndicator('saving');
  const payload=cloneValue({data:works,joinRequests,templates,feedbackItems,tagOptions,baseCollections:remoteState.collections}),teamSnapshot=cloneValue(TEAM);
  try{
    await apiPost('works',payload);await apiPost('team',teamSnapshot);
    if(generation===editGeneration){hasPendingChanges=false;draftActive=keepDraft;pendingConflict=null;setSaveIndicator('saved');updateSyncStatus(keepDraft?'paused':'connected');}
    else {setSaveIndicator(saveTimer?'saving':'pending');return false;}
    return true;
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.status===409?'Your edits are kept. Select Review conflict to compare versions.':error.status>=400&&error.status<500?error.message+' Your edits are kept.':'Save failed. Your edits are kept; retry after checking the connection.','error');return false;}
  finally{finishButton();}
}
function setSaveIndicator(state) {
  if(state==='saving'||state==='pending'||state==='conflict')updateSyncStatus('paused');
  const el = document.getElementById('save-indicator');
  if (!el) return;
  if (state === 'saving') { el.className='save-indicator saving'; el.textContent='⏳ Saving…'; }
  else if (state === 'saved') { el.className='save-indicator saved'; el.textContent='✓ Saved'; }
  else if (state === 'pending') { el.className='save-indicator'; el.textContent='Unsaved changes'; }
  else if(state==='conflict'||state==='error'){
    el.className='save-indicator saving';el.textContent=state==='conflict'?'Save conflict — edits kept':'Save failed — edits kept';
    if(state==='conflict'&&pendingConflict){const review=document.createElement('button');review.className='btn btn-ghost btn-sm';review.textContent='Review conflict';review.onclick=()=>openConflictReview();el.appendChild(review);}
    if(state==='error'&&hasPendingChanges){
      const retry=document.createElement('button');retry.className='btn btn-ghost btn-sm';retry.textContent='Retry';
      retry.onclick=()=>saveRequestsNow({preserveDraft:true,button:retry});el.appendChild(retry);
    }
  }
  else { el.className='save-indicator'; el.textContent=''; }
  document.querySelectorAll('.work-save-status').forEach(status=>{status.textContent=el.textContent;});
  const modal=document.getElementById('modal-overlay');
  const previous=document.getElementById('modal-conflict-actions');
  if(state==='conflict'&&pendingConflict&&modal?.style.display==='flex'){
    if(!previous){
      const actions=document.createElement('div');actions.id='modal-conflict-actions';actions.className='work-update-notice';
      const text=document.createElement('span');text.textContent='Your edits are kept. Compare them with the latest saved version. ';
      const review=document.createElement('button');review.className='btn btn-ghost btn-sm';review.textContent='Review conflict';review.onclick=()=>openConflictReview();
      actions.appendChild(text);actions.appendChild(review);document.getElementById('modal-body').prepend(actions);
    }
  }else if(state!=='conflict')previous?.remove();
}

// ============================================================
// ── Boot ──────────────────────────────────────────────────
let pendingResetToken = '';

function syncBaseline(teamData, worksData) {
  updateSyncStatus('synced');
  TEAM = Array.isArray(teamData) ? teamData : [];
  works = Array.isArray(worksData?.data) ? worksData.data : [];
  joinRequests = Array.isArray(worksData?.joinRequests) ? worksData.joinRequests : [];
  templates = Array.isArray(worksData?.templates) ? worksData.templates : [];
  feedbackItems = Array.isArray(worksData?.feedbackItems) ? worksData.feedbackItems : [];
  tagOptions = Array.isArray(worksData?.tagOptions) ? worksData.tagOptions : [];
  remoteState = {
    works: cloneValue(works), team: cloneValue(TEAM),
    collections: { joinRequests: cloneValue(joinRequests), templates: cloneValue(templates), feedbackItems: cloneValue(feedbackItems), tagOptions: cloneValue(tagOptions) },
    versions: { ...(worksData?.versions || {}) },
  };
  nextMemberId = TEAM.length ? Math.max(...TEAM.map(member => Number(member.id) || 0)) + 1 : 1;
  nextId = works.length ? Math.max(...works.map(work => Number(work.id) || 0)) + 1 : 1;
  nextTemplateId = templates.length ? Math.max(...templates.map(item => Number(item.id) || 0)) + 1 : 1;
  nextRequestId = joinRequests.length ? Math.max(...joinRequests.map(item => Number(item.id) || 0)) + 1 : 1;
  nextFeedbackId = feedbackItems.length ? Math.max(...feedbackItems.map(item => Number(item.id) || 0)) + 1 : 1;
  works.forEach(work => {
    if (!work.workType) work.workType = 'regular';
    if (!Number.isFinite(Number(work.estimatedHours))) work.estimatedHours = 0;
    if (!Array.isArray(work.assignees)) work.assignees = [];
    if (!Array.isArray(work.tags)) work.tags = [];
    if (!Array.isArray(work.files)) work.files = [];
    if (!Array.isArray(work.notes)) work.notes = [];
    if (!work.phaseTasks) work.phaseTasks = mkPhaseTasks();
    if (!work.phaseChecks) work.phaseChecks = mkPhaseChecks(work.phaseTasks);
    work.notes = work.notes.map(note => {
      if (note.authorId) return note;
      const member = TEAM.find(item => item.name === (note.author || note.authorName));
      return { ...note, authorId: member?.id || 0, authorName: note.author || note.authorName || 'Unknown', text: note.text, createdDate: note.date || note.createdDate || todayStr, editedDate: note.editedDate || null };
    });
  });
  TEAM.forEach(member => { if (!Number.isFinite(Number(member.weeklyCapacityHours))) member.weeklyCapacityHours = 40; });
  remoteState.works = cloneValue(works);
  remoteState.team = cloneValue(TEAM);
  remoteState.collections = { joinRequests: cloneValue(joinRequests), templates: cloneValue(templates), feedbackItems: cloneValue(feedbackItems), tagOptions: cloneValue(tagOptions) };
  if (typeof afterWorkspaceSync === 'function') setTimeout(afterWorkspaceSync, 0);
}

async function loadWorkspace(user) {
  clearActiveWorkFilters();
  workspaceRevisionSeen = null;
  const revision = await checkWorkspaceRevision();
  const [teamData, worksData, reads, meetingData, absenceData] = await Promise.all([apiGet('team'), apiGet('works'), apiGet('reads').catch(() => null), apiGet('meetings').catch(() => null), apiGet('absences').catch(() => null)]);
  noteReads = reads?.seen ? reads : { since: new Date().toISOString(), seen: {} };
  syncBaseline(teamData, worksData);
  rememberWorkspaceRevision(revision);
  currentUser = user;
  currentUser = TEAM.find(member => String(member.id) === String(user.id)) || user;
  meetings = meetingData?.items || [];dismissedMeetingBanners.clear();
  absences = absenceData?.items || [];
  enterApp(currentUser, savedPage());
  updateMeetingBanner();
}

function savedPage() {
  try { return JSON.parse(localStorage.getItem('teamflow_session') || '{}').page || 'dashboard'; }
  catch { return 'dashboard'; }
}

function enterApp(user, page = 'dashboard') {
  const loginEl = document.getElementById('login-page');
  const appEl = document.getElementById('app');
  if (loginEl) loginEl.style.display = 'none';
  if (appEl) { appEl.style.display = 'flex'; appEl.classList.add('visible'); }
  const avatar = document.getElementById('sb-avatar');
  const name = document.getElementById('sb-name');
  const role = document.getElementById('sb-role');
  if (avatar) updateSidebarAvatar(user);
  if (name) name.textContent = user.name || 'Team member';
  if (role) role.textContent = `${(user.role || 'member').charAt(0).toUpperCase()}${(user.role || 'member').slice(1)}`;
  const adminNav = document.getElementById('admin-nav');
  if (adminNav) adminNav.style.display = user.role === 'admin' ? 'flex' : 'none';
  const day = document.getElementById('topbar-date');
  if (day) day.textContent = new Date().toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Bangkok' });
  const hamburger = document.getElementById('hamburger-btn');
  if (hamburger) hamburger.style.display = window.innerWidth <= 680 ? 'flex' : 'none';
  localStorage.setItem('teamflow_session', JSON.stringify({ page }));
  updateBadges();
  restoreSidebarState();
  navigate(page);
  startBackgroundSync();
}

async function boot() {
  setupKeyboardSupport();
  const loading = document.getElementById('loading-screen');
  const login = document.getElementById('login-page');
  try {
    const params = new URLSearchParams(window.location.search);
    const resetToken = params.get('reset') || params.get('invite');
    if (resetToken) {
      pendingResetToken = resetToken;
      window.history.replaceState({},'',window.location.pathname);
      showAuthPanel('reset');
      if (login) login.style.display = 'flex';
      return;
    }
    if (params.get('setup') === '1') {
      showAuthPanel('bootstrap');
      if (login) login.style.display = 'flex';
      return;
    }
    const { user } = await apiGet('auth/me');
    if (!user) throw apiFailure('Sign in to continue.', 401, {});
    await loadWorkspace(user);
  } catch (error) {
    currentUser = null;
    localStorage.removeItem('teamflow_session');
    const appEl = document.getElementById('app');
    if (appEl) appEl.style.display = 'none';
    if (login) login.style.display = 'flex';
    if (error.status && error.status !== 401) {
      const message = document.getElementById('login-error');
      if (message) { message.textContent = error.message; message.style.display = 'block'; }
    }
  } finally {
    if (loading) loading.style.display = 'none';
  }
}
function setupKeyboardSupport(){
  document.querySelectorAll('.nav-item').forEach(item=>{item.setAttribute('role','button');item.tabIndex=0;});
  document.querySelectorAll('.sidebar-section-header').forEach(item=>{item.setAttribute('role','button');item.tabIndex=0;item.setAttribute('aria-expanded',String(!document.getElementById(item.id.replace('hdr-','sec-'))?.classList.contains('collapsed')));});
  document.addEventListener('keydown',event=>{
    const target=event.target;
    if(event.key==='Escape'&&document.getElementById('modal-overlay')?.style.display==='flex'){closeModal();return;}
    if((event.key==='Enter'||event.key===' ')&&target?.matches('[role="button"], [role="checkbox"], [role="radio"], [role="tab"]')){
      event.preventDefault();target.click();
    }
    if(target?.matches('[role="radio"]')&&['ArrowRight','ArrowDown','ArrowLeft','ArrowUp'].includes(event.key)){
      event.preventDefault();const radios=[...target.parentElement.querySelectorAll('[role="radio"]')],index=radios.indexOf(target),step=['ArrowRight','ArrowDown'].includes(event.key)?1:-1,next=radios[(index+step+radios.length)%radios.length];next.focus();next.click();
    }
  });
}
// ── Background sync every 30s ─────────────────────────────
function hasOpenDraft(){
  const modal=document.getElementById('modal-overlay');
  return Boolean(document.querySelector('.app-dialog[open]')) || draftActive || hasPendingChanges || requestResolutionBusy || Boolean(document.getElementById('conflict-review-overlay')) || (modal && modal.style.display==='flex');
}
function openWorkModalState(){
  const modal=document.getElementById('modal-overlay'),body=document.getElementById('modal-body');
  if(modal?.style.display!=='flex')return null;
  const id=Number(body?.dataset.detailWorkId),work=works.find(item=>item.id===id);
  if(!work)return null;
  const title=document.getElementById('modal-title').textContent;
  const viewing=title===work.title&&Boolean(document.getElementById(`activity-history-${id}`));
  const editing=['Edit Work','Edit Name & Description','Add File / Folder Link'].includes(title);
  return viewing||editing?{id,viewing}:null;
}
function showWorkUpdateNotice(message){
  const body=document.getElementById('modal-body');
  let notice=document.getElementById('work-update-notice');
  if(!notice){notice=document.createElement('div');notice.id='work-update-notice';notice.className='work-update-notice';notice.setAttribute('role','status');body.prepend(notice);}
  notice.textContent=message;
}
async function backgroundSync({force=false,fromBroadcast=false}={}) {
  const openWork=openWorkModalState();
  if (!currentUser || document.querySelector('.app-dialog[open]') || document.hidden || document.getElementById('conflict-review-overlay') || (hasOpenDraft()&&!openWork) || syncInFlight){if(currentUser&&(draftActive||hasPendingChanges))updateSyncStatus('paused');if(!syncInFlight)releaseSyncLease();return;}
  syncInFlight=true;
  const generation=editGeneration,userId=currentUser.id,page=currentPage;
  let shareSync=false;
  try {
    if(!fromBroadcast&&!force&&(Date.now()<syncRetryAt||Date.now()-lastSyncCheckAt<1000))return;
    if(!fromBroadcast&&!force&&!await ownsSyncLease())return;
    const packet=fromBroadcast?sharedWorkspaceUpdate:null;
    sharedWorkspaceUpdate=null;
    if(fromBroadcast&&!packet)return;
    lastSyncCheckAt=Date.now();
    const revision = packet ? packet.revision : await checkWorkspaceRevision();
    if (!currentUser || currentUser.id !== userId) return;
    const day = new Intl.DateTimeFormat('en-CA', { timeZone: TEAM_TIME_ZONE }).format(new Date());
    if (revision !== null && revision === workspaceRevisionSeen
        && Date.now() - workspaceFullSyncAt < FULL_SYNC_INTERVAL && day === workspaceSyncDay) {
      await updateBadges();
      shareSync=true;syncFailures=0;syncRetryAt=0;
      return;
    }
    // Keep the revision read BEFORE the data: a concurrent save will trigger the next check.
    const refresh=Date.now()-workspaceFullSyncAt>=FULL_SYNC_INTERVAL;
    const [teamData, worksData] = packet?[packet.teamData,packet.worksData]:await Promise.all([apiGet('team'),apiGet(refresh?'works?refresh=1':'works')]);
    if(openWork){
      const active=openWorkModalState();
      if(!currentUser||currentUser.id!==userId||!active||active.id!==openWork.id||page!==currentPage)return;
      const latest=worksData.data.find(item=>item.id===active.id),previous=remoteState.works.find(item=>item.id===active.id);
      const workChanged=JSON.stringify(latest)!==JSON.stringify(previous);
      const blocked=Boolean(document.querySelector('.app-dialog[open]'))||!active.viewing||draftActive||hasPendingChanges||requestResolutionBusy||generation!==editGeneration;
      if(blocked){
        updateSyncStatus('paused');
        if(workChanged)showWorkUpdateNotice(latest?'This work was updated elsewhere. Your edits are kept. Save may require resolving a conflict.':'This work was removed or is no longer accessible. Your edits are kept.');
        return;
      }
      const changed=JSON.stringify(teamData)!==JSON.stringify(remoteState.team)||JSON.stringify(worksData)!==JSON.stringify({data:remoteState.works,...remoteState.collections,versions:remoteState.versions});
      const focused=document.activeElement;
      const modalFocus=focused&&document.getElementById('modal-overlay').contains(focused)?{id:focused.id,action:focused.getAttribute('onclick'),summary:focused.tagName==='SUMMARY',start:focused.selectionStart,end:focused.selectionEnd}:null;
      syncBaseline(teamData,worksData);
      rememberWorkspaceRevision(revision);
      currentUser=TEAM.find(member=>String(member.id)===String(userId))||currentUser;
      shareSync=true;
      if(!latest){closeModal();await navigate(page,{preserveScroll:true});showToast('This work was removed or is no longer accessible.','info');return;}
      if(changed){
        await navigate(page,{preserveScroll:true});
        await openWorkDetail(active.id);
        if(workChanged)showWorkUpdateNotice('Updated with the latest saved changes.');
        if(modalFocus){
          const dialog=document.getElementById('modal-overlay');
          const target=modalFocus.id?document.getElementById(modalFocus.id):modalFocus.action?[...dialog.querySelectorAll('[onclick]')].find(control=>control.getAttribute('onclick')===modalFocus.action):modalFocus.summary?dialog.querySelector('.activity-history summary'):null;
          if(target){target.focus({preventScroll:true});if(typeof modalFocus.start==='number'&&target.setSelectionRange)target.setSelectionRange(modalFocus.start,modalFocus.end);}
        }
      }
      return;
    }
    if(!currentUser||currentUser.id!==userId||hasOpenDraft()||generation!==editGeneration)return;
    const changed=JSON.stringify(teamData)!==JSON.stringify(remoteState.team)||JSON.stringify(worksData.data)!==JSON.stringify(remoteState.works)||JSON.stringify(worksData.versions)!==JSON.stringify(remoteState.versions);
    syncBaseline(teamData, worksData);
    rememberWorkspaceRevision(revision);
    currentUser=TEAM.find(member=>String(member.id)===String(userId))||currentUser;
    shareSync=true;
    if(changed&&page===currentPage)await navigate(page,{preserveScroll:true});
    else await updateBadges();
    syncFailures=0;syncRetryAt=0;
  } catch(error){
    shareSync=false;syncFailures++;syncRetryAt=Date.now()+Math.min(300000,30000*2**Math.min(syncFailures-1,4));
    if(syncLeaseKey)try{const lease=JSON.parse(localStorage.getItem(syncLeaseKey)||'null');if(lease?.owner===syncTabId)localStorage.setItem(syncLeaseKey,JSON.stringify({...lease,expiresAt:syncRetryAt+1000}));}catch{}
    if(error.status===401)await doLogout(true);
    else if(openWork&&openWorkModalState()?.id===openWork.id)showWorkUpdateNotice('Could not check for updates. The last loaded version is shown; checking will resume when the connection returns.');
    else setSaveIndicator('error');
  }
  finally{syncInFlight=false;if(shareSync&&!fromBroadcast&&currentUser)broadcastWorkspace();}
}
function startBackgroundSync() {
  clearInterval(backgroundSyncTimer);
  openSyncChannel();
  backgroundSyncTimer = setInterval(backgroundSync, 30000);
}
function stopBackgroundSync() { clearInterval(backgroundSyncTimer); backgroundSyncTimer = null; workspaceRevisionSeen = null; workspaceFullSyncAt = 0; workspaceSyncDay = ''; syncFailures=0;syncRetryAt=0;lastSyncCheckAt=0;closeSyncChannel(); }

function showAuthPanel(panel) {
  const ids = { login: 'auth-login-form', request: 'auth-request-form', reset: 'auth-reset-form', bootstrap: 'auth-bootstrap-form' };
  Object.entries(ids).forEach(([key, id]) => {
    const element = document.getElementById(id);
    if (element) element.style.display = key === panel ? 'block' : 'none';
  });
  const error = document.getElementById('login-error');
  if (error) error.style.display = 'none';
}

async function requestPasswordReset() {
  showAuthPanel('request');
}

async function completePasswordReset() {
  const password = document.getElementById('reset-password')?.value || '';
  const confirmation = document.getElementById('reset-password-confirm')?.value || '';
  if (password !== confirmation) return showToast('The passwords do not match.', 'error');
  try {
    const result = await sendJson('auth/reset/complete', { token: pendingResetToken, password });
    pendingResetToken = '';
    history.replaceState({}, '', window.location.pathname);
    await loadWorkspace(result.user);
  } catch (error) {
    const message = document.getElementById('login-error');
    if (message) { message.textContent = error.message; message.style.display = 'block'; }
  }
}

async function bootstrapAdministrator() {
  const token = document.getElementById('bootstrap-token')?.value || '';
  const body = {
    name: document.getElementById('bootstrap-name')?.value.trim(),
    email: document.getElementById('bootstrap-email')?.value.trim(),
    password: document.getElementById('bootstrap-password')?.value || '',
  };
  try {
    const result = await sendJson('auth/bootstrap', body, 'POST', { 'X-Bootstrap-Token': token });
    history.replaceState({}, '', window.location.pathname);
    await loadWorkspace(result.user);
  } catch (error) {
    const message = document.getElementById('login-error');
    if (message) { message.textContent = error.message; message.style.display = 'block'; }
  }
}

async function doLogin() {
  const identifier = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const button = document.getElementById('login-submit');
  const label = button?.querySelector('span');
  const originalLabel = label?.textContent;
  const loading = document.getElementById('loading-screen');
  if (button) button.disabled = true;
  if (label) label.textContent = 'Signing in…';
  document.getElementById('login-error')?.style && (document.getElementById('login-error').style.display = 'none');
  try {
    const result = await sendJson('auth/login', { identifier, password });
    document.getElementById('login-password').value = '';
    // Credentials accepted: show the app skeleton while the workspace loads instead of leaving the login form frozen.
    if (loading) loading.style.display = 'flex';
    await loadWorkspace(result.user);
  } catch (error) {
    const message = document.getElementById('login-error');
    if (message) { message.textContent = error.message; message.style.display = 'block'; }
  } finally {
    if (loading) loading.style.display = 'none';
    if (button) button.disabled = false;
    if (label && originalLabel) label.textContent = originalLabel;
  }
}

async function doLogout(silent = false) {
  const button = document.querySelector('.logout-btn');
  if (button?.classList.contains('is-loading')) return;
  if (!silent && hasPendingChanges && !await appConfirm('There are unsaved changes. Sign out anyway?')) return;
  const originalHtml = button?.innerHTML;
  if (button) { button.classList.add('is-loading'); button.setAttribute('aria-busy', 'true'); button.innerHTML = '<span class="btn-spinner" aria-hidden="true"></span> Signing out…'; }
  stopBackgroundSync();
  // Only an explicit sign-out stops alerts on this device; an expired session keeps them flowing until the next sign-in.
  if (!silent && typeof removePushSubscription === 'function') await removePushSubscription();
  try { await sendJson('auth/logout', {}); } catch {}
  currentUser = null;
  clearActiveWorkFilters();
  closeModal();
  closeConflictReview();pendingConflict=null;lastSyncedAt=null;updateSyncStatus('connected');
  hasPendingChanges = false;
  localStorage.removeItem('teamflow_session');
  const app = document.getElementById('app');
  const login = document.getElementById('login-page');
  if (app) { app.style.display = 'none'; app.classList.remove('visible'); }
  if (login) login.style.display = 'flex';
  showAuthPanel('login');
  const email = document.getElementById('login-email');
  const password = document.getElementById('login-password');
  if (email) email.value = '';
  if (password) password.value = '';
  if (button) { button.classList.remove('is-loading'); button.removeAttribute('aria-busy'); button.innerHTML = originalHtml; }
}
// UTILITIES
// ============================================================
const todayStr = TeamFlowDomain.dateKeyInZone(new Date(), TEAM_TIME_ZONE);
const todayDate = new Date(todayStr);
function fmt(d){if(!d)return'—';const date=TeamFlowDomain.parseDateKey(String(d).slice(0,10));return date?new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}).format(date):'—';}
function daysUntil(d){if(!d)return null;return Math.ceil((new Date(d)-todayDate)/86400000);}
function deadlineChip(deadline,status){
  if(status==='done')return'';const d=daysUntil(deadline);if(d===null)return'';
  if(d<0)return`<span class="deadline-chip overdue"><svg class="ui-icon" aria-hidden="true"><use href="#i-alert"/></svg> ${Math.abs(d)}d overdue</span>`;
  if(d<=3)return`<span class="deadline-chip soon"><svg class="ui-icon" aria-hidden="true"><use href="#i-clock"/></svg> ${d}d left</span>`;
  return`<span class="deadline-chip ok"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> ${d}d left</span>`;
}
function getMember(id){return TEAM.find(m=>m.id===id);}
function safeProfilePhoto(value){return typeof value==='string'&&value.length<=90000&&/^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]+={0,2}$/.test(value)?value:'';}
function avatarContentHtml(member){const photo=safeProfilePhoto(member?.profilePhoto);return photo?`<img class="profile-avatar-image" src="${photo}" alt="" decoding="async">`:escapeHtml(member?.initials||'');}
function avatarTextColor(color){
  const luminance=hex=>{const rgb=hex.slice(1).match(/.{2}/g).map(value=>parseInt(value,16)/255).map(value=>value<=0.04045?value/12.92:((value+0.055)/1.055)**2.4);return rgb[0]*0.2126+rgb[1]*0.7152+rgb[2]*0.0722;};
  const background=luminance(color);
  if(1.05/(background+0.05)>=4.5)return '#fff';
  const dark=luminance('#111827');
  return (background+0.05)/(dark+0.05)>=4.5?'#111827':'#000';
}
const AVATAR_COLORS=[{hex:'#34507F',name:'Navy'},{hex:'#1F6F78',name:'Teal'},{hex:'#2F6B4F',name:'Forest'},{hex:'#8A6D3B',name:'Bronze'},{hex:'#9A5B2E',name:'Copper'},{hex:'#7B2D3B',name:'Burgundy'},{hex:'#5B3F7A',name:'Plum'},{hex:'#4A5568',name:'Graphite'}];
const LEGACY_AVATAR_COLORS={'#5c6ef8':'#34507F','#06b6d4':'#1F6F78','#22c55e':'#2F6B4F','#f59e0b':'#8A6D3B','#f97316':'#9A5B2E','#ef4444':'#7B2D3B','#a855f7':'#5B3F7A','#ec4899':'#4A5568'};
function avatarColor(value){const color=String(value||'').toLowerCase();if(!/^#[0-9a-f]{6}$/.test(color))return AVATAR_COLORS[0].hex;return LEGACY_AVATAR_COLORS[color]||value;}
function updateSidebarAvatar(member){const element=document.getElementById('sb-avatar');if(!element)return;const color=avatarColor(member.color);element.innerHTML=avatarContentHtml(member);element.style.background=color;element.style.color=avatarTextColor(color);}
function avatarHtml(m,size=26){if(!m)return'';const color=avatarColor(m.color);return`<div class="assignee-avatar" role="img" style="width:${size}px;height:${size}px;background:${color};color:${avatarTextColor(color)};font-size:${Math.round(size*0.38)}px;" title="${escapeHtml(m.name)}" aria-label="${escapeHtml(m.name)}">${avatarContentHtml(m)}</div>`;}
function assigneesHtml(ids){return`<div class="assignee-list">${ids.map(id=>{const m=getMember(id);return m?avatarHtml(m):'';}).join('')}</div>`;}
function roleBadge(role){const L={admin:'Admin',manager:'Manager',member:'Member',board:'Board'};return`<span class="badge badge-${Object.hasOwn(L,role)?role:'member'}">${escapeHtml(L[role]||role)}</span>`;}
function workTypeBadge(wt){
  const isAd=wt==='adHoc';
  const c=isAd?'var(--orange)':'var(--primary)';
  const b=isAd?'var(--orange-dim)':'var(--primary-dim)';
  const br=isAd?'2px dashed var(--orange)':'1px solid rgba(59,111,212,0.2)';
  const label=isAd?'Ad-hoc':'Regular';
  return`<span class="badge" style="background:${b};color:${c};border:${br};">${label}</span>`;
}
function phaseProgress(w){let done=0,total=0;PHASES.forEach(p=>{const t=w.phaseTasks[p]||[];const c=w.phaseChecks[p]||[];total+=t.length;done+=c.filter(Boolean).length;});return total?Math.round(done/total*100):0;}
function canManageAssignments(w){return !!currentUser&&!!w&&(['admin','manager'].includes(currentUser.role)||(currentUser.role==='member'&&[w.createdBy,w.pic].some(id=>id!=null&&String(id)===String(currentUser.id))));}
function canEdit(w){
  if(!w)return false;
  if(currentUser.role==='board')return false;
  if(currentUser.role==='admin'||currentUser.role==='manager')return true;
  if(w.pic===currentUser.id)return true;
  if(w.assignees&&w.assignees.includes(currentUser.id))return true;
  return false;
}

function makeInitials(name){return name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);}
function randomColor(){return AVATAR_COLORS[Math.floor(Math.random()*AVATAR_COLORS.length)].hex;}

// ============================================================
// NAVIGATION
// ============================================================
let pageRenderGeneration=0;
function capturePageScroll(){
  const elements=new Set([document.scrollingElement]);
  for(let element=document.getElementById('content');element;element=element.parentElement)elements.add(element);
  return [...elements].filter(Boolean).map(element=>({element,top:element.scrollTop,left:element.scrollLeft}));
}
function restorePageScroll(positions){
  positions.forEach(({element,top,left})=>{
    if(!element.isConnected)return;
    const behavior=element.style.scrollBehavior;
    element.style.scrollBehavior='auto';element.scrollTop=top;element.scrollLeft=left;element.style.scrollBehavior=behavior;
  });
}
async function navigate(page,{preserveScroll=false}={}){
  if(page==='capacity')loadAbsences().then(()=>{if(currentPage==='capacity')renderCapacity();});
  if(page==='notifications'||page==='daily-digest')page='dashboard'; // Redirect older saved page selections.
  if((hasPendingChanges||draftActive)&&page!==currentPage&&!await appConfirm('You have unsaved changes. Leave this page?'))return;
  if(page!==currentPage)draftActive=false;
  preserveScroll=preserveScroll&&page===currentPage;
  const scrollPositions=preserveScroll?capturePageScroll():null;
  const renderGeneration=++pageRenderGeneration;
  currentPage=page;
  const titles={dashboard:'Dashboard',ongoing:'Ongoing Work',meetings:'Meetings',upcoming:'Schedule',history:'Work History',audit:'Audit Report',team:'Team Overview',admin:'Admin Panel',templates:'Work Templates',requests:'Join / Leave Requests',changelog:'Changelog',help:'Help & Guide',feedback:'Feedback',capacity:'Capacity'};
  document.getElementById('topbar-title').textContent=titles[page]||page;
  document.querySelectorAll('.nav-item').forEach(el=>el.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(el=>{if(el.getAttribute('onclick')&&el.getAttribute('onclick').includes(`'${page}'`))el.classList.add('active');});
  document.getElementById('add-work-btn').style.display=(page==='ongoing'||page==='upcoming')&&currentUser&&['admin','manager','member'].includes(currentUser.role)?'flex':'none';
  document.getElementById('add-meeting-btn').style.display=page==='meetings'&&canCreateMeeting()?'flex':'none';
  document.getElementById('add-member-btn').style.display=page==='admin'&&currentUser?.role==='admin'?'flex':'none';
  const tmplNav=document.getElementById('templates-nav');if(tmplNav)tmplNav.style.display=currentUser&&currentUser.role==='board'?'none':'flex';
  const reqNav=document.getElementById('requests-nav');if(reqNav)reqNav.style.display=currentUser&&currentUser.role==='board'?'none':'flex';
  try{ closeMobileMenu(); }catch(e){}
  // Update saved session page
  try {
    const session = localStorage.getItem('teamflow_session');
    if(session && currentUser) {
      const s = JSON.parse(session);
      s.page = page;
      localStorage.setItem('teamflow_session', JSON.stringify(s));
    }
  } catch(e) {}
  const c=document.getElementById('content');if(!preserveScroll)c.innerHTML='';
  c.getAnimations().forEach(animation=>animation.cancel());
  const renders={dashboard:renderDashboard,ongoing:renderOngoing,meetings:renderMeetings,upcoming:renderUpcoming,history:renderHistory,audit:renderAudit,team:renderTeam,admin:renderAdmin,templates:renderTemplates,requests:renderRequests,changelog:renderChangelog,help:renderHelp,feedback:renderFeedback,capacity:renderCapacity};
  const rendered=renders[page]?(preserveScroll&&['requests','feedback'].includes(page)?renders[page](false):renders[page]()):null;
  updateBadges();
  if(!preserveScroll&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){
    c.animate([{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'translateY(0)'}],{duration:250,easing:'ease'});
  }
  if(preserveScroll){
    const restore=()=>{if(currentPage===page&&renderGeneration===pageRenderGeneration)restorePageScroll(scrollPositions);};
    restore();
    return Promise.resolve(rendered).then(restore);
  }
  return rendered;
}

// ============================================================
// DASHBOARD
// ============================================================
function showToast(msg,type='info'){const t=document.getElementById('toast');t.textContent=msg;t.className=`show ${type}`;setTimeout(()=>{t.className='';},3000);}
async function updateBadges(){
  document.getElementById('ongoing-badge').textContent=works.filter(w=>w.status==='ongoing').length;
  const ov=getOverdue(),rr=getReviewReady(),db=document.getElementById('digest-badge');
  if(ov.length>0){db.style.display='';db.textContent=ov.length;db.style.background='var(--red)';db.style.color='#fff';}
  else if(rr.length>0){db.style.display='';db.textContent=rr.length;db.style.background='var(--yellow)';db.style.color='#000';}
  else{db.style.display='none';}
  updateRequestsBadge();
}

function getWorkloadLevel(count){
  const level=count===0?0:count===1?1:count<=3?2:count<=5?3:4;
  const colors=['var(--text3)','var(--green)','#eab308','var(--orange)','var(--red)'];
  return {level,color:colors[level]};
}
function renderDashboard(){
  const hour=new Date().getHours();
  const greeting=hour<12?'Good morning':hour<18?'Good afternoon':'Good evening';
  const ongoing=works.filter(w=>w.status==='ongoing'),done=works.filter(w=>w.status==='done'),upcoming=works.filter(w=>w.status==='upcoming');
  const overdue=getOverdue(),rr=getReviewReady(),onTime=done.filter(w=>w.completedDate&&w.completedDate<=w.deadline);
  let html=`<div class="section-header"><div><div class="section-title">${greeting}, ${escapeHtml(currentUser.name.split(' ')[0])}!</div></div><button type="button" class="btn btn-ghost btn-sm" onclick="exportDailyReportPDF()"><svg class="ui-icon" aria-hidden="true"><use href="#i-file"/></svg> Export PDF</button></div>`;
  html+=`<div class="grid-4 dashboard-kpis" style="margin-bottom:20px;">
    <div class="stat-card"><div class="stat-label">Ongoing</div><div class="stat-value">${ongoing.length}</div><div class="stat-sub">active projects</div></div>
    <div class="stat-card"><div class="stat-label">Upcoming</div><div class="stat-value">${upcoming.length}</div><div class="stat-sub">scheduled</div></div>
    <div class="stat-card"><div class="stat-label">Completed</div><div class="stat-value">${done.length}</div><div class="stat-sub">${onTime.length} on time</div></div>
    <div class="stat-card"><div class="stat-label">Overdue</div><div class="stat-value"${overdue.length>0?' style="color:var(--red);"':''}>${overdue.length}</div><div class="stat-sub">${overdue.length===0?'All on track!':'needs attention'}</div></div>
  </div>`;
  if(rr.length>0&&!myReviewQueue().length)html+=`<div class="review-banner"><span class="review-banner-icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-search"/></svg></span><div class="review-banner-text"><div class="review-banner-title">${rr.length} item${rr.length>1?'s':''} ready for review</div><div class="review-banner-sub">${rr.map(w=>escapeHtml(w.title)).join(', ')}</div></div><button class="btn btn-ghost btn-sm dashboard-view-action" onclick="openReviewReady()">View <svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></button></div>`;
  if(overdue.length>0)html+=`<div class="review-banner review-banner-overdue"><span class="review-banner-icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-alert"/></svg></span><div class="review-banner-text"><div class="review-banner-title">${overdue.length} overdue item${overdue.length>1?'s':''}</div><div class="review-banner-sub">${overdue.map(w=>escapeHtml(w.title)).join(', ')}</div></div><button class="btn btn-ghost btn-sm dashboard-view-action" onclick="navigate('ongoing')">View <svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></button></div>`;
  html+=`<div class="dash-focus">${reviewQueueHtml()}${todayMeetingsHtml()}</div>`;
  const urgent = works.filter(w=>w.status!=='done'&&w.deadline).sort((a,b)=>a.deadline.localeCompare(b.deadline)).slice(0,8);
  html+=`<div class="grid-2 dashboard-panels">
    <div class="card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-sync"/></svg> Active Work</div><button class="btn btn-ghost btn-sm" onclick="navigate('ongoing')">See all</button></div>`;
  if(!ongoing.length)html+=`<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-inbox"/></svg></div><p>No ongoing work</p></div>`;
  [...ongoing].sort((a,b)=>(a.deadline||'9999-12-31').localeCompare(b.deadline||'9999-12-31')||Number(a.id)-Number(b.id)).slice(0,6).forEach(w=>{const prog=phaseProgress(w),days=daysUntil(w.deadline);html+=`<div style="padding:10px 0;border-bottom:1px solid var(--border);cursor:pointer;" onclick="openWorkDetail(${w.id})"><div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;"><span class="badge badge-${PHASES[w.phase].toLowerCase()}">${PHASES[w.phase]}</span><span class="badge badge-priority-${(w.priority||'Medium').toLowerCase()}">${escapeHtml(w.priority||'Medium')}</span><span style="font-size:13px;font-weight:600;flex:1;min-width:0;">${escapeHtml(w.title)}${unreadBadgeHtml(w)}</span>${days<0?'<span style="font-size:11px;color:var(--red);"><svg class="ui-icon" aria-hidden="true"><use href="#i-alert"/></svg> Overdue</span>':days<=3?`<span style="font-size:11px;color:var(--yellow-ink);"><svg class="ui-icon" aria-hidden="true"><use href="#i-clock"/></svg> ${days}d</span>`:''}</div><div class="progress-bar"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div><div style="display:flex;justify-content:space-between;margin-top:4px;"><span style="font-size:11px;color:var(--text3);">${prog}% complete</span><span style="font-size:11px;color:var(--text3);">Due ${fmt(w.deadline)}</span></div></div>`;});
  html+=`</div>`;
  html+=`<div class="card"><div class="card-header dashboard-phase-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-chart"/></svg> Work by Phase</div><button class="btn btn-ghost btn-sm" onclick="navigate('ongoing')">See all</button></div>`;
  PHASES.forEach((phase,index)=>{
    const count=ongoing.filter(work=>Number(work.phase)===index).length;
    const percent=ongoing.length?Math.round(count/ongoing.length*100):0;
    const color=['var(--primary)','var(--orange)','var(--yellow)','var(--green)'][index];
    html+=`<div style="margin-bottom:14px;"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;"><span class="badge badge-${phase.toLowerCase()}">${phase}</span><span style="font-size:12px;color:var(--text3);"><strong style="color:var(--text);">${count}</strong> item${count!==1?'s':''} · ${percent}%</span></div><div class="perf-bar"><div class="perf-bar-fill" style="width:${percent}%;background:${color};"></div></div></div>`;
  });
  html+=`<div class="card-title dashboard-priority-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-chart"/></svg> Work by Priority</div>`;
  PRIORITIES.forEach(priority=>{
    const count=ongoing.filter(work=>work.priority===priority).length;
    const percent=ongoing.length?Math.round(count/ongoing.length*100):0;
    const color=priority==='High'?'var(--red)':priority==='Medium'?'var(--yellow)':'var(--green)';
    html+=`<div style="margin-bottom:14px;"><div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;"><span class="badge badge-priority-${priority.toLowerCase()}">${priority}</span><span style="font-size:12px;color:var(--text3);"><strong style="color:var(--text);">${count}</strong> item${count!==1?'s':''} · ${percent}%</span></div><div class="perf-bar"><div class="perf-bar-fill" style="width:${percent}%;background:${color};"></div></div></div>`;
  });
  html+=`</div>`;
  html+=`<div class="card"><div class="card-header dashboard-due-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> Due Soon</div></div>`;
  if(!urgent.length)html+=`<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg></div><p>No upcoming deadlines</p></div>`;
  urgent.forEach(w=>{html+=`<div class="digest-row" onclick="openWorkDetail(${w.id})" style="cursor:pointer;"><span class="badge badge-${w.status==='upcoming'?'upcoming':PHASES[w.phase].toLowerCase()}">${w.status==='upcoming'?'Upcoming':PHASES[w.phase]}</span><span class="badge badge-priority-${(w.priority||'Medium').toLowerCase()}">${escapeHtml(w.priority||'Medium')}</span><span style="flex:1;font-size:13px;min-width:0;">${escapeHtml(w.title)}</span>${deadlineChip(w.deadline,w.status)}<span style="font-size:11px;color:var(--text3);">${fmt(w.deadline)}</span></div>`;});
  html+=`</div>`;
  html+=`<div class="card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-users"/></svg> Team Workload</div><button type="button" class="btn btn-ghost btn-sm" onclick="navigate('capacity')">View capacity</button></div>`;
  const workloadTeam=TEAM.filter(m=>['member','manager'].includes(m.role)&&m.active!==false);
  if(!workloadTeam.length)html+=`<div class="empty-state"><p>No active team members</p></div>`;
  workloadTeam.forEach(m=>{
    const load=ongoing.filter(w=>(w.assignees||[]).includes(m.id)).length;
    const {level,color}=getWorkloadLevel(load);
    html+=`<div class="member-perf-row">${avatarHtml(m,32)}<div style="flex:1;min-width:0;"><div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;margin-bottom:6px;"><span style="font-size:13px;font-weight:600;">${escapeHtml(m.name)}</span><span style="font-size:12px;color:var(--text3);">${load} work item${load!==1?'s':''}</span></div><div class="perf-bar" role="meter" aria-label="${escapeHtml(m.name)} ongoing assignments" aria-valuemin="0" aria-valuemax="${Math.max(6,load)}" aria-valuenow="${load}" aria-valuetext="${load} ongoing work items"><div class="perf-bar-fill" style="width:${level*25}%;background:${color};"></div></div></div></div>`;
  });
  html+=`</div></div>`;
  document.getElementById('content').innerHTML=html;
}

// ============================================================

window.addEventListener('focus',()=>backgroundSync());
document.addEventListener('visibilitychange',()=>{if(!document.hidden)backgroundSync();else if(syncLeaseKey)try{const lease=JSON.parse(localStorage.getItem(syncLeaseKey)||'null');if(lease?.owner===syncTabId)localStorage.removeItem(syncLeaseKey);}catch{}});
window.addEventListener('pagehide',closeSyncChannel);
function trackDraftInput(event){const el=event.target;if((el.id&&/^(f-|fb-|p-|em-|m-|t-|et-|en-|end-|file-|new-note-text)/.test(el.id))){draftActive=el.id!=='new-note-text'||Boolean(el.value.trim());editGeneration++;}}
document.addEventListener('input',trackDraftInput);
document.addEventListener('change',trackDraftInput);
window.addEventListener('beforeunload',event=>{if(hasPendingChanges||draftActive){event.preventDefault();event.returnValue='';}});

// App dialogs keep confirmation and text-entry flows inside the application.
let appDialogQueue = Promise.resolve();
function appConfirm(message){return enqueueAppDialog({message});}
function appPrompt(message,value='',extraHtml=''){return enqueueAppDialog({message,value,prompt:true,extraHtml});}
function appAlert(message){return enqueueAppDialog({message,alert:true});}
function enqueueAppDialog(options){
  const pending=appDialogQueue.then(()=>showAppDialog(options));
  appDialogQueue=pending.catch(()=>{});
  return pending;
}
function showAppDialog(options){
  return new Promise(resolve=>{
    const previousFocus=document.activeElement,userId=currentUser?.id;
    const destructive=/^(Delete|Remove)\b/i.test(options.message);
    const dialog=document.createElement('dialog');
    dialog.className='app-dialog';
    dialog.setAttribute('aria-labelledby','app-dialog-title');
    dialog.setAttribute('aria-describedby','app-dialog-message');
    dialog.innerHTML='<form method="dialog"><div class="app-dialog-body"><h2 id="app-dialog-title"></h2><p id="app-dialog-message"></p><div class="app-dialog-entry" hidden><label for="app-dialog-input">Template name</label><input id="app-dialog-input" class="app-input" type="text" maxlength="200" autocomplete="off"></div></div><div class="app-dialog-actions"><button type="button" class="btn btn-ghost" data-cancel>Cancel</button><button type="submit" class="btn btn-primary" value="accept" data-accept></button></div></form>';
    dialog.querySelector('h2').textContent=options.prompt?'Save as template':options.alert?'Notice':destructive?'Confirm deletion':'Confirm action';
    dialog.querySelector('p').textContent=options.message;
    const input=dialog.querySelector('input'),cancel=dialog.querySelector('[data-cancel]'),accept=dialog.querySelector('[data-accept]');
    accept.textContent=options.prompt?'Save template':options.alert?'OK':destructive?'Delete':'Continue';
    if(destructive)accept.className='btn app-dialog-danger';
    if(options.prompt){dialog.querySelector('.app-dialog-entry').hidden=false;input.value=options.value;input.required=true;if(options.extraHtml)dialog.querySelector('.app-dialog-entry').insertAdjacentHTML('beforeend',options.extraHtml);}
    if(options.alert)cancel.hidden=true;
    cancel.addEventListener('click',()=>dialog.close('cancel'));
    dialog.addEventListener('keydown',event=>{if(event.key==='Escape')event.stopPropagation();});
    dialog.querySelector('form').addEventListener('submit',event=>{
      if(options.prompt&&!input.value.trim()){event.preventDefault();input.setCustomValidity('Enter a template name.');input.reportValidity();}
    });
    input.addEventListener('input',()=>input.setCustomValidity(''));
    dialog.addEventListener('close',()=>{
      const accepted=dialog.returnValue==='accept'&&userId===currentUser?.id;
      const result=options.prompt?(accepted?input.value.trim():null):accepted;
      dialog.remove();
      if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});
      resolve(result);
    },{once:true});
    document.body.append(dialog);
    dialog.showModal();
    if(options.prompt){input.focus();input.select();}else(options.alert?accept:cancel).focus();
  });
}
window.addEventListener('pageshow',event=>{if(event.persisted&&currentUser)openSyncChannel();});

function membersInRoleOrder(){const rank={admin:0,member:1,manager:2,board:3};return [...TEAM].sort((a,b)=>(rank[a.role]??4)-(rank[b.role]??4));}
