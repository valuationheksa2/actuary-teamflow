// Reduce motion (View menu): an app setting kept on this device that works like the system setting. It marks the page so
// CSS stops movement, and makes every "prefers-reduced-motion" check in the scripts answer yes. Runs first, in any window.
var TF_REDUCE_KEY = 'tfReduceMotion';
function appReduceMotion() { try { return localStorage.getItem(TF_REDUCE_KEY) === '1'; } catch (_) { return false; } }
function systemReduceMotion() { try { return window.__tfMatchMedia('(prefers-reduced-motion: reduce)').matches; } catch (_) { return false; } }
function setAppReduceMotion(on) {
  try { if (on) localStorage.setItem(TF_REDUCE_KEY, '1'); else localStorage.removeItem(TF_REDUCE_KEY); } catch (_) {}
  document.documentElement.toggleAttribute('data-reduce-motion', !!on);
}
(function () {
  var original = window.matchMedia.bind(window);
  window.__tfMatchMedia = original;
  window.matchMedia = function (query) {
    if (/prefers-reduced-motion:\s*reduce/.test(query) && appReduceMotion()) {
      var real = original(query);
      return { matches: true, media: real.media, onchange: null, addListener: function () {}, removeListener: function () {}, addEventListener: function () {}, removeEventListener: function () {}, dispatchEvent: function () { return false; } };
    }
    return original(query);
  };
  if (appReduceMotion()) document.documentElement.setAttribute('data-reduce-motion', '');
})();

// Installed app window (same pattern as ActuarialPro): the window title is only the app name, and with
// Chrome's window controls overlay a compact title bar shows Back, Forward, Toggle sidebar, File / Edit / View /
// Help menus with keyboard shortcuts, Quick open (Ctrl+K), a Find bar and page zoom.
// The bar is shown or hidden by CSS (display-mode), so it switches in the same frame as Chrome.
(function () {
  'use strict';
  var DEV = ['127.0.0.1', 'localhost', '[::1]'].indexOf(location.hostname) >= 0;
  var NAME = DEV ? 'Actuarial TeamFlow Dev' : 'Actuarial TeamFlow';
  // Deep ink navy: a quieter, darker shade of the brand navy (#002b84) so the bar reads as window chrome, not a banner.
  var COLOR = '#0f1f3d';
  var mq = function (mode) { return window.matchMedia('(display-mode: ' + mode + ')').matches; };
  if (window.top !== window || !['standalone', 'window-controls-overlay', 'minimal-ui'].some(mq)) return;

  var meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', COLOR);
  if (document.title !== NAME) document.title = NAME;
  // Built for every installed window; CSS shows it only while Chrome's title bar is hidden (window controls overlay).
  var overlay = navigator.windowControlsOverlay || null;

  var ICONS = {
    back: '<path d="M12 4.5L6.5 10l5.5 5.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
    forward: '<path d="M8 4.5l5.5 5.5L8 15.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
    sidebar: '<rect x="3" y="4" width="14" height="12" rx="2.5" stroke="currentColor" stroke-width="1.6"/>' +
             '<rect class="tb-pane" x="3.8" y="4.8" height="10.4" rx="1.7" fill="currentColor"/>' +
             '<path class="tb-divider" d="M7.5 4.5v11" stroke="currentColor" stroke-width="1.6"/>',
    search: '<circle cx="9" cy="9" r="5.2" stroke="currentColor" stroke-width="1.6"/><path d="M13 13l3.5 3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    up: '<path d="M5 12.5l5-5 5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
    down: '<path d="M5 7.5l5 5 5-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
    close: '<path d="M6 6l8 8M14 6l-8 8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    page: '<rect x="4.5" y="3" width="11" height="14" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M7.5 7.5h5M7.5 10.5h5M7.5 13.5h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    work: '<rect x="3" y="6" width="14" height="10.5" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M7.5 6V4.5a1.5 1.5 0 0 1 1.5-1.5h2a1.5 1.5 0 0 1 1.5 1.5V6M3 10.5h14" stroke="currentColor" stroke-width="1.5"/>',
    meeting: '<rect x="3" y="4.5" width="14" height="12.5" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M13.5 3v3M6.5 3v3M3 8.5h14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    command: '<path d="M6 7l3 3-3 3M10.5 13h4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><rect x="2.8" y="3.5" width="14.4" height="13" rx="2.5" stroke="currentColor" stroke-width="1.5"/>',
    enter: '<path d="M15 5v4.5a2 2 0 0 1-2 2H5M8 8.5 5 11.5l3 3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>'
  };
  var svg = function (name, size) { return '<svg width="' + (size || 18) + '" height="' + (size || 18) + '" viewBox="0 0 20 20" fill="none" aria-hidden="true">' + ICONS[name] + '</svg>'; };
  var FONT = '"Segoe UI",system-ui,sans-serif';
  var TB_H = 'env(titlebar-area-height,33px)';
  var css = [
    '@media (display-mode: window-controls-overlay){',
    'body{padding-top:' + TB_H + '!important}',
    '#app,#loading-screen{height:calc(100dvh - ' + TB_H + ')!important}#loading-screen{top:' + TB_H + '!important}',
    '#login-page{min-height:calc(100dvh - ' + TB_H + ')!important}',
    '@media (min-width:681px){#hamburger-btn{display:none!important}}',
    // The title bar status already shows saving and online state; only problems (conflict, failed save) stay in the page header.
    // Confirm dialogs dim the page only, like the other modals; the title bar stays clear.
    'dialog.app-dialog::backdrop{top:' + TB_H + '}',
    '#save-indicator:not([data-state="conflict"]):not([data-state="error"]){display:none}',
    '#topbar .topbar-status-group .sync-status{display:none}#topbar .topbar-date::before{display:none}}',
    '@media not (display-mode: window-controls-overlay){.app-titlebar,.app-menu-panel,.app-findbar{display:none!important}}',
    '#app.sidebar-hidden #sidebar{display:none}',
    // --tb-z is the page zoom; zoom:1/z keeps the bar the same size as the window buttons whatever the zoom level,
    // and the title-bar area (given in page pixels) is multiplied back so the bar still fills it exactly.
    '.app-titlebar{position:fixed;z-index:2147483000;zoom:calc(1 / var(--tb-z,1));left:calc(env(titlebar-area-x,0px) * var(--tb-z,1));top:calc(env(titlebar-area-y,0px) * var(--tb-z,1));',
    'width:calc(env(titlebar-area-width,100vw) * var(--tb-z,1));height:calc(' + TB_H + ' * var(--tb-z,1));display:flex;align-items:center;gap:2px;',
    'padding:0 6px;box-sizing:border-box;background:' + COLOR + ';color:#fff;-webkit-app-region:drag;app-region:drag;',
    'user-select:none;font:400 13px/1 ' + FONT + '}',
    '.app-titlebar button{-webkit-app-region:no-drag;app-region:no-drag;height:26px;border:0;border-radius:6px;',
    'background:transparent;color:inherit;cursor:pointer;padding:0;font:inherit;opacity:.85}',
    '.app-titlebar .tb-icon{width:30px;display:grid;place-items:center}',
    '.app-titlebar .tb-menu{padding:0 9px;font-size:12px}',
    '.app-titlebar .tb-gap{width:8px}',
    '.app-titlebar button:hover:not(:disabled),.app-titlebar button[aria-expanded="true"]{background:rgba(255,255,255,.16);opacity:1}',
    '.app-titlebar button:focus-visible{outline:2px solid rgba(255,255,255,.75);outline-offset:-2px}',
    '.app-titlebar button:disabled{opacity:.32;cursor:default}',
    '.app-titlebar button[hidden]{display:none!important}',
    '.tb-pane{width:2.2px;opacity:.28;transition:width .22s cubic-bezier(.2,.7,.3,1)}',
    '.tb-divider{transform:translateX(-1.2px);transition:transform .22s cubic-bezier(.2,.7,.3,1)}',
    '.is-open .tb-pane{width:4.9px}.is-open .tb-divider{transform:translateX(1.4px)}',
    '@media (prefers-reduced-motion:reduce){.tb-pane,.tb-divider{transition:none}}',
    // Three columns with equal side tracks: the search box stays put when the status text or online avatars change width.
    '.app-titlebar{display:flex;justify-content:space-between}',
    '.app-titlebar .tb-side{display:flex;align-items:center;gap:2px;min-width:0}',
    '.app-titlebar .tb-side-right{justify-content:flex-end}',
    // The search box is placed on its own (centerSearch), outside the row, so nothing beside it can push it.
    '.app-titlebar .tb-search{margin:-12px 0 0;position:absolute;top:50%;left:calc(50% - 110px)}',
    // While the search panel is open the box has moved into it, so the title bar copy is hidden; it fades back as the panel lands.
    '.app-titlebar .tb-search.is-open{opacity:0;pointer-events:none;transition:none}',
    '.app-titlebar .tb-search.is-back{transition:opacity .16s ease .08s}',
    // The search panel dims the page only, like other dialogs; the title bar stays clear.
    '.app-qo-backdrop.below-bar{top:' + TB_H + ';padding-top:calc(14vh - ' + TB_H + ')}',
    '.app-titlebar .tb-search{-webkit-app-region:no-drag;app-region:no-drag;height:24px;box-sizing:border-box;border-radius:7px;cursor:text;display:flex;align-items:center;gap:8px;width:220px;padding:0 8px 0 10px;transition:background .15s,box-shadow .15s;',
    'background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.14);color:rgba(255,255,255,.82);font-size:12.5px;opacity:1}',
    '.app-titlebar .tb-search input{flex:1;min-width:0;height:100%;border:0!important;box-shadow:none!important;outline:none;background:transparent!important;color:#fff;font:inherit;font-size:12.5px;padding:0}',
    '.app-titlebar .tb-search input::placeholder{color:rgba(255,255,255,.72);transition:opacity .2s}',
    '.app-titlebar .tb-search:focus-within,.app-titlebar .tb-search.is-open{background:#fff;color:var(--text3,#52647a);box-shadow:0 2px 10px rgba(0,0,0,.18)}',
    '.app-titlebar .tb-search:focus-within input,.app-titlebar .tb-search.is-open input{color:var(--text,#1a2535)}',
    '.app-titlebar .tb-search:focus-within input::placeholder,.app-titlebar .tb-search.is-open input::placeholder{color:#8a9bb0}',
    '.app-titlebar .tb-search:focus-within kbd{display:none}',
    '.app-titlebar .tb-search[hidden]{display:none!important}',
    '.app-qo-backdrop.is-drop{background:transparent;display:block;padding:0;top:' + TB_H + '}',
    '.app-qo-backdrop.is-drop .app-qo{position:fixed;max-height:min(68vh,520px);border-radius:10px;box-shadow:0 12px 32px rgba(15,23,42,.18),0 2px 6px rgba(15,23,42,.06);font-size:13px}',
    '.app-qo-backdrop.is-drop .app-qo-search{display:none}',
    '.app-qo-backdrop.is-drop .app-qo-top{padding:6px 8px}.app-qo-backdrop.is-drop .app-qo-types{margin-top:0}',
    '.app-qo-list.is-swap{animation:tfQoSwap .18s ease-out}',
    '@keyframes tfQoIn{from{opacity:0;transform:translateY(-8px) scale(.97)}to{opacity:1;transform:none}}',
    '@keyframes tfQoOut{from{opacity:1;transform:none}to{opacity:0;transform:translateY(-6px) scale(.98)}}',
    '@keyframes tfQoFade{from{opacity:0}to{opacity:1}}',
    '@keyframes tfQoSwap{from{opacity:.25;transform:translateY(3px)}to{opacity:1;transform:none}}',
    '@media (prefers-reduced-motion:reduce){.app-qo,.app-qo-backdrop,.app-qo-list.is-swap{animation:none!important}}',
    '.app-qo-row mark{background:transparent;color:var(--primary,#2b55a4);font-weight:600;padding:0}',
    '.app-qo-badge{flex:none;display:inline-flex;align-items:center;gap:5px;font-style:normal;font-size:11.5px;font-weight:500;color:var(--text3,#52647a)}',
    '.app-qo-badge::before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor;opacity:.85}',
    '.app-qo-badge.is-blue{color:var(--primary,#2b55a4)}',
    '.app-qo-badge.is-red{color:var(--red-ink,#b42318)}',
    '.app-qo-badge.is-green{color:#15803d}',
    '.app-titlebar .tb-search kbd{font:inherit;font-size:10.5px;opacity:.6;letter-spacing:.02em;white-space:nowrap}',
    '.app-titlebar .tb-search:not(:focus-within):not(.is-open):hover{background:rgba(255,255,255,.2);border-color:rgba(255,255,255,.24)}',
    '.app-titlebar .tb-online{-webkit-app-region:no-drag;app-region:no-drag;display:flex;align-items:center;height:26px;padding:0 6px;margin-left:6px;border:0;border-radius:6px;background:transparent;cursor:pointer}',
    '.app-titlebar .tb-online[hidden]{display:none}',
    '.app-titlebar .tb-online:hover{background:rgba(255,255,255,.12)}',
    '.app-titlebar .tb-online-av{display:inline-flex;margin-left:-4px;border-radius:50%;box-shadow:0 0 0 2px ' + COLOR + ';position:relative}',
    '.app-titlebar .tb-online-av:first-child{margin-left:0}',
    '.app-titlebar .tb-online-av .assignee-avatar{font-size:9px!important;border:0!important}',
    '.app-titlebar .tb-online-more{margin-left:4px;font-size:11px;color:rgba(255,255,255,.85)}',
    '.app-titlebar .tb-sync{display:flex;align-items:center;gap:6px;padding:0 8px;font-size:12px;opacity:.85;white-space:nowrap}',
    '.app-titlebar .tb-sync i{width:7px;height:7px;border-radius:50%;background:#4ade80;box-shadow:0 0 0 2px rgba(74,222,128,.25)}',
    '.app-titlebar .tb-sync[data-state="offline"] i,.app-titlebar .tb-sync[data-state="error"] i{background:#f87171;box-shadow:0 0 0 2px rgba(248,113,113,.25)}',
    '.app-titlebar .tb-sync[data-state="paused"] i{background:#fbbf24;box-shadow:0 0 0 2px rgba(251,191,36,.25)}',
    '.app-titlebar.tb-narrow .tb-sync span,.app-titlebar.tb-narrow .tb-search kbd{display:none}',
    '.app-menu-catcher{position:fixed;inset:0;z-index:2147482999;background:transparent}',
    '.app-menu-panel{position:fixed;z-index:2147483001;min-width:250px;padding:5px;border-radius:10px;box-sizing:border-box;',
    'background:#fff;color:var(--text,#1a2535);border:1px solid var(--border,#d0dcea);box-shadow:0 12px 32px rgba(15,23,42,.18);',
    'font:400 13px/1.2 ' + FONT + '}',
    '.app-menu-panel[hidden],.app-menu-catcher[hidden],.app-findbar[hidden],.app-qo-backdrop[hidden]{display:none}',
    '.app-menu-panel button{display:flex;align-items:center;gap:24px;width:100%;padding:7px 10px;border:0;border-radius:6px;',
    'background:transparent;color:inherit;font:inherit;text-align:left;cursor:pointer}',
    '.app-menu-panel button span{flex:1}',
    '.app-menu-panel button:hover,.app-menu-panel button:focus-visible,.app-menu-panel button.is-sub-open{background:var(--bg3,#e8eef5);outline:none}',
    '.app-menu-panel kbd{font:inherit;font-size:12px;color:var(--text3,#52647a)}',
    '.app-menu-panel .tb-chev{font-style:normal;font-size:14px;color:var(--text3,#52647a);margin-left:-14px}',
    '.app-menu-panel .tb-check{width:14px;margin-left:-4px;margin-right:-14px;color:var(--primary,#2b55a4);font-style:normal}',
    '.app-menu-panel hr{border:0;border-top:1px solid var(--border,#d0dcea);margin:5px 4px}',
    '.app-findbar{position:fixed;z-index:2147483001;top:calc(' + TB_H + ' + 8px);right:16px;display:flex;align-items:center;gap:2px;',
    'padding:5px 5px 5px 10px;border-radius:10px;background:#fff;color:var(--text,#1a2535);border:1px solid var(--border,#d0dcea);',
    'box-shadow:0 12px 32px rgba(15,23,42,.18);font:400 13px/1.2 ' + FONT + '}',
    '.app-findbar input{width:220px;border:0!important;box-shadow:none!important;outline:none;background:transparent;color:inherit;font:inherit;padding:4px 2px}',
    '.app-findbar .tb-find-msg{color:var(--text3,#52647a);font-size:12px;margin:0 6px;min-width:58px;text-align:right}',
    '.app-findbar button{width:28px;height:26px;display:grid;place-items:center;border:0;border-radius:6px;background:transparent;color:inherit;cursor:pointer}',
    '.app-findbar button:hover{background:var(--bg3,#e8eef5)}',
    '.app-qo-backdrop{position:fixed;inset:0;z-index:2147483002;background:rgba(15,23,42,.28);-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);display:flex;justify-content:center;align-items:flex-start;padding-top:14vh}',
    '.app-qo{width:min(680px,94vw);max-height:76vh;display:flex;flex-direction:column;border-radius:16px;overflow:hidden;',
    'background:#fff;color:var(--text,#1a2535);border:1px solid var(--border,#d0dcea);box-shadow:0 28px 70px rgba(15,23,42,.30);font:400 14px/1.3 ' + FONT + '}',
    '.app-qo-top{padding:16px 16px 12px 20px;border-bottom:1px solid var(--bg3,#e8eef5)}',
    '.app-qo-search{display:flex;align-items:center;gap:10px;color:var(--text3,#52647a)}',
    '.app-qo-search input{flex:1;border:0!important;box-shadow:none!important;outline:none;padding:4px 0;font:inherit;font-size:17px;color:var(--text,#1a2535);background:transparent}',
    '.app-qo-types{display:flex;gap:4px;margin-top:12px;flex-wrap:wrap}',
    '.app-qo-types button{border:0;background:transparent;color:var(--text2,#4a6080);font:inherit;font-size:13.5px;padding:6px 12px;border-radius:8px;cursor:pointer}',
    '.app-qo-types button:hover{background:var(--bg,#f0f4f8)}',
    '.app-qo-types button[aria-selected="true"]{background:var(--primary-dim,rgba(59,111,212,.1));color:var(--primary,#2b55a4);font-weight:600}',
    '.app-qo-list{overflow:auto;padding:4px 6px 6px}',
    '.app-qo-group{padding:10px 10px 4px;font-size:10.5px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#8a9bb0}',
    '.app-qo-group b{font-weight:500;letter-spacing:0;text-transform:none}',
    '.app-qo-row{display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:6px;cursor:pointer}',
    '.app-qo-row .app-qo-ic{width:16px;height:16px;flex:none;display:grid;place-items:center;color:var(--text3,#52647a)}',
    '.app-qo-row span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px}',
    '.app-qo-row small{color:#8a9bb0;font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:42%}',
    '.app-qo-row kbd{font:inherit;font-size:12px;color:var(--text3,#52647a)}',
    '.app-qo-row .app-qo-enter{width:14px;color:var(--text3,#52647a);visibility:hidden}',
    '.app-qo-row.is-active{background:var(--bg,#f0f4f8);box-shadow:inset 2px 0 0 var(--primary,#2b55a4)}',
    '.app-qo-row.is-active .app-qo-enter{visibility:visible}',
    '.app-qo-tip{padding:8px 10px 4px;font-size:11.5px;color:#8a9bb0}.app-qo-tip i{font-style:normal;color:var(--text2,#4a6080);background:var(--bg,#f0f4f8);border-radius:4px;padding:0 5px;margin:0 1px}',
    '.app-qo-empty{padding:22px 12px;color:var(--text3,#52647a);text-align:center}',
    '.app-qo-foot{display:flex;align-items:center;gap:16px;padding:8px 12px;border-top:1px solid var(--bg3,#e8eef5);font-size:11.5px;color:#8a9bb0;flex-wrap:nowrap;white-space:nowrap}',
    '.app-qo-foot{justify-content:flex-end}.app-qo-backdrop.is-drop .app-qo-types{gap:2px}.app-qo-backdrop.is-drop .app-qo-types button{font-size:12px;padding:3px 9px;border-radius:5px}',
    '.app-qo-backdrop.is-drop .app-qo-types button[aria-selected="true"]{background:var(--bg3,#e8eef5);color:var(--text,#1a2535);font-weight:600}',
    '.app-qo-foot span{display:flex;align-items:center;gap:5px}',
    '.app-qo-foot kbd{min-width:18px!important;padding:0 5px!important;border-bottom-width:1px!important;font-size:10.5px!important;background:#fff!important}',
    '.app-sc-body{column-count:2;column-gap:32px}@media (max-width:640px){.app-sc-body{column-count:1}}',
    '.app-sc-group{break-inside:avoid;margin:0 0 14px}',
    '.app-sc-group h3{margin:0 0 4px;font-size:11px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--text3,#52647a)}',
    '.app-sc-row{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:6px 0;border-bottom:1px solid var(--bg3,#e8eef5);font-size:13px}',
    '.app-sc-row:last-child{border-bottom:0}',
    '.app-sc-keys{display:flex;gap:4px;flex:none}',
    '.app-sc-keys kbd,.app-qo-foot kbd{min-width:22px;box-sizing:border-box;padding:1px 7px;border-radius:6px;border:1px solid var(--border,#d0dcea);border-bottom-width:2px;background:var(--bg,#f0f4f8);',
    'font:600 11.5px/1.6 ' + FONT + ';color:var(--text2,#4a6080);text-align:center}',
    '@media print{.app-titlebar,.app-menu-panel,.app-findbar,.app-qo-backdrop{display:none!important}body{padding-top:0!important}}'
  ].join('');

  var ZOOMS = [0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2];
  var zoom = 1, sidebarHidden = false;
  try { zoom = parseFloat(localStorage.getItem('tfWindowZoom')) || 1; sidebarHidden = localStorage.getItem('tfSidebarHidden') === '1'; } catch (_) {}
  if (ZOOMS.indexOf(zoom) < 0) zoom = 1;

  var bar, panel, subPanel, catcher, findbar, findInput, findMsg, qo = null, buttons = {};
  var openKey = null, hoverOpened = null, editTarget = null, subTimer = null;
  // Page history for Back / Forward (TeamFlow pages don't use the browser history).
  var trail = [], at = -1, travelling = false;

  var signedIn = function () { return typeof currentUser !== 'undefined' && !!currentUser; };
  var role = function () { return signedIn() ? currentUser.role : ''; };
  // App permissions are page globals (some are const arrows, so not on window): call them by name, safely.
  var can = function (test) { try { return !!test(); } catch (_) { return false; } };
  var call = function (fn) { var args = [].slice.call(arguments, 1); return function () { if (typeof window[fn] === 'function') window[fn].apply(window, args); }; };
  function go(page) { if (typeof window.navigate === 'function') window.navigate(page); }

  /* ---------- pages (only those the sidebar shows for this role) ---------- */
  var PAGE_KEYS = { dashboard: 'Ctrl+Alt+D', ongoing: 'Ctrl+Alt+O', upcoming: 'Ctrl+Alt+U', meetings: 'Ctrl+Alt+M', history: 'Ctrl+Alt+H', capacity: 'Ctrl+Alt+C', audit: 'Ctrl+Alt+R', team: 'Ctrl+Alt+T' };
  function pages() {
    var out = [];
    Array.prototype.forEach.call(document.querySelectorAll('#sidebar .nav-item'), function (item) {
      var m = /navigate\('([a-z-]+)'\)/.exec(item.getAttribute('onclick') || '');
      if (!m || item.style.display === 'none') return;
      var label = '';
      item.childNodes.forEach(function (node) { if (node.nodeType === 3) label += node.textContent; });
      out.push({ page: m[1], label: label.trim(), key: PAGE_KEYS[m[1]] });
    });
    return out;
  }

  /* ---------- edit ---------- */
  function isField(el) {
    return !!el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search|email|url|tel|number|password)?$/i.test(el.type || ''))) && !el.readOnly && !el.disabled;
  }
  function selectedText(el) {
    if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) { try { return el.value.slice(el.selectionStart, el.selectionEnd); } catch (_) { return ''; } }
    return String(document.getSelection() || '');
  }
  function insertText(el, text) {
    if (!isField(el)) return;
    el.focus(); el.setRangeText(text, el.selectionStart, el.selectionEnd, 'end');
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
  function copy() { var text = selectedText(editTarget); if (text && navigator.clipboard) navigator.clipboard.writeText(text).catch(function () {}); }
  function cut() { copy(); if (isField(editTarget) && selectedText(editTarget)) insertText(editTarget, ''); }
  function paste() {
    var el = editTarget; if (!isField(el) || !navigator.clipboard) return;
    navigator.clipboard.readText().then(function (text) { insertText(el, text); }).catch(function () {});
  }
  function selectAll() {
    var el = editTarget;
    if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) { el.focus(); el.select(); return; }
    var modal = document.getElementById('modal-overlay');
    var scope = modal && modal.style.display === 'flex' ? modal.querySelector('.modal-body') : document.getElementById('content');
    if (scope) document.getSelection().selectAllChildren(scope);
  }

  /* ---------- view ---------- */
  function chrome(el) { return [bar, panel, subPanel, catcher, findbar, qo && qo.backdrop].indexOf(el) >= 0; }
  function applyZoom() {
    var value = zoom === 1 ? '' : String(zoom);
    Array.prototype.forEach.call(document.body.children, function (el) {
      if (!chrome(el) && el.tagName !== 'SCRIPT' && el.tagName !== 'STYLE' && el.tagName !== 'svg') el.style.zoom = value;
    });
  }
  function setZoom(next) { zoom = next; try { localStorage.setItem('tfWindowZoom', String(zoom)); } catch (_) {} applyZoom(); }
  function zoomStep(dir) { var i = ZOOMS.indexOf(zoom); if (i < 0) i = ZOOMS.indexOf(1); setZoom(ZOOMS[Math.max(0, Math.min(ZOOMS.length - 1, i + dir))]); }
  function toggleSidebar() {
    var app = document.getElementById('app'); if (!app) return;
    if (window.innerWidth <= 680) { if (typeof window.toggleMobileMenu === 'function') window.toggleMobileMenu(); return; }
    sidebarHidden = !sidebarHidden;
    try { localStorage.setItem('tfSidebarHidden', sidebarHidden ? '1' : '0'); } catch (_) {}
    // Slide the sidebar out to the left (the page widens with it) or back in, instead of switching instantly.
    var side = document.getElementById('sidebar');
    if (sidebarSlide) { sidebarSlide.cancel(); sidebarSlide = null; }
    if (!side || reduceMotion()) { syncSidebar(); return; }
    var width = side.offsetWidth || 240, ease = 'cubic-bezier(.32,.72,0,1)';
    if (sidebarHidden) {
      sidebarSlide = side.animate([{ marginLeft: '0px', opacity: 1 }, { marginLeft: -width + 'px', opacity: 0.4 }], { duration: 300, easing: ease });
      sidebarSlide.finished.then(function () { sidebarSlide = null; syncSidebar(); }, function () {});
    } else {
      syncSidebar();
      sidebarSlide = side.animate([{ marginLeft: -(side.offsetWidth || width) + 'px', opacity: 0.4 }, { marginLeft: '0px', opacity: 1 }], { duration: 340, easing: ease });
      sidebarSlide.finished.then(function () { sidebarSlide = null; }, function () {});
    }
  }
  var sidebarSlide = null;
  function syncSidebar() {
    var app = document.getElementById('app'); if (app) app.classList.toggle('sidebar-hidden', sidebarHidden && window.innerWidth > 680);
    if (buttons.sidebar) { buttons.sidebar.classList.toggle('is-open', !sidebarHidden); buttons.sidebar.hidden = !signedIn(); }
  }
  function toggleFullscreen() {
    if (document.fullscreenElement) document.exitFullscreen().catch(function () {});
    else document.documentElement.requestFullscreen().catch(function () {});
  }
  function openFind() {
    closeMenu(); closeQuick();
    var t = selectedText(document.activeElement);
    findbar.hidden = false;
    if (t && t.length < 80) findInput.value = t;
    findInput.focus(); findInput.select(); findMsg.textContent = '';
  }
  function closeFind() { findbar.hidden = true; }
  function findNext(back) {
    var text = findInput.value; if (!text) return;
    var found = false;
    try { found = window.find(text, false, !!back, true, false, false, false); } catch (_) {}
    findMsg.textContent = found ? '' : 'Not found';
    findInput.focus();
  }

  /* ---------- back / forward ---------- */
  function record(page) {
    if (travelling) { travelling = false; return; }
    if (trail[at] === page) return;
    trail = trail.slice(0, at + 1); trail.push(page); at = trail.length - 1;
    if (trail.length > 50) { trail.shift(); at -= 1; }
  }
  function travel(step) {
    var next = at + step; if (next < 0 || next >= trail.length) return;
    travelling = true; at = next; go(trail[at]);
  }
  function hookNavigate() {
    var original = window.navigate;
    if (typeof original !== 'function' || original.__tf) return;
    var wrapped = function (page) {
      var result = original.apply(this, arguments);
      Promise.resolve(result).then(function () { if (typeof currentPage !== 'undefined') record(currentPage); refresh(); });
      return result;
    };
    wrapped.__tf = true;
    window.navigate = wrapped;
  }

  /* ---------- quick open (Ctrl+K) ---------- */
  var QO_TYPES = [['all', 'All'], ['pages', 'Pages'], ['work', 'Work'], ['meetings', 'Meetings'], ['commands', 'Actions']];
  function commandEntries() {
    var out = [], m = menus();
    Object.keys(m).forEach(function (g) {
      clean(m[g]).forEach(function (item) {
        if (item === '-' || item.page || item.disabled || item.run === openQuick || item.sub || item.native) return;
        out.push({ type: 'commands', label: item.label.replace(/…$/, ''), key: item.key, run: item.run });
      });
    });
    return out;
  }
  var STATUS = { ongoing: 'Ongoing', upcoming: 'Upcoming', done: 'Completed' };
  // Smart words: typed alone or with other words they filter instead of matching text.
  var SMART = {
    overdue: { label: 'overdue', test: function (w) { return w.status !== 'done' && w.deadline && typeof todayStr !== 'undefined' && w.deadline < todayStr; } },
    mine: { label: 'mine', test: function (w) { var me = signedIn() && String(currentUser.id); return me && (String(w.pic) === me || (w.assignees || []).map(String).indexOf(me) >= 0); } },
    today: { label: 'today' },
    review: { label: 'review', test: function (w) { return w.status === 'ongoing' && Number(w.phase) === 2; } }
  };
  function parseQuery(raw) {
    var words = raw.trim().toLowerCase().split(/\s+/).filter(Boolean), smart = [];
    words = words.filter(function (w) { var key = w === 'my' ? 'mine' : w; if (SMART[key]) { smart.push(key); return false; } return true; });
    return { words: words, smart: smart };
  }
  function person(id) { try { var m = TEAM.find(function (x) { return String(x.id) === String(id); }); return m ? m.name : ''; } catch (_) { return ''; } }
  // Higher is better: title starts with the query, then a word in the title starts with it, then anywhere.
  function score(label, words) {
    var text = label.toLowerCase(), total = 0;
    words.forEach(function (w) { total += text.indexOf(w) === 0 ? 3 : new RegExp('(^|[^a-z0-9])' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).test(text) ? 2 : text.indexOf(w) >= 0 ? 1 : 0; });
    return total;
  }
  function workEntries(query) {
    if (typeof works === 'undefined') return [];
    var words = query.words, smart = query.smart.filter(function (k) { return SMART[k].test; });
    return works.filter(function (w) {
      if (!smart.every(function (k) { return SMART[k].test(w); })) return false;
      var text = (typeof workSearchText === 'function' ? workSearchText(w) : String(w.title || '')).toLowerCase();
      return words.every(function (word) { return text.indexOf(word) >= 0; });
    }).map(function (w) {
      var overdue = SMART.overdue.test(w), pic = person(w.pic);
      return { type: 'work', id: w.id, label: w.title, rank: score(w.title, words) * 10 + (w.status === 'ongoing' ? 2 : w.status === 'upcoming' ? 1 : 0), due: w.deadline || '',
        badge: overdue ? ['Overdue', 'red'] : [STATUS[w.status] || '', w.status === 'done' ? 'grey' : 'blue'],
        hint: (pic ? 'PIC ' + pic : '') + (w.deadline ? (pic ? ' · ' : '') + 'due ' + w.deadline : ''),
        run: function () { if (typeof openWorkDetail === 'function') openWorkDetail(w.id); } };
    }).sort(function (a, b) { return b.rank - a.rank || String(a.due).localeCompare(String(b.due)); });
  }
  function meetingEntries(query) {
    if (typeof meetings === 'undefined') return [];
    if (query.smart.indexOf('overdue') >= 0 || query.smart.indexOf('review') >= 0) return [];
    var today = typeof todayStr !== 'undefined' ? todayStr : '', onlyToday = query.smart.indexOf('today') >= 0, mineOnly = query.smart.indexOf('mine') >= 0;
    return meetings.filter(function (m) {
      if (m.status === 'cancelled' || (onlyToday && m.date !== today)) return false;
      if (mineOnly && !(typeof isMyMeeting === 'function' && isMyMeeting(m))) return false;
      var text = (m.title + ' ' + (m.location || '') + ' ' + m.date + ' ' + (m.agenda || '')).toLowerCase();
      return query.words.every(function (word) { return text.indexOf(word) >= 0; });
    }).map(function (m) {
      var past = Date.parse(m.startsAt) + (m.durationMinutes || 0) * 60000 < Date.now();
      return { type: 'meetings', id: m.id, label: m.title, rank: score(m.title, query.words) * 10 + (past ? 0 : 1), when: m.startsAt,
        badge: m.date === today ? ['Today', 'blue'] : past ? ['Past', 'grey'] : ['Upcoming', 'green'],
        hint: m.date + ' · ' + m.startTime + (m.location ? ' · ' + m.location : ''),
        run: function () { if (typeof openMeetingDetail === 'function') openMeetingDetail(m.id); } };
    }).sort(function (a, b) { return b.rank - a.rank || String(b.when).localeCompare(String(a.when)); });
  }
  /* recent: what was opened from search, newest first */
  function recentList() { try { return JSON.parse(localStorage.getItem('tfRecentOpen') || '[]'); } catch (_) { return []; } }
  function remember(entry) {
    if (!entry.id && entry.type !== 'pages') return;
    var key = entry.type + ':' + (entry.id != null ? entry.id : entry.page);
    var list = recentList().filter(function (r) { return r.key !== key; });
    list.unshift({ key: key, type: entry.type, id: entry.id, page: entry.page });
    try { localStorage.setItem('tfRecentOpen', JSON.stringify(list.slice(0, 8))); } catch (_) {}
  }
  function recentEntries(all) {
    return recentList().map(function (r) {
      return all.filter(function (e) { return e.type === r.type && (r.type === 'pages' ? e.page === r.page : String(e.id) === String(r.id)); })[0];
    }).filter(Boolean).slice(0, 5);
  }
  function renderQuick() {
    var raw = qo.input.value, query = parseQuery(raw), words = query.words, q = raw.trim(), type = qo.type, cap = type === 'all' ? 5 : 40;
    var want = function (t) { return type === 'all' || type === t; };
    var match = function (e) { var text = (e.label + ' ' + (e.hint || '')).toLowerCase(); return words.every(function (w) { return text.indexOf(w) >= 0; }); };
    var byScore = function (a, b) { return score(b.label, words) - score(a.label, words); };
    var smartOnly = query.smart.length > 0;
    var pageRows = smartOnly ? [] : pages().map(function (p) { return { type: 'pages', page: p.page, label: p.label, key: p.key, run: function () { go(p.page); } }; }).filter(match).sort(byScore);
    var workRows = workEntries(query), meetingRows = meetingEntries(query);
    var commandRows = smartOnly ? [] : commandEntries().filter(match).sort(byScore);
    var groups = [];
    if (!q) {
      var recent = recentEntries(pages().map(function (p) { return { type: 'pages', page: p.page, label: p.label, key: p.key, run: function () { go(p.page); } }; }).concat(workEntries(query), meetingEntries(query)));
      var all = workEntries({ words: [], smart: [] }), mine = workEntries({ words: [], smart: ['mine'] });
      var byDue = function (a, b) { return String(a.due || '9999').localeCompare(String(b.due || '9999')); };
      var active = function (e) { return e.badge[0] !== 'Completed'; };
      var byWhen = function (a, b) { return String(a.when).localeCompare(String(b.when)); };
      var todayM = meetingRows.filter(function (e) { return e.badge[0] === 'Today'; }).sort(byWhen);
      var nextM = meetingRows.filter(function (e) { return e.badge[0] === 'Upcoming'; }).sort(byWhen);
      var pastM = meetingRows.filter(function (e) { return e.badge[0] === 'Past'; }).sort(function (a, b) { return byWhen(b, a); });
      if (type === 'all') {
        if (recent.length) groups.push(['Recently opened', recent]);
        var myActive = mine.filter(active).sort(byDue);
        groups.push(myActive.length ? ['My work', myActive.slice(0, 4)] : ['Due soon', all.filter(active).sort(byDue).slice(0, 4)]);
        groups.push(['Coming up', todayM.concat(nextM).slice(0, 3)]);
        if (!recent.length) groups.push(['Go to', pageRows.slice(0, 4)]);
      } else if (type === 'work') {
        var seen = {}, take = function (list) { return list.filter(function (e) { if (seen[e.id]) return false; seen[e.id] = 1; return true; }); };
        groups.push(['Overdue', take(all.filter(function (e) { return e.badge[0] === 'Overdue'; }).sort(byDue))]);
        groups.push(['My work', take(mine.filter(active).sort(byDue))]);
        groups.push(['Ongoing', take(all.filter(function (e) { return e.badge[0] === 'Ongoing'; }).sort(byDue))]);
        groups.push(['Upcoming', take(all.filter(function (e) { return e.badge[0] === 'Upcoming'; }).sort(byDue))]);
        groups.push(['Recently completed', take(all.filter(function (e) { return !active(e); }).sort(function (a, b) { return byDue(b, a); })).slice(0, 8)]);
      } else if (type === 'meetings') {
        groups.push(['Today', todayM], ['Upcoming', nextM], ['Past', pastM.slice(0, 10)]);
      }
      if (want('pages') && type !== 'all') groups.push(['Pages', pageRows]);
      if (want('commands') && type !== 'all') groups.push(['Actions', commandRows]);
    } else {
      // The best group leads: the one whose top result matches the query most closely.
      var found = [];
      if (want('pages')) found.push(['Pages', pageRows.slice(0, cap)]);
      if (want('work')) found.push(['Work', workRows.slice(0, cap), workRows.length]);
      if (want('meetings')) found.push(['Meetings', meetingRows.slice(0, cap), meetingRows.length]);
      if (want('commands')) found.push(['Actions', commandRows.slice(0, cap)]);
      found.sort(function (a, b) { return (b[1][0] ? score(b[1][0].label, words) : -1) - (a[1][0] ? score(a[1][0].label, words) : -1); });
      groups = found;
    }
    qo.items = []; qo.list.textContent = '';
    groups.forEach(function (g) {
      if (!g[1].length) return;
      var head = document.createElement('div'); head.className = 'app-qo-group';
      head.innerHTML = esc(g[0]) + (g[2] > g[1].length ? ' <b>· ' + g[2] + '</b>' : ''); qo.list.appendChild(head);
      g[1].forEach(function (entry) {
        var index = qo.items.length;
        var row = document.createElement('div'); row.className = 'app-qo-row'; row.setAttribute('role', 'option');
        var ic = document.createElement('i'); ic.className = 'app-qo-ic';
        ic.innerHTML = svg({ pages: 'page', work: 'work', meetings: 'meeting', commands: 'command' }[entry.type]); row.appendChild(ic);
        var label = document.createElement('span'); label.innerHTML = highlight(entry.label, words); row.appendChild(label);
        if (entry.badge && entry.badge[0]) { var bd = document.createElement('em'); bd.className = 'app-qo-badge is-' + entry.badge[1]; bd.textContent = entry.badge[0]; row.appendChild(bd); }
        if (entry.hint) { var hint = document.createElement('small'); hint.textContent = entry.hint; row.appendChild(hint); }
        if (entry.key) { var k = document.createElement('kbd'); k.textContent = entry.key; row.appendChild(k); }
        var enter = document.createElement('i'); enter.className = 'app-qo-enter'; enter.innerHTML = svg('enter', 17); row.appendChild(enter);
        row.addEventListener('mousemove', function () { if (qo.active !== index) setActive(index); });
        row.addEventListener('mousedown', function (e) { e.preventDefault(); });
        row.addEventListener('click', function () { runQuick(index); });
        qo.list.appendChild(row); qo.items.push({ entry: entry, row: row });
      });
    });
    if (!qo.items.length) {
      var empty = document.createElement('div'); empty.className = 'app-qo-empty';
      empty.innerHTML = q ? 'No matches for “' + esc(q) + '”.' : 'Type to search work, meetings, pages and actions.';
      qo.list.appendChild(empty);
    }
    setActive(0);
  }
  function highlight(text, words) {
    var out = esc(text);
    words.filter(function (w) { return w.length > 0; }).sort(function (a, b) { return b.length - a.length; }).forEach(function (w) {
      out = out.replace(new RegExp('(' + esc(w).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')(?![^<]*>)', 'ig'), '<mark>$1</mark>');
    });
    return out;
  }
  function setActive(index) {
    if (!qo.items.length) { qo.active = -1; return; }
    qo.active = Math.max(0, Math.min(qo.items.length - 1, index));
    qo.items.forEach(function (it, i) { it.row.classList.toggle('is-active', i === qo.active); });
    qo.items[qo.active].row.scrollIntoView({ block: 'nearest' });
  }
  function setType(next) {
    if (qo.type !== next && qo.list) { qo.list.classList.remove('is-swap'); void qo.list.offsetWidth; qo.list.classList.add('is-swap'); }
    qo.type = next;
    Array.prototype.forEach.call(qo.typeButtons, function (b) { b.setAttribute('aria-selected', String(b.dataset.type === next)); });
    renderQuick(); focusInput();
  }
  function focusInput() { (qo.drop ? buttons.searchInput : qo.input).focus(); }
  function runQuick(index) { var it = qo.items[index]; if (!it) return; remember(it.entry); closeQuick(); it.entry.run(); }
  function quickKey(e) {
    var input = qo.drop ? buttons.searchInput : qo.input;
    var order = QO_TYPES.map(function (t) { return t[0]; }), i = order.indexOf(qo.type);
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(qo.active + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(qo.active - 1); }
    else if (e.key === 'Tab') { e.preventDefault(); setType(order[(i + (e.shiftKey ? order.length - 1 : 1)) % order.length]); }
    else if (e.key === 'ArrowRight' && (!input.value || input.selectionStart === input.value.length) && !qo.drop) { e.preventDefault(); setType(order[(i + 1) % order.length]); }
    else if (e.key === 'ArrowLeft' && (!input.value || input.selectionStart === 0) && !qo.drop) { e.preventDefault(); setType(order[(i + order.length - 1) % order.length]); }
    else if (e.key === 'Enter') { e.preventDefault(); runQuick(qo.active); }
    else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeQuick(); }
  }
  function buildQuick() {
    qo = { items: [], active: -1, type: 'all', drop: false };
    qo.backdrop = document.createElement('div'); qo.backdrop.className = 'app-qo-backdrop'; qo.backdrop.hidden = true;
    var box = document.createElement('div'); box.className = 'app-qo'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-label', 'Search');
    var top = document.createElement('div'); top.className = 'app-qo-top';
    var search = document.createElement('div'); search.className = 'app-qo-search'; search.innerHTML = svg('search', 20);
    qo.input = document.createElement('input'); qo.input.type = 'text'; qo.input.placeholder = 'Search pages, work, meetings and actions';
    qo.input.setAttribute('aria-label', 'Search pages, work, meetings and actions'); qo.input.setAttribute('autocomplete', 'off');
    search.appendChild(qo.input); top.appendChild(search);
    var types = document.createElement('div'); types.className = 'app-qo-types'; types.setAttribute('role', 'tablist');
    QO_TYPES.forEach(function (t) {
      var b = document.createElement('button'); b.type = 'button'; b.dataset.type = t[0]; b.textContent = t[1]; b.setAttribute('role', 'tab');
      b.addEventListener('mousedown', function (e) { e.preventDefault(); });
      b.addEventListener('click', function () { setType(t[0]); });
      types.appendChild(b);
    });
    qo.typeButtons = types.children;
    qo.list = document.createElement('div'); qo.list.className = 'app-qo-list'; qo.list.setAttribute('role', 'listbox');
    var foot = document.createElement('div'); foot.className = 'app-qo-foot';
    foot.innerHTML = '<span><kbd>↑</kbd><kbd>↓</kbd> move</span><span><kbd>↵</kbd> open</span><span><kbd>Esc</kbd> close</span>';
    types.title = 'Tab switches scope'; top.appendChild(types);
    box.appendChild(top); box.appendChild(qo.list); box.appendChild(foot); qo.backdrop.appendChild(box);
    qo.box = box;
    qo.backdrop.addEventListener('mousedown', function (e) { if (e.target === qo.backdrop) closeQuick(); });
    qo.input.addEventListener('input', renderQuick);
    qo.input.addEventListener('keydown', quickKey);
    document.body.prepend(qo.backdrop);
  }
  function reduceMotion() { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (_) { return false; } }
  function barShown() { return !!bar && getComputedStyle(bar).display !== 'none'; }
  // In the title bar you type straight into the search box and results drop down under it; elsewhere it opens as a window.
  function openQuick() {
    if (!signedIn()) return;
    closeMenu(); closeFind();
    if (!qo) buildQuick();
    if (qo.closing) { qo.closing = 0; (qo.anims || []).forEach(function (a) { a.cancel(); }); qo.anims = []; qo.backdrop.hidden = true; }
    // Always the floating panel further into the page; from the title bar it grows out of the search box (Spotlight-style).
    var reopening = !qo.backdrop.hidden;
    qo.drop = false;
    qo.backdrop.classList.remove('is-drop');
    qo.input.value = buttons.searchInput ? buttons.searchInput.value : '';
    if (buttons.searchInput) buttons.searchInput.value = '';
    qo.backdrop.hidden = false; qo.backdrop.style.zoom = '';
    qo.backdrop.classList.toggle('below-bar', barShown());
    if (buttons.search && barShown()) { buttons.search.classList.remove('is-back'); buttons.search.classList.add('is-open'); }
    setType('all');
    if (!reopening) animateQuick(true);
  }
  // Open: the panel springs from the search box's place to its own, the dimmed blur fades in, then the rows cascade in.
  // Close: the same path in reverse, panel and background together.
  function quickOrigin() { return buttons.search && barShown() ? buttons.search.getBoundingClientRect() : null; }
  function animateQuick(opening, done) {
    (qo.anims || []).forEach(function (a) { a.cancel(); }); qo.anims = [];
    if (reduceMotion()) { if (done) done(); return; }
    var box = qo.box, to = box.getBoundingClientRect(), from = quickOrigin();
    var shrunk = from ? 'translate(' + (from.left - to.left) + 'px,' + (from.top - to.top) + 'px) scale(' + (from.width / to.width) + ',' + (from.height / to.height) + ')' : 'translateY(-16px) scale(.95)';
    box.style.transformOrigin = from ? 'top left' : 'top center';
    var parts = [qo.box.querySelector('.app-qo-top'), qo.list, qo.box.querySelector('.app-qo-foot')];
    var shade = [{ backgroundColor: 'rgba(15,23,42,0)', backdropFilter: 'blur(0px)' }, { backgroundColor: 'rgba(15,23,42,.28)', backdropFilter: 'blur(6px)' }];
    if (opening) {
      var spring = { duration: 520, easing: 'cubic-bezier(.32,.72,0,1)' };
      qo.anims.push(box.animate([{ transform: shrunk, opacity: from ? 1 : 0, borderRadius: '10px' }, { transform: 'none', opacity: 1, borderRadius: '16px' }], spring));
      qo.anims.push(qo.backdrop.animate(shade, { duration: 360, easing: 'ease-out' }));
      parts.forEach(function (el) { if (el) qo.anims.push(el.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 260, delay: 110, easing: 'ease-out', fill: 'backwards' })); });
      Array.prototype.slice.call(qo.list.querySelectorAll('.app-qo-row, .app-qo-group'), 0, 14).forEach(function (row, i) {
        qo.anims.push(row.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'none' }], { duration: 340, delay: 150 + i * 22, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'backwards' }));
      });
    } else {
      var out = { duration: 240, easing: 'cubic-bezier(.4,0,.2,1)', fill: 'forwards' };
      var last = box.animate([{ transform: 'none', opacity: 1 }, { transform: shrunk, opacity: 0 }], out);
      qo.anims.push(last, qo.backdrop.animate(shade.slice().reverse(), out));
      parts.forEach(function (el) { if (el) qo.anims.push(el.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 120, easing: 'ease-in', fill: 'forwards' })); });
      last.finished.then(function () { if (done) done(); }, function () {});
    }
  }
  function placeDrop() {
    var r = buttons.search.getBoundingClientRect(), width = Math.max(320, Math.min(560, innerWidth * 0.46, innerWidth - 24));
    qo.box.style.left = Math.max(12, Math.min(innerWidth - width - 12, r.left + r.width / 2 - width / 2)) + 'px';
    qo.box.style.top = (r.bottom + 6) + 'px'; qo.box.style.width = width + 'px';
  }
  function syncInput() { if (!qo || qo.backdrop.hidden) openQuick(); qo.input.value = buttons.searchInput.value; renderQuick(); }
  function closeQuick() {
    if (!qo || qo.backdrop.hidden || qo.closing) return;
    qo.closing = 1;
    animateQuick(false, function () { qo.closing = 0; qo.backdrop.hidden = true; (qo.anims || []).forEach(function (a) { a.cancel(); }); qo.anims = []; });
    if (buttons.search) { buttons.search.classList.add('is-back'); buttons.search.classList.remove('is-open'); buttons.searchInput.value = ''; if (document.activeElement === buttons.searchInput) buttons.searchInput.blur(); }
  }

  /* ---------- help ---------- */
  function about() {
    var version = typeof APP_VERSION !== 'undefined' ? APP_VERSION : '';
    var body = '<div style="text-align:center;padding:6px 0;"><img src="/icon-192.png" alt="" width="56" height="56" style="border-radius:12px;"><h3 style="margin:10px 0 4px;font-size:16px;">' + NAME + '</h3>'
      + (version ? '<p style="color:var(--text2);font-size:13px;">Version ' + version + '</p>' : '')
      + '<p style="color:var(--text3);font-size:12px;margin-top:6px;">' + (DEV ? 'Local development preview' : 'Production') + ' · ' + location.host + '</p>'
      + '<p style="color:var(--text3);font-size:12px;margin-top:10px;">Work, capacity and reporting for actuarial teams</p></div>';
    showDialog('About ' + NAME, body);
  }
  function keyChips(combo) {
    return '<span class="app-sc-keys">' + combo.split('+').map(function (part, i, all) {
      if (part === '' && i === all.length - 1) part = '+';
      if (!part) return '';
      return '<kbd>' + (part === 'Left' ? '←' : part === 'Right' ? '→' : part) + '</kbd>';
    }).join('') + '</span>';
  }
  var esc = function (v) { return String(v).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  function shortcutList() {
    var groups = { File: [], Edit: [], View: [], Go: [], Help: [] }, m = menus();
    Object.keys(m).forEach(function (g) {
      clean(m[g]).forEach(function (item) {
        if (item === '-') return;
        if (item.key) groups[g].push([item.label.replace(/\s+\(\d+%\)$/, '').replace(/…$/, ''), item.key]);
        (item.sub || []).forEach(function (s) { if (s.key) groups.Go.push([s.label, s.key]); });
      });
    });
    var html = '<div class="app-sc-body">' + ['File', 'Go', 'Edit', 'View', 'Help'].filter(function (g) { return groups[g].length; }).map(function (g) {
      return '<section class="app-sc-group"><h3>' + g + '</h3>' + groups[g].map(function (p) { return '<div class="app-sc-row"><span>' + esc(p[0]) + '</span>' + keyChips(p[1]) + '</div>'; }).join('') + '</section>';
    }).join('') + '</div><p style="font-size:12px;color:var(--text3);margin-top:6px;">Shortcuts work in the installed app.</p>';
    showDialog('Keyboard shortcuts', html, true);
  }
  // Uses the app's own modal so it looks like every other dialog.
  function showDialog(title, body, wide) {
    var overlay = document.getElementById('modal-overlay'); if (!overlay) return;
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML = body;
    document.getElementById('modal-footer').innerHTML = '<button type="button" class="btn btn-primary" onclick="closeModal()">Close</button>';
    var modal = overlay.querySelector('.modal'); if (modal) modal.style.maxWidth = wide ? '760px' : '';
    overlay.style.display = 'flex';
    var restore = new MutationObserver(function () { if (overlay.style.display !== 'flex') { if (modal) modal.style.maxWidth = ''; restore.disconnect(); } });
    restore.observe(overlay, { attributes: true, attributeFilter: ['style'] });
  }

  /* ---------- menus ---------- */
  function menus() {
    var on = signedIn(), writer = on && role() !== 'board';
    var goTo = on ? { label: 'Go to', run: function () {}, sub: pages().map(function (p) { return { label: p.label, key: p.key, page: p.page, run: function () { go(p.page); } }; }) } : null;
    return {
      File: [
        on ? { label: 'Quick open…', key: 'Ctrl+K', run: openQuick } : null,
        '-',
        writer && can(function () { return canCreateWork(); }) ? { label: 'New work…', key: 'Ctrl+Alt+N', run: function () { go('ongoing'); setTimeout(call('openAddWork'), 0); } } : null,
        writer && can(function () { return canCreateMeeting(); }) ? { label: 'New meeting…', key: 'Ctrl+Alt+E', run: function () { go('meetings'); setTimeout(call('openMeetingForm'), 0); } } : null,
        writer ? { label: 'Leave & holidays…', key: 'Ctrl+Alt+L', run: call('openAbsences') } : null,
        '-',
        on ? { label: 'Export dashboard PDF', run: function () { go('dashboard'); setTimeout(call('exportDailyReportPDF'), 0); } } : null,
        '-',
        on ? { label: 'My profile…', key: 'Ctrl+Alt+P', run: call('openMyProfile') } : null,
        on ? { label: 'Sign out', key: 'Ctrl+Alt+Q', run: function () { if (typeof doLogout === 'function') doLogout(); } } : null
      ],
      Edit: [
        { label: 'Cut', key: 'Ctrl+X', native: true, run: cut },
        { label: 'Copy', key: 'Ctrl+C', native: true, run: copy },
        { label: 'Paste', key: 'Ctrl+V', native: true, run: paste },
        '-',
        { label: 'Select all', key: 'Ctrl+A', native: true, run: selectAll },
        '-',
        { label: 'Find', key: 'Ctrl+F', run: openFind }
      ],
      View: [
        goTo,
        '-',
        on ? { label: 'Back', key: 'Alt+Left', run: function () { travel(-1); } } : null,
        on ? { label: 'Forward', key: 'Alt+Right', run: function () { travel(1); } } : null,
        '-',
        { label: 'Zoom in', key: 'Ctrl+=', run: function () { zoomStep(1); } },
        { label: 'Zoom out', key: 'Ctrl+-', run: function () { zoomStep(-1); } },
        { label: 'Actual size' + (zoom !== 1 ? ' (' + Math.round(zoom * 100) + '%)' : ''), key: 'Ctrl+0', run: function () { setZoom(1); } },
        '-',
        on ? { label: 'Toggle sidebar', key: 'Ctrl+B', run: toggleSidebar } : null,
        systemReduceMotion() ? { label: 'Reduce motion (on in system settings)', checked: true, run: function () {} } : { label: 'Reduce motion', checked: appReduceMotion(), run: function () { setAppReduceMotion(!appReduceMotion()); } },
        on && typeof setHelpLang === 'function' ? { label: 'Help language', run: function () {}, sub: [['en', 'English'], ['id', 'Bahasa Indonesia']].map(function (l) { return { label: l[1], checked: helpLang() === l[0], run: function () { setHelpLang(l[0]); } }; }) } : null,
        { label: 'Reload', key: 'F5', native: true, run: function () { location.reload(); } },
        { label: 'Full screen', key: 'F11', native: true, run: toggleFullscreen }
      ],
      Help: [
        on ? { label: 'Help & Guide', key: 'F1', run: function () { go('help'); } } : null,
        { label: 'Keyboard shortcuts', key: 'Ctrl+/', run: shortcutList },
        on ? { label: 'Changelog', run: function () { go('changelog'); } } : null,
        on ? { label: 'Send feedback', run: function () { go('feedback'); } } : null,
        '-',
        { label: 'About ' + NAME, run: about }
      ]
    };
  }
  function clean(items) {
    var out = [];
    items.forEach(function (item) {
      if (!item) return;
      if (item === '-' && (!out.length || out[out.length - 1] === '-')) return;
      out.push(item);
    });
    while (out.length && out[out.length - 1] === '-') out.pop();
    return out;
  }
  function closeSub() {
    clearTimeout(subTimer);
    subPanel.hidden = true; subPanel.textContent = '';
    Array.prototype.forEach.call(panel.querySelectorAll('.is-sub-open'), function (b) { b.classList.remove('is-sub-open'); });
  }
  function closeMenu() {
    if (!openKey) return;
    buttons[openKey].setAttribute('aria-expanded', 'false');
    openKey = null; panel.hidden = true; catcher.hidden = true; panel.textContent = '';
    closeSub();
  }
  function fill(target, items) {
    target.textContent = '';
    items.forEach(function (item) {
      if (item === '-') { target.appendChild(document.createElement('hr')); return; }
      var b = document.createElement('button'); b.type = 'button'; b.setAttribute('role', 'menuitem');
      var label = document.createElement('span'); label.textContent = item.label; b.appendChild(label);
      if (item.checked || (item.page && typeof currentPage !== 'undefined' && currentPage === item.page)) {
        var check = document.createElement('i'); check.className = 'tb-check'; check.textContent = '✓'; b.insertBefore(check, label);
      }
      if (item.key) { var k = document.createElement('kbd'); k.textContent = item.key; b.appendChild(k); }
      if (item.sub && item.sub.length) {
        var chev = document.createElement('i'); chev.className = 'tb-chev'; chev.textContent = '›'; b.appendChild(chev);
        b.setAttribute('aria-haspopup', 'menu');
        b.addEventListener('mouseenter', function () { clearTimeout(subTimer); subTimer = setTimeout(function () { openSub(b, item.sub); }, 120); });
        b.addEventListener('click', function (e) { e.stopPropagation(); openSub(b, item.sub); });
      } else if (target === panel) {
        b.addEventListener('mouseenter', function () { clearTimeout(subTimer); subTimer = setTimeout(closeSub, 150); });
      }
      b.addEventListener('mousedown', function (e) { e.preventDefault(); });
      if (!(item.sub && item.sub.length)) b.addEventListener('click', function () { closeMenu(); item.run(); });
      target.appendChild(b);
    });
  }
  function openSub(anchor, items) {
    closeSub();
    anchor.classList.add('is-sub-open');
    fill(subPanel, items);
    var r = anchor.getBoundingClientRect();
    subPanel.hidden = false;
    var left = r.right + 4;
    if (left + subPanel.offsetWidth > innerWidth - 4) left = Math.max(4, r.left - subPanel.offsetWidth - 4);
    subPanel.style.left = left + 'px';
    subPanel.style.top = Math.max(4, r.top - 6) + 'px';
  }
  function openMenu(key) {
    if (openKey === key) { closeMenu(); return; }
    if (openKey) closeMenu();
    var items = clean(menus()[key]);
    if (!items.length) return;
    fill(panel, items);
    var rect = buttons[key].getBoundingClientRect();
    panel.style.left = Math.max(4, rect.left) + 'px';
    panel.style.top = (rect.bottom + 4) + 'px';
    panel.hidden = false; catcher.hidden = false;
    openKey = key; buttons[key].setAttribute('aria-expanded', 'true');
  }

  /* ---------- keyboard shortcuts ---------- */
  function comboOf(e) {
    var k = e.key || '';
    if (e.code && /^Digit\d$/.test(e.code)) k = e.code.slice(5);
    else if (e.code === 'Equal' || k === '+') k = '=';
    else if (e.code === 'Minus') k = '-';
    else if (e.code === 'Slash') k = '/';
    else if (k === 'ArrowLeft') k = 'Left';
    else if (k === 'ArrowRight') k = 'Right';
    else if (k.length === 1) k = k.toUpperCase();
    return (e.ctrlKey || e.metaKey ? 'Ctrl+' : '') + (e.altKey ? 'Alt+' : '') + k;
  }
  function onKey(e) {
    if (e.defaultPrevented) return;
    if (e.key === 'Escape') {
      if (openKey) { closeMenu(); return; }
      if (findbar && !findbar.hidden) { closeFind(); return; }
      if (qo && !qo.backdrop.hidden) { closeQuick(); return; }
    }
    if (!e.ctrlKey && !e.altKey && !e.metaKey && e.key !== 'F1') return;
    var combo = comboOf(e), m = menus(), hit = null;
    Object.keys(m).forEach(function (g) {
      clean(m[g]).forEach(function (item) {
        if (item === '-' || hit) return;
        if (item.key === combo && !item.native) hit = item;
        (item.sub || []).forEach(function (s) { if (!hit && s.key === combo) hit = s; });
      });
    });
    if (!hit) return;
    // Back/Forward keys inside a text field keep their usual meaning.
    if (/^Alt\+(Left|Right)$/.test(combo) && isField(e.target)) return;
    e.preventDefault(); e.stopPropagation();
    if (e.repeat && !/^Ctrl\+(=|-)$/.test(combo)) return;
    closeMenu(); hit.run();
  }

  /* ---------- bar ---------- */
  function refresh() {
    if (!bar) return;
    var on = signedIn();
    buttons.back.disabled = !on || at <= 0;
    buttons.forward.disabled = !on || at >= trail.length - 1;
    buttons.back.hidden = buttons.forward.hidden = !on;
    buttons.search.hidden = !on;
    syncSidebar();
    var source = document.getElementById('sync-status');
    buttons.sync.hidden = !on || !source;
    if (source) {
      buttons.sync.dataset.state = source.dataset.state || 'connected';
      buttons.sync.querySelector('span').textContent = (source.textContent || '').split(' · ')[0]; // last sync time stays in the tooltip
      buttons.sync.title = source.textContent || '';
    }
    paintOnline(on);
  }
  // Teammates active in the last few minutes, from the presence data the sync check returns.
  function paintOnline(on) {
    var box = buttons.online; if (!box) return;
    var people = [];
    try {
      if (on && typeof TEAM !== 'undefined' && typeof presenceState === 'function') {
        people = TEAM.filter(function (m) { return m.active !== false && String(m.id) !== String(currentUser.id) && presenceState(m.id).online; });
      }
    } catch (_) { people = []; }
    var key = people.map(function (m) { return m.id + ':' + m.name + ':' + m.color; }).join('|');
    if (key === box.dataset.key) return;
    box.dataset.key = key; box.hidden = !people.length;
    if (!people.length) { box.textContent = ''; return; }
    var shown = people.slice(0, 4), extra = people.length - shown.length;
    box.innerHTML = shown.map(function (m) { return '<span class="tb-online-av">' + (typeof avatarHtml === 'function' ? avatarHtml(m, 22) : '') + '</span>'; }).join('') + (extra > 0 ? '<span class="tb-online-more">+' + extra + '</span>' : '');
    var names = people.map(function (m) { return m.name; });
    box.title = 'Online now: ' + names.join(', ');
    box.setAttribute('aria-label', people.length + ' teammate' + (people.length === 1 ? '' : 's') + ' online: ' + names.join(', '));
  }
  function iconButton(key, label, action) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'tb-icon'; b.title = label; b.setAttribute('aria-label', label);
    b.innerHTML = svg(key);
    b.addEventListener('click', function () { closeMenu(); action(); });
    buttons[key] = b; return b;
  }
  function menuButton(key) {
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'tb-menu'; b.textContent = key;
    b.setAttribute('aria-haspopup', 'menu'); b.setAttribute('aria-expanded', 'false');
    b.addEventListener('mousedown', function (e) { editTarget = document.activeElement; e.preventDefault(); });
    b.addEventListener('click', function () { if (hoverOpened === key) { hoverOpened = null; return; } openMenu(key); });
    b.addEventListener('mouseenter', function () { if (openKey && openKey !== key) { openMenu(key); hoverOpened = key; } });
    b.addEventListener('mouseleave', function () { hoverOpened = null; });
    buttons[key] = b; return b;
  }
  function smallButton(icon, label, action) {
    var b = document.createElement('button'); b.type = 'button'; b.title = label; b.setAttribute('aria-label', label);
    b.innerHTML = svg(icon, 16);
    b.addEventListener('mousedown', function (e) { e.preventDefault(); });
    b.addEventListener('click', action); return b;
  }
  function buildFind() {
    findbar = document.createElement('div'); findbar.className = 'app-findbar'; findbar.hidden = true; findbar.setAttribute('role', 'search');
    findInput = document.createElement('input'); findInput.type = 'text'; findInput.placeholder = 'Find in page'; findInput.setAttribute('aria-label', 'Find in page');
    findMsg = document.createElement('span'); findMsg.className = 'tb-find-msg';
    findInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); findNext(e.shiftKey); }
      else if (e.key === 'Escape') { e.preventDefault(); closeFind(); }
    });
    findInput.addEventListener('input', function () { findMsg.textContent = ''; });
    findbar.appendChild(findInput); findbar.appendChild(findMsg);
    findbar.appendChild(smallButton('up', 'Previous (Shift+Enter)', function () { findNext(true); }));
    findbar.appendChild(smallButton('down', 'Next (Enter)', function () { findNext(false); }));
    findbar.appendChild(smallButton('close', 'Close (Esc)', closeFind));
  }
  // The title bar leaves room for the window buttons on the right, so its own middle sits left of the window's middle.
  // Nudge the search box toward the window's centre, as far as the menus and status allow.
  // Browser zoom (Ctrl +/-) scales page pixels; the window's own buttons don't scale, so neither should the bar.
  var ZOOMS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5];
  function syncZoom() {
    var ratio = innerWidth > 0 && outerWidth > 0 ? outerWidth / innerWidth : 1;
    var z = ZOOMS.reduce(function (best, level) { return Math.abs(level - ratio) < Math.abs(best - ratio) ? level : best; }, 1);
    if (Math.abs(z - ratio) > 0.06) z = 1;
    document.documentElement.style.setProperty('--tb-z', String(z));
  }
  function centerSearch() {
    var search = buttons.search; if (!search || !barShown()) return;
    // The box is pinned to the middle of the whole window with plain left/width (no transform: the window's
    // click and drag areas follow layout boxes only). Page pixels are turned into bar units (x z) because the
    // bar is zoomed by 1/z. What the window shows or hides on the right never enters the sum, unless the box
    // would touch the menus or the status, where it stops short.
    var z = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--tb-z')) || 1;
    bar.classList.toggle('tb-narrow', innerWidth * z < 760);
    var box = bar.getBoundingClientRect(), sides = bar.querySelectorAll('.tb-side');
    var unit = function (el) { return el && !el.hidden ? el.getBoundingClientRect().width * z : 0; };
    var leftEnd = 0; Array.prototype.forEach.call(sides[0].children, function (el) { if (!el.hidden && el.offsetWidth) leftEnd = Math.max(leftEnd, (el.getBoundingClientRect().right - box.left) * z); });
    // Keep room for the longest status ("Refresh paused — edits kept") so a status change never moves the box.
    var used = 0; Array.prototype.forEach.call(sides[1].children, function (el) { if (el !== buttons.sync) used += unit(el); });
    var narrow = bar.classList.contains('tb-narrow');
    var min = leftEnd + 12, max = box.width * z - 6 - used - Math.max(unit(buttons.sync), narrow ? 0 : 196) - 12;
    var width = Math.max(96, Math.min(220, max - min));
    var left = (innerWidth / 2 - box.left) * z - width / 2;
    left = Math.max(min, Math.min(left, max - width));
    search.style.width = width + 'px'; search.style.left = Math.round(left) + 'px';
  }
  function build() {
    var style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);
    bar = document.createElement('div'); bar.className = 'app-titlebar'; bar.setAttribute('role', 'toolbar'); bar.setAttribute('aria-label', 'Window');
    // No app name or icon here: the sidebar already shows them, so the bar starts with the controls.
    var left = document.createElement('div'); left.className = 'tb-side'; bar.appendChild(left);
    left.appendChild(iconButton('back', 'Back (Alt+Left)', function () { travel(-1); }));
    left.appendChild(iconButton('forward', 'Forward (Alt+Right)', function () { travel(1); }));
    left.appendChild(iconButton('sidebar', 'Toggle sidebar (Ctrl+B)', toggleSidebar));
    var gap = document.createElement('span'); gap.className = 'tb-gap'; left.appendChild(gap);
    ['File', 'Edit', 'View', 'Help'].forEach(function (key) { left.appendChild(menuButton(key)); });
    var search = document.createElement('label'); search.className = 'tb-search'; search.title = 'Search (Ctrl+K)';
    search.innerHTML = svg('search', 15) + '<input type="text" autocomplete="off" spellcheck="false" aria-label="Search work, meetings, pages and actions"><kbd>Ctrl K</kbd>';
    var input = search.querySelector('input'); buttons.searchInput = input;
    input.placeholder = 'Search';
    input.addEventListener('focus', function () { input.placeholder = 'Search work, meetings, pages and actions'; openQuick(); });
    input.addEventListener('blur', function () { input.placeholder = 'Search'; });
    input.addEventListener('input', syncInput);
    input.addEventListener('blur', function () { setTimeout(function () { if (qo && qo.drop && !qo.backdrop.hidden && !qo.box.contains(document.activeElement) && document.activeElement !== input) closeQuick(); }, 120); });
    input.addEventListener('keydown', function (e) { if (qo && !qo.backdrop.hidden) quickKey(e); });
    buttons.search = search; bar.appendChild(search);
    var right = document.createElement('div'); right.className = 'tb-side tb-side-right'; bar.appendChild(right);
    var online = document.createElement('button'); online.type = 'button'; online.className = 'tb-online'; online.hidden = true;
    online.addEventListener('click', function () { closeMenu(); go('team'); });
    buttons.online = online; left.appendChild(online);
    var sync = document.createElement('button'); sync.type = 'button'; sync.className = 'tb-sync'; sync.hidden = true;
    sync.innerHTML = '<i aria-hidden="true"></i><span></span>';
    sync.addEventListener('click', function () { if (typeof backgroundSync === 'function') backgroundSync(); });
    buttons.sync = sync; right.appendChild(sync);
    panel = document.createElement('div'); panel.className = 'app-menu-panel'; panel.setAttribute('role', 'menu'); panel.hidden = true;
    subPanel = document.createElement('div'); subPanel.className = 'app-menu-panel'; subPanel.setAttribute('role', 'menu'); subPanel.hidden = true;
    subPanel.addEventListener('mouseenter', function () { clearTimeout(subTimer); });
    catcher = document.createElement('div'); catcher.className = 'app-menu-catcher'; catcher.hidden = true;
    catcher.addEventListener('mousedown', closeMenu);
    buildFind();
    [findbar, subPanel, panel, catcher, bar].forEach(function (el) { document.body.prepend(el); });
    document.addEventListener('keydown', onKey, true);
    syncZoom();
    window.addEventListener('resize', function () { closeMenu(); syncSidebar(); syncZoom(); centerSearch(); });
    if (window.ResizeObserver) { var ro = new ResizeObserver(function () { centerSearch(); }); ro.observe(bar); ro.observe(online); ro.observe(sync); }
    centerSearch();
    if (overlay) overlay.addEventListener('geometrychange', function () { closeMenu(); refresh(); centerSearch(); });
    try { window.matchMedia('(display-mode: window-controls-overlay)').addEventListener('change', function () { closeMenu(); refresh(); }); } catch (_) {}
    document.documentElement.dataset.titlebar = 'ready';
    var status = document.getElementById('sync-status');
    if (status) new MutationObserver(refresh).observe(status, { childList: true, characterData: true, subtree: true, attributes: true });
    // The app's scripts load after this one; wrap navigate once they are ready.
    var tries = 0, wait = setInterval(function () {
      hookNavigate();
      if ((window.navigate && window.navigate.__tf) || ++tries > 100) clearInterval(wait);
      if (signedIn() && typeof currentPage !== 'undefined' && at < 0) record(currentPage);
      refresh();
    }, 100);
    // Sign-in, sign-out and page changes announce themselves; a slow fallback covers anything else (e.g. a sync state).
    var settle = function () { if (signedIn() && at < 0 && typeof currentPage !== 'undefined') record(currentPage); refresh(); };
    window.addEventListener('tf-session', settle);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) settle(); });
    setInterval(settle, 15000);
    // Fetch presence once soon after sign-in so the online avatars do not wait for the first background sync.
    var presenceKick = setInterval(function () { if (!signedIn()) return; clearInterval(presenceKick); try { if (typeof teamPresence !== 'undefined' && !teamPresence && typeof checkWorkspaceRevision === 'function') checkWorkspaceRevision().catch(function () {}); } catch (_) {} }, 2000);
    applyZoom(); refresh();
  }
  if (document.body) build(); else document.addEventListener('DOMContentLoaded', build);
})();
