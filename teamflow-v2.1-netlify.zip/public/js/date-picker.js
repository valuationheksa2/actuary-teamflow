/* Same date picker as ActuarialPro: every <input type="date"> or type="time" keeps its native value, typing and change events;
   only the popup is replaced by a soft rounded one (month/year navigation, Today, Clear). Touch devices keep their native picker. */
(() => {
  'use strict';
  if (window.__datePicker) return;
  window.__datePicker = true;
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const DAYS = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
  const pad = n => String(n).padStart(2, '0');
  const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parse = v => { const m = /^(\d{4})-(\d{2})(?:-(\d{2}))?$/.exec(v || ''); return m ? new Date(+m[1], +m[2] - 1, +(m[3] || 1)) : null; };
  const FIELDS = 'input[type="date"],input[type="month"],input[type="time"]';
  let current = null;

  function close(focus = true) {
    if (!current) return;
    current.panel.remove();
    document.removeEventListener('mousedown', outside, true);
    document.removeEventListener('scroll', onScroll, true);
    window.removeEventListener('resize', onResize, true);
    if (focus) current.input.focus({ preventScroll: true });
    current = null;
  }
  const outside = e => { if (current && !current.panel.contains(e.target) && e.target !== current.input) close(false); };
  const onScroll = e => { if (current && !current.panel.contains(e.target)) close(false); };
  const onResize = () => close(false);

  function show(input) {
    close(false);
    if (input.disabled || input.readOnly) return;
    const monthOnly = input.type === 'month', fmt = d => monthOnly ? `${d.getFullYear()}-${pad(d.getMonth() + 1)}` : iso(d);
    const min = parse(input.min), max = parse(input.max), today = new Date();
    const selected = parse(input.value);
    let view = new Date((selected || today).getFullYear(), (selected || today).getMonth(), 1);
    let focusDay = selected ? new Date(selected) : new Date(today.getFullYear(), today.getMonth(), today.getDate());
    let mode = monthOnly ? 'months' : 'days';
    const panel = document.createElement('div');
    panel.className = 'dp-panel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Choose date'); panel.tabIndex = -1;
    const within = d => (monthOnly ? (!min || d >= new Date(min.getFullYear(), min.getMonth(), 1)) && (!max || d <= max) : (!min || d >= min) && (!max || d <= max));
    const commit = d => {
      input.value = fmt(d);
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      close();
    };
    const nav = (cls, icon, label) => `<button type="button" class="dp-nav" data-act="${cls}" aria-label="${label}">${icon}</button>`;

    function render() {
      let body;
      if (mode === 'days') {
        const start = new Date(view.getFullYear(), view.getMonth(), 1);
        const offset = (start.getDay() + 6) % 7;
        const first = new Date(start); first.setDate(1 - offset);
        let cells = '';
        for (let i = 0; i < 42; i++) {
          const d = new Date(first); d.setDate(first.getDate() + i);
          const out = d.getMonth() !== view.getMonth(), on = selected && iso(d) === iso(selected), now = iso(d) === iso(today), ok = within(d);
          cells += `<button type="button" class="dp-day${out ? ' out' : ''}${on ? ' sel' : ''}${now ? ' today' : ''}${iso(d) === iso(focusDay) ? ' focus' : ''}" data-date="${iso(d)}"${ok ? '' : ' disabled'} tabindex="-1">${d.getDate()}</button>`;
        }
        body = `<div class="dp-week">${DAYS.map(d => `<span>${d}</span>`).join('')}</div><div class="dp-grid">${cells}</div>`;
      } else if (mode === 'months') {
        body = `<div class="dp-months">${MONTHS.map((m, i) => `<button type="button" class="dp-month${selected && selected.getFullYear() === view.getFullYear() && i === selected.getMonth() ? ' sel' : ''}${view.getFullYear() === today.getFullYear() && i === today.getMonth() ? ' now' : ''}" data-month="${i}"${within(new Date(view.getFullYear(), i, 1)) || (max && new Date(view.getFullYear(), i, 1) <= max) ? '' : ' disabled'}>${m.slice(0, 3)}</button>`).join('')}</div>`;
      } else {
        const base = view.getFullYear() - (view.getFullYear() % 12);
        body = `<div class="dp-months">${Array.from({ length: 12 }, (_, i) => base + i).map(y => `<button type="button" class="dp-month${selected && selected.getFullYear() === y ? ' sel' : ''}${y === today.getFullYear() ? ' now' : ''}" data-year="${y}">${y}</button>`).join('')}</div>`;
      }
      const yb = view.getFullYear() - (view.getFullYear() % 12);
      const title = mode === 'days' ? `${MONTHS[view.getMonth()]} ${view.getFullYear()}` : mode === 'months' ? String(view.getFullYear()) : `${yb} – ${yb + 11}`;
      panel.innerHTML = `<div class="dp-head">
        <button type="button" class="dp-title" data-act="mode" aria-label="Change view">${title} <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button>
        <span class="dp-arrows">${nav('prev', '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 5-7 7 7 7"/></svg>', mode === 'days' ? 'Previous month' : mode === 'months' ? 'Previous year' : 'Previous years')}${nav('next', '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg>', mode === 'days' ? 'Next month' : mode === 'months' ? 'Next year' : 'Next years')}</span></div>
        ${body}
        <div class="dp-foot"><button type="button" data-act="clear">Clear</button><button type="button" data-act="today">${monthOnly ? 'This month' : 'Today'}</button></div>`;
    }
    // Changing month or view fades the new page in; moving day by day with the keyboard doesn't.
    const fadeIn = () => panel.querySelector('.dp-grid,.dp-months')?.classList.add('dp-change');
    const shift = n => { view = mode === 'days' ? new Date(view.getFullYear(), view.getMonth() + n, 1) : new Date(view.getFullYear() + (mode === 'years' ? 12 * n : n), view.getMonth(), 1); render(); fadeIn(); };

    panel.addEventListener('mousedown', e => e.preventDefault());
    panel.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b || b.disabled) return;
      if (b.dataset.date) return commit(parse(b.dataset.date));
      if (b.dataset.year) { view = new Date(+b.dataset.year, view.getMonth(), 1); mode = 'months'; render(); return fadeIn(); }
      if (b.dataset.month) { view = new Date(view.getFullYear(), +b.dataset.month, 1); if (monthOnly) return commit(view); mode = 'days'; render(); return fadeIn(); }
      switch (b.dataset.act) {
        case 'prev': return shift(-1);
        case 'next': return shift(1);
        case 'mode': mode = mode === 'days' ? 'months' : mode === 'months' ? 'years' : (monthOnly ? 'months' : 'days'); render(); return fadeIn();
        case 'today': { const t = monthOnly ? new Date(today.getFullYear(), today.getMonth(), 1) : new Date(today.getFullYear(), today.getMonth(), today.getDate()); return within(t) ? commit(t) : undefined; }
        case 'clear': input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true })); return close();
      }
    });
    panel.addEventListener('keydown', e => {
      const move = days => { if (monthOnly) return; focusDay = new Date(focusDay.getFullYear(), focusDay.getMonth(), focusDay.getDate() + days); view = new Date(focusDay.getFullYear(), focusDay.getMonth(), 1); mode = 'days'; render(); };
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); move(-1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); move(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); move(-7); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); move(7); }
      else if (e.key === 'PageUp') { e.preventDefault(); shift(-1); }
      else if (e.key === 'PageDown') { e.preventDefault(); shift(1); }
      else if (e.key === 'Enter' && document.activeElement === panel && mode === 'days') { e.preventDefault(); if (within(focusDay)) commit(focusDay); }
    });
    render();
    mount(panel, input);
  }

  function mount(panel, input) {
    (input.closest('dialog[open]') || document.body).appendChild(panel);
    const r = input.getBoundingClientRect(), h = panel.offsetHeight, w = panel.offsetWidth;
    const flip = window.innerHeight - r.bottom < h + 16 && r.top > h + 16;
    panel.style.left = Math.max(12, Math.min(r.left, window.innerWidth - w - 12)) + 'px';
    panel.style.top = (flip ? Math.max(12, r.top - h - 6) : Math.min(r.bottom + 6, Math.max(12, window.innerHeight - h - 12))) + 'px';
    current = { input, panel };
    document.addEventListener('mousedown', outside, true);
    document.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onResize, true);
    panel.focus({ preventScroll: true });
  }

  // The same panel for <input type="time">: hour and minute columns, with the choice scrolling smoothly to the middle.
  function showTime(input) {
    close(false);
    if (input.disabled || input.readOnly) return;
    const now = /^(\d{2}):(\d{2})/.exec(input.value);
    let hour = now ? now[1] : null, minute = now ? now[2] : null, column = 'hour';
    const hours = Array.from({ length: 24 }, (_, i) => pad(i)), minutes = Array.from({ length: 12 }, (_, i) => pad(i * 5));
    // A time typed by hand may fall between the five-minute steps.
    if (minute && !minutes.includes(minute)) minutes.push(minute), minutes.sort();
    const panel = document.createElement('div');
    panel.className = 'dp-panel tp-panel'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Choose time'); panel.tabIndex = -1;
    const cells = (name, values) => `<div class="tp-col" data-col="${name}">${values.map(v => `<button type="button" class="tp-cell" data-${name}="${v}" tabindex="-1">${v}</button>`).join('')}</div>`;
    panel.innerHTML = `<div class="tp-head"><span>Hour</span><span>Minute</span></div><div class="tp-cols">${cells('hour', hours)}${cells('minute', minutes)}</div><div class="dp-foot"><button type="button" data-act="clear">Clear</button><button type="button" data-act="done">Done</button></div>`;
    const calm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const sync = smooth => {
      panel.querySelectorAll('.tp-col').forEach(col => {
        const name = col.dataset.col, value = name === 'hour' ? hour : minute;
        let target = null;
        col.querySelectorAll('.tp-cell').forEach(cell => { const on = cell.dataset[name] === value; cell.classList.toggle('sel', on); if (on) target = cell; });
        col.classList.toggle('active', column === name);
        target = target || (name === 'hour' ? col.querySelector('[data-hour="09"]') : col.firstElementChild);
        col.scrollTo({ top: target.offsetTop - (col.clientHeight - target.offsetHeight) / 2, behavior: smooth && !calm ? 'smooth' : 'auto' });
      });
    };
    const write = () => {
      hour = hour ?? '09'; minute = minute ?? '00';
      input.value = `${hour}:${minute}`;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      sync(true);
    };
    const step = delta => {
      const values = column === 'hour' ? hours : minutes, value = column === 'hour' ? hour : minute;
      const next = values[(Math.max(values.indexOf(value), 0) + delta + values.length) % values.length];
      if (column === 'hour') hour = next; else minute = next;
      write();
    };
    panel.addEventListener('mousedown', e => e.preventDefault());
    panel.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.hour) { hour = b.dataset.hour; column = 'hour'; return write(); }
      // Choosing the minute finishes the job; the short wait lets the choice be seen.
      if (b.dataset.minute) { minute = b.dataset.minute; column = 'minute'; write(); return setTimeout(() => { if (current && current.panel === panel) close(); }, 160); }
      if (b.dataset.act === 'done') return close();
      if (b.dataset.act === 'clear') { input.value = ''; input.dispatchEvent(new Event('input', { bubbles: true })); input.dispatchEvent(new Event('change', { bubbles: true })); return close(); }
    });
    panel.addEventListener('keydown', e => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
      else if (e.key === 'Enter') { e.preventDefault(); close(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); step(-1); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); step(1); }
      else if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault(); column = e.key === 'ArrowLeft' ? 'hour' : 'minute'; sync(true); }
    });
    mount(panel, input);
    sync(false);
  }

  function enhance(input) {
    if (window.matchMedia('(pointer: coarse)').matches) return;
    if (input._dp || input.closest('[data-native-date]')) return;
    input._dp = true;
    const open = input.type === 'time' ? showTime : show;
    input.classList.add('dp-input');
    // Clicking the calendar icon area (right edge) opens the picker; the rest of the field stays editable by typing.
    const hit = e => { const r = input.getBoundingClientRect(); return e.clientX > r.right - 38; };
    input.addEventListener('mousedown', e => { if (e.button === 0 && hit(e)) { e.preventDefault(); input.focus({ preventScroll: true }); current && current.input === input ? close() : open(input); } });
    input.addEventListener('click', e => { if (hit(e)) e.preventDefault(); });
    input.addEventListener('keydown', e => { if ((e.altKey && e.key === 'ArrowDown') || e.key === 'F4') { e.preventDefault(); open(input); } });
  }
  const scan = root => (root.querySelectorAll ? root.querySelectorAll(FIELDS) : []).forEach(enhance);
  const start = () => {
    scan(document);
    new MutationObserver(rs => rs.forEach(r => r.addedNodes.forEach(n => { if (n.nodeType === 1) { if (n.matches && n.matches(FIELDS)) enhance(n); else scan(n); } }))).observe(document.body, { childList: true, subtree: true });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
