(function attachTeamFlowDomain(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.TeamFlowDomain = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function createTeamFlowDomain() {
  'use strict';

  function dateKeyInZone(date = new Date(), timeZone = 'Asia/Bangkok') {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
    const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  }
  function parseDateKey(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))) return null;
    const date = new Date(`${value}T00:00:00Z`);
    return Number.isNaN(date.getTime()) ? null : date;
  }
  function addDays(value, amount) {
    const date = parseDateKey(value);
    if (!date) return '';
    date.setUTCDate(date.getUTCDate() + amount);
    return date.toISOString().slice(0, 10);
  }
  function startOfWeek(value, offset = 0) {
    const date = parseDateKey(value);
    if (!date) return '';
    date.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7) + offset * 7);
    return date.toISOString().slice(0, 10);
  }
  function weekRange(value, offset = 0) {
    const start = startOfWeek(value, offset);
    return { start, end: addDays(start, 6) };
  }
  function monthRange(year, month) {
    return { start: new Date(Date.UTC(year, month, 1)).toISOString().slice(0, 10), end: new Date(Date.UTC(year, month + 1, 0)).toISOString().slice(0, 10) };
  }
  function yearRange(year) {
    return { start: `${year}-01-01`, end: `${year}-12-31` };
  }
  function shiftMonth(year, month, offset) {
    const date = new Date(Date.UTC(year, month + offset, 1));
    return { year: date.getUTCFullYear(), month: date.getUTCMonth() };
  }
  function formatRange(range, options = { month: 'short', day: 'numeric', year: 'numeric' }) {
    const format = value => {
      const date = parseDateKey(value);
      return date ? new Intl.DateTimeFormat('en-US', { ...options, timeZone: 'UTC' }).format(date) : '';
    };
    return `${format(range.start)} – ${format(range.end)}`;
  }
  // Hours spread evenly over the Monday-to-Friday dates from start through deadline, skipping public holidays
  // and, when a member is given, that member's leave. If every weekday in the range is a day off, the hours
  // fall back to those weekdays so they are never lost (the clash then shows as over capacity).
  function allocateEffortByWeek(work, absences, memberId) {
    const totalHours = Number(work?.estimatedHours);
    const start = parseDateKey(work?.startDate || work?.deadline);
    const end = parseDateKey(work?.deadline || work?.startDate);
    if (!Number.isFinite(totalHours) || totalHours <= 0 || !start || !end || end < start) return {};
    const daysOff = (Array.isArray(absences) ? absences : []).filter(entry => entry && entry.startDate && entry.endDate
      && (entry.type === 'holiday' || (entry.type === 'leave' && memberId != null && String(entry.memberId) === String(memberId))));
    const isDayOff = key => daysOff.some(entry => entry.startDate <= key && entry.endDate >= key);
    const weekdays = [];
    for (let day = new Date(start); day <= end; day.setUTCDate(day.getUTCDate() + 1)) {
      if (day.getUTCDay() === 0 || day.getUTCDay() === 6) continue;
      weekdays.push(day.toISOString().slice(0, 10));
    }
    const workdays = weekdays.filter(key => !isDayOff(key));
    const counts = new Map();
    for (const key of workdays.length ? workdays : weekdays) {
      const week = startOfWeek(key);
      counts.set(week, (counts.get(week) || 0) + 1);
    }
    const totalDays = [...counts.values()].reduce((sum, value) => sum + value, 0);
    if (!totalDays) return {};
    return Object.fromEntries([...counts].map(([week, days]) => [week, totalHours * days / totalDays]));
  }
  // Completed work keeps its effort in the weeks it actually ran, using actual hours when recorded.
  function allocateCapacityByWeek(work, absences, memberId) {
    if (work?.status !== 'done') return allocateEffortByWeek(work, absences, memberId);
    const actual = Number(work.actualHours);
    const estimatedHours = work.actualHours != null && Number.isFinite(actual) && actual >= 0 ? actual : work.estimatedHours;
    if (parseDateKey(work.completedDate)) {
      const start = parseDateKey(work.startDate) && work.startDate <= work.completedDate ? work.startDate : work.completedDate;
      const weekly = allocateEffortByWeek({ startDate: start, deadline: work.completedDate, estimatedHours }, absences, memberId);
      if (Object.keys(weekly).length) return weekly;
    }
    return allocateEffortByWeek({ ...work, estimatedHours }, absences, memberId);
  }
  function reportAsOf(range, today = dateKeyInZone()) {
    return range.end < today ? range.end : today;
  }
  function reportCompletion(work, range, today = dateKeyInZone()) {
    const cutoff = reportAsOf(range, today);
    return work?.status === 'done' && Boolean(parseDateKey(work.completedDate)) && work.completedDate >= range.start && work.completedDate <= cutoff;
  }
  function allocateEffortByMember(work, members, hours = work?.estimatedHours) {
    const totalHours = Number(hours);
    if (!Number.isFinite(totalHours) || totalHours <= 0) return {};
    const eligible = new Map((Array.isArray(members) ? members : [])
      .filter(member => member && member.id != null && member.role !== 'board')
      .map(member => [String(member.id), member]));
    const participantIds = new Set((Array.isArray(work?.assignees) ? work.assignees : []).map(String));
    if (work?.pic != null) participantIds.add(String(work.pic));
    const weighted = [...participantIds].filter(id => eligible.has(id)).map(id => {
      const weight = id === String(work?.pic) ? 1.5 : eligible.get(id).role === 'manager' ? 0.4 : 1;
      return [id, weight];
    });
    const totalWeight = weighted.reduce((sum, [, weight]) => sum + weight, 0);
    return Object.fromEntries(weighted.map(([id, weight]) => [id, totalHours * weight / totalWeight]));
  }
  function reportOngoing(work, range, today = dateKeyInZone()) {
    const cutoff = reportAsOf(range, today);
    // Actual ongoing status takes precedence over a planned start date in the current period.
    if (work?.status === 'ongoing' && range.start <= today && range.end >= today) return true;
    if (!work || range.start > cutoff || !['ongoing', 'done'].includes(work.status)
      || !parseDateKey(work.startDate) || work.startDate > cutoff) return false;
    if (work.status === 'done') {
      return Boolean(parseDateKey(work.completedDate)) && work.completedDate > cutoff;
    }
    return true;
  }
  function reportInMonth(work, range, today = dateKeyInZone()) {
    return reportCompletion(work, range, today) || reportOngoing(work, range, today);
  }
  function mergeCollectionChanges(current, base, next) {
    const same=(a,b)=>JSON.stringify(a??null)===JSON.stringify(b??null);
    const index=items=>{
      if(!Array.isArray(items))throw Object.assign(new Error('Invalid collection snapshot.'),{statusCode:400});
      const map=new Map();
      for(const item of items){
        if(!item||item.id==null||map.has(String(item.id)))throw Object.assign(new Error('Collection IDs must be unique.'),{statusCode:400});
        map.set(String(item.id),item);
      }
      return map;
    };
    const result=index(current),before=index(base),after=index(next);
    for(const id of new Set([...before.keys(),...after.keys()])){
      const old=before.get(id),updated=after.get(id),latest=result.get(id);
      if(same(old,updated))continue;
      if(!same(latest,old)&&!same(latest,updated))throw Object.assign(new Error('This entry changed elsewhere. Refresh before editing it again.'),{statusCode:409});
      if(updated)result.set(id,updated);else result.delete(id);
    }
    return [...result.values()];
  }
  function fileLocationKind(value){
    const location=String(value||'').trim();
    if(!location||location.length>2048||/[\x00-\x1f\x7f]/.test(location))return null;
    if(/^https?:\/\//i.test(location)){
      try{const url=new URL(location);return ['http:','https:'].includes(url.protocol)&&url.hostname?url.protocol.slice(0,-1):null;}catch{return null;}
    }
    if(/^[A-Za-z]:[\\/]/.test(location)&&!/[<>:"|?*]/.test(location.slice(3)))return 'path';
    const network=location.replace(/\\/g,'/');
    if(/^\/\/[A-Za-z0-9._-]+\/[^/]+(?:\/.*)?$/.test(network)&&!/[<>:"|?*]/.test(network))return 'path';
    return null;
  }
  // Elapsed days between two timestamps, leaving out the Saturdays and Sundays in between. Public holidays still count.
  function daysExcludingWeekends(from,to,timeZone='Asia/Bangkok'){
    const start=new Date(from),end=new Date(to);
    if(!(end>start))return 0;
    let days=(end-start)/86400000,key=addDays(dateKeyInZone(start,timeZone),1);
    const last=dateKeyInZone(end,timeZone);
    for(let guard=0;key<last&&guard<3660;guard+=1,key=addDays(key,1)){const weekday=parseDateKey(key).getUTCDay();if(weekday===0||weekday===6)days-=1;}
    return Math.max(0,days);
  }
  const PERFORMANCE_PHASES=['Planning','Executing','Review','Finalize'];
  const clampPoints=(value,max)=>Math.max(0,Math.min(max,value));
  function formatDays(days){return days<1/24?'under 1 h':Math.round(days*24)<24?`${Math.round(days*24)} h`:`${Math.round(days*10)/10} d`;}
  // Rebuilds a completed work's timeline from its activity log. The score is a fixed formula, so the same history always gives the same result.
  function workPerformance(work,entries,timeZone='Asia/Bangkok'){
    const span=(from,to)=>daysExcludingWeekends(from,to,timeZone);
    const phaseDays=[0,0,0,0],visited=[false,false,false,false],decisions=[];
    let current=null,since=null,incomplete=false,awaitingSince=null,reworkSince=null,reworkDays=0,sentBacks=0,movedBack=0,waitDays=0,waitRounds=0,lateDays=null,originalDeadline=null,deadlineMoves=0,deadlineHistoryKnown=true;
    const close=at=>{if(current!=null&&since){phaseDays[current]+=span(since,at);visited[current]=true;}};
    const enter=(phase,at)=>{close(at);current=phase;since=at;};
    for(const entry of (entries||[]).slice().sort((a,b)=>String(a.createdAt).localeCompare(String(b.createdAt)))){
      const at=entry.createdAt,lines=entry.details||[];
      const status=lines.map(line=>line.match(/^Status: (.+) → (.+)$/)).find(Boolean),move=lines.map(line=>line.match(/^Phase: (.+) → (.+)$/)).find(Boolean);
      if(entry.action==='created'&&!since){current=0;since=at;}
      if(entry.action!=='created'&&(entry.changedFields?.phase||entry.changedFields?.status)&&!status&&!move)incomplete=true;
      const deadlineChange=lines.map(line=>line.match(/^Deadline: (.+) → (.+)$/)).find(Boolean);
      if(entry.changedFields?.deadline&&!deadlineChange&&entry.action!=='created')deadlineHistoryKnown=false;
      if(deadlineChange&&deadlineChange[1]!=='none'){if(!originalDeadline)originalDeadline=deadlineChange[1];deadlineMoves+=1;}
      if(status){
        // Replanning before the work starts doesn't count: the commitment is the deadline at the start.
        if(status[1]==='Upcoming'&&status[2]==='Ongoing'){current=0;since=at;originalDeadline=null;deadlineMoves=0;}
        else if(status[2]==='Completed'||status[2]==='Upcoming'){close(at);current=null;since=null;}
        else if(status[1]==='Completed'&&status[2]==='Ongoing'){current=3;since=at;}
      }
      if(entry.action==='approved'||entry.action==='sent back'){
        if(awaitingSince){const wait=span(awaitingSince,at);waitDays+=wait;waitRounds+=1;awaitingSince=null;decisions.push({actorId:entry.actorId,actorName:entry.actorName,decision:entry.action,waitDays:wait,selfReview:String(entry.actorId)===String(work.pic)});}
        if(entry.action==='sent back'){sentBacks+=1;reworkSince=at;}
      }
      if(move){
        const from=PERFORMANCE_PHASES.indexOf(move[1]),to=PERFORMANCE_PHASES.indexOf(move[2]);
        if(to<0)continue;
        if(current!==from){incomplete=true;current=null;since=null;}
        if(from>=2&&to<2&&entry.action!=='sent back'){movedBack+=1;reworkSince=at;}
        enter(to,at);
        if(to===2){if(reworkSince){reworkDays+=span(reworkSince,at);reworkSince=null;}awaitingSince=at;}
        else awaitingSince=null;
      }
    }
    const total=phaseDays.reduce((sum,days)=>sum+days,0),phasesKnown=total>0&&!incomplete;
    const hurried=visited.filter((seen,index)=>seen&&phaseDays[index]<1/24).length;
    const timingReliable=phasesKnown&&hurried<2;
    const phases=PERFORMANCE_PHASES.map((name,index)=>({name,days:phaseDays[index],share:total?phaseDays[index]/total:0}));
    const longest=phases.reduce((top,phase)=>phase.days>top.days?phase:top,phases[0]);
    const bottleneck=timingReliable&&(longest.name==='Executing'?longest.share>=0.7:longest.share>=0.35)?longest:null;
    const reviewWait=waitRounds?waitDays/waitRounds:null;
    const rework=sentBacks+movedBack;
    const components=[],good=[],improve=[];
    const dayWord=value=>`${value} working day${value===1?'':'s'}`;
    const scoredDeadline=originalDeadline||work.deadline||null,which=deadlineMoves?'the original deadline':'the deadline';
    if(scoredDeadline&&work.completedDate){
      const late=work.completedDate>scoredDeadline,gap=Math.round(late?daysExcludingWeekends(scoredDeadline+'T00:00:00Z',work.completedDate+'T00:00:00Z','UTC'):daysExcludingWeekends(work.completedDate+'T00:00:00Z',scoredDeadline+'T00:00:00Z','UTC'));
      lateDays=late?gap:0;
      components.push({label:'Delivery',points:late?clampPoints(40-5*gap,40):40,max:40});
      if(late)improve.push(`Completed ${dayWord(gap)} after ${which}.`);else good.push(gap?`Completed ${dayWord(gap)} before ${which}.`:`Completed on ${which}.`);
      if(deadlineMoves)improve.push(`Deadline moved ${deadlineMoves} time${deadlineMoves===1?'':'s'}, from ${scoredDeadline} to ${work.deadline}.`);
    }
    if(work.actualHours!=null&&Number(work.estimatedHours)>0){
      const estimate=Number(work.estimatedHours),variance=(Number(work.actualHours)-estimate)/estimate,size=Math.abs(variance);
      components.push({label:'Effort vs estimate',points:Math.round(clampPoints((0.5-size)/0.4*20,20)),max:20});
      const text=`${Number(work.actualHours)} h actual against ${estimate} h estimated (${variance>0?'+':''}${Math.round(variance*100)}%).`;
      if(size<=0.1)good.push(`Effort was close to the estimate: ${text}`);else improve.push(`${variance>0?'Effort ran over':'Effort came in under'} the estimate: ${text}`);
    }
    // A PIC approving their own work has no independent review, so a fast decision and no send-backs earn nothing.
    const approval=(work.reviews||[]).filter(review=>review.decision==='approved').pop(),selfReviewed=Boolean(approval?.selfReview);
    if(phasesKnown&&selfReviewed){
      if(rework)improve.push(`Went back from Review or Finalize ${rework} time${rework===1?'':'s'}${reworkDays?`, adding ${formatDays(reworkDays)} before returning to Review`:''}.`);
    }else if(phasesKnown){
      components.push({label:'Rework',points:clampPoints(20-10*rework,20),max:20});
      if(rework)improve.push(`Went back from Review or Finalize ${rework} time${rework===1?'':'s'}${reworkDays?`, adding ${formatDays(reworkDays)} before returning to Review`:''}.`);
      else if(visited[2])good.push('Passed Review without going back.');
    }
    if(reviewWait!=null&&timingReliable&&!selfReviewed){
      components.push({label:'Review wait',points:Math.round(clampPoints((7-reviewWait)/5*20,20)),max:20});
      const text=`${formatDays(reviewWait)} on average for a Review decision${waitRounds>1?` across ${waitRounds} rounds`:''}.`;
      if(reviewWait<=3)good.push(`Quick review: ${text}`);else improve.push(`Slow review: ${text}`);
    }
    if(bottleneck)improve.push(`${bottleneck.name} took ${Math.round(bottleneck.share*100)}% of the time (${formatDays(bottleneck.days)}), the slowest phase.`);
    if(selfReviewed)improve.push('Approved by the PIC, so there was no independent review. Review wait and Rework aren’t scored.');
    const available=components.reduce((sum,item)=>sum+item.max,0);
    const score=available>=60?Math.round(components.reduce((sum,item)=>sum+item.points,0)/available*100):null;
    return {score,available,lateDays,decisions,selfReviewed,originalDeadline:scoredDeadline,deadlineMoves,deadlineHistoryKnown,components,phases,totalDays:total,phasesKnown,timingReliable,incomplete,bottleneck,reviewWait,waitRounds,rework,reworkDays,good,improve};
  }
  // Meeting times are entered in the team's time zone. This finds the instant they refer to.
  function zonedTimeToIso(date,time,timeZone='Asia/Bangkok'){
    const guess=Date.parse(`${date}T${time}:00Z`);
    const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone,hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}).formatToParts(new Date(guess)).map(part=>[part.type,part.value]));
    const shown=Date.UTC(Number(parts.year),Number(parts.month)-1,Number(parts.day),Number(parts.hour),Number(parts.minute),Number(parts.second));
    return new Date(guess-(shown-guess)).toISOString();
  }
  const MEETING_REMINDER_WINDOW_MS=65*60*1000;
  // A calendar file lets a phone raise its own alarm, even with TeamFlow closed.
  function meetingIcs(meeting,now=new Date()){
    const stamp=value=>new Date(value).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
    const text=value=>String(value||'').replace(/\\/g,'\\\\').replace(/;/g,'\\;').replace(/,/g,'\\,').replace(/\r?\n/g,'\\n');
    const fold=line=>{let out='',rest=line;while(rest.length>73){out+=rest.slice(0,73)+'\r\n ';rest=rest.slice(73);}return out+rest;};
    const start=Date.parse(meeting.startsAt),end=start+Number(meeting.durationMinutes||0)*60000;
    return ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Actuarial TeamFlow//Meetings//EN','CALSCALE:GREGORIAN','BEGIN:VEVENT',
      `UID:meeting-${meeting.id}@teamflow`,`DTSTAMP:${stamp(now)}`,`DTSTART:${stamp(start)}`,`DTEND:${stamp(end)}`,`SUMMARY:${text(meeting.title)}`,
      ...(meeting.location?[`LOCATION:${text(meeting.location)}`]:[]),...(meeting.agenda?[`DESCRIPTION:${text(meeting.agenda)}`]:[]),
      'BEGIN:VALARM','ACTION:DISPLAY',`DESCRIPTION:${text(meeting.title)}`,'TRIGGER:-PT15M','END:VALARM','END:VEVENT','END:VCALENDAR'].map(fold).join('\r\n')+'\r\n';
  }
  // Monday-to-Friday days a person is available in a week, after public holidays and their leave.
  function weekAvailability(memberId,weekStart,absences){
    const covers=(entry,day)=>entry.startDate<=day&&entry.endDate>=day;
    const holidays=[],leave=[];
    for(let index=0;index<5;index+=1){
      const day=addDays(weekStart,index),holiday=(absences||[]).find(entry=>entry.type==='holiday'&&covers(entry,day));
      if(holiday)holidays.push(holiday.label);
      else if((absences||[]).some(entry=>entry.type==='leave'&&String(entry.memberId)===String(memberId)&&covers(entry,day)))leave.push(day);
    }
    return {available:5-holidays.length-leave.length,holidays:[...new Set(holidays)],holidayDays:holidays.length,leaveDays:leave.length};
  }
  // Team-wide view over many completed items. Only full, believable timelines count toward phase figures; delivery and effort use everything.
  function summarizePerformance(rows){
    const usable=rows.filter(row=>row.perf.timingReliable);
    const average=values=>values.length?values.reduce((sum,value)=>sum+value,0)/values.length:null;
    const phaseAverages=list=>PERFORMANCE_PHASES.map((name,index)=>({name,days:average(list.map(row=>row.perf.phases[index].days))??0}));
    const phases=phaseAverages(usable);
    const total=phases.reduce((sum,phase)=>sum+phase.days,0);
    phases.forEach(phase=>{phase.share=total?phase.days/total:0;});
    const counts=PERFORMANCE_PHASES.map(name=>({name,count:usable.filter(row=>row.perf.bottleneck?.name===name).length}));
    const known=rows.filter(row=>row.perf.phasesKnown);
    const independent=usable.filter(row=>row.perf.reviewWait!=null&&!row.perf.selfReviewed);
    const waits=independent.map(row=>row.perf.reviewWait);
    const measured=rows.filter(row=>row.perf.lateDays!=null),late=measured.filter(row=>row.perf.lateDays>0);
    const effortRows=rows.filter(row=>row.actualHours!=null&&Number(row.estimatedHours)>0);
    const actual=effortRows.reduce((sum,row)=>sum+Number(row.actualHours),0),estimate=effortRows.reduce((sum,row)=>sum+Number(row.estimatedHours),0);
    const reviewed=known.filter(row=>row.perf.waitRounds>0||row.perf.rework>0);
    const groupBy=(keysOf,limit=20)=>{
      const groups=new Map();
      for(const row of usable)for(const key of keysOf(row))if(key){if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row);}
      return [...groups.entries()].map(([name,list])=>{
        const days=phaseAverages(list),slowest=days.reduce((top,phase)=>phase.days>top.days?phase:top,days[0]);
        return {name,count:list.length,phases:days.map(phase=>phase.days),total:days.reduce((sum,phase)=>sum+phase.days,0),slowest:slowest.name};
      }).sort((a,b)=>b.count-a.count||String(a.name).localeCompare(String(b.name))).slice(0,limit);
    };
    return {
      completed:rows.length,analyzed:usable.length,phases,bottleneckCounts:counts,
      averageTotalDays:average(usable.map(row=>row.perf.totalDays)),
      averageReviewWait:average(waits),reviewWaitCount:waits.length,
      reworked:known.filter(row=>row.perf.rework>0).length,knownCount:known.length,
      selfReviewed:rows.filter(row=>row.perf.selfReviewed).length,
      delivery:{measured:measured.length,onTime:measured.length-late.length,rate:measured.length?(measured.length-late.length)/measured.length:null,averageDaysLate:average(late.map(row=>row.perf.lateDays))},
      effort:{count:effortRows.length,actual,estimate,variance:estimate?(actual-estimate)/estimate:null},
      firstTime:{count:reviewed.length,passed:reviewed.filter(row=>row.perf.rework===0).length,rate:reviewed.length?reviewed.filter(row=>row.perf.rework===0).length/reviewed.length:null},
      breakdowns:{workType:groupBy(row=>[row.workType||'regular']),priority:groupBy(row=>[row.priority||'Medium']),tag:groupBy(row=>row.tags||[],8)},
      longestWaits:independent.slice().sort((a,b)=>b.perf.reviewWait-a.perf.reviewWait).slice(0,5).map(row=>({id:row.id,title:row.title,days:row.perf.reviewWait,rounds:row.perf.waitRounds})),
      slowest:usable.slice().sort((a,b)=>b.perf.totalDays-a.perf.totalDays).slice(0,10).map(row=>({id:row.id,title:row.title,days:row.perf.totalDays,phases:row.perf.phases.map(phase=>phase.days),bottleneck:row.perf.bottleneck?.name||null})),
    };
  }
  // Per-person figures. The server only sends these to administrators.
  function summarizePeople(rows,nameOf){
    const average=values=>values.length?values.reduce((sum,value)=>sum+value,0)/values.length:null;
    const pics=new Map(),reviewers=new Map();
    for(const row of rows){
      if(row.pic!=null){if(!pics.has(String(row.pic)))pics.set(String(row.pic),[]);pics.get(String(row.pic)).push(row);}
      for(const decision of (row.perf.decisions||[])){
        if(decision.selfReview)continue;
        const key=String(decision.actorId);
        if(!reviewers.has(key))reviewers.set(key,{name:decision.actorName||nameOf(decision.actorId),waits:[],sentBack:0});
        const reviewer=reviewers.get(key);reviewer.waits.push(decision.waitDays);if(decision.decision==='sent back')reviewer.sentBack+=1;
      }
    }
    return {
      pics:[...pics.entries()].map(([id,list])=>{
        const measured=list.filter(row=>row.perf.lateDays!=null),usable=list.filter(row=>row.perf.timingReliable);
        return {name:nameOf(id),completed:list.length,onTimeRate:measured.length?measured.filter(row=>row.perf.lateDays===0).length/measured.length:null,averageDays:average(usable.map(row=>row.perf.totalDays)),usable:usable.length,rework:list.filter(row=>row.perf.rework>0).length};
      }).sort((a,b)=>String(a.name).localeCompare(String(b.name))),
      reviewers:[...reviewers.values()].map(reviewer=>({name:reviewer.name,decisions:reviewer.waits.length,averageWait:average(reviewer.waits),sentBack:reviewer.sentBack})).sort((a,b)=>String(a.name).localeCompare(String(b.name))),
    };
  }
  const FILE_ICONS={folder:'📁',doc:'📄',dashboard:'📊',workspace:'🏢',others:'🔖',notes:'📝',design:'🎨',sheet:'📊',checklist:'✅',internal:'🔗',media:'🖼',archive:'📦'};
  // Managers, administrators and the PIC can sign off; a PIC deciding on their own work is labelled self-review.
  function canSignOff(user,work){
    if(!user||!work)return false;
    return ['admin','manager'].includes(user.role)||(user.role==='member'&&String(work.pic)===String(user.id));
  }
  function isSelfReview(user,work){return Boolean(user&&work)&&String(work.pic)===String(user.id);}
  // Work can't pass Review without an approval. Work already past Review, or finished, is never held back.
  function signOffBlocks(current,next){
    if(!current||current.status==='done')return false;
    const from=Number(current.phase)||0;
    if(from>2||!(Number(next.phase)>2||next.status==='done'))return false;
    return !(from===2&&current.reviewApproved===true);
  }
  return { addDays, allocateCapacityByWeek, allocateEffortByMember, allocateEffortByWeek, canSignOff, dateKeyInZone, daysExcludingWeekends, FILE_ICONS, fileLocationKind, formatDays, formatRange, isSelfReview, meetingIcs, MEETING_REMINDER_WINDOW_MS, mergeCollectionChanges, monthRange, parseDateKey, reportAsOf, reportCompletion, reportInMonth, reportOngoing, shiftMonth, signOffBlocks, startOfWeek, summarizePeople, summarizePerformance, weekAvailability, weekRange, workPerformance, yearRange, zonedTimeToIso };
});
