(function attachTeamFlowDomain(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.TeamFlowDomain = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function createTeamFlowDomain() {
  'use strict';

  function dateKeyInZone(date = new Date(), timeZone = 'Asia/Bangkok') {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
    const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  }
  function parseDateKey(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))) return null;
    const date = new Date(`${value}T00:00:00Z`);
    return Number.isNaN(date.getTime()) ? null : date;
  }
  function addDays(value, amount) {
    const date = parseDateKey(value);
    if (!date) return '';
    date.setUTCDate(date.getUTCDate() + amount);
    return date.toISOString().slice(0, 10);
  }
  function startOfWeek(value, offset = 0) {
    const date = parseDateKey(value);
    if (!date) return '';
    date.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7) + offset * 7);
    return date.toISOString().slice(0, 10);
  }
  function weekRange(value, offset = 0) {
    const start = startOfWeek(value, offset);
    return { start, end: addDays(start, 6) };
  }
  function monthRange(year, month) {
    return { start: new Date(Date.UTC(year, month, 1)).toISOString().slice(0, 10), end: new Date(Date.UTC(year, month + 1, 0)).toISOString().slice(0, 10) };
  }
  function yearRange(year) {
    return { start: `${year}-01-01`, end: `${year}-12-31` };
  }
  function shiftMonth(year, month, offset) {
    const date = new Date(Date.UTC(year, month + offset, 1));
    return { year: date.getUTCFullYear(), month: date.getUTCMonth() };
  }
  function formatRange(range, options = { month: 'short', day: 'numeric', year: 'numeric' }) {
    const format = value => {
      const date = parseDateKey(value);
      return date ? new Intl.DateTimeFormat('en-US', { ...options, timeZone: 'UTC' }).format(date) : '';
    };
    return `${format(range.start)} – ${format(range.end)}`;
  }
  function allocateEffortByWeek(work) {
    const totalHours = Number(work?.estimatedHours);
    const start = parseDateKey(work?.startDate || work?.deadline);
    const end = parseDateKey(work?.deadline || work?.startDate);
    if (!Number.isFinite(totalHours) || totalHours <= 0 || !start || !end || end < start) return {};
    const counts = new Map();
    for (let day = new Date(start); day <= end; day.setUTCDate(day.getUTCDate() + 1)) {
      if (day.getUTCDay() === 0 || day.getUTCDay() === 6) continue;
      const key = startOfWeek(day.toISOString().slice(0, 10));
      counts.set(key, (counts.get(key) || 0) + 1);
    }
    const totalDays = [...counts.values()].reduce((sum, value) => sum + value, 0);
    if (!totalDays) return {};
    return Object.fromEntries([...counts].map(([week, days]) => [week, totalHours * days / totalDays]));
  }
  function reportAsOf(range, today = dateKeyInZone()) {
    return range.end < today ? range.end : today;
  }
  function reportCompletion(work, range, today = dateKeyInZone()) {
    const cutoff = reportAsOf(range, today);
    return work?.status === 'done' && Boolean(parseDateKey(work.completedDate)) && work.completedDate >= range.start && work.completedDate <= cutoff;
  }
  function allocateEffortByMember(work, members, hours = work?.estimatedHours) {
    const totalHours = Number(hours);
    if (!Number.isFinite(totalHours) || totalHours <= 0) return {};
    const eligible = new Map((Array.isArray(members) ? members : [])
      .filter(member => member && member.id != null && member.role !== 'board')
      .map(member => [String(member.id), member]));
    const participantIds = new Set((Array.isArray(work?.assignees) ? work.assignees : []).map(String));
    if (work?.pic != null) participantIds.add(String(work.pic));
    const weighted = [...participantIds].filter(id => eligible.has(id)).map(id => {
      const weight = id === String(work?.pic) ? 1.5 : eligible.get(id).role === 'manager' ? 0.4 : 1;
      return [id, weight];
    });
    const totalWeight = weighted.reduce((sum, [, weight]) => sum + weight, 0);
    return Object.fromEntries(weighted.map(([id, weight]) => [id, totalHours * weight / totalWeight]));
  }
  function reportOngoing(work, range, today = dateKeyInZone()) {
    const cutoff = reportAsOf(range, today);
    // Actual ongoing status takes precedence over a planned start date in the current period.
    if (work?.status === 'ongoing' && range.start <= today && range.end >= today) return true;
    if (!work || range.start > cutoff || !['ongoing', 'done'].includes(work.status)
      || !parseDateKey(work.startDate) || work.startDate > cutoff) return false;
    if (work.status === 'done') {
      return Boolean(parseDateKey(work.completedDate)) && work.completedDate > cutoff;
    }
    return true;
  }
  function reportInMonth(work, range, today = dateKeyInZone()) {
    return reportCompletion(work, range, today) || reportOngoing(work, range, today);
  }
  function mergeCollectionChanges(current, base, next) {
    const same=(a,b)=>JSON.stringify(a??null)===JSON.stringify(b??null);
    const index=items=>{
      if(!Array.isArray(items))throw Object.assign(new Error('Invalid collection snapshot.'),{statusCode:400});
      const map=new Map();
      for(const item of items){
        if(!item||item.id==null||map.has(String(item.id)))throw Object.assign(new Error('Collection IDs must be unique.'),{statusCode:400});
        map.set(String(item.id),item);
      }
      return map;
    };
    const result=index(current),before=index(base),after=index(next);
    for(const id of new Set([...before.keys(),...after.keys()])){
      const old=before.get(id),updated=after.get(id),latest=result.get(id);
      if(same(old,updated))continue;
      if(!same(latest,old)&&!same(latest,updated))throw Object.assign(new Error('This entry changed elsewhere. Refresh before editing it again.'),{statusCode:409});
      if(updated)result.set(id,updated);else result.delete(id);
    }
    return [...result.values()];
  }
  function fileLocationKind(value){
    const location=String(value||'').trim();
    if(!location||location.length>2048||/[\x00-\x1f\x7f]/.test(location))return null;
    if(/^https?:\/\//i.test(location)){
      try{const url=new URL(location);return ['http:','https:'].includes(url.protocol)&&url.hostname?url.protocol.slice(0,-1):null;}catch{return null;}
    }
    if(/^[A-Za-z]:[\\/]/.test(location)&&!/[<>:"|?*]/.test(location.slice(3)))return 'path';
    const network=location.replace(/\\/g,'/');
    if(/^\/\/[A-Za-z0-9._-]+\/[^/]+(?:\/.*)?$/.test(network)&&!/[<>:"|?*]/.test(network))return 'path';
    return null;
  }
  return { addDays, allocateEffortByMember, allocateEffortByWeek, dateKeyInZone, fileLocationKind, formatRange, mergeCollectionChanges, monthRange, parseDateKey, reportAsOf, reportCompletion, reportInMonth, reportOngoing, shiftMonth, startOfWeek, weekRange, yearRange };
});
