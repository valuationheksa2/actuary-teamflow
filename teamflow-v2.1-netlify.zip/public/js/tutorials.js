'use strict';
// Step-by-step tutorials shown inside each Help & Guide section. Keys match the section titles in renderHelp.
// "roles" limits a tutorial to people who can actually do it; "page" adds a button that opens the right place.
const HELP_TUTORIALS={
  'Work Management':[
    {title:'Create a work item',page:'ongoing',roles:['admin','manager','member'],steps:[
      'Open Ongoing or Upcoming and select <strong>+ Add Work</strong> in the top bar.',
      'Enter a title and description, or pick a template under <strong>Use a template</strong> to fill the form in.',
      'Set the start date, deadline, estimated hours, priority and work type.',
      'Choose the PIC and select the team members who will work on it.',
      'Check the tasks for each phase, adding or removing them as needed.',
      'Select <strong>Create Work</strong>. Upcoming work starts by itself on its start date.',
    ]},
    {title:'Move work through its phases',page:'ongoing',roles:['admin','manager','member'],steps:[
      'Open the work item from any list.',
      'On the <strong>Overview</strong> tab, tick tasks in the current phase as they finish.',
      'Select <strong>Advance to …</strong> at the bottom of the window to move to the next phase. Remaining tasks in that phase are ticked for you.',
      'Use <strong>Back to …</strong> if the work needs to return to an earlier phase.',
      'Work in Review needs a sign-off decision before it can move on. See the next tutorial.',
    ]},
    {title:'Approve or send back work in Review',page:'dashboard',roles:['admin','manager','member'],steps:[
      'Find what is waiting under <strong>Waiting for Your Sign-off</strong> on the Dashboard, oldest first. Admins and managers see all of it; members see work where they are the PIC.',
      'Open the work item and check it.',
      'To accept it, select <strong>Approve</strong>. A comment is optional. The work can then move to Finalize.',
      'To return it, select <strong>Send Back</strong> and say what needs to change. The work goes back to Executing and the PIC is notified.',
      'When work comes back to Review it needs a new decision. Earlier decisions stay on record under <strong>Review Sign-off</strong>.',
      'If you are the PIC, your decision is recorded as PIC self-review.',
    ]},
    {title:'Add notes and file links',page:'ongoing',roles:['admin','manager','member'],steps:[
      'Open a work item you are working on.',
      'Open the <strong>Notes</strong> tab, type your update and select <strong>Add Note</strong>. Everyone on the work is alerted. Use <strong>Edit</strong> on your own note to change it.',
      'On the <strong>Overview</strong> tab, select <strong>+ Add File / Folder Link</strong>.',
      'Enter a name and a web link, a Windows drive path or a network path, choose the type, then select <strong>Add Link</strong>.',
      'Web links show <strong>Open</strong>. Windows and network paths show <strong>Copy Path</strong>, which you paste into File Explorer.',
    ]},
    {title:'Change who is working on it',page:'ongoing',roles:['admin','manager','member'],steps:[
      'If you are the creator or PIC, or an admin or manager: open the work and select <strong>Manage Assignees</strong> on the Overview tab, change the selection, then select <strong>Save Assignees</strong>.',
      'If you are a member who wants to join: open the work and select <strong>Request to Join</strong>.',
      'To step off work you are on: select <strong>Request to Leave</strong>.',
      'The PIC, a manager or an admin approves or rejects these on the Requests page.',
    ]},
    {title:'Complete work',page:'ongoing',roles:['admin','manager','member'],steps:[
      'Move the work to Finalize, then open it.',
      'Select <strong>Mark Complete</strong>.',
      'Enter the actual hours spent. It starts with the estimate.',
      'Select <strong>Complete Work</strong>. It moves to History, and recurring work creates its next occurrence.',
      'Admins can use <strong>Reopen Work</strong> or <strong>Edit Completed Work</strong> on completed items if something needs correcting.',
    ]},
    {title:'Read the Performance tab on completed work',page:'history',steps:[
      'Open a completed item from History and select the <strong>Performance</strong> tab.',
      'The score out of 100 combines Delivery, Effort vs estimate, Rework and Review wait. A grey partial score means some of those couldn’t be measured.',
      'The bars show time in each phase, leaving out weekends. A red bar marks a phase that took an unusually large share.',
      'Read <strong>What went well</strong> and <strong>What to improve</strong> for the reasons behind the score.',
      'Treat the score as a pointer to where to look, not as an assessment of people.',
    ]},
  ],
  'Search & Filters':[
    {title:'Find work quickly',page:'ongoing',steps:[
      'Open Ongoing, Upcoming or History.',
      'Type in <strong>Search work</strong>. It looks through titles, people, tags, phase, priority, notes and file names, in any word order.',
      'Narrow the list with Work type, Priority, Phase and PIC, and choose an order under <strong>Sort by</strong>.',
      'Filters are remembered when you come back. Select the <strong>reset</strong> icon beside them to clear them.',
      'On Ongoing, select <strong>View</strong> on the “ready for review” banner to show only work in Review, and <strong>Show all</strong> to go back.',
    ]},
  ],
  'Accounts & Roles':[
    {title:'Update your profile',steps:[
      'Select your name at the bottom of the sidebar to open <strong>My Profile</strong>.',
      'On the <strong>Profile</strong> tab, change your details, weekly capacity, photo or avatar color.',
      'Select <strong>Save changes</strong>.',
      'Use the <strong>Security</strong> tab to change your password.',
    ],action:{label:'Open My Profile',call:'openMyProfile()'}},
    {title:'Turn on notifications',steps:[
      'Select your name at the bottom of the sidebar and open the <strong>Notifications</strong> tab.',
      'Select <strong>Turn on</strong> for this device and allow notifications when your browser asks. Each browser or installed app asks separately.',
      'Choose which alerts you want: Updates on your work, Meetings, and Due today &amp; overdue. Board accounts have Meetings only.',
      'Select <strong>Save changes</strong>.',
    ],action:{label:'Open My Profile',call:'openMyProfile()'}},
    {title:'Add or change a team member',page:'admin',roles:['admin'],steps:[
      'Open <strong>Admin Panel</strong>.',
      'Select <strong>+ Add Member</strong>, enter their details, role and weekly capacity, then select <strong>Add Member</strong>.',
      'Share the single-use invitation link so they can set a password. It lasts 24 hours.',
      'Use <strong>Edit</strong> on a member to change their details or role, or to create a new reset link.',
    ]},
    {title:'Manage default tags',page:'admin',roles:['admin'],steps:[
      'Open <strong>Admin Panel</strong> and find <strong>Default Tags</strong>.',
      'Type a tag and add it. It then appears as a choice on work and template forms.',
      'Remove any tag you no longer want offered. Work already using it keeps it.',
    ]},
  ],
  'Schedule & Calendar':[
    {title:'Use the calendar',page:'upcoming',steps:[
      'Open <strong>Upcoming</strong>. The month calendar is at the top.',
      'Move between months with the arrows or the month and year selectors. <strong>Today</strong> returns to this month.',
      'Light blue marks a start date and red marks a deadline.',
      'Select a day to see what starts and is due that day, then open any item from there.',
    ]},
  ],
  'Meetings':[
    {title:'Schedule a meeting',page:'meetings',roles:['admin','manager','member'],steps:[
      'Open <strong>Meetings</strong> and select <strong>+ New Meeting</strong> in the top bar. To link work straight away, open the work item, go to its <strong>Meetings</strong> tab and select <strong>+ Schedule Meeting</strong>.',
      'Enter the title and agenda.',
      'Set the date, start time (Jakarta GMT +7), duration, and a room or link.',
      'Select the attendees.',
      'Under <strong>Linked work</strong>, search and tick any related work. This is optional, and a meeting can link to several items.',
      'Select <strong>Schedule Meeting</strong>. Attendees are alerted straight away.',
    ]},
    {title:'Get reminded',page:'meetings',steps:[
      'Turn on notifications for your device in My Profile, and keep <strong>Meetings</strong> switched on.',
      'A reminder arrives within the hour before the meeting. Its timing can vary from a few minutes to an hour.',
      'While TeamFlow is open, a banner also shows during the last hour. Select <strong>Open</strong> to see the meeting.',
      'For an exact alarm, open the meeting and select <strong>Add to Calendar</strong>. Open the downloaded file to add it to your phone or computer calendar, which alerts you 15 minutes before.',
    ]},
    {title:'Record minutes and action points',page:'meetings',roles:['admin','manager','member'],steps:[
      'Open the meeting from the list. Past meetings are on the <strong>Past</strong> tab.',
      'Type under <strong>Minutes</strong> and select <strong>Save Minutes</strong>.',
      'Under <strong>Action Points</strong>, type the action, choose an owner and select <strong>Add</strong>.',
      'Select <strong>Create Work</strong> on an action point to turn it into a work item. The form fills in, and the new work links back to the meeting.',
      'Under <strong>Linked Files &amp; Folders</strong>, select <strong>+ Add File / Folder Link</strong> to attach documents.',
    ]},
    {title:'Change or cancel a meeting',page:'meetings',roles:['admin','manager','member'],steps:[
      'Open the meeting. Only its organizer or an admin sees these options.',
      'Select <strong>Edit</strong>, make your changes and select <strong>Save Changes</strong>. Attendees are alerted if the time or place changes, and anyone added or removed hears about it.',
      'Select <strong>Cancel Meeting</strong> to cancel it. Attendees are alerted, and it stays on the Past tab marked Cancelled.',
    ]},
  ],
  'Weekly Capacity':[
    {title:'Check who has room',page:'capacity',steps:[
      'Open <strong>Capacity</strong> and use the arrows to choose a week.',
      'Each person shows planned hours against available hours. A red bar means over capacity.',
      'The chips under each person show the work behind those hours. Select a chip to open that work.',
      'Hours are spread evenly across a work item’s weekdays and shared among its team, with the PIC carrying more.',
    ]},
    {title:'Record leave and public holidays',page:'capacity',roles:['admin','manager','member'],steps:[
      'Open <strong>Capacity</strong> and select <strong>Leave &amp; Holidays</strong>.',
      'Choose the type. Members can add their own leave, and managers and admins can also add anyone’s leave and public holidays.',
      'Set the dates and a note or holiday name, then select <strong>Add</strong>.',
      'That person’s available hours drop for those days. Planned hours don’t move, so a clash shows as over capacity for you to resolve.',
      'Select <strong>Remove</strong> if plans change.',
    ]},
  ],
  'Daily PDF':[
    {title:'Export the daily report',page:'dashboard',steps:[
      'Open the <strong>Dashboard</strong> and select <strong>Export PDF</strong> at the top right.',
      'Open the downloaded file in your browser.',
      'Use Print, then Save as PDF.',
    ]},
  ],
  'Dashboard, Audit & History':[
    {title:'Start your day from the Dashboard',page:'dashboard',steps:[
      'Open the <strong>Dashboard</strong>. Overdue items show just below the totals. Select <strong>View</strong> to see them.',
      'Check <strong>Waiting for Your Sign-off</strong> and <strong>Today’s Meetings</strong>, then select a row to open it.',
      'Use the totals, Active Work, Work by Phase, Due Soon and Team Workload for the overall picture.',
    ]},
    {title:'Run an Audit Report',page:'audit',steps:[
      'Open <strong>Audit Report</strong> and choose <strong>Weekly</strong>, <strong>Monthly</strong> or <strong>Annual</strong>.',
      'Use the arrows to choose the period. Completed work is grouped by its completion date.',
      'Select a row to open that work. Its sign-off shows on the row, and hovering over it shows the full comment.',
      'Select <strong>Export PDF</strong> to download the report. Open the file and use Print, then Save as PDF.',
    ]},
    {title:'See team performance',page:'audit',roles:['admin','manager','board'],steps:[
      'Open <strong>Audit Report</strong> and select the <strong>Performance</strong> tab.',
      'Choose the last 30 days, 90 days or 12 months.',
      'Start with the summary line, then the bars, which show the average time work spends in each phase. A red bar marks a phase taking an unusually large share.',
      'Check the measures below it: on-time delivery, effort against estimate, review wait and first-time approval, each with the previous period where there is enough history.',
      'Use the tables to see where different kinds of work slow down, by work type, priority and tag. Groups marked “few items” can’t support a conclusion yet. Select a row under Longest-running items to open that work.',
      'Read the line about how many items were counted. Work without a full history is left out of the phase figures, so early results may rest on few items.',
      'Select <strong>Export PDF</strong> to save the report. Administrators also see figures by person, which stay out of the PDF.',
    ]},
    {title:'Look at past work and the team',page:'history',steps:[
      'Open <strong>History</strong> to search completed work, then open an item for its full record.',
      'The <strong>History</strong> tab on any work item lists who changed what, and when.',
      'Open <strong>Team</strong> to see each person’s ongoing and completed work.',
    ]},
  ],
  'Templates, Recurrence & Requests':[
    {title:'Create a template',page:'ongoing',roles:['admin','manager','member'],steps:[
      'Select <strong>+ Add Work</strong> and fill in the form as you want the template to be.',
      'Select <strong>Save as Template</strong> at the bottom of the form.',
      'Name it, choose an icon and colour, and select <strong>Save template</strong>.',
    ]},
    {title:'Use or edit a template',page:'templates',roles:['admin','manager','member'],steps:[
      'Open <strong>Templates</strong> and search if needed.',
      'Select <strong>Use Template</strong>. The work form opens filled in. Check the dates and team, then create the work.',
      'To change a template, including its icon and colour, select the pencil on its card, then select <strong>Save Template</strong>.',
    ]},
    {title:'Set up recurring work',page:'ongoing',roles:['admin','manager','member'],steps:[
      'In the work form, choose how often it repeats under <strong>Recurrence</strong>. Custom sets a number of days.',
      'When the work is completed, the next occurrence is created automatically with new dates and unticked tasks.',
      'See what is currently repeating under <strong>Active Recurring Work</strong> on the Templates page.',
    ]},
    {title:'Handle join and leave requests',page:'requests',roles:['admin','manager','member'],steps:[
      'Open <strong>Requests</strong>. The number beside it shows how many are waiting.',
      'Select <strong>Approve</strong> or <strong>Reject</strong>. Members can do this for work where they are the PIC.',
      'An approved request updates the work’s assignees straight away. A PIC must be changed before they can leave their own work.',
    ]},
  ],
  'Saving & Accessibility':[
    {title:'Resolve a save conflict',steps:[
      'If two people change the same work, you’ll see <strong>Save conflict — edits kept</strong> in the top bar. Nothing is lost.',
      'Select <strong>Review conflict</strong> to compare the versions.',
      'Choose a version for each field both people changed, then select <strong>Save reviewed version</strong>. Or select <strong>Use latest saved</strong> to drop your changes.',
    ]},
    {title:'Send feedback',page:'feedback',steps:[
      'Open <strong>Feedback</strong>.',
      'Choose a category and describe the issue or idea.',
      'Select <strong>Submit Feedback</strong>. You can see its status on the same page.',
    ]},
  ],
};
function helpTutorialsHtml(sectionTitle){
  const key=String(sectionTitle).replace(/&amp;/g,'&');
  const tutorials=(HELP_TUTORIALS[key]||[]).filter(tutorial=>!tutorial.roles||tutorial.roles.includes(currentUser?.role));
  if(!tutorials.length)return'';
  const open=(tutorial)=>{
    if(tutorial.action)return`<button type="button" class="btn btn-ghost btn-sm" onclick="${tutorial.action.call}">${tutorial.action.label}</button>`;
    return tutorial.page?`<button type="button" class="btn btn-ghost btn-sm" onclick="navigate('${tutorial.page}')">Go to this page</button>`:'';
  };
  return`<div class="help-tutorials"><div class="help-subhead">Tutorials</div>${tutorials.map(tutorial=>`<details class="help-tutorial"><summary>${tutorial.title}</summary><ol>${tutorial.steps.map(step=>`<li>${step}</li>`).join('')}</ol>${open(tutorial)}</details>`).join('')}<div class="help-subhead" style="margin-top:14px;">Reference</div></div>`;
}
