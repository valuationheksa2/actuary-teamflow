'use strict';
// Step-by-step tutorials shown inside each Help & Guide section. Keys match the section titles in renderHelp.
// "roles" limits a tutorial to people who can actually do it; "page" adds a button that opens the right place.
const HELP_TUTORIALS={
  'Work Management':[
    {title:'Create a work item',targets:['#add-work-btn','@field:Use a Template','@row:Start Date','@field:PIC','@field:Phase Tasks','@text:Create Work'],page:'ongoing',roles:['admin','manager','member'],steps:[
      'Open Ongoing or Upcoming and select <strong>+ Add Work</strong> in the top bar.',
      'Enter a title and description, or pick a template under <strong>Use a template</strong> to fill the form in.',
      'Set the start date, deadline, estimated hours, priority and work type.',
      'Choose the PIC and select the team members who will work on it.',
      'Check the tasks for each phase, adding or removing them as needed.',
      'Select <strong>Create Work</strong>. Upcoming work starts by itself on its start date.',
    ]},
    {title:'Move work through its phases',targets:['.work-item','@section:Phase Progress','@text:Advance to…','@text:Back to…','@text:Approve'],page:'ongoing',roles:['admin','manager','member'],steps:[
      'Open the work item from any list.',
      'On the <strong>Overview</strong> tab, tick tasks in the current phase as they finish.',
      'Select <strong>Advance to …</strong> at the bottom of the window to move to the next phase. Remaining tasks in that phase are ticked for you.',
      'Use <strong>Back to …</strong> if the work needs to return to an earlier phase.',
      'Work in Review needs a sign-off decision before it can move on. See the next tutorial.',
    ]},
    {title:'Approve or send back work in Review',targets:['section:Waiting for Your Sign-off','@section:Phase Progress','@text:Approve','@text:Send Back','@section:Review Sign-off','#modal-overlay .form-hint'],page:'dashboard',roles:['admin','manager','member'],steps:[
      'Find what is waiting under <strong>Waiting for Your Sign-off</strong> on the Dashboard, oldest first. Admins and managers see all of it; members see work where they are the PIC.',
      'Open the work item and check it.',
      'To accept it, select <strong>Approve</strong>. A comment is optional. The work can then move to Finalize.',
      'To return it, select <strong>Send Back</strong> and say what needs to change. The work goes back to Executing and the PIC is notified.',
      'When work comes back to Review it needs a new decision. Earlier decisions stay on record under <strong>Review Sign-off</strong>.',
      'If you are the PIC, your decision is recorded as PIC self-review.',
    ]},
    {title:'Add notes and file links',targets:['.work-item','@text:Add Note','@text:+ Add File / Folder Link','#modal-overlay .modal-body','@.file-link-item'],page:'ongoing',roles:['admin','manager','member'],steps:[
      'Open a work item you are working on.',
      'Open the <strong>Notes</strong> tab, type your update and select <strong>Add Note</strong>. Everyone on the work is alerted. Use <strong>Edit</strong> on your own note to change it.',
      'On the <strong>Overview</strong> tab, select <strong>+ Add File / Folder Link</strong>.',
      'Enter a name and a web link, a Windows drive path or a network path, choose the type, then select <strong>Add Link</strong>.',
      'Web links show <strong>Open</strong>. Windows and network paths show <strong>Copy Path</strong>, which you paste into File Explorer.',
    ]},
    {title:'Change who is working on it',targets:['@text:Manage Assignees','@text:Request to Join','@text:Request to Leave','section:Pending Requests'],page:'ongoing',roles:['admin','manager','member'],steps:[
      'If you are the creator or PIC, or an admin or manager: open the work and select <strong>Manage Assignees</strong> on the Overview tab, change the selection, then select <strong>Save Assignees</strong>.',
      'If you are a member who wants to join: open the work and select <strong>Request to Join</strong>.',
      'To step off work you are on: select <strong>Request to Leave</strong>.',
      'The PIC, a manager or an admin approves or rejects these on the Requests page.',
    ]},
    {title:'Complete work',targets:['@section:Phase Progress','@text:Mark Complete','@field:Actual','@text:Complete Work','@text:Reopen Work'],page:'ongoing',roles:['admin','manager','member'],steps:[
      'Move the work to Finalize, then open it.',
      'Select <strong>Mark Complete</strong>.',
      'Enter the actual hours spent. It starts with the estimate.',
      'Select <strong>Complete Work</strong>. It moves to History, and recurring work creates its next occurrence.',
      'Admins can use <strong>Reopen Work</strong> or <strong>Edit Completed Work</strong> on completed items if something needs correcting.',
    ]},
    {title:'Read the Performance tab on completed work',targets:['@text:Performance','@[id^="performance-body-"] > div:first-child','@[id^="performance-body-"] > div:has(.perf-bar)','@[id^="performance-body-"] > div:has(> ul.history-details)','@[id^="performance-body-"] > div:nth-child(2)'],page:'history',steps:[
      'Open a completed item from History and select the <strong>Performance</strong> tab.',
      'The score out of 100 combines Delivery, Effort vs estimate, Rework and Review wait. A grey partial score means some of those couldn’t be measured.',
      'The bars show time in each phase, leaving out weekends. A red bar marks a phase that took an unusually large share.',
      'Read <strong>What went well</strong> and <strong>What to improve</strong> for the reasons behind the score.',
      'Treat the score as a pointer to where to look, not as an assessment of people.',
    ]},
  ],
  'Search & Filters':[
    {title:'Find work quickly',targets:['#work-list','.work-filter-search','.filter-bar','.work-filter-reset','.review-banner:not(.review-banner-overdue)'],page:'ongoing',steps:[
      'Open Ongoing, Upcoming or History.',
      'Type in <strong>Search work</strong>. It looks through titles, people, tags, phase, priority, notes and file names, in any word order.',
      'Narrow the list with Work type, Priority, Phase and PIC, and choose an order under <strong>Sort by</strong>.',
      'Filters are remembered when you come back. Select the <strong>reset</strong> icon beside them to clear them.',
      'On Ongoing, select <strong>View</strong> on the “ready for review” banner to show only work in Review, and <strong>Show all</strong> to go back.',
    ]},
    {title:'Search from the title bar',targets:['.tb-search','.app-qo-list','.app-qo-list','.app-qo-types','.app-qo-list'],page:'dashboard',steps:[
      'In the installed app, select <strong>Search</strong> in the title bar, or press <strong>Ctrl+K</strong> from any page.',
      'Before you type, the list shows Recently opened, your work and upcoming meetings. Start typing to search pages, work, meetings and actions together.',
      'Add <strong>mine</strong>, <strong>overdue</strong>, <strong>review</strong> or <strong>today</strong> to narrow the work, for example “mine overdue”.',
      'Press <strong>Tab</strong>, or select a scope, to switch between All, Pages, Work, Meetings and Actions.',
      'Use the arrow keys and press <strong>Enter</strong>, or select a result, to open it. <strong>Esc</strong> closes the search panel.',
    ]},
  ],
  'Accounts & Roles':[
    {title:'Update your profile',targets:['.sidebar-user','@.pf-panel.active','@text:Save changes','@text:Security'],steps:[
      'Select your name at the bottom of the sidebar to open <strong>My Profile</strong>.',
      'On the <strong>Profile</strong> tab, change your details, weekly capacity, photo or avatar color. <strong>Help language</strong> switches Help & Guide, tutorial steps and Changelog between English (EN) and Bahasa Indonesia (ID) on this device.',
      'Select <strong>Save changes</strong>.',
      'Use the <strong>Security</strong> tab to change your password.',
    ],action:{label:'Open My Profile',call:'openMyProfile()'}},
    {title:'Turn on notifications',targets:['@text:Notifications','@.pf-device','@.pf-list','@text:Save changes'],steps:[
      'Select your name at the bottom of the sidebar and open the <strong>Notifications</strong> tab.',
      'Select <strong>Turn on</strong> for this device and allow notifications when your browser asks. Each browser or installed app asks separately.',
      'Choose which alerts you want: Updates on your work, Meetings, and Due today &amp; overdue. Board accounts have Meetings only.',
      'Select <strong>Save changes</strong>.',
    ],action:{label:'Open My Profile',call:'openMyProfile()'}},
    {title:'Add or change a team member',targets:['#add-member-btn','#modal-overlay .modal-body',null,'text:Edit'],page:'admin',roles:['admin'],steps:[
      'Open <strong>Admin Panel</strong>.',
      'Select <strong>+ Add Member</strong>, enter their details, role and weekly capacity, then select <strong>Add Member</strong>.',
      'Share the single-use invitation link so they can set a password. It lasts 24 hours.',
      'Use <strong>Edit</strong> on a member to change their details or role, or to create a new reset link.',
    ]},
    {title:'Manage default tags',targets:['section:Default Tags','#new-tag-name','#tag-admin-list'],page:'admin',roles:['admin'],steps:[
      'Open <strong>Admin Panel</strong> and find <strong>Default Tags</strong>.',
      'Type a tag and add it. It then appears as a choice on work and template forms.',
      'Remove any tag you no longer want offered. Work already using it keeps it.',
    ]},
  ],
  'Schedule & Calendar':[
    {title:'Use the calendar',targets:['section:Schedule','.schedule-controls','.schedule-legend','#modal-overlay .modal'],page:'upcoming',steps:[
      'Open <strong>Upcoming</strong>. The month calendar is at the top.',
      'Move between months with the arrows or the month and year selectors. <strong>Today</strong> returns to this month.',
      'Light blue marks a start date and red marks a deadline.',
      'Select a day to see what starts and is due that day, then open any item from there.',
    ]},
  ],
  'Meetings':[
    {title:'Schedule a meeting',targets:['#add-meeting-btn','@field:Title','@row:Date','@field:Attendees','@field:Linked work','@text:Schedule Meeting'],page:'meetings',roles:['admin','manager','member'],steps:[
      'Open <strong>Meetings</strong> and select <strong>+ New Meeting</strong> in the top bar. To link work straight away, open the work item, go to its <strong>Meetings</strong> tab and select <strong>+ Schedule Meeting</strong>.',
      'Enter the title and agenda.',
      'Set the date, start time (Jakarta GMT +7), duration, and a room or link.',
      'Select the attendees.',
      'Under <strong>Linked work</strong>, search and tick any related work. This is optional, and a meeting can link to several items.',
      'Select <strong>Schedule Meeting</strong>. Attendees are alerted straight away.',
    ]},
    {title:'Record a meeting that already happened',targets:['#add-meeting-btn','@row:Date','#mf-past-hint','@text:Record Meeting','@text:Save Minutes'],page:'meetings',roles:['admin','manager','member'],steps:[
      'Open <strong>Meetings</strong> and select <strong>+ New Meeting</strong>. Use this for a meeting you forgot to schedule or an impromptu one.',
      'Enter the title, agenda and attendees, then set the date and time the meeting actually took place.',
      'Once that time has passed, a note says the meeting will be recorded as held. No invites or reminders are sent.',
      'Select <strong>Record Meeting</strong>. It goes on the Past tab, marked Recorded afterwards.',
      'The meeting opens straight away: type the minutes and select <strong>Save Minutes</strong>, then add any action points.',
    ]},
    {title:'Get reminded',targets:['@.pf-list','#meetings-list','.meeting-banner','@text:Add to Calendar'],page:'meetings',steps:[
      'Turn on notifications for your device in My Profile, and keep <strong>Meetings</strong> switched on.',
      'A reminder arrives within the hour before the meeting. Its timing can vary from a few minutes to an hour.',
      'While TeamFlow is open, a banner also shows during the last hour. Select <strong>Open</strong> to see the meeting.',
      'For an exact alarm, open the meeting and select <strong>Add to Calendar</strong>. Open the downloaded file to add it to your phone or computer calendar, which alerts you 15 minutes before.',
    ]},
    {title:'Record minutes and action points',targets:['text:Past','@text:Save Minutes','@section:Action Points','@text:Create Work','@text:+ Add File / Folder Link'],page:'meetings',roles:['admin','manager','member'],steps:[
      'Open the meeting from the list. Past meetings are on the <strong>Past</strong> tab.',
      'Type under <strong>Minutes</strong> and select <strong>Save Minutes</strong>.',
      'Under <strong>Action Points</strong>, type the action, choose an owner and select <strong>Add</strong>.',
      'Select <strong>Create Work</strong> on an action point to turn it into a work item. The form fills in, and the new work links back to the meeting.',
      'Under <strong>Linked Files &amp; Folders</strong>, select <strong>+ Add File / Folder Link</strong> to attach documents.',
    ]},
    {title:'Change or cancel a meeting',targets:['#meetings-list','@text:Edit','@text:Cancel Meeting'],page:'meetings',roles:['admin','manager','member'],steps:[
      'Open the meeting. Only its organizer or an admin sees these options.',
      'Select <strong>Edit</strong>, make your changes and select <strong>Save Changes</strong>. Attendees are alerted if the time or place changes, and anyone added or removed hears about it.',
      'Select <strong>Cancel Meeting</strong> to cancel it. Attendees are alerted, and it stays on the Past tab marked Cancelled.',
    ]},
  ],
  'Weekly Capacity':[
    {title:'Check who has room',targets:['.capacity-header','.cap-row .cap-bar','.cap-toggle','text:Leave & Holidays'],page:'capacity',steps:[
      'Open <strong>Capacity</strong> and use the arrows to choose a week. The line under the dates says how many people are over capacity and whether the week has a public holiday.',
      'Each person shows planned hours against the hours they have that week. Past their limit, the bar runs on in red stripes after a marker, and the percentage sits beside the hours.',
      'Select <strong>work items</strong> under a bar to see the work behind those hours. Select an item to open it.',
      'Leave and public holidays reduce available hours. Record them under <strong>Leave &amp; Holidays</strong>.',
    ]},
    {title:'Open a teammate’s profile',targets:['.team-card','#modal-overlay .mp-stats','#modal-overlay .mp-section'],page:'team',steps:[
      'Open <strong>Team</strong>. Each card shows whether the person is online and their nearest four projects. Select the card.',
      'The profile shows ongoing work, work they lead as PIC, anything overdue, and their on-time rate over the last 12 months.',
      'Below are current work by deadline, work starting soon, leave and recently completed items. Select any item to open it.',
    ]},
    {title:'Record leave and public holidays',targets:['text:Leave & Holidays','#modal-overlay .modal-body','@text:Add','.cap-row:has(.cap-away)','@text:Remove'],page:'capacity',roles:['admin','manager','member'],steps:[
      'Open <strong>Capacity</strong> and select <strong>Leave &amp; Holidays</strong>.',
      'Choose the type. Members can add their own leave, and managers and admins can also add anyone’s leave and public holidays.',
      'Set the dates and a note or holiday name, then select <strong>Add</strong>.',
      'That person’s available hours drop for those days, and their planned hours move to the other working days between each work’s start date and deadline. If there are no other working days, the hours stay and show as over capacity.',
      'Select <strong>Remove</strong> if plans change.',
    ]},
  ],
  'Dashboard Report':[
    {title:'Export the Dashboard Report',targets:['text:Export PDF',null,null],page:'dashboard',steps:[
      'Open the <strong>Dashboard</strong>, select <strong>Export PDF</strong> at the top right, then <strong>Export</strong> to confirm.',
      'Open the downloaded file in your browser.',
      'Use Print, then Save as PDF.',
    ]},
  ],
  'Dashboard, Audit & History':[
    {title:'Start your day from the Dashboard',targets:['.review-banner-overdue','section:Waiting for Your Sign-off','.stat-card[title^="Work completed by its deadline"]','section:Active Work'],page:'dashboard',steps:[
      'Open the <strong>Dashboard</strong>. Overdue items show just below the totals. Select <strong>View</strong> to see them.',
      'Check <strong>Waiting for Your Sign-off</strong> and <strong>Today’s Meetings</strong>, then select a row to open it.',
      '<strong>On-time Rate</strong> shows how much work over the last 12 months was finished by its deadline, with the change against last month. It turns red below 75%.',
      'Use the totals, Active Work, Work by Phase, Due Soon and Team Workload for the overall picture.',
    ]},
    {title:'Run an Audit Report',targets:['text:Weekly Report','#audit-content','section:Completed Work','text:Export PDF'],page:'audit',steps:[
      'Open <strong>Audit Report</strong> and choose <strong>Weekly</strong>, <strong>Monthly</strong> or <strong>Annual</strong>.',
      'Use the arrows to choose the period. Completed work is grouped by its completion date.',
      'Select a row to open that work. Its sign-off shows on the row, and hovering over it shows the full comment.',
      'Select <strong>Export PDF</strong> to download the report. Open the file and use Print, then Save as PDF.',
    ]},
    {title:'See team performance',targets:['text:Performance','.card-header:has(#bottleneck-days) > div:last-child','.perf-summary','.perf-kpis','.perf-table-wrap','.perf-note','text:Export PDF'],page:'audit',roles:['admin','manager','board'],steps:[
      'Open <strong>Audit Report</strong> and select the <strong>Performance</strong> tab.',
      'Choose the last 30 days, 90 days or 12 months.',
      'Start with the summary line, then the bars, which show the average time work spends in each phase. A red bar marks a phase taking an unusually large share.',
      'Check the measures below it: on-time delivery, effort against estimate, review wait and first-time approval, each with the previous period where there is enough history.',
      'Use the tables to see where different kinds of work slow down, by work type, priority and tag. Groups marked “few items” can’t support a conclusion yet. Select a row under Longest-running items to open that work.',
      'Read the line about how many items were counted. Work without a full history is left out of the phase figures, so early results may rest on few items.',
      'Select <strong>Export PDF</strong> to save the report. Administrators also see figures by person, which stay out of the PDF.',
    ]},
    {title:'Look at past work and the team',targets:['#work-list','@text:History','.team-card'],page:'history',steps:[
      'Open <strong>History</strong> to search completed work, then open an item for its full record.',
      'The <strong>History</strong> tab on any work item lists who changed what, and when.',
      'Open <strong>Team</strong> to see each person’s ongoing and completed work.',
    ]},
  ],
  'Templates, Recurrence & Requests':[
    {title:'Create a template',targets:['#add-work-btn','@text:Save as Template','.app-dialog-body'],page:'ongoing',roles:['admin','manager','member'],steps:[
      'Select <strong>+ Add Work</strong> and fill in the form as you want the template to be.',
      'Select <strong>Save as Template</strong> at the bottom of the form.',
      'Name it, choose an icon and colour, and select <strong>Save template</strong>.',
    ]},
    {title:'Use or edit a template',targets:['#template-search','text:Use Template','.template-icon-btn'],page:'templates',roles:['admin','manager','member'],steps:[
      'Open <strong>Templates</strong> and search if needed.',
      'Select <strong>Use Template</strong>. The work form opens filled in. Check the dates and team, then create the work.',
      'To change a template, including its icon and colour, select the pencil on its card, then select <strong>Save Template</strong>.',
    ]},
    {title:'Set up recurring work',targets:['@field:Recurrence',null,'section:Active Recurring Work'],page:'ongoing',roles:['admin','manager','member'],steps:[
      'In the work form, choose how often it repeats under <strong>Recurrence</strong>. Custom sets a number of days.',
      'When the work is completed, the next occurrence is created automatically with new dates and unticked tasks.',
      'See what is currently repeating under <strong>Active Recurring Work</strong> on the Templates page.',
    ]},
    {title:'Handle join and leave requests',targets:['section:Pending Requests','text:Approve','section:Request History'],page:'requests',roles:['admin','manager','member'],steps:[
      'Open <strong>Requests</strong>. The number beside it shows how many are waiting.',
      'Select <strong>Approve</strong> or <strong>Reject</strong>. Members can do this for work where they are the PIC.',
      'An approved request updates the work’s assignees straight away. A PIC must be changed before they can leave their own work.',
    ]},
  ],
  'Saving & Accessibility':[
    {title:'Use the installed app’s title bar',targets:[null,'.app-titlebar .tb-icon','.app-menu-panel','.tb-online','.tb-sync'],steps:[
      'Install TeamFlow from Chrome (Cast, save, and share → Install page as app) and open it. TeamFlow’s own title bar replaces Chrome’s.',
      'Use <strong>Back</strong> and <strong>Forward</strong> to move between pages, and <strong>Toggle sidebar</strong> (Ctrl+B) for more room.',
      'The <strong>File</strong>, <strong>Edit</strong>, <strong>View</strong> and <strong>Help</strong> menus list common actions with their shortcuts, including Find in page (Ctrl+F) and zoom.',
      'Avatars show the teammates who are online now. Select them to open Team.',
      'The sync status sits on the right. Select it to check for changes now.',
    ]},
    {title:'Resolve a save conflict',targets:[null,null,null],steps:[
      'If two people change the same work, you’ll see <strong>Save conflict — edits kept</strong> in the top bar. Nothing is lost.',
      'Select <strong>Review conflict</strong> to compare the versions.',
      'Choose a version for each field both people changed, then select <strong>Save reviewed version</strong>. Or select <strong>Use latest saved</strong> to drop your changes.',
    ]},
    {title:'Send feedback',targets:['section:Submit Feedback','#fb-text','text:Submit Feedback'],page:'feedback',steps:[
      'Open <strong>Feedback</strong>.',
      'Choose a category and describe the issue or idea.',
      'Select <strong>Submit Feedback</strong>. You can see its status on the same page.',
    ]},
  ],
};
// Each step with a target has a picture named after the tutorial, e.g. check-who-has-room-2.jpg (made by scripts/tutorial-shots.js).
function tutorialSlug(title){return String(title).toLowerCase().replace(/[’']/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');}
Object.values(HELP_TUTORIALS).forEach(list=>list.forEach(tutorial=>{if(tutorial.targets&&!tutorial.shots)tutorial.shots=tutorial.targets.map((target,i)=>target?`${tutorialSlug(tutorial.title)}-${i+1}`:null);}));
function helpTutorialsHtml(sectionTitle){
  const key=String(sectionTitle).replace(/&amp;/g,'&');
  const tutorials=(HELP_TUTORIALS[key]||[]).filter(tutorial=>!tutorial.roles||tutorial.roles.includes(currentUser?.role));
  if(!tutorials.length)return'';
  const open=(tutorial)=>{
    if(tutorial.action)return`<button type="button" class="btn btn-ghost btn-sm" onclick="${tutorial.action.call}">${tutorial.action.label}</button>`;
    return tutorial.page?`<button type="button" class="btn btn-ghost btn-sm" onclick="navigate('${tutorial.page}')">Go to this page</button>`:'';
  };
  const key2=encodeURIComponent(key);
  return`<div class="help-tutorials"><div class="help-subhead">Tutorials</div><div class="tut-grid">${tutorials.map(tutorial=>{const index=(HELP_TUTORIALS[key]||[]).indexOf(tutorial),shot=tutorial.shots&&tutorial.shots.find(Boolean);return`<button type="button" class="tut-card${shot?' has-shot':''}" onclick="openTutorial(decodeURIComponent('${key2}'),${index})">${shot?`<img src="/img/tutorials/${shot}.jpg" alt="" loading="lazy" decoding="async">`:'<span class="tut-card-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5V5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-1.5z"/><path d="M8 7h6M8 11h6"/></svg></span>'}<span class="tut-card-text"><strong>${tutorial.title}</strong><small>${tutorial.steps.length} steps${shot?' · with pictures':''}</small></span></button>`;}).join('')}</div><div class="help-subhead" style="margin-top:14px;">Reference</div></div>`;
}
// Tutorial viewer: a floating panel with no backdrop, so people can follow the steps in the app while it stays open.
// It keeps its tutorial, step, position and minimised state for the tab session, across page changes and reloads.
// "targets" (one per step) lets "Show me" glow the real element: a CSS selector, or "text:Label" for a button by its text.
let tutorialState=null;
const TUT_KEY='tfTutorial';
function tutSave(){try{if(tutorialState)sessionStorage.setItem(TUT_KEY,JSON.stringify({section:tutorialState.section,index:tutorialState.index,step:tutorialState.step,min:!!tutorialState.min,x:tutorialState.x,y:tutorialState.y,w:tutorialState.w}));else sessionStorage.removeItem(TUT_KEY);}catch(e){}}
function tutPanel(){
  let el=document.getElementById('tut-float');
  if(!el){el=document.createElement('div');el.id='tut-float';el.className='tut-float';el.setAttribute('role','dialog');el.setAttribute('aria-label','Tutorial');document.body.appendChild(el);el.addEventListener('keydown',tutKeys);}
  return el;
}
function openTutorial(section,index,restore){
  const tutorial=(HELP_TUTORIALS[section]||[])[index];if(!tutorial)return;
  const keep=restore||{};
  tutorialState={tutorial,section,index,step:Math.min(keep.step||0,tutorial.steps.length-1),min:!!keep.min,x:keep.x,y:keep.y,w:keep.w};
  const el=tutPanel();el.classList.remove('is-closing');el.classList.add('is-entering');setTimeout(()=>el.classList.remove('is-entering'),300);
  renderTutorialStep();tutSave();
  (tutorial.shots||[]).forEach(name=>{if(name){const img=new Image();img.src=`/img/tutorials/${name}.jpg`;}}); // preload the rest
  if(!restore&&!matchMedia('(pointer: coarse)').matches)setTimeout(()=>el.querySelector('.tut-f-next,.tut-f-primary')?.focus({preventScroll:true}),50);
}
function closeTutorial(){
  const el=document.getElementById('tut-float');tutorialState=null;tutSave();tutClearSpot();document.body.classList.remove('tut-open','tut-min');
  if(!el)return;el.classList.add('is-closing');setTimeout(()=>el.remove(),200);
}
function toggleTutorialMin(){if(!tutorialState)return;tutorialState.min=!tutorialState.min;renderTutorialStep();tutSave();}
const TUT_MIN_W=300,TUT_MAX_W=820;
function tutPlace(el){
  if(window.innerWidth<=640){el.style.left='';el.style.top='';el.style.right='';el.style.bottom='';el.style.width='';return;}
  el.style.width=!tutorialState.min&&tutorialState.w?Math.max(TUT_MIN_W,Math.min(TUT_MAX_W,window.innerWidth-16,tutorialState.w))+'px':'';
  if(tutorialState.x==null){el.style.left='';el.style.top='';el.style.right='';el.style.bottom='';return;}
  const w=el.offsetWidth,h=el.offsetHeight;
  const x=Math.max(8,Math.min(window.innerWidth-w-8,tutorialState.x)),y=Math.max(8,Math.min(window.innerHeight-Math.min(h,120)-8,tutorialState.y));
  el.style.left=x+'px';el.style.top=y+'px';el.style.right='auto';el.style.bottom='auto';
}
function renderTutorialStep(direction=0){
  if(!tutorialState)return;
  const {tutorial,step,min}=tutorialState,total=tutorial.steps.length,shot=tutorial.shots&&tutorial.shots[step];
  const anyShots=(tutorial.shots||[]).some(Boolean),last=step===total-1,target=tutorial.targets&&tutorial.targets[step];
  const el=tutPanel();el.classList.toggle('is-min',!!min);document.body.classList.add('tut-open');document.body.classList.toggle('tut-min',!!min);
  const icon=(d)=>`<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  if(min){
    el.innerHTML=`<button type="button" class="tut-pill" onclick="toggleTutorialMin()" aria-label="Expand tutorial"><span class="tut-pill-icon">${icon('<path d="M4 19.5V5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-1.5z"/><path d="M8 7h6M8 11h6"/>')}</span><span class="tut-pill-text"><strong>${tutorial.title}</strong><small>Step ${step+1} of ${total}</small></span></button><button type="button" class="tut-icon-btn" onclick="closeTutorial()" aria-label="Close tutorial">${icon('<path d="M18 6 6 18M6 6l12 12"/>')}</button>`;
    tutPlace(el);return;
  }
  const onPage=tutorial.page&&typeof currentPage!=='undefined'&&currentPage===tutorial.page;
  el.innerHTML=`<div class="tut-f-head" data-drag><div class="tut-f-title"><small>Tutorial · Step ${step+1} of ${total}</small><strong>${tutorial.title}</strong></div>
      <button type="button" class="tut-icon-btn" onclick="toggleTutorialMin()" aria-label="Minimise tutorial" title="Minimise">${icon('<path d="M5 12h14"/>')}</button>
      <button type="button" class="tut-icon-btn" onclick="closeTutorial()" aria-label="Close tutorial" title="Close">${icon('<path d="M18 6 6 18M6 6l12 12"/>')}</button></div>
    <div class="tut-f-body">
      ${anyShots?`<div class="tut-figure">${shot?`<button type="button" class="tut-zoom" onclick="zoomTutorialShot()" aria-label="Enlarge picture" title="Click to enlarge"><img src="/img/tutorials/${shot}.jpg" alt="Example screen for step ${step+1}" decoding="async"></button>`:'<div class="tut-figure-empty">No picture for this step</div>'}</div>`:''}
      <div class="tut-step${direction?` tut-step-${direction>0?'next':'prev'}`:''}"><p${longTextLang(tutorial.steps[step])}>${longText(tutorial.steps[step])}</p></div>
      <div class="tut-f-tools">${tutorial.page&&!onPage?`<button type="button" class="btn btn-ghost btn-sm" onclick="tutorialGo()">Take me there</button>`:''}${target?`<button type="button" class="btn btn-ghost btn-sm" onclick="tutorialShowMe()">${icon('<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>')} Show me</button>`:''}${anyShots?'<span class="tut-note">Pictures use fictional sample data.</span>':''}</div>
    </div>
    <div class="tut-f-foot"><div class="tut-dots" role="tablist" aria-label="Steps">${tutorial.steps.map((_,i)=>`<button type="button" role="tab" aria-selected="${i===step}" aria-label="Step ${i+1}" class="${i===step?'is-on':''}" onclick="goTutorialStep(${i})"></button>`).join('')}</div>
      <div class="tut-f-btns">${step>0?'<button type="button" class="btn btn-ghost btn-sm" onclick="goTutorialStep(tutorialState.step-1)">Back</button>':''}${last?'<button type="button" class="btn btn-primary btn-sm tut-f-primary" onclick="closeTutorial()">Done</button>':'<button type="button" class="btn btn-primary btn-sm tut-f-next" onclick="goTutorialStep(tutorialState.step+1)">Next</button>'}</div></div><div class="tut-resize" data-resize title="Drag to resize · double-click to reset" aria-hidden="true"></div>`;
  tutPlace(el);
}
function goTutorialStep(index){if(!tutorialState)return;const next=Math.max(0,Math.min(tutorialState.tutorial.steps.length-1,index));if(next===tutorialState.step)return;const dir=next>tutorialState.step?1:-1;tutorialState.step=next;tutClearSpot();renderTutorialStep(dir);tutSave();}
async function tutorialGo(){if(!tutorialState?.tutorial.page)return;if(document.getElementById('modal-overlay')?.style.display==='flex'&&typeof closeModal==='function')closeModal();await navigate(tutorialState.tutorial.page);renderTutorialStep();}
// Target syntax: "text:Label" a button or tab by its text (a trailing … matches the start), "field:Label" a form field by its label,
// "row:Label" the form row holding that field, "section:Title" a card or detail section by its title, otherwise a CSS selector.
// Elements in an open window are preferred over the page behind it.
function tutFind(target){
  if(!target)return null;
  const visible=el=>!!el&&(el.offsetParent!==null||(getComputedStyle(el).position==='fixed'&&el.getClientRects().length>0))&&!el.closest('#tut-float');
  const modal=document.getElementById('modal-overlay');const modalOpen=modal&&modal.style.display==='flex';
  const roots=[modalOpen?modal:null,document.getElementById('content'),document.body].filter(Boolean);
  const norm=t=>String(t||'').replace(/\s+/g,' ').trim();
  const match=(text,label)=>label.endsWith('…')?text.startsWith(label.slice(0,-1).trim()):text===label;
  // A leading @ means the element lives in a window (Add Work, a work item, My Profile…), so the page behind is never searched.
  const inWindow=target.startsWith('@');if(inWindow){target=target.slice(1);if(!modalOpen)return null;}
  const [kind,...rest]=target.split(':');const label=rest.join(':').trim();
  for(const root of (inWindow?[modal]:roots)){
    let found=null;
    if(kind==='text')found=[...root.querySelectorAll('button,[role=tab],a,.tab')].find(el=>visible(el)&&match(norm(el.textContent).replace(/\s*\(\d+\)$/,''),label));
    else if(kind==='field'||kind==='row'){const lab=[...root.querySelectorAll('.form-label,label')].find(el=>visible(el)&&norm(el.textContent).startsWith(label));const group=lab&&(lab.closest('.form-group')||lab.parentElement);found=kind==='row'?(group&&(group.closest('.form-row')||group)):group;}
    else if(kind==='section'){const head=[...root.querySelectorAll('.card-title,.detail-section-title,.section-title,.mp-section-title')].find(el=>visible(el)&&norm(el.textContent).startsWith(label));found=head&&(head.closest('.card,.detail-section,.mp-section')||head.parentElement);}
    else found=[...root.querySelectorAll(target)].find(visible);
    if(found)return found;
  }
  return null;
}
function tutClearSpot(){document.querySelectorAll('.tut-live-spot').forEach(el=>el.remove());}
async function tutorialShowMe(){
  if(!tutorialState)return;
  const {tutorial,step}=tutorialState,target=tutorial.targets&&tutorial.targets[step];
  let el=tutFind(target);
  if(!el&&!target.startsWith('@')&&tutorial.page&&typeof currentPage!=='undefined'&&currentPage!==tutorial.page){await tutorialGo();await new Promise(r=>setTimeout(r,350));el=tutFind(target);}
  if(!el&&/^\.(tb-|app-titlebar|app-qo|app-menu)/.test(target)&&!matchMedia('(display-mode: window-controls-overlay)').matches){showToast('This is in the installed app’s title bar. Install TeamFlow from Chrome to use it.','info');return;}
  if(!el){showToast(target.startsWith('@')?'Open the window from the earlier steps first, then try Show me again.':'Follow the earlier steps first, then try Show me again.','info');return;}
  tutClearSpot();
  // Scroll first and wait until the page has settled, then glow. The glow stays where it is and goes as soon as
  // someone scrolls, clicks, or a window opens over the element, so it never drifts over other content.
  const token=(window.__tutSpotToken=(window.__tutSpotToken||0)+1);
  el.scrollIntoView({block:'center',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
  await new Promise(resolve=>{let last=null,still=0;const start=Date.now();const tick=()=>{const r=el.getBoundingClientRect(),key=Math.round(r.top)+','+Math.round(r.left);still=key===last?still+1:0;last=key;if(still>=4||Date.now()-start>1500)resolve();else requestAnimationFrame(tick);};requestAnimationFrame(tick);});
  if(token!==window.__tutSpotToken||!el.isConnected||!tutorialState)return;
  const spot=document.createElement('div');spot.className='tut-live-spot';document.body.appendChild(spot);
  const r=el.getBoundingClientRect();Object.assign(spot.style,{left:r.left-6+'px',top:r.top-6+'px',width:r.width+12+'px',height:r.height+12+'px'});
  let done=false;
  const finish=()=>{if(done)return;done=true;clearInterval(timer);document.removeEventListener('pointerdown',onDown,true);document.removeEventListener('scroll',onScroll,true);window.removeEventListener('wheel',onScroll,true);window.removeEventListener('touchmove',onScroll,true);window.removeEventListener('resize',onScroll);spot.classList.add('is-out');setTimeout(()=>spot.remove(),300);};
  const onDown=event=>{if(!event.target.closest('#tut-float'))finish();};
  const onScroll=event=>{if(event&&event.target&&event.target.closest&&event.target.closest('#tut-float'))return;finish();};
  const timer=setInterval(()=>{const modal=document.getElementById('modal-overlay');if(!el.isConnected||(modal&&modal.style.display==='flex'&&!modal.contains(el)))finish();},120);
  document.addEventListener('pointerdown',onDown,true);document.addEventListener('scroll',onScroll,true);window.addEventListener('wheel',onScroll,{capture:true,passive:true});window.addEventListener('touchmove',onScroll,{capture:true,passive:true});window.addEventListener('resize',onScroll);
  setTimeout(finish,2600);
}
function zoomTutorialShot(){
  const img=document.querySelector('#tut-float .tut-figure img');if(!img)return;
  const box=document.createElement('div');box.className='tut-lightbox';box.setAttribute('role','dialog');box.setAttribute('aria-label','Enlarged picture');
  box.innerHTML=`<img src="${img.getAttribute('src')}" alt="${img.alt}"><span>Click anywhere or press Esc to close</span>`;
  const close=()=>{box.classList.add('is-out');setTimeout(()=>box.remove(),180);document.removeEventListener('keydown',esc,true);};
  const esc=e=>{if(e.key==='Escape'){e.stopPropagation();close();}};
  box.addEventListener('click',close);document.addEventListener('keydown',esc,true);document.body.appendChild(box);
}
function tutKeys(event){
  if(!tutorialState||tutorialState.min)return;
  if(event.target.closest('input,textarea,select'))return;
  if(event.key==='ArrowRight'){event.preventDefault();goTutorialStep(tutorialState.step+1);}
  else if(event.key==='ArrowLeft'){event.preventDefault();goTutorialStep(tutorialState.step-1);}
  else if(event.key==='Escape'){event.preventDefault();toggleTutorialMin();}
}
// Resize from the bottom-right corner (desktop only). The picture scales with the width; double-click resets the size.
document.addEventListener('pointerdown',event=>{
  const grip=event.target.closest('#tut-float [data-resize]');
  if(!grip||window.innerWidth<=640||event.button!==0||!tutorialState)return;
  event.preventDefault();
  const el=document.getElementById('tut-float'),r=el.getBoundingClientRect(),startX=event.clientX,startW=r.width;
  tutorialState.x=r.left;tutorialState.y=r.top;tutPlace(el);
  el.classList.add('is-resizing');grip.setPointerCapture(event.pointerId);
  const move=e=>{tutorialState.w=Math.round(startW+(e.clientX-startX));tutPlace(el);const b=el.getBoundingClientRect();if(b.bottom>window.innerHeight-8){tutorialState.y=Math.max(8,window.innerHeight-8-b.height);tutPlace(el);}};
  const up=()=>{el.classList.remove('is-resizing');grip.removeEventListener('pointermove',move);grip.removeEventListener('pointerup',up);grip.removeEventListener('pointercancel',up);tutSave();};
  grip.addEventListener('pointermove',move);grip.addEventListener('pointerup',up);grip.addEventListener('pointercancel',up);
});
document.addEventListener('dblclick',event=>{if(event.target.closest('#tut-float [data-resize]')&&tutorialState){tutorialState.w=null;tutorialState.x=null;tutorialState.y=null;tutPlace(document.getElementById('tut-float'));tutSave();}});
// Drag the panel by its header (desktop only).
document.addEventListener('pointerdown',event=>{
  const head=event.target.closest('#tut-float [data-drag]');
  if(!head||event.target.closest('button')||window.innerWidth<=640||event.button!==0)return;
  const el=document.getElementById('tut-float'),r=el.getBoundingClientRect(),dx=event.clientX-r.left,dy=event.clientY-r.top;
  el.classList.add('is-dragging');head.setPointerCapture(event.pointerId);
  const move=e=>{tutorialState.x=e.clientX-dx;tutorialState.y=e.clientY-dy;tutPlace(el);};
  const up=()=>{el.classList.remove('is-dragging');head.removeEventListener('pointermove',move);head.removeEventListener('pointerup',up);head.removeEventListener('pointercancel',up);tutSave();};
  head.addEventListener('pointermove',move);head.addEventListener('pointerup',up);head.addEventListener('pointercancel',up);
});
window.addEventListener('resize',()=>{const el=document.getElementById('tut-float');if(el&&tutorialState)tutPlace(el);});
// Bring the panel back after a reload once someone is signed in, and hide it after sign-out.
function tutSessionCheck(){
  const signedIn=typeof currentUser!=='undefined'&&!!currentUser;
  if(!signedIn){if(tutorialState){const el=document.getElementById('tut-float');if(el)el.remove();tutorialState=null;tutSave();tutClearSpot();document.body.classList.remove('tut-open','tut-min');}return;}
  if(!tutorialState){let saved=null;try{saved=JSON.parse(sessionStorage.getItem(TUT_KEY)||'null');}catch(e){}if(saved&&HELP_TUTORIALS[saved.section])openTutorial(saved.section,saved.index,saved);}
  else if(!tutorialState.min){const el=document.getElementById('tut-float'),btn=el&&el.querySelector('.tut-f-tools');const onPage=typeof currentPage!=='undefined'&&currentPage===tutorialState.tutorial.page;if(btn&&!!btn.querySelector('button[onclick="tutorialGo()"]')===onPage)renderTutorialStep();}
}
// Runs on sign-in/out and page changes instead of polling.
window.addEventListener('tf-session',tutSessionCheck);window.addEventListener('tf-page',()=>setTimeout(tutSessionCheck,0));document.addEventListener('DOMContentLoaded',()=>setTimeout(tutSessionCheck,0));
