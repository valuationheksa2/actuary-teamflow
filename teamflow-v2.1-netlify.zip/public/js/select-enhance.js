/* Same dropdown as ActuarialPro: every single-choice <select> keeps working natively (value, change events, forms) while its
   menu is drawn as a soft rounded list. Long lists get a search box. Touch devices keep their own native picker. */
(() => {
  'use strict';
  if (window.__selectEnhance) return;
  window.__selectEnhance = true;
  const SKIP = '[data-native-select]';
  let open = null; // {select, wrap, button, panel}

  function enhance(select) {
    if (window.matchMedia('(pointer: coarse)').matches) return;
    if (select._cs || select.multiple || select.size > 1 || select.closest(SKIP)) return;
    select._cs = { select, button: select };
    // The native select stays the visible, focusable control; only its popup is replaced.
    select.addEventListener('mousedown', event => {
      if (event.button !== 0 || select.disabled) return;
      event.preventDefault(); select.focus({ preventScroll: true });
      open && open.select === select ? close() : show(select);
    });
    select.addEventListener('keydown', event => {
      if (select.disabled || open) return;
      if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(event.key) || (event.altKey && event.key === 'ArrowDown')) { event.preventDefault(); show(select); }
    });
  }

  function close(focus = true) {
    if (!open) return;
    const { panel, button } = open;
    panel.remove();
    if (focus) button.focus({ preventScroll: true });
    document.removeEventListener('mousedown', outside, true);
    window.removeEventListener('resize', close, true);
    document.removeEventListener('scroll', onScroll, true);
    open = null;
  }
  const outside = event => { if (open && !open.panel.contains(event.target) && !open.button.contains(event.target)) close(false); };
  const onScroll = event => { if (open && !open.panel.contains(event.target)) close(false); };

  function show(select) {
    close(false);
    const { button } = select._cs;
    if (select.disabled) return;
    const panel = document.createElement('div');
    panel.className = 'cs-panel';
    panel.setAttribute('role', 'listbox');
    const items = Array.from(select.options).filter(o => !o.hidden);
    let search = null;
    if (items.length > 12) {
      search = document.createElement('input');
      search.type = 'search'; search.className = 'cs-search'; search.placeholder = 'Search'; search.setAttribute('aria-label', 'Search options');
      panel.appendChild(search);
    }
    const list = document.createElement('div');
    list.className = 'cs-list';
    panel.appendChild(list);
    let active = -1, rows = [];
    const choose = option => {
      if (option.disabled) return;
      // A background refresh can redraw the form while the list is open.
      if (!select.isConnected) { close(false); return; }
      select.value = option.value;
      select.dispatchEvent(new Event('input', { bubbles: true }));
      select.dispatchEvent(new Event('change', { bubbles: true }));
      close();
    };
    const paint = () => rows.forEach((r, i) => r.el.classList.toggle('active', i === active));
    const build = term => {
      list.replaceChildren(); rows = [];
      items.forEach(option => {
        if (term && !option.textContent.toLowerCase().includes(term)) return;
        const el = document.createElement('div');
        el.className = 'cs-option' + (option.selected ? ' selected' : '') + (option.disabled ? ' disabled' : '');
        el.setAttribute('role', 'option'); el.setAttribute('aria-selected', option.selected);
        el.textContent = option.textContent.trim() || ' ';
        // <option data-icon="folder"> shows that icon from the sprite beside its label.
        if (option.dataset.icon) { el.classList.add('has-icon'); el.insertAdjacentHTML('afterbegin', `<svg class="ui-icon" aria-hidden="true"><use href="#i-${option.dataset.icon}"/></svg>`); }
        el.addEventListener('mousedown', e => e.preventDefault());
        el.addEventListener('click', () => choose(option));
        el.addEventListener('mousemove', () => { active = rows.findIndex(r => r.el === el); paint(); });
        list.appendChild(el); rows.push({ el, option });
      });
      if (!rows.length) { const none = document.createElement('div'); none.className = 'cs-none'; none.textContent = 'No matches'; list.appendChild(none); }
      active = Math.max(0, rows.findIndex(r => r.option.selected)); paint();
      rows[active]?.el.scrollIntoView({ block: 'nearest' });
    };
    build('');
    (select.closest('dialog[open]') || document.body).appendChild(panel);
    const rect = button.getBoundingClientRect();
    const room = window.innerHeight - rect.bottom - 12, above = rect.top - 12;
    const flip = room < 220 && above > room;
    panel.style.minWidth = rect.width + 'px';
    panel.style.maxWidth = Math.min(560, window.innerWidth - 24) + 'px';
    panel.style.left = Math.max(12, Math.min(rect.left, window.innerWidth - panel.offsetWidth - 12)) + 'px';
    list.style.maxHeight = Math.max(160, Math.min(320, (flip ? above : room) - (search ? 52 : 12))) + 'px';
    panel.style.top = flip ? Math.max(12, rect.top - panel.offsetHeight - 6) + 'px' : rect.bottom + 6 + 'px';
    open = { select, button, panel };
    document.addEventListener('mousedown', outside, true);
    window.addEventListener('resize', close, true);
    document.addEventListener('scroll', onScroll, true);
    rows[active]?.el.scrollIntoView({ block: 'nearest' });
    const move = step => { if (!rows.length) return; active = (active + step + rows.length) % rows.length; paint(); rows[active].el.scrollIntoView({ block: 'nearest' }); };
    let typed = '', typedAt = 0;
    panel.addEventListener('keydown', event => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); }
      else if (event.key === 'ArrowDown') { event.preventDefault(); move(1); }
      else if (event.key === 'ArrowUp') { event.preventDefault(); move(-1); }
      else if (event.key === 'Home') { event.preventDefault(); active = 0; paint(); rows[0]?.el.scrollIntoView({ block: 'nearest' }); }
      else if (event.key === 'End') { event.preventDefault(); active = rows.length - 1; paint(); rows[active]?.el.scrollIntoView({ block: 'nearest' }); }
      else if (event.key === 'Enter') { event.preventDefault(); if (rows[active]) choose(rows[active].option); }
      else if (event.key === 'Tab') close(false);
      else if (!search && event.key.length === 1) {
        const now = Date.now(); typed = now - typedAt > 700 ? event.key.toLowerCase() : typed + event.key.toLowerCase(); typedAt = now;
        const i = rows.findIndex(r => r.el.textContent.trim().toLowerCase().startsWith(typed));
        if (i >= 0) { active = i; paint(); rows[i].el.scrollIntoView({ block: 'nearest' }); }
      }
    });
    if (search) { search.addEventListener('input', () => build(search.value.trim().toLowerCase())); search.focus(); }
    else { panel.tabIndex = -1; panel.focus({ preventScroll: true }); }
  }

  const scan = root => (root.querySelectorAll ? root.querySelectorAll('select') : []).forEach(enhance);
  const start = () => {
    scan(document);
    new MutationObserver(records => records.forEach(r => r.addedNodes.forEach(n => {
      if (n.nodeType !== 1) return;
      if (n.tagName === 'SELECT') enhance(n); else scan(n);
    }))).observe(document.body, { childList: true, subtree: true });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
