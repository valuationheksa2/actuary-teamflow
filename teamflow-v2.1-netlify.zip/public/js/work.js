// ── NOTES & UNREAD ────────────────────────────────────────
// Unread = notes by someone else, newer than the time you last opened the work. Only people working on it get badges.
function isInvolved(w){return !!currentUser&&[...(w.assignees||[]),w.pic].some(id=>id!=null&&String(id)===String(currentUser.id));}
function unreadNotes(w){
  if(!isInvolved(w))return[];
  const seen=noteReads.seen?.[String(w.id)]||noteReads.since||'';
  return (w.notes||[]).filter(n=>n.createdAt&&n.createdAt>seen&&String(n.authorId)!==String(currentUser.id));
}
function unreadBadgeHtml(w){const count=unreadNotes(w).length;return count?`<span class="unread-badge" title="${count} unread note${count>1?'s':''}" aria-label="${count} unread note${count>1?'s':''}">${count>99?'99+':count}</span>`:'';}
async function markNotesRead(w){
  const latest=(w.notes||[]).map(n=>n.createdAt||'').filter(Boolean).sort().pop();
  if(!latest||!unreadNotes(w).length)return;
  noteReads.seen={...noteReads.seen,[String(w.id)]:latest};
  document.querySelectorAll(`[onclick="openWorkDetail(${Number(w.id)})"] .unread-badge`).forEach(badge=>badge.remove());
  try{const result=await sendJson('reads',{workId:w.id,seenAt:latest});if(result?.seen)noteReads=result;}catch{}
}
function noteItemHtml(w,n,ni,unread){
  if(n.system)return`<div class="note-item note-system" id="note-item-${w.id}-${ni}"><div class="note-meta"><svg class="ui-icon" aria-hidden="true"><use href="#i-repeat"/></svg> TeamFlow &middot; ${fmt(n.createdDate||n.date)}</div><div class="note-text" style="white-space:pre-wrap;">${escapeHtml(n.text)}</div></div>`;
  const aName=n.authorName||n.author||'Unknown';
  const eStr=n.editedDate?` &middot; <span style="font-size:11px;color:var(--text3);">Edited ${fmt(n.editedDate)}</span>`:'';
  const canEN=currentUser.role==='admin'||(n.authorId&&n.authorId===currentUser.id)||(aName===currentUser.name&&!n.authorId);
  const eBtn=canEN?`<button class="btn btn-ghost btn-sm" style="margin-left:auto;font-size:11px;padding:2px 6px;" onclick="editNote(${w.id},${ni})"><svg class="ui-icon" aria-hidden="true"><use href="#i-pencil"/></svg> Edit</button>`:'';
  return`<div class="note-item${unread?' note-unread':''}" id="note-item-${w.id}-${ni}"><div class="note-meta" style="display:flex;align-items:center;"><span>${unread?'<span class="note-new">New</span>':''}Created by ${escapeHtml(aName)} &middot; ${fmt(n.createdDate||n.date)}${eStr}</span>${eBtn}</div><div class="note-text" style="white-space:pre-wrap;">${escapeHtml(n.text)}</div></div>`;
}
function notesListHtml(w,unread=[]){return w.notes.length?w.notes.map((n,ni)=>noteItemHtml(w,n,ni,!!n.createdAt&&unread.includes(n.createdAt))).join(''):'<div style="font-size:13px;color:var(--text3);">No notes yet.</div>';}
// WORK ITEM HTML
// ============================================================
function workItemHtml(w){
  const prog=phaseProgress(w),isRR=w.status==='ongoing'&&w.phase===2,isOD=w.status!=='done'&&daysUntil(w.deadline)<0,isLate=w.status==='done'&&w.completedDate&&w.completedDate>w.deadline;
  const cls=isRR?'review-ready':isOD?'overdue':w.status==='done'?'completed':'';
  const phaseLabel=w.status==='done'?'Done':w.status==='upcoming'?'Upcoming':PHASES[w.phase];
  const badgeCls=w.status==='done'?'badge-done':w.status==='upcoming'?'badge-upcoming':`badge-${PHASES[w.phase].toLowerCase()}`;
  const creator=getMember(w.createdBy);
  const recurrenceLabel = w.recurrence ? RECURRENCE_OPTIONS.find(o=>o.value===w.recurrence)?.label : '';
  return`<div class="work-item ${cls}" role="button" tabindex="0" onclick="openWorkDetail(${Number(w.id)})">
    <div style="display:flex;align-items:flex-start;gap:12px;"><div style="flex:1;">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">
        <span class="badge ${badgeCls}">${phaseLabel}</span>`+workTypeBadge(w.workType||'regular')+`<span class="badge badge-priority-${w.priority.toLowerCase()}">${w.priority}</span>
        ${isRR?'<span class="badge" style="background:var(--yellow-dim);color:var(--yellow);"><svg class="ui-icon" aria-hidden="true"><use href="#i-search"/></svg> Review Ready</span>':''}
        ${isOD?'<span class="badge badge-overdue"><svg class="ui-icon" aria-hidden="true"><use href="#i-alert"/></svg> Overdue</span>':''}
        ${isLate?'<span class="badge badge-overdue"><svg class="ui-icon" aria-hidden="true"><use href="#i-clock"/></svg> Delivered Late</span>':''}
        ${(w.tags||[]).map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}
      </div>
      <div class="work-title">${escapeHtml(w.title)}${unreadBadgeHtml(w)}</div>
    </div></div>
    <div style="margin-top:10px;"><div class="work-desc" data-fit="${escapeHtml(w.desc)}">${escapeHtml(w.desc)}</div>
      ${w.status!=='upcoming'?`<div style="margin-top:12px;"><div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="font-size:11px;color:var(--text3);">Overall Progress</span><span style="font-size:11px;color:var(--text3);">${prog}%</span></div><div class="progress-bar"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div></div>`:''}
    </div>
    <div class="work-item-footer">
      ${assigneesHtml(w.assignees)}<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> ${fmt(w.startDate)}</div><div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-flag"/></svg> ${fmt(w.deadline)}</div>
      ${w.completedDate?`<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> ${fmt(w.completedDate)}</div>`:''}
      ${w.status==='done'&&w.actualHours!=null?`<div class="meta-item" title="Actual vs estimated effort"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> ${Number(w.actualHours)} / ${Number(w.estimatedHours||0)} h</div>`:''}
      ${deadlineChip(w.deadline,w.status)}
      ${w.files.length?`<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-paperclip"/></svg> ${w.files.length} file${w.files.length>1?'s':''}</div>`:''}
      ${w.notes.length?`<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-message"/></svg> ${w.notes.length} note${w.notes.length>1?'s':''}</div>`:''}
      ${creator?`<div class="meta-item" style="margin-left:auto;font-size:11px;">by ${escapeHtml(creator.name)}</div>`:''}
    </div>
  </div>`;
}

function getReviewReady(){return works.filter(w=>w.status==='ongoing'&&w.phase===2);}
function getOverdue(){return works.filter(w=>w.status!=='done'&&daysUntil(w.deadline)<0);}
const workFilterStates=new Map();
const workFilterSorts=['deadline_asc','deadline_desc','title_asc','title_desc','created_asc','created_desc'];
function workFilterKey(status){
  return currentUser&&['ongoing','upcoming','done'].includes(status)?'teamflow_work_filters_v1:'+String(currentUser.id)+':'+status:null;
}
function normalizeWorkFilters(state,status){
  const filters=state?.filters||{};
  return {
    filters:{
      workType:WORK_TYPES.some(type=>type.value===filters.workType)?filters.workType:'',
      priority:PRIORITIES.includes(filters.priority)?filters.priority:'',
      phase:status==='ongoing'&&['0','1','2','3'].includes(String(filters.phase))?String(filters.phase):'',
      pic:TEAM.some(member=>!['admin','board'].includes(member.role)&&String(member.id)===String(filters.pic))?String(filters.pic):''
    },
    sort:workFilterSorts.includes(state?.sort)?state.sort:'deadline_asc',
    search:typeof state?.search==='string'?state.search.slice(0,1000):''
  };
}
function restoreWorkFilters(status){
  const key=workFilterKey(status);
  let state=key?workFilterStates.get(key):null;
  if(key&&!state){try{state=JSON.parse(localStorage.getItem(key)||'null');}catch{}}
  state=normalizeWorkFilters(state,status);
  currentFilters={...state.filters};
  currentSort=state.sort;
  _fSq=state.search;
  if(key)workFilterStates.set(key,state);
}
function saveWorkFilters(status){
  const key=workFilterKey(status);
  if(!key)return;
  const state=normalizeWorkFilters({filters:currentFilters,sort:currentSort,search:_fSq},status);
  workFilterStates.set(key,state);
  try{localStorage.setItem(key,JSON.stringify(state));}catch{}
}
function clearActiveWorkFilters(){
  currentFilters={workType:'',priority:'',phase:'',pic:''};
  currentSort='deadline_asc';
  _fSq='';
}
// Smart search: every word must match somewhere in the work's title, description, tags, people, phase, priority, type, files or notes.
function workSearchText(w){
  const names=ids=>(ids||[]).map(id=>getMember(id)?.name||'').join(' ');
  const phase=w.status==='done'?'done completed':w.status==='upcoming'?'upcoming':PHASES[w.phase]||'';
  const type=WORK_TYPES.find(t=>t.value===w.workType)?.label||'';
  const recurrence=w.recurrence?RECURRENCE_OPTIONS.find(o=>o.value===w.recurrence)?.label||'':'';
  return [w.title,w.desc,(w.tags||[]).join(' '),names(w.assignees),getMember(w.pic)?.name,getMember(w.createdBy)?.name,phase,w.status,w.priority,type,recurrence,(w.files||[]).map(f=>f.name).join(' '),(w.notes||[]).map(n=>n.text+' '+(n.authorName||'')).join(' ')].filter(Boolean).join(' ').toLocaleLowerCase();
}
function workMatchesSearch(w,query){
  const terms=String(query||'').toLocaleLowerCase().split(/\s+/).filter(Boolean);
  if(!terms.length)return true;
  const text=workSearchText(w);
  return terms.every(term=>text.includes(term));
}
function applyFiltersAndSort(list){
  let r=[...list];
  if(_fSq.trim())r=r.filter(w=>workMatchesSearch(w,_fSq));
  if(currentFilters.workType)r=r.filter(w=>w.workType===currentFilters.workType);
  if(currentFilters.priority)r=r.filter(w=>w.priority===currentFilters.priority);
  if(currentFilters.phase!=='')r=r.filter(w=>w.phase===parseInt(currentFilters.phase));
  if(currentFilters.pic)r=r.filter(w=>String(w.pic)===String(currentFilters.pic));
  r.sort((a,b)=>{
    switch(currentSort){
      case'title_asc':return a.title.localeCompare(b.title);
      case'title_desc':return b.title.localeCompare(a.title);
      case'deadline_asc':return new Date(a.deadline||'9999')-new Date(b.deadline||'9999');
      case'deadline_desc':return new Date(b.deadline||'0')-new Date(a.deadline||'0');
      case'created_asc':return new Date(a.createdAt||'0')-new Date(b.createdAt||'0');
      case'created_desc':return new Date(b.createdAt||'0')-new Date(a.createdAt||'0');
      case'priority':{const p={High:0,Medium:1,Low:2};return(p[a.priority]||1)-(p[b.priority]||1);}
      default:return 0;
    }
  });
  return r;
}
function buildFilterBar(status){
  restoreWorkFilters(status);
  const mems=TEAM.filter(m=>m.role!=='admin'&&m.role!=='board');
  const field=(label,key,options)=>`<label class="work-filter-field"><span class="work-filter-label">${label}</span><select class="filter-select ${currentFilters[key]?'is-filtered':''}" data-filter="${key}" onchange="currentFilters.${key}=this.value;_fRefresh('${status}')">${options}</select></label>`;
  const options=(items,value,label,selected)=>items.map(item=>`<option value="${escapeHtml(value(item))}" ${String(selected)===String(value(item))?'selected':''}>${escapeHtml(label(item))}</option>`).join('');
  return `<div class="work-filter-shell"><div class="filter-bar work-filter-panel" data-work-status="${status}">
    <label class="work-filter-field work-filter-search"><span class="work-filter-label">Search work</span><span class="work-search-control">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.5 4.5" stroke-linecap="round"/></svg>
      <input class="search-input" type="search" value="${escapeHtml(_fSq)}" placeholder="Search title, people, tags, phase, notes…" oninput="_fSearch(this.value,'${status}')">
    </span></label>
    ${field('Work type','workType','<option value="">All types</option>'+options(WORK_TYPES,t=>t.value,t=>t.label,currentFilters.workType))}
    ${field('Priority','priority','<option value="">All priorities</option>'+options(PRIORITIES,p=>p,p=>p,currentFilters.priority))}
    ${status==='ongoing'?field('Phase','phase','<option value="">All phases</option>'+options(PHASES.map((label,index)=>({label,index})),p=>p.index,p=>p.label,currentFilters.phase)):''}
    ${field('PIC','pic','<option value="">All PICs</option>'+options(mems,m=>m.id,m=>m.name,currentFilters.pic))}
    <label class="work-filter-field"><span class="work-filter-label">Sort by</span><select class="filter-select" data-sort onchange="currentSort=this.value;_fRefresh('${status}')">
      ${options([{value:'deadline_asc',label:'Deadline · earliest'},{value:'deadline_desc',label:'Deadline · latest'},{value:'title_asc',label:'Title · A to Z'},{value:'title_desc',label:'Title · Z to A'},{value:'created_desc',label:'Newest first'},{value:'created_asc',label:'Oldest first'}],o=>o.value,o=>o.label,currentSort)}
    </select></label>
    <button type="button" class="btn work-filter-reset" onclick="resetWorkFilters('${status}')" aria-label="Reset search, filters and sorting" title="Reset search, filters and sorting">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M4 10a8 8 0 1 1 1.8 8.1M4 4v6h6" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
  </div></div>`;
}
function resetWorkFilters(status){
  currentFilters={workType:'',priority:'',phase:'',pic:''};
  currentSort='deadline_asc';
  _fSq='';
  const panel=document.querySelector('.work-filter-panel');
  if(panel){
    panel.querySelector('.search-input').value='';
    panel.querySelectorAll('[data-filter]').forEach(select=>{select.value='';select.classList.remove('is-filtered');});
    panel.querySelector('[data-sort]').value=currentSort;
  }
  _fRefresh(status);
}
let _fSq='';
function _fSearch(q,s){_fSq=q;_fRefresh(s);}
const workListPages=new Map();
const WORK_PAGE_SIZE=10;
function workPageKey(status){return workFilterKey(status)||'anonymous:'+status;}
function pagedWorkListHtml(list,status,emptyMessage='No results.'){
  const key=workPageKey(status),totalPages=Math.max(1,Math.ceil(list.length/WORK_PAGE_SIZE));
  const page=Math.min(totalPages,Math.max(1,workListPages.get(key)||1));
  workListPages.set(key,page);
  if(!list.length)return '<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-folder"/></svg></div><p>'+emptyMessage+'</p></div>';
  const start=(page-1)*WORK_PAGE_SIZE;
  const rows=list.slice(start,start+WORK_PAGE_SIZE).map(workItemHtml).join('');
  return rows+`<nav class="history-pagination" aria-label="${status==='done'?'Work History':status==='ongoing'?'Ongoing Work':'Upcoming Work'} pages"><span role="status">Showing ${start+1}–${Math.min(start+WORK_PAGE_SIZE,list.length)} of ${list.length}</span><div class="history-page-controls"><button type="button" class="btn btn-ghost btn-sm" onclick="changeWorkPage('${status}',${page-1})" ${page===1?'disabled':''} aria-label="Previous work page">Previous</button><span>Page ${page} of ${totalPages}</span><button type="button" class="btn btn-ghost btn-sm" onclick="changeWorkPage('${status}',${page+1})" ${page===totalPages?'disabled':''} aria-label="Next work page">Next</button></div></nav>`;
}
function changeWorkPage(status,page){
  if(currentPage!==({done:'history',ongoing:'ongoing',upcoming:'upcoming'})[status]||!Number.isSafeInteger(page))return;
  workListPages.set(workPageKey(status),Math.max(1,page));
  _fRefresh(status,false);
  const list=document.getElementById('work-list');
  if(list){list.scrollIntoView({block:'start'});list.tabIndex=-1;list.focus({preventScroll:true});}
}
function _fRefresh(status,resetPage=true){
  if(resetPage)workListPages.set(workPageKey(status),1);
  const el=document.getElementById('work-list');if(!el)return;
  document.querySelectorAll('.work-filter-panel [data-filter]').forEach(select=>select.classList.toggle('is-filtered',Boolean(select.value)));
  let list=works.filter(w=>w.status===status);
  saveWorkFilters(status);
  list=applyFiltersAndSort(list);
  el.innerHTML=pagedWorkListHtml(list,status);
}
// Filters Ongoing to work in Review, using the normal Phase filter so it stays visible and Reset clears it.
function showReviewReady(){
  currentFilters={workType:'',priority:'',phase:'2',pic:''};_fSq='';
  saveWorkFilters('ongoing');workListPages.set(workPageKey('ongoing'),1);
  renderOngoing();
}
function toggleReviewReady(){
  if(String(currentFilters.phase)==='2'){currentFilters.phase='';saveWorkFilters('ongoing');renderOngoing();}
  else showReviewReady();
}
async function openReviewReady(){await navigate('ongoing');showReviewReady();}
function renderOngoing(){
  const rr=getReviewReady();
  let html=buildFilterBar('ongoing');
  const reviewOnly=String(currentFilters.phase)==='2';
  if(rr.length>0)html+=`<div class="review-banner" role="button" tabindex="0" aria-pressed="${reviewOnly}" style="cursor:pointer;" onclick="toggleReviewReady()"><span class="review-banner-icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-search"/></svg></span><div class="review-banner-text"><div class="review-banner-title">${rr.length} item${rr.length>1?'s':''} ready for review</div><div class="review-banner-sub">${reviewOnly?'Showing only work in the Review phase':'Select to show them'}</div></div><span class="btn btn-ghost btn-sm dashboard-view-action">${reviewOnly?'Show all':'View'}</span></div>`;
  const _fl=applyFiltersAndSort(works.filter(w=>w.status==='ongoing'));
  html+=`<div id="work-list">${pagedWorkListHtml(_fl,'ongoing','No ongoing work.')}</div>`;
  document.getElementById('content').innerHTML=html;
}

function renderUpcoming(){
  const list=works.filter(w=>w.status==='upcoming');
  const monthNames=['January','February','March','April','May','June','July','August','September','October','November','December'];
  const yearOptions=Array.from({length:11},(_,index)=>calendarYear-5+index);
  let html=`<div class="card schedule-card" style="margin-bottom:20px;">
    <div class="card-header">
      <div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> Schedule</div>
      <div class="schedule-controls" role="group" aria-label="Calendar navigation">
        <button type="button" class="btn calendar-nav" aria-label="Previous month" onclick="changeCalMonth(-1)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m14 6-6 6 6 6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
        <label class="calendar-field calendar-month"><span class="sr-only">Month</span><select class="filter-select" onchange="setCalMonth(this.value)">
          ${monthNames.map((m,i)=>`<option value="${i}" ${i===calendarMonth?'selected':''}>${m}</option>`).join('')}
        </select></label>
        <label class="calendar-field calendar-year"><span class="sr-only">Year</span><select class="filter-select" onchange="setCalYear(this.value)">
          ${yearOptions.map(y=>`<option value="${y}" ${y===calendarYear?'selected':''}>${y}</option>`).join('')}
        </select></label>
        <button type="button" class="btn calendar-nav" aria-label="Next month" onclick="changeCalMonth(1)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m10 6 6 6-6 6" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
        <button type="button" class="btn schedule-today" onclick="resetCalToday()">Today</button>
      </div>
    </div>
    ${renderCalendar(calendarYear,calendarMonth)}
    <div class="schedule-legend" style="display:flex;gap:16px;flex-wrap:wrap;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--primary-dim);border:1px solid var(--primary);"></div> Regular Start</div>
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--primary-dim);border:1px dashed var(--orange);"></div> Ad-hoc Start</div>
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--red-dim);border:1px solid var(--primary);"></div> Regular Deadline</div>
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--red-dim);border:1px dashed var(--orange);"></div> Ad-hoc Deadline</div>

    </div>
  </div>`;
  html+=buildFilterBar('upcoming');
  const filtered=applyFiltersAndSort(list);
  html+=`<div id="work-list">${pagedWorkListHtml(filtered,'upcoming','No upcoming work scheduled.')}</div>`;
  document.getElementById('content').innerHTML=html;
}
function escapeHtml(value){return String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
function safeExternalHref(value){const url=String(value||'').trim();return ['http','https'].includes(TeamFlowDomain.fileLocationKind(url))?escapeHtml(url):'';}
function linkedFileHtml(file,workId,index,editable,removeCall=`removeFile(${Number(workId)},${Number(index)})`){const safeUrl=escapeHtml(file.url),safeHref=safeExternalHref(file.url),label=FILE_TYPES.find(type=>type.type===file.type)?.label||'Others';const action=TeamFlowDomain.fileLocationKind(file.url)==='path'?`<button class="file-link-open" onclick="copyPath(this)" data-path="${safeUrl}" title="Copy path to clipboard"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg> Copy Path</button>`:safeHref?`<a href="${safeHref}" target="_blank" rel="noopener noreferrer" class="file-link-open">Open ↗</a>`:'<span class="file-link-open">Link unavailable</span>';return`<div class="file-link-item"><span class="file-link-icon">${fileTypeIconHtml(file.type)}</span><div style="flex:1;min-width:0;"><div class="file-link-name">${escapeHtml(file.name)}</div><div class="file-link-url">${safeUrl}</div></div><span class="file-link-type">${escapeHtml(label)}</span>${action}${editable?`<button class="btn btn-danger btn-sm" onclick="${removeCall};event.stopPropagation();"><svg class="ui-icon" aria-hidden="true"><use href="#i-x"/></svg></button>`:''}</div>`;}

function renderCapacity(){
  const range=TeamFlowDomain.weekRange(todayStr,capacityWeekOffset),totals=new Map(),allocations=new Map();
  TEAM.filter(member=>['member','manager'].includes(member.role)).forEach(member=>totals.set(String(member.id),0));
  works.forEach(work=>{
    // Each person's share follows their own calendar: public holidays and their leave move their hours to the other working days.
    const shares={};
    Object.keys(TeamFlowDomain.allocateEffortByMember(work,TEAM,1)).forEach(id=>{
      const hours=TeamFlowDomain.allocateCapacityByWeek(work,absences,id)[range.start]||0;
      const share=TeamFlowDomain.allocateEffortByMember(work,TEAM,hours)[id]||0;
      if(share>0)shares[id]=share;
    });
    allocations.set(work.id,shares);
    Object.entries(shares).forEach(([id,share])=>{if(totals.has(id))totals.set(id,totals.get(id)+share);});
  });
  const unscheduled=works.filter(work=>work.status!=='done'&&Number(work.estimatedHours)>0&&!Object.keys(TeamFlowDomain.allocateEffortByWeek(work)).length);
  const scheduleWarning=unscheduled.length?`<p role="status" style="font-size:12px;color:var(--yellow);">Choose dates that include a weekday to allocate capacity: ${unscheduled.map(work=>escapeHtml(work.title)).join(', ')}.</p>`:'';
  const members=TEAM.filter(member=>['member','manager'].includes(member.role));
  const weekCapacity=member=>Math.round(Number(member.weeklyCapacityHours??40)*TeamFlowDomain.weekAvailability(member.id,range.start,absences).available/5*10)/10;
  const weekHolidays=TeamFlowDomain.weekAvailability(null,range.start,absences).holidayDays||0;
  const overloaded=members.filter(member=>(totals.get(String(member.id))||0)>weekCapacity(member)).length;
  const rows=members.map(member=>{
    const away=TeamFlowDomain.weekAvailability(member.id,range.start,absences),awayNote=away.leaveDays?`${away.leaveDays} day${away.leaveDays===1?'':'s'} leave`:'',assigned=totals.get(String(member.id))||0,capacity=weekCapacity(member),percent=capacity?Math.round(assigned/capacity*100):(assigned?100:0),over=assigned>capacity;
    const pieces=works.filter(work=>(allocations.get(work.id)?.[String(member.id)]||0)>0);
    const chips=pieces.map(work=>`<span class="tag capacity-work" role="button" tabindex="0" onclick="openWorkDetail(${Number(work.id)})">${escapeHtml(work.title)} · ${allocations.get(work.id)[String(member.id)].toFixed(1)}h${String(work.pic)===String(member.id)?' · PIC':member.role==='manager'?' · Reviewer':''}${work.status==='done'?' · Done':''}</span>`).join('');
    return`<div class="cap-row"><div class="cap-head">${avatarHtml(member,28)}<strong class="cap-name">${escapeHtml(member.name)}</strong>${awayNote?`<span class="cap-away">${awayNote}</span>`:''}<span class="cap-spacer"></span>${pieces.length?'':'<span class="cap-none">No work this week</span>'}<span class="cap-hours${over?' is-over':''}" title="${over?`${(assigned-capacity).toFixed(1)} h over capacity`:`${(capacity-assigned).toFixed(1)} h free`}">${assigned.toFixed(1)} / ${capacity} h${over&&capacity?` · ${Math.round(assigned/capacity*100)}%`:''}</span></div>${capacityBarHtml(assigned,capacity)}${pieces.length?`<button type="button" class="cap-toggle" aria-expanded="false" onclick="toggleCapacityItems(this)">${pieces.length} work item${pieces.length===1?'':'s'}<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button><div class="cap-items" hidden>${chips}</div>`:''}</div>`;
  }).join('');
  document.getElementById('content').innerHTML=`<div class="card" style="margin-bottom:14px;"><div class="card-header capacity-header"><div class="card-title capacity-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M16 3v4M8 3v4M3 11h18M8 16h2M14 16h2"/></svg>Weekly Capacity</div><div class="capacity-navigation" role="group" aria-label="Week navigation"><button type="button" class="btn btn-ghost capacity-nav" aria-label="Previous week" onclick="shiftCapacityWeek(-1)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 5-7 7 7 7"/></svg></button><div class="capacity-week"><strong>${TeamFlowDomain.formatRange(range)}</strong><div style="font-size:11px;color:var(--text3);">${overloaded} member${overloaded===1?'':'s'} over capacity${weekHolidays?` · ${weekHolidays} public holiday${weekHolidays===1?'':'s'}`:''}</div></div><button type="button" class="btn btn-ghost capacity-nav" aria-label="Next week" onclick="shiftCapacityWeek(1)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button></div></div><div style="margin-bottom:6px;"><button type="button" class="btn btn-ghost btn-sm" onclick="openAbsences()">Leave &amp; Holidays</button></div>${scheduleWarning}${rows||'<div class="empty-state"><p>No team members yet.</p></div>'}</div>`;
}
// Over capacity, the track stretches to the assigned hours: blue up to capacity, a marker at the limit, red for the overflow.
function capacityBarHtml(assigned,capacity){
  const scale=Math.max(assigned,capacity)||1,within=Math.min(assigned,capacity)/scale*100,overflow=Math.max(0,assigned-capacity)/scale*100,limit=capacity/scale*100;
  const pct=capacity?Math.round(assigned/capacity*100):0;
  return`<div class="cap-bar${overflow?' is-over':''}" role="img" aria-label="${assigned.toFixed(1)} of ${capacity} hours (${pct}%)"><div class="cap-fill" style="width:${within}%"></div>${overflow?`<div class="cap-over" style="left:${within}%;width:${overflow}%"></div><i class="cap-limit" style="left:${limit}%"></i>`:''}</div>`;
}
function toggleCapacityItems(button){const items=button.nextElementSibling,open=items.hidden;items.hidden=!open;button.setAttribute('aria-expanded',String(open));}
function shiftCapacityWeek(direction){capacityWeekOffset+=direction;renderCapacity();}

function changeCalMonth(dir){
  calendarMonth+=dir;
  if(calendarMonth>11){calendarMonth=0;calendarYear++;}
  if(calendarMonth<0){calendarMonth=11;calendarYear--;}
  renderUpcoming();
}
function setCalMonth(m){calendarMonth=parseInt(m);renderUpcoming();}
function setCalYear(y){calendarYear=parseInt(y);renderUpcoming();}
function resetCalToday(){calendarMonth=new Date().getMonth();calendarYear=new Date().getFullYear();renderUpcoming();}

function renderHistory(){
  let html=buildFilterBar('done');
  const _fd=applyFiltersAndSort(works.filter(w=>w.status==='done'));
  html+=`<div id="work-list">${pagedWorkListHtml(_fd,'done','No completed work yet.')}</div>`;
  document.getElementById('content').innerHTML=html;
}

// Cuts one line of text between words. A first word too long for the space is left for the stylesheet to cut.
function textAtWord(text,fits){
  if(fits(text))return text;
  const words=text.trim().split(/\s+/);
  const cut=count=>words.slice(0,count).join(' ').replace(/[\s\-–—/·,:;&.]+$/,'');
  let low=0,high=words.length-1;
  while(low<high){
    const middle=Math.ceil((low+high)/2);
    if(fits(cut(middle)+'…'))low=middle;else high=middle-1;
  }
  return low&&cut(low)?cut(low)+'…':text;
}
// Elements marked data-fit hold their full text there. Calendar titles share their line with an icon, so the line is what's measured.
function fitLineText(){
  document.querySelectorAll('[data-fit]').forEach(element=>{
    const line=element.classList.contains('cal-title')?element.parentElement:element;
    const style=getComputedStyle(line),room=line.clientWidth-parseFloat(style.paddingLeft)-parseFloat(style.paddingRight)-1,range=document.createRange();
    // Measured to the fraction of a pixel: a rounded width lets the stylesheet's own ellipsis cut the last word.
    const fits=text=>{element.textContent=text;range.selectNodeContents(line);return range.getBoundingClientRect().width<=room;};
    element.textContent=textAtWord(element.dataset.fit,fits);
  });
}

function renderCalendar(year,month){
  const fd=(new Date(year,month,1).getDay()+6)%7,dim=new Date(year,month+1,0).getDate(),dn=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  let html=`<div class="cal-grid">${dn.map(d=>`<div class="cal-header">${d}</div>`).join('')}`;
  for(let i=0;i<fd;i++)html+=`<div class="cal-day other-month"></div>`;
  for(let d=1;d<=dim;d++){
    const ds=`${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,isToday=ds===todayStr;
    const dw=works.filter(w=>w.startDate===ds||w.deadline===ds);
    const scheduled=works.filter(w=>w.startDate===ds||w.deadline===ds||(w.startDate&&w.startDate<=ds&&(w.status==='done'?Boolean(w.deadline&&w.deadline>=ds):(!w.deadline||w.deadline>=ds))));
    html+=`<div class="cal-day ${isToday?'today':''}" role="button" tabindex="0" aria-label="${ds}, ${scheduled.length} scheduled work items" onclick="showDayEvents('${ds}')">`;
    html+=`<div class="cal-day-num" style="${isToday?'color:var(--primary);font-weight:700;':''}">${d}</div>`;
    // Show max 2 events
    dw.slice(0,2).forEach(w=>{
      const isDl=w.deadline===ds;
      const isAd=w.workType==='adHoc';
      const bg=isDl?'var(--red-dim)':'var(--primary-dim)';
      const fg=isDl?'var(--red)':'var(--primary)';
      const bdr=isAd?'1px dashed var(--orange)':'1px solid var(--primary)';
      html+=`<div class="cal-event" style="background:${bg};color:${fg};border:${bdr};" title="${escapeHtml(w.title)}${isAd?' [Ad-hoc]':''}">${isDl?'<svg class="ui-icon" aria-hidden="true"><use href="#i-flag"/></svg>':'▶'} <span class="cal-title" data-fit="${escapeHtml(w.title)}">${escapeHtml(w.title)}</span></div>`;
    });
    // Show "+N more" if there are more events
    if(dw.length>2){
      html+=`<div class="cal-event" style="background:var(--bg4);color:var(--text3);font-weight:700;text-align:center;">+${dw.length-2} more</div>`;
    }
    html+=`</div>`;
  }
  return html+`</div>`;
}

function showDayEvents(dateStr){
  const starting=works.filter(w=>w.startDate===dateStr);
  const deadlines=works.filter(w=>w.deadline===dateStr);
  const active=works.filter(w=>{
    if(w.status==='done')return false;
    return Boolean(w.startDate&&w.startDate<=dateStr&&(!w.deadline||w.deadline>=dateStr)&&w.startDate!==dateStr&&w.deadline!==dateStr);
  });
  const completed=works.filter(w=>w.status==='done'&&w.startDate&&w.deadline&&w.startDate<dateStr&&w.deadline>dateStr);
  const d=TeamFlowDomain.parseDateKey(dateStr);
  document.getElementById('modal-title').innerHTML='<svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg> '+d.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric',timeZone:'UTC'});
  function wCard(w,isS,isDl){
    const prog=phaseProgress(w),pic=getMember(w.pic||w.createdBy||0);
    const wtB=workTypeBadge(w.workType||'regular');
    return`<div class="work-item" role="button" tabindex="0" style="margin-bottom:0;cursor:pointer;" onclick="closeModal();openWorkDetail(${Number(w.id)})">`
      +`<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">`
      +`${isS?'<span class="badge badge-executing"><svg class="ui-icon" aria-hidden="true"><use href="#i-play"/></svg> Start</span>':''}`
      +`${isDl?'<span class="badge badge-overdue"><svg class="ui-icon" aria-hidden="true"><use href="#i-flag"/></svg> Deadline</span>':''}`
      +`<span class="badge badge-${w.status==='done'?'done':w.status==='upcoming'?'upcoming':PHASES[w.phase].toLowerCase()}">${w.status==='done'?'Completed':w.status==='upcoming'?'Upcoming':PHASES[w.phase]}</span>`
      +`${wtB}<span class="badge badge-priority-${w.priority.toLowerCase()}">${w.priority}</span></div>`
      +`<div style="font-size:13px;font-weight:700;margin-bottom:6px;">${escapeHtml(w.title)}</div>`
      +`${w.status!=='upcoming'?`<div class="progress-bar" style="margin-bottom:6px;"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div>`:''}`
      +`<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">`
      +`${assigneesHtml(w.assignees)}`
      +`${pic?`<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-user"/></svg> ${escapeHtml(pic.name)}</div>`:''}`
      +`<span class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-flag"/></svg> ${fmt(w.deadline)}</span>`
      +`${deadlineChip(w.deadline,w.status)}`
      +`${w.status!=='upcoming'?`<span style="font-size:11px;color:var(--text3);">${prog}%</span>`:''}`
      +`</div></div>`;
  }
  let body='';
  if(starting.length){
    body+=`<div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--primary);margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid var(--primary-dim);"><svg class="ui-icon" aria-hidden="true"><use href="#i-play"/></svg> Starting Today (${starting.length})</div>`;
    body+=`<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;">${starting.map(w=>wCard(w,true,false)).join('')}</div>`;
  }
  if(deadlines.length){
    body+=`<div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--red);margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid var(--red-dim);"><svg class="ui-icon" aria-hidden="true"><use href="#i-flag"/></svg> Deadlines Today (${deadlines.length})</div>`;
    body+=`<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;">${deadlines.map(w=>wCard(w,false,true)).join('')}</div>`;
  }
  if(active.length){
    body+=`<div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--green);margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid var(--green-dim);"><svg class="ui-icon" aria-hidden="true"><use href="#i-sync"/></svg> Active Work (${active.length})</div>`;
    body+=`<div style="display:flex;flex-direction:column;gap:8px;">${active.map(w=>wCard(w,false,false)).join('')}</div>`;
  }
  if(completed.length){
    body+=`<div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--green);margin-top:${active.length?16:0}px;margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid var(--green-dim);"><svg class="ui-icon" aria-hidden="true"><use href="#i-check"/></svg> Completed Work (${completed.length})</div>`;
    body+=`<div style="display:flex;flex-direction:column;gap:8px;">${completed.map(w=>wCard(w,false,false)).join('')}</div>`;
  }
  document.getElementById('modal-body').innerHTML=body||'<div class="empty-state"><p>No work scheduled for this date.</p></div>';
  document.getElementById('modal-footer').innerHTML=`<button class="btn btn-ghost" onclick="closeModal()">Close</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}
function filterWorks(q,status){const el=document.getElementById('work-list');if(!el)return;const f=works.filter(w=>w.status===status&&workMatchesSearch(w,q));el.innerHTML=f.length?f.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-search"/></svg></div><p>No results found.</p></div>';}
function filterByPhase(phase){const el=document.getElementById('work-list');if(!el)return;const f=works.filter(w=>w.status==='ongoing'&&(phase===''||w.phase===parseInt(phase)));el.innerHTML=f.length?f.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-search"/></svg></div><p>No results found.</p></div>';}
function filterByPriority(priority,status){const el=document.getElementById('work-list');if(!el)return;const f=works.filter(w=>w.status===status&&(priority===''||w.priority===priority));el.innerHTML=f.length?f.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-search"/></svg></div><p>No results found.</p></div>';}

// ============================================================
// WORK DETAIL MODAL
// ============================================================
function myReviewQueue(){
  return works.filter(work=>work.status==='ongoing'&&work.phase===2&&work.reviewApproved!==true&&TeamFlowDomain.canSignOff(currentUser,work)).sort((a,b)=>String(a.reviewEnteredAt||'9999').localeCompare(String(b.reviewEnteredAt||'9999')));
}
// What's waiting on you, oldest first, so slow reviews are visible before they become the bottleneck.
function reviewQueueHtml(){
  const queue=myReviewQueue();
  if(!['admin','manager','member'].includes(currentUser?.role))return'';
  if(!queue.length)return`<div class="card focus-card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Waiting for Your Sign-off</div></div><div class="focus-empty">Nothing is waiting for your sign-off.</div></div>`;
  const shown=queue.slice(0,5),more=queue.length-shown.length;
  const rows=shown.map(work=>{
    const days=work.reviewEnteredAt?TeamFlowDomain.daysExcludingWeekends(work.reviewEnteredAt,new Date().toISOString(),TEAM_TIME_ZONE):null;
    const age=days==null?'—':days<1?'<1d':`${Math.round(days)}d`,left=work.deadline?daysUntil(work.deadline):null;
    const due=left==null?'No deadline':left<0?`<span style="color:var(--red);font-weight:600;">Overdue ${Math.abs(left)}d</span>`:left===0?'<span style="color:var(--red);font-weight:600;">Due today</span>':`Due in ${left}d`;
    const owner=TeamFlowDomain.isSelfReview(currentUser,work)?'Your own work':`PIC ${escapeHtml(getMember(work.pic)?.name||'not assigned')}`;
    return`<div class="focus-row" role="button" tabindex="0" onclick="openWorkDetail(${Number(work.id)})"><div class="focus-tile ${days!=null&&days>=3?'alert':''}"><strong>${age}</strong><span>in review</span></div><div class="focus-main"><div class="focus-title">${escapeHtml(work.title)}</div><div class="focus-sub">${owner} · ${due}</div></div><svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg></div>`;
  }).join('');
  return`<div class="card focus-card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Waiting for Your Sign-off <span class="focus-count">${queue.length}</span></div>${more?`<button type="button" class="btn btn-ghost btn-sm" onclick="openReviewReady()">See all</button>`:''}</div>${rows}</div>`;
}
function selectWorkTab(tab){workDetailTab=tab;applyWorkTab();}
function applyWorkTab(){
  const body=document.getElementById('modal-body');
  const panels=[...body.querySelectorAll('.work-tab-panel')];if(!panels.length)return;
  if(!panels.some(panel=>panel.dataset.panel===workDetailTab))workDetailTab='overview';
  panels.forEach(panel=>{
    const active=panel.dataset.panel===workDetailTab;
    panel.hidden=!active;
    // History and Performance load when their tab is first opened.
    if(active){const details=panel.querySelector(':scope > details');if(details&&!details.open)details.open=true;}
  });
  body.querySelectorAll('.work-tab').forEach(tab=>{const active=tab.dataset.tab===workDetailTab;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));});
}
let workDetailTab='overview';
async function openWorkDetail(id){
  // Show modal immediately with cached data (no delay)
  const w=works.find(x=>x.id===id);if(!w)return;
  const body=document.getElementById('modal-body');
  const sameWork=body.dataset.detailWorkId===String(id)&&Boolean(document.getElementById(`activity-history-${id}`));
  const noteDraft=sameWork?document.getElementById('new-note-text')?.value||'':'';
  // Coming back from a form in this modal (Cancel) discards what was typed in it.
  if(document.getElementById('modal-overlay')?.style.display==='flex'&&!hasPendingChanges&&!noteDraft.trim())draftActive=false;
  const scroll=sameWork?body.scrollTop:0;
  const historyOpen=sameWork&&document.getElementById(`activity-history-${id}`)?.open;
  if(!sameWork)workDetailTab='overview';
  body.dataset.detailWorkId=String(id);
  const editable=canEdit(w),prog=phaseProgress(w);
  const pic=getMember(w.pic||w.createdBy||0);
  document.getElementById('modal-title').textContent=w.title;
  let phaseHtml=`<div class="phase-track">`;
  PHASES.forEach((p,i)=>{const isDone=i<w.phase||w.status==='done',isActive=i===w.phase&&w.status==='ongoing';phaseHtml+=`<div class="phase-step"><div class="phase-step-inner"><div class="phase-dot ${isDone?'done':isActive?'active':'pending'}">${isDone?'<svg class="ui-icon" aria-hidden="true"><use href="#i-check"/></svg>':i+1}</div><div class="phase-label ${isDone?'done':isActive?'active':''}">${p}</div></div></div>`;if(i<PHASES.length-1)phaseHtml+=`<div class="phase-line ${isDone?'done':isActive?'active':''}"></div>`;});
  phaseHtml+=`</div>`;
  let pdHtml=`<div class="phase-detail-grid">`;
  PHASES.forEach((p,i)=>{const isDone=i<w.phase||w.status==='done',isActive=i===w.phase&&w.status==='ongoing',tasks=w.phaseTasks[p]||[],checks=w.phaseChecks[p]||[],doneCount=checks.filter(Boolean).length;pdHtml+=`<div class="phase-card ${isActive?'active-phase':isDone?'done-phase':''}"><div class="phase-card-title" style="color:${isDone?'var(--green)':isActive?'var(--primary-light)':'var(--text2)'};">${isDone?'<svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg>':isActive?'<svg class="ui-icon" aria-hidden="true"><use href="#i-dot"/></svg>':'<svg class="ui-icon" aria-hidden="true"><use href="#i-square"/></svg>'} ${p}</div><div style="font-size:11px;color:var(--text3);margin-bottom:6px;">${doneCount}/${tasks.length} tasks</div><ul class="phase-card-items">${tasks.map((item,idx)=>{const checked=checks[idx]||false,canCheck=editable&&(isActive||isDone);return`<li style="${checked?'text-decoration:line-through;color:var(--text3);':''}" ${canCheck?`role="checkbox" aria-checked="${checked}" tabindex="0" onclick="togglePhaseCheck(${id},'${p}',${idx})"`:''}>${checked?'<svg class="ui-icon" aria-hidden="true"><use href="#i-check"/></svg> ':''}${escapeHtml(item)}</li>`;}).join('')}</ul></div>`;});
  pdHtml+=`</div>`;
  let aHtml=`<div style="display:flex;flex-wrap:wrap;gap:8px;">`;w.assignees.forEach(aid=>{const m=getMember(aid);if(m)aHtml+=`<div style="display:flex;align-items:center;gap:6px;padding:5px 10px;background:var(--bg3);border-radius:20px;font-size:12px;">${avatarHtml(m,22)} ${escapeHtml(m.name)} ${roleBadge(m.role)}</div>`;});aHtml+=`</div>`;
  let fHtml=w.files.length?w.files.map((f,fi)=>linkedFileHtml(f,id,fi,editable)).join(''):`<div style="font-size:13px;color:var(--text3);">No files linked yet.</div>`;
  // Highlight what was unread when the work was opened, then record it as read.
  const unreadAtOpen=sameWork?(body._unreadAtOpen||[]):unreadNotes(w).map(n=>n.createdAt);body._unreadAtOpen=unreadAtOpen;
  let nHtml=notesListHtml(w,unreadAtOpen);
  const meetingsHtml=workMeetingsHtml(w),linkedMeetings=meetings.filter(meeting=>(meeting.linkedWorkIds||[]).includes(id)).length;
  // The activity log (History, Performance) is shared with the work's team, managers, admins and Board only, as on the server.
  const activityVisible=currentUser.role==='board'||canEdit(w);
  const workTabs=[['overview','Overview'],['notes',`Notes (${w.notes.length})${unreadAtOpen.length?` · ${unreadAtOpen.length} new`:''}`],...(meetingsHtml?[['meetings',`Meetings (${linkedMeetings})`]]:[]),...(activityVisible&&w.status==='done'?[['performance','Performance']]:[]),...(activityVisible?[['history','History']]:[])];
  document.getElementById('modal-body').innerHTML=`
  <div class="detail-section"><div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">`+workTypeBadge(w.workType||'regular')+`<span class="badge badge-priority-${w.priority.toLowerCase()}">${escapeHtml(w.priority)} Priority</span>${(w.tags||[]).map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}${deadlineChip(w.deadline,w.status)}</div><div style="font-size:13px;color:var(--text2);line-height:1.7;margin-bottom:12px;white-space:pre-wrap;">${escapeHtml(w.desc)}</div><div style="display:flex;gap:20px;flex-wrap:wrap;"><div class="meta-item">▶ Start: <strong>${fmt(w.startDate)}</strong></div><div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-flag"/></svg> Deadline: <strong>${fmt(w.deadline)}</strong></div><div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-clock"/></svg> Estimate: <strong>${Number(w.estimatedHours||0)} h</strong></div>${w.actualHours!=null?`<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> Actual: <strong>${Number(w.actualHours)} h</strong></div>`:''}${w.completedDate?`<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Completed: <strong>${fmt(w.completedDate)}</strong></div>`:''}</div></div>
  <div class="tabs work-tabs" role="tablist" aria-label="Work detail">${workTabs.map(([key,label])=>`<div class="tab work-tab" role="tab" tabindex="0" data-tab="${key}" aria-selected="false" onclick="selectWorkTab('${key}')">${escapeHtml(label)}</div>`).join('')}</div>
  <div class="work-tab-panel" data-panel="overview">
  <div class="detail-section"><div class="detail-section-title">Phase Progress</div>${phaseHtml}<div style="margin:10px 0 4px;display:flex;justify-content:space-between;"><span style="font-size:12px;color:var(--text3);">Overall</span><span style="font-size:12px;color:var(--text3);">${prog}%</span></div><div class="progress-bar" style="height:8px;"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div><div style="font-size:11px;color:var(--text3);margin-top:4px;">Click tasks in active/done phases to check them off</div>${pdHtml}</div>
  <div class="work-save-status" role="status" style="font-size:12px;color:var(--text3);height:0;position:relative;top:-20px;">${hasPendingChanges?'Saving…':''}</div>
  ${reviewSectionHtml(w)}
  <div class="detail-section"><div class="detail-section-title">Team Members</div>${aHtml}
    ${canManageAssignments(w)?`<button class="btn btn-ghost btn-sm" style="margin-top:12px;" onclick="openManageAssignees(${id})">Manage Assignees</button>`:''}
    <div style="margin-top:10px;display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--primary-dim);border-radius:var(--radius-sm);border:1px solid rgba(59,111,212,0.2);">
      <span style="font-size:12px;font-weight:700;color:var(--primary);"><svg class="ui-icon" aria-hidden="true"><use href="#i-user"/></svg> PIC:</span>
      ${pic?`${avatarHtml(pic,24)}<span style="font-size:13px;font-weight:600;">${escapeHtml(pic.name)}</span><span style="font-size:11px;color:var(--text3);">(Person in Charge)</span>`:'<span style="font-size:12px;color:var(--text3);">Not assigned</span>'}
    </div>
  </div>
  <div class="detail-section"><div class="detail-section-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-paperclip"/></svg> Linked Files & Folders</div><div id="files-list-${id}">${fHtml}</div>${editable?`<button class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="openAddFile(${id})">+ Add File / Folder Link</button>`:''}</div>
  </div>
  <div class="work-tab-panel" data-panel="notes"><div class="detail-section"><div class="detail-section-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-message"/></svg> Notes & Updates</div><div id="notes-list-${id}">${nHtml}</div>${editable?`<div style="margin-top:10px;"><textarea id="new-note-text" maxlength="1000" data-count placeholder="Add a note or update..." style="margin-bottom:8px;"></textarea><button class="btn btn-primary btn-sm" onclick="addNote(${id})">Add Note</button></div>`:''}</div></div>
  ${meetingsHtml?`<div class="work-tab-panel" data-panel="meetings">${meetingsHtml}</div>`:''}
  ${w.status==='done'?`<div class="work-tab-panel" data-panel="performance"><details class="detail-section activity-history" id="performance-${id}" ontoggle="if(this.open)loadWorkPerformance(${id})"><summary class="detail-section-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-trend"/></svg> Performance Analysis</summary><div id="performance-body-${id}" style="font-size:13px;color:var(--text3);">Loading analysis…</div></details></div>`:''}
  <div class="work-tab-panel" data-panel="history"><details class="detail-section activity-history" id="activity-history-${id}" ontoggle="if(this.open)loadWorkActivity(${id})"><summary class="detail-section-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-receipt"/></svg> Activity History</summary><div id="activity-list-${id}" style="font-size:12px;color:var(--text3);">Loading history…</div></details></div>`;
  applyWorkTab();
  let footer='';
  // Join/Leave buttons for members (not done work)
  if(w.status!=='done'){
    const isAssigned=w.assignees.includes(currentUser.id);
    const isPic=w.pic===currentUser.id;
    const hasPendingJoin=joinRequests.find(r=>r.workId===id&&r.userId===currentUser.id&&r.type==='join'&&r.status==='pending');
    const hasPendingLeave=joinRequests.find(r=>r.workId===id&&r.userId===currentUser.id&&r.type==='leave'&&r.status==='pending');
    if(!isAssigned&&currentUser.role==='member'&&!hasPendingJoin){
      footer+=`<button class=\"btn btn-ghost\" onclick=\"requestJoin(${id})\" style=\"border-color:var(--primary);color:var(--primary);\"><svg class="ui-icon" aria-hidden="true"><use href="#i-hand"/></svg> Request to Join</button>`;
    }
    if(hasPendingJoin)footer+=`<span style=\"font-size:12px;color:var(--text3);padding:8px;\"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> Join request pending...</span>`;
    if(isAssigned&&!isPic&&currentUser.role==='member'&&!hasPendingLeave){
      footer+=`<button class=\"btn btn-ghost\" onclick=\"requestLeave(${id})\" style=\"border-color:var(--red);color:var(--red);\"><svg class="ui-icon" aria-hidden="true"><use href="#i-door"/></svg> Request to Leave</button>`;
    }
    if(hasPendingLeave)footer+=`<span style=\"font-size:12px;color:var(--text3);padding:8px;\"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> Leave request pending...</span>`;
  }
  // Rarely used actions (edit, delete) live in a ⋯ menu so the footer keeps one clear primary action.
  const more=[];
  // Action buttons for editors
  if(canEdit(w)&&(w.status!=='done'||currentUser.role==='admin')){
    if(currentUser.role==='admin'&&w.status==='done'){
      // Admin on completed work: Reopen + Edit
      footer+=`<button class=\"btn btn-ghost\" onclick=\"reopenWork(${id})\" style=\"border-color:var(--yellow);color:var(--yellow);\">${actionIcon('return')}Reopen Work</button>`;
      more.push(['openEditNameDesc('+id+')','pencil','Edit completed work']);
    } else if(w.status==='upcoming'){
      footer+=`<button class=\"btn btn-primary\" onclick=\"startWork(${id})\"><svg class="ui-icon" aria-hidden="true"><use href="#i-play"/></svg> Start Work</button>`;
      more.push(['openEditWork('+id+')','pencil','Edit work']);
    } else {
      // Ongoing work: Back + Advance/Complete + Edit
      const awaitingSignOff=w.phase===2&&w.reviewApproved!==true,signsOff=TeamFlowDomain.canSignOff(currentUser,w);
      if(awaitingSignOff&&signsOff){
        footer+=`<button class=\"btn btn-ghost\" onclick=\"openSignOff(${id},'sent_back')\" style=\"border-color:var(--yellow);color:var(--yellow);\">${actionIcon('return')}Send Back</button>`;
        footer+=`<button class=\"btn btn-success\" onclick=\"openSignOff(${id},'approved')\">${actionIcon('check')}Approve</button>`;
      }else{
        if(w.phase>0)footer+=`<button class=\"btn btn-ghost\" onclick=\"movePhaseBack(${id})\" style=\"border-color:var(--yellow);color:var(--yellow);\">${actionIcon('back')}Back to ${PHASES[w.phase-1]}</button>`;
        if(awaitingSignOff)footer+=`<span style=\"font-size:12px;color:var(--text3);padding:8px;\"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> Awaiting sign-off</span>`;
        else if(w.phase<PHASES.length-1)footer+=`<button class=\"btn btn-primary\" onclick=\"advancePhase(${id})\">Advance to ${PHASES[w.phase+1]}${actionIcon('next')}</button>`;
      }
      if(w.phase===PHASES.length-1)footer+=`<button class=\"btn btn-success\" onclick=\"openCompleteWork(${id})\"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Mark Complete</button>`;
      more.push(['openEditWork('+id+')','pencil','Edit work']);
    }
  }
  if(currentUser.role==='admin'||currentUser.role==='manager')more.push(['deleteWork('+id+')','trash','Delete work','danger']);
  footer+=`<button class=\"btn btn-ghost\" onclick=\"closeModal()\">Close</button>`;
  if(more.length)footer=`<details class="footer-more"><summary class="btn btn-ghost" aria-label="More actions" title="More actions"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg></summary><div class="footer-more-menu" role="menu">${more.map(m=>`<button type="button" role="menuitem" class="${m[3]==='danger'?'is-danger':''}" onclick="this.closest('details').open=false;${m[0]}"><svg class="ui-icon" aria-hidden="true"><use href="#i-${m[1]}"/></svg>${m[2]}</button>`).join('')}</div></details>`+footer;
  document.getElementById('modal-footer').innerHTML=footer;
  document.getElementById('modal-overlay').style.display='flex';
  const noteInput=document.getElementById('new-note-text');
  if(noteInput)noteInput.value=noteDraft;
  body.scrollTop=scroll;
  if(historyOpen){document.getElementById(`activity-history-${id}`).open=true;loadWorkActivity(id);}
  markNotesRead(w);
  if(!syncInFlight&&!draftActive&&!hasPendingChanges)backgroundSync();
}
function performanceHtml(result){
  const partial=result.score!=null&&result.available<100;
  const color=result.score==null||partial?'var(--text3)':result.score>=80?'var(--green)':result.score>=60?'var(--yellow)':'var(--red)';
  const label=result.score==null?'Not enough data':partial?`Partial score · ${result.available} of 100 points could be measured`:result.score>=80?'Good':result.score>=60?'Fair':'Needs attention';
  const parts=result.components.map(item=>`${escapeHtml(item.label)} ${item.points}/${item.max}`).join(' · ');
  const header=`<div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;"><div style="font-size:22px;font-weight:700;line-height:1;color:${color};">${result.score==null?'—':result.score}</div><div style="min-width:0;flex:1;"><div style="font-size:13px;font-weight:700;color:${color};">${label}</div><div style="margin-top:2px;font-size:12px;color:var(--text2);">${parts}</div></div></div>`;
  const caveat=`<div style="margin-top:10px;font-size:11px;color:var(--text3);">Indicative only: a fixed formula not yet calibrated to the team’s data. Use it to decide where to look, not to assess people.</div>`;
  const deadlineNote=result.deadlineHistoryKnown?'':' This work’s deadline also changed before detailed history began, so the original deadline may be earlier than the one scored.';
  const warning=(!result.phasesKnown?'Phase timing isn’t available because this work’s phase moves weren’t recorded in detail. The score uses the other measures only.':!result.timingReliable?'Several phases moved within an hour, so phase times may not reflect when the work really happened. They aren’t used for the slowest phase or the review wait.':'')+deadlineNote;
  const warningHtml=warning?`<div style="margin-top:12px;padding:8px 12px;font-size:12px;color:var(--text2);border-radius:var(--radius-sm);background:var(--bg3);border:1px solid var(--border);">${warning}</div>`:'';
  const rows=result.phasesKnown?`<div style="margin-top:14px;">${result.phases.map(phase=>{const flagged=result.bottleneck?.name===phase.name;return`<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;"><span style="width:64px;flex:none;font-size:12px;font-weight:${flagged?700:500};color:${flagged?'var(--red)':'var(--text2)'};">${escapeHtml(phase.name)}</span><div class="perf-bar" style="flex:1;margin-top:0;"><div class="perf-bar-fill" style="width:${Math.round(phase.share*100)}%;background:${flagged?'var(--red)':'var(--primary)'};"></div></div><span style="width:82px;flex:none;text-align:right;font-size:12px;color:var(--text2);">${TeamFlowDomain.formatDays(phase.days)} · ${Math.round(phase.share*100)}%</span></div>`;}).join('')}<div style="font-size:11px;color:var(--text3);">Times are elapsed days from the activity log, leaving out weekends. Public holidays still count.</div></div>`:'';
  const notes=(title,items,tone)=>items.length?`<div style="margin-top:14px;"><div style="font-size:12px;font-weight:700;color:${tone};">${title}</div><ul class="history-details">${items.map(item=>`<li>${escapeHtml(item)}</li>`).join('')}</ul></div>`:'';
  return header+caveat+warningHtml+rows+notes('What went well',result.good,'var(--green)')+notes('What to improve',result.improve,'var(--red)');
}
async function loadWorkPerformance(workId){
  const target=document.getElementById(`performance-body-${workId}`);if(!target||target.dataset.loading==='true'||target.dataset.loaded==='true')return;
  target.dataset.loading='true';
  try{
    const entries=[];let cursor='';
    do{
      const page=await apiGet(`activity?workId=${encodeURIComponent(workId)}&page=1&limit=200${cursor?'&cursor='+encodeURIComponent(cursor):''}`);
      entries.push(...page.items);cursor=page.nextCursor||'';
    }while(cursor);
    if(document.getElementById(`performance-body-${workId}`)!==target)return;
    const work=works.find(item=>item.id===workId);if(!work)return;
    target.innerHTML=performanceHtml(TeamFlowDomain.workPerformance(work,entries,TEAM_TIME_ZONE));
    target.style.color='var(--text)';target.dataset.loaded='true';
  }catch{target.textContent='Performance analysis is not available for this work.';}
  finally{delete target.dataset.loading;}
}
async function loadWorkActivity(workId,more=false){
  const target=document.getElementById(`activity-list-${workId}`);if(!target)return;
  if(target.dataset.loading==='true'||(target.dataset.loaded==='true'&&!more))return;
  target.dataset.loading='true';
  try{
    const page=await apiGet(`activity?workId=${encodeURIComponent(workId)}&page=1&limit=50${more&&target.dataset.cursor?'&cursor='+encodeURIComponent(target.dataset.cursor):''}`);
    const entries=Array.isArray(page)?page:page.items;
    if(document.getElementById(`activity-list-${workId}`)!==target)return;
    document.getElementById(`activity-more-${workId}`)?.remove();
    const rows=entries.length?entries.map(entry=>`<div style="padding:8px 0;border-bottom:1px solid var(--border);"><div><strong>${escapeHtml(entry.actorName)}</strong> ${escapeHtml(entry.action)} this work</div><div style="color:var(--text3);margin:3px 0;">${new Date(entry.createdAt).toLocaleString()}</div>${(entry.details||[]).length?`<ul class="history-details">${entry.details.map(line=>`<li>${escapeHtml(line)}</li>`).join('')}</ul>`:(entry.action==='created'?'':`<div>${Object.entries(entry.changedFields||{}).map(([field,change])=>`<span class="tag">${escapeHtml(field)}</span>`).join(' ')}</div>`)}</div>`).join(''):'<span>No changes recorded yet.</span>';
    target.innerHTML=more?target.innerHTML+rows:rows;
    target.dataset.cursor=page.nextCursor||'';
    if(page.nextCursor)target.innerHTML+=`<button id="activity-more-${workId}" type="button" class="btn btn-ghost btn-sm" onclick="loadWorkActivity(${Number(workId)},true)">Load more</button>`;
    target.dataset.loaded='true';
  }catch{if(more)showToast('Could not load more activity. Try again.','error');else target.textContent='Activity history is not available. Close and expand this section to retry.';}
  finally{delete target.dataset.loading;}
}
function togglePhaseCheck(workId,phase,idx){
  const w=works.find(x=>x.id===workId);if(!w||!canEdit(w))return;
  if(document.querySelector('#modal-body [id^="en-"]')){showToast('Finish editing the note before changing tasks.','info');return;}
  const phaseIndex=PHASES.indexOf(phase),tasks=w.phaseTasks[phase]||[];
  if(!Number.isInteger(idx)||idx<0||idx>=tasks.length||!(phaseIndex<w.phase||w.status==='done'||phaseIndex===w.phase&&w.status==='ongoing'))return;
  if(!w.phaseChecks[phase])w.phaseChecks[phase]=[];
  w.phaseChecks[phase][idx]=!w.phaseChecks[phase][idx];
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  scheduleSave(true);openWorkDetail(workId);
  const task=document.querySelectorAll('.phase-card')[phaseIndex]?.querySelectorAll('li')[idx];
  task?.focus({preventScroll:true});
}
let pendingNote=null;
async function addNote(workId){if(!hasPendingChanges)pendingNote=null;const w=works.find(x=>x.id===workId);const text=document.getElementById('new-note-text').value.trim();if(!text){showToast('Please enter a note.','error');return;}const note={authorId:currentUser.id,authorName:currentUser.name,text,createdDate:todayStr,editedDate:null};if(pendingNote?.workId===workId)w.notes[pendingNote.index]=note;else{pendingNote={workId,index:w.notes.length};w.notes.push(note);}
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  if(!(await saveRequestsNow()))return;
  pendingNote=null;showToast('Note added!','success');
  const notesTab=document.querySelector('.work-tab[data-tab="notes"]');if(notesTab)notesTab.textContent=`Notes (${w.notes.length})`;
  const notesEl=document.getElementById('notes-list-'+workId);
  if(notesEl)notesEl.innerHTML=notesListHtml(w);
  pendingNote=null;const ta=document.getElementById('new-note-text');if(ta)ta.value='';
}
async function removeFile(workId,fi){const w=works.find(x=>x.id===workId);w.files.splice(fi,1);
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  if(!(await saveRequestsNow()))return;
  showToast('File removed.','info');
  const filesEl2=document.getElementById('files-list-'+workId);
  if(filesEl2){const editable=canEdit(w);filesEl2.innerHTML=w.files.length?w.files.map((f,fi2)=>linkedFileHtml(f,workId,fi2,editable)).join(''):'<div style="font-size:13px;color:var(--text3);">No files linked yet.</div>';}
}
function openCompleteWork(id){
  const w=works.find(work=>work.id===id);if(!w)return;
  if(hasPendingChanges){showToast('Save your pending edits before completing work.','error');return;}
  document.getElementById('modal-title').textContent='Complete Work';
  document.getElementById('modal-body').innerHTML=`<p style="margin-bottom:14px;">${escapeHtml(w.title)}</p><div class="form-group"><label class="form-label" for="complete-actual-hours">Actual effort (hours)</label><input id="complete-actual-hours" type="number" min="0" max="10000" step="0.5" value="${Number(w.estimatedHours||0)}"><div class="form-hint">Estimated: ${Number(w.estimatedHours||0)} h. Enter the total hours the team actually spent.</div></div>`;
  document.getElementById('modal-footer').innerHTML=`<button class="btn btn-success" onclick="confirmCompleteWork(${id})"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Complete Work</button><button class="btn btn-ghost" onclick="openWorkDetail(${id})">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
  const input=document.getElementById('complete-actual-hours');input.focus();input.select();
}
function confirmCompleteWork(id){
  const raw=document.getElementById('complete-actual-hours').value.trim(),hours=Number(raw);
  if(raw===''||!Number.isFinite(hours)||hours<0||hours>10000){showToast('Actual hours must be between 0 and 10,000.','error');return;}
  return completeWork(id,hours);
}
async function completeWork(id,actualHours){
  if(hasPendingChanges){showToast('Save your pending edits before completing work.','error');return;}
  const current=remoteState.works.find(work=>work.id===id);if(!current)return;
  const finishButton=setButtonBusy(document.activeElement);
  try{
    const result=await sendJson('works',{operation:'complete',id,expectedVersion:current.version,actualHours});
    works=works.map(work=>work.id===id?result.work:work);remoteState.works=remoteState.works.map(work=>work.id===id?cloneValue(result.work):work);
    if(result.nextWork&&!works.some(work=>work.id===result.nextWork.id)){works.push(result.nextWork);remoteState.works.push(cloneValue(result.nextWork));}
    showToast('Work completed.','success');if(typeof celebrate==='function')celebrate();closeModal();navigate(currentPage);
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.message,'error');}
  finally{finishButton();}
}
const ACTION_ICONS={back:'<path d="m15 5-7 7 7 7"/>',next:'<path d="m9 5 7 7-7 7"/>',return:'<path d="m9 14-5-5 5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',check:'<path d="M20 6 9 17l-5-5"/>'};
function actionIcon(name){return`<svg class="action-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${ACTION_ICONS[name]}</svg>`;}
function reviewDecisionHtml(review){
  const approved=review.decision==='approved';
  return`<div style="padding:8px 12px;margin-top:8px;border-radius:var(--radius-sm);border:1px solid var(--border);background:var(--bg3);"><div style="font-size:13px;font-weight:600;color:${approved?'var(--green)':'var(--yellow)'};">${approved?'<svg class="ui-icon" aria-hidden="true"><use href="#i-check"/></svg> Approved':'<svg class="ui-icon" aria-hidden="true"><use href="#i-return"/></svg> Sent back'} by ${escapeHtml(review.actorName)}${review.selfReview?' (PIC self-review)':''}<span style="font-size:11px;font-weight:400;color:var(--text3);"> · ${fmt(review.date)}</span></div>${review.comment?`<div style="font-size:13px;margin-top:4px;overflow-wrap:anywhere;">${escapeHtml(review.comment)}</div>`:''}</div>`;
}
function reviewSectionHtml(w){
  const reviews=w.reviews||[],awaiting=w.status==='ongoing'&&w.phase===2&&w.reviewApproved!==true;
  if(!reviews.length&&!awaiting)return'';
  return`<div class="detail-section"><div class="detail-section-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-note"/></svg> Review Sign-off</div>${awaiting?'<div style="font-size:13px;color:var(--text3);">Waiting for the PIC, a manager or an administrator to approve or send back.</div>':''}${awaiting&&reviews.length?'<div style="font-size:11px;font-weight:700;color:var(--text3);margin-top:12px;">Earlier decisions</div>':''}${reviews.slice().reverse().map(reviewDecisionHtml).join('')}</div>`;
}
function openSignOff(id,decision){
  const w=works.find(work=>work.id===id);if(!w)return;
  if(hasPendingChanges){showToast('Save your pending edits before signing off.','error');return;}
  const approve=decision==='approved',self=TeamFlowDomain.isSelfReview(currentUser,w);
  document.getElementById('modal-title').textContent=approve?'Approve Review':'Send Back from Review';
  document.getElementById('modal-body').innerHTML=`<p style="margin-bottom:14px;">${escapeHtml(w.title)}</p>${self?'<div class="form-hint" style="margin-bottom:12px;">You are the PIC of this work, so this decision will be recorded as PIC self-review.</div>':''}<div class="form-group"><label class="form-label" for="review-comment">${approve?'Comment (optional)':'What needs to change?'}</label><textarea id="review-comment" maxlength="1000"></textarea>${approve?'':'<div class="form-hint">The work returns to Executing and the PIC is notified.</div>'}</div>`;
  document.getElementById('modal-footer').innerHTML=`<button class="btn ${approve?'btn-success':'btn-primary'}" onclick="confirmSignOff(${id},'${approve?'approved':'sent_back'}')">${approve?actionIcon('check')+'Approve':actionIcon('return')+'Send Back'}</button><button class="btn btn-ghost" onclick="openWorkDetail(${id})">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
  document.getElementById('review-comment').focus();
}
async function confirmSignOff(id,decision){
  const comment=document.getElementById('review-comment').value.trim();
  if(decision==='sent_back'&&!comment){showToast('Say what needs to change before sending this work back.','error');return;}
  const current=remoteState.works.find(work=>work.id===id);if(!current)return;
  const finishButton=setButtonBusy(document.activeElement);
  try{
    const result=await sendJson('works',{operation:'review',id,decision,comment,expectedVersion:current.version});
    works=works.map(work=>work.id===id?result.work:work);remoteState.works=remoteState.works.map(work=>work.id===id?cloneValue(result.work):work);
    showToast(decision==='approved'?'Review approved.':'Sent back to Executing.','success');if(decision==='approved'&&typeof celebrate==='function')celebrate();closeModal();navigate(currentPage,{preserveScroll:true});openWorkDetail(id);
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.message,'error');}
  finally{finishButton();}
}
async function advancePhase(id){
  const w=works.find(x=>x.id===id);
  if(TeamFlowDomain.signOffBlocks(w,{phase:w.phase+1,status:w.status})){showToast('Review sign-off is required before this work can move on.','error');return;}
  if(w.phase<PHASES.length-1){
    // Auto-complete all tasks in current phase
    const curPhase=PHASES[w.phase];
    if(w.phaseChecks[curPhase]){
      w.phaseChecks[curPhase]=w.phaseChecks[curPhase].map(()=>true);
    }
    w.phase++;
    if(w.phase===2){markReviewSeen(id);delete w.reviewApproved;}
    if(!(await saveRequestsNow()))return;
    showToast('Advanced to '+PHASES[w.phase]+'! Previous phase tasks auto-completed','success');
    closeModal();openWorkDetail(id);
  }
}
async function movePhaseBack(id){
  const w=works.find(x=>x.id===id);
  if(!w||w.phase<=0){showToast('Already at the first phase.','info');return;}
  const oldP=PHASES[w.phase],newP=PHASES[w.phase-1];
  if(!await appConfirm('Move back from '+oldP+' to '+newP+'? Checklist progress will be preserved.'))return;
  w.phase--;
  if(w.phase===2)markReviewSeen(id);
  if(w.phase<=2)delete w.reviewApproved;
  w.notes.push({authorId:currentUser.id,authorName:currentUser.name,text:'Phase moved back from '+oldP+' to '+newP+' by '+currentUser.name,createdDate:todayStr,editedDate:null});
  if(!(await saveRequestsNow()))return;
  showToast('Moved back to '+newP+'.','info');
  openWorkDetail(id);
}
async function reopenWork(id){
  if(currentUser.role!=='admin'){showToast('Only admin can reopen completed work.','error');return;}
  const w=works.find(x=>x.id===id);
  if(!w)return;
  if(!await appConfirm('Reopen this completed work and set it back to Finalize phase?'))return;
  w.status='ongoing';
  w.phase=PHASES.length-1;
  w.completedDate=null;
  delete w.actualHours;
  w.notes.push({authorId:currentUser.id,authorName:currentUser.name,text:'Work reopened by '+currentUser.name,createdDate:todayStr,editedDate:null});
  if(!(await saveRequestsNow()))return;
  showToast('Work reopened!','success');
  closeModal();
  navigate('ongoing');
}
async function startWork(id){const w=works.find(x=>x.id===id);w.status='ongoing';w.phase=0;if(!(await saveRequestsNow()))return;showToast('Work started!','success');closeModal();navigate(currentPage);}

async function deleteWork(id){if(!await appConfirm('Delete this work item?'))return;works=works.filter(x=>x.id!==id);if(!(await saveRequestsNow()))return;showToast('Work deleted.','info');closeModal();navigate(currentPage);}

// ============================================================
// ADD FILE
// ============================================================
function openAddFile(workId){document.getElementById('modal-body').dataset.detailWorkId=String(workId);document.getElementById('modal-title').textContent='Add File / Folder Link';document.getElementById('modal-body').innerHTML=`<div class="form-group"><label class="form-label">Name *</label><input id="file-name" type="text" placeholder="e.g. Working Files"></div><div class="form-group"><label class="form-label">URL / Path *</label><input id="file-url" type="text" placeholder="http://dashboard/... or https://... or //fileserver/folder/..."><div class="form-hint">Accepts HTTP/HTTPS links, Windows drive paths and network paths. Windows paths use Copy Path; paste into File Explorer. Drive letters must be mapped on each PC.</div></div><div class="form-group"><label class="form-label">Type</label><select id="file-type">${FILE_TYPES.map(t=>`<option value="${t.type}" data-icon="${FILE_TYPE_ICONS[t.type]}">${t.label}</option>`).join('')}</select></div>`;document.getElementById('modal-footer').innerHTML=`<button class="btn btn-primary" onclick="saveFile(${workId})">Add Link</button><button class="btn btn-ghost" onclick="openWorkDetail(${workId})">Cancel</button>`;}
let pendingFile=null;
async function saveFile(workId){if(!hasPendingChanges)pendingFile=null;const w=works.find(x=>x.id===workId);const name=document.getElementById('file-name').value.trim(),url=document.getElementById('file-url').value.trim(),type=document.getElementById('file-type').value;if(!name||!url){showToast('Please fill in all fields.','error');return;}if(!TeamFlowDomain.fileLocationKind(url)){showToast('Enter an HTTP or HTTPS link, a Windows drive path, or a network path.','error');return;}const ft=FILE_TYPES.find(t=>t.type===type);if(!ft){showToast('Choose a valid file type.','error');return;}const file={name,url,icon:ft.icon,type};if(pendingFile?.workId===workId)w.files[pendingFile.index]=file;else{pendingFile={workId,index:w.files.length};w.files.push(file);}
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  if(!(await saveRequestsNow()))return;
  pendingFile=null;showToast('File link added!','success');
  closeModal();
  openWorkDetail(workId);

  document.getElementById('modal-overlay').style.display='flex';
}

// ============================================================
// ADD / EDIT WORK
// ============================================================
function openManageAssignees(id){
  const w=works.find(work=>work.id===id);
  if(!canManageAssignments(w))return;
  if(hasPendingChanges||draftActive){showToast('Save your pending edits before changing assignees.','error');return;}
  draftActive=true;editGeneration++;updateSyncStatus('paused');
  document.getElementById('modal-title').textContent='Manage Assignees';
  const members=TEAM.filter(member=>(member.active!==false&&member.role!=='board'&&member.role!=='admin')||w.assignees.includes(member.id));
  document.getElementById('modal-body').innerHTML=`<p style="margin-bottom:16px;">${escapeHtml(w.title)}</p><div id="member-chips" style="display:flex;flex-wrap:wrap;gap:8px;">${members.map(member=>`<div class="member-chip ${w.assignees.includes(member.id)?'selected':''}" role="checkbox" aria-checked="${w.assignees.includes(member.id)}" tabindex="0" onclick="toggleMember(${Number(member.id)})" data-id="${Number(member.id)}">${avatarHtml(member,20)} ${escapeHtml(member.name)}</div>`).join('')}</div><div class="form-hint" style="margin-top:12px;">Assign at least one member. The PIC stays unchanged.</div>`;
  document.getElementById('modal-body').dataset.assignmentVersion=String(remoteState.works.find(work=>work.id===id)?.version??w.version);
  document.getElementById('modal-footer').innerHTML=`<button class="btn btn-primary" onclick="saveWorkAssignees(${id})">Save Assignees</button><button class="btn btn-ghost" onclick="closeModal();openWorkDetail(${id})">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}
let assignmentSaveBusy=false;
async function saveWorkAssignees(id){
  const w=works.find(work=>work.id===id);
  if(assignmentSaveBusy||!canManageAssignments(w))return;
  if(hasPendingChanges){showToast('Save your pending edits before changing assignees.','error');return;}
  const assignees=getSelectedMembers();
  if(!assignees.length){showToast('Assign at least one member.','error');return;}
  const expectedVersion=Number(document.getElementById('modal-body').dataset.assignmentVersion);
  assignmentSaveBusy=true;
  const finishButton=setButtonBusy(document.activeElement);
  editGeneration++;setSaveIndicator('saving');
  try{
    const result=await sendJson('works',{operation:'assign',id,assignees,expectedVersion});
    works=works.map(work=>work.id===id?result.work:work);
    remoteState.works=remoteState.works.map(work=>work.id===id?cloneValue(result.work):work);
    editGeneration++;draftActive=false;setSaveIndicator('saved');updateSyncStatus('connected');
    showToast('Assignees updated.','success');openWorkDetail(id);
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.message,'error');}
  finally{assignmentSaveBusy=false;finishButton();}
}
// Admin-defined default tags appear as toggles beside the free-text tag field.
function parseTagInput(value){return String(value||'').split(',').map(tag=>tag.trim()).filter(Boolean);}
function tagPickerHtml(inputId,current){
  if(!tagOptions.length)return'';
  const selected=new Set((current||[]).map(tag=>String(tag).toLocaleLowerCase()));
  return`<div class="tag-picker" id="${inputId}-picker" role="group" aria-label="Default tags">${tagOptions.map(option=>{const on=selected.has(option.name.toLocaleLowerCase());return`<button type="button" class="tag-option ${on?'selected':''}" aria-pressed="${on}" data-tag="${escapeHtml(option.name)}" onclick="toggleTagOption('${inputId}',this)">${escapeHtml(option.name)}</button>`;}).join('')}</div>`;
}
function toggleTagOption(inputId,button){
  const input=document.getElementById(inputId);if(!input)return;
  const tag=button.dataset.tag,tags=parseTagInput(input.value),index=tags.findIndex(item=>item.toLocaleLowerCase()===tag.toLocaleLowerCase());
  if(index>=0)tags.splice(index,1);else tags.push(tag);
  input.value=tags.join(', ');syncTagPicker(inputId);
}
function syncTagPicker(inputId){
  const input=document.getElementById(inputId),picker=document.getElementById(inputId+'-picker');if(!input||!picker)return;
  const selected=new Set(parseTagInput(input.value).map(tag=>tag.toLocaleLowerCase()));
  picker.querySelectorAll('[data-tag]').forEach(button=>{const on=selected.has(button.dataset.tag.toLocaleLowerCase());button.classList.toggle('selected',on);button.setAttribute('aria-pressed',String(on));});
}
function toggleWorkTemplates(button){
  const list=document.getElementById('work-template-options');
  if(!list)return;
  const expanded=list.classList.toggle('expanded');
  button.setAttribute('aria-expanded',String(expanded));
  button.textContent=expanded?'Show fewer templates ▴':'Show all templates ▾';
}
function openAddWork(prefill=null){pendingActionLink=null;if(!hasPendingChanges)pendingCreationId=null;if(!canCreateWork()){showToast('Your account cannot create work.','error');return;}document.getElementById('modal-title').textContent='Add New Work';renderWorkForm(null,prefill);document.getElementById('modal-overlay').style.display='flex';}
function openEditWork(id){const w=works.find(x=>x.id===id);if(!w)return;document.getElementById('modal-body').dataset.detailWorkId=String(id);document.getElementById('modal-title').textContent='Edit Work';renderWorkForm(w);document.getElementById('modal-overlay').style.display='flex';}
function renderWorkForm(w, fromTemplate=null){
  const isEdit=!!w;
  const assignmentsEditable=!isEdit||canManageAssignments(w);
  const src=fromTemplate||w||{};
  const phaseEditors=PHASES.map(p=>{
    const tasks=(src.phaseTasks&&src.phaseTasks[p])||DEFAULT_PHASE_TASKS[p];
    return `<div class="phase-task-editor">
      <div class="phase-task-editor-header" onclick="togglePE('${p}')">
        <div class="phase-task-editor-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg> ${p} Phase <span style="font-size:11px;color:var(--text3);">(${tasks.length} tasks)</span></div>
        <span id="arrow-${p}" style="color:var(--text3);">▼</span>
      </div>
      <div id="pe-${p}" style="display:none;">
        <div class="phase-task-list" id="ptl-${p}">
          ${tasks.map((t,i)=>`<div class="phase-task-row" id="ptr-${p}-${i}"><input type="text" value="${escapeHtml(t)}" id="pt-${p}-${i}" placeholder="Task description"><button class="remove-task-btn" onclick="removePT('${p}',${i})">✕</button></div>`).join('')}
        </div>
        <button class="add-task-btn" onclick="addPT('${p}')">+ Add Task</button>
      </div>
    </div>`;
  }).join('');

  const templateSelector = !isEdit && templates.length > 0 ? `
    <div class="form-group work-template-picker" style="background:var(--primary-dim);border:1px solid rgba(59,111,212,0.2);border-radius:var(--radius-sm);padding:12px;">
      <label class="form-label"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg> Use a Template</label>
      <div id="work-template-options" class="work-template-options">
        ${templates.map(t=>`<button type="button" class="btn btn-ghost btn-sm" onclick="applyTemplate(${Number(t.id)})">${templateIconHtml(t)} ${escapeHtml(t.name)}</button>`).join('')}
      </div>
      <button type="button" class="btn btn-ghost btn-sm work-template-toggle" aria-controls="work-template-options" aria-expanded="false" onclick="toggleWorkTemplates(this)">Show all templates ▾</button>
    </div>` : '';

  const recurrenceVal=src.recurrence||'';
  const customDaysVal=src.customDays||'7';
  const picVal=src.pic||currentUser.id;
  const members=TEAM.filter(m=>(m.active!==false&&m.role!=='admin'&&m.role!=='board')||(isEdit&&(src.assignees||[]).includes(m.id)));
  const selectedAssignees=[...(src.assignees||[])];
  if(!isEdit&&currentUser.role==='member'&&!selectedAssignees.includes(currentUser.id))selectedAssignees.push(currentUser.id);

  document.getElementById('modal-body').innerHTML=`
    ${templateSelector}
    <div class="form-group"><label class="form-label" for="f-title">Title *</label><input id="f-title" type="text" maxlength="120" data-count value="${escapeHtml(src.title||'')}" placeholder="Project title"></div>
    <div class="form-group"><label class="form-label" for="f-desc">Description</label><textarea id="f-desc" maxlength="2000" data-count placeholder="Brief description...">${escapeHtml(src.desc||'')}</textarea></div>
    <div class="form-row">
      <div class="form-group"><label class="form-label">Status</label>
        <select id="f-status">
          <option value="upcoming" ${src.status==='upcoming'?'selected':''}>Upcoming</option>
          <option value="ongoing" ${src.status==='ongoing'?'selected':''}>Ongoing</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Priority</label>
        <select id="f-priority">${PRIORITIES.map(p=>`<option value="${p}" ${src.priority===p?'selected':''}>${p}</option>`).join('')}</select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="form-label" for="f-start">Start Date</label><input id="f-start" type="date" value="${escapeHtml(src.startDate||todayStr)}"></div>
      <div class="form-group"><label class="form-label" for="f-deadline">Deadline</label><input id="f-deadline" type="date" value="${escapeHtml(src.deadline||'')}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="form-label" for="f-effort">Estimated effort (hours)</label><input id="f-effort" type="number" min="0" max="10000" step="0.5" value="${Number(src.estimatedHours||0)}"><div class="form-hint">Divided across assignees for capacity planning</div></div>
      <div class="form-group"><label class="form-label" for="f-worktype">Work Type</label><select id="f-worktype">${WORK_TYPES.map(wt=>`<option value="${wt.value}" ${(src.workType||'regular')===wt.value?'selected':''}>${wt.label}</option>`).join('')}</select></div>
    </div>
    <div class="form-group"><label class="form-label" for="f-tags">Tags (comma separated)</label><input id="f-tags" type="text" value="${escapeHtml((src.tags||[]).join(', '))}" placeholder="${tagOptions.length?'Choose below or type your own':'Design, Marketing, Tech'}" oninput="syncTagPicker('f-tags')">${tagPickerHtml('f-tags',src.tags)}</div>
    <div class="form-group" style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;">
      <label class="form-label" for="f-recurrence"><svg class="ui-icon" aria-hidden="true"><use href="#i-repeat"/></svg> Recurrence</label>
      <select id="f-recurrence" onchange="toggleCustomDays(this.value)" style="margin-bottom:8px;">
        ${RECURRENCE_OPTIONS.map(o=>`<option value="${o.value}" ${recurrenceVal===o.value?'selected':''}>${o.label}</option>`).join('')}
      </select>
      <div id="custom-days-row" style="display:${recurrenceVal==='custom'?'flex':'none'};align-items:center;gap:8px;margin-top:6px;">
        <span style="font-size:13px;color:var(--text2);white-space:nowrap;">Repeat every</span>
        <input id="f-custom-days" type="number" min="1" max="365" value="${customDaysVal}" style="width:80px;">
        <span style="font-size:13px;color:var(--text2);">days</span>
      </div>
      <div class="form-hint">When completed, a new occurrence will be automatically created</div>
    </div>
    <div class="form-group"><label class="form-label" for="f-pic"><svg class="ui-icon" aria-hidden="true"><use href="#i-user"/></svg> PIC (Person in Charge)</label>
      <select id="f-pic" ${isEdit&&!['admin','manager'].includes(currentUser.role)?'disabled':''}>
        ${isEdit&&!members.some(m=>m.id===picVal)?`<option value="${Number(picVal)}" selected>${escapeHtml(getMember(picVal)?.name||'Current PIC')}</option>`:''}
        ${members.map(m=>`<option value="${Number(m.id)}" ${picVal===m.id?'selected':''}>${escapeHtml(m.name)} (${escapeHtml(m.role)})</option>`).join('')}
      </select>

    </div>
    <div class="form-group"><label class="form-label">Assign Team Members</label>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:6px;" id="member-chips" data-readonly="${!assignmentsEditable}">
        ${members.map(m=>`<div class="member-chip ${selectedAssignees.includes(m.id)?'selected':''}" role="checkbox" aria-checked="${selectedAssignees.includes(m.id)}" aria-disabled="${!assignmentsEditable}" tabindex="${assignmentsEditable?'0':'-1'}" style="${assignmentsEditable?'':'cursor:default;opacity:0.65;'}" onclick="toggleMember(${Number(m.id)})" data-id="${Number(m.id)}">${avatarHtml(m,20)} ${escapeHtml(m.name)}</div>`).join('')}
      </div>
      ${isEdit?'<div class="form-hint">The work creator, PIC, Admin and Manager can change assignees. Only Admin and Manager can reassign the PIC.</div>':''}
    </div>
    <div class="form-group"><label class="form-label">Phase Tasks</label>${phaseEditors}</div>`;

  const saveBtn=isEdit
    ?`<button class="btn btn-primary" onclick="saveEditWork(${w.id})">Save Changes</button>`
    :`<button class="btn btn-primary" onclick="saveNewWork()">Create Work</button>`;
  const templateBtn=!isEdit
    ?`<button class="btn btn-ghost" onclick="saveAsTemplate()" style="border-color:var(--primary);color:var(--primary);"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg> Save as Template</button>`:'';
  document.getElementById('modal-footer').innerHTML=`${saveBtn}${templateBtn}<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>`;
}


function togglePE(p){const el=document.getElementById(`pe-${p}`),ar=document.getElementById(`arrow-${p}`),open=el.style.display==='none';el.style.display=open?'block':'none';ar.textContent=open?'▲':'▼';}
function addPT(p){const list=document.getElementById(`ptl-${p}`),idx=list.querySelectorAll('.phase-task-row').length;const row=document.createElement('div');row.className='phase-task-row';row.id=`ptr-${p}-${idx}`;row.innerHTML=`<input type="text" id="pt-${p}-${idx}" placeholder="New task..."><button class="remove-task-btn" onclick="removePT('${p}',${idx})">✕</button>`;list.appendChild(row);}
function removePT(p,idx){const r=document.getElementById(`ptr-${p}-${idx}`);if(r)r.remove();}
function getPhaseTasks(p){const list=document.getElementById(`ptl-${p}`);if(!list)return[...DEFAULT_PHASE_TASKS[p]];return Array.from(list.querySelectorAll('input[type=text]')).map(i=>i.value.trim()).filter(Boolean);}
function toggleMember(id){if(document.getElementById('member-chips')?.dataset.readonly==='true')return;const chip=document.querySelector(`.member-chip[data-id="${id}"]`);if(!chip)return;chip.classList.toggle('selected');chip.setAttribute('aria-checked',chip.classList.contains('selected')?'true':'false');}
function getSelectedMembers(){return Array.from(document.querySelectorAll('.member-chip.selected')).map(el=>parseInt(el.dataset.id));}
let pendingCreationId=null;
async function saveNewWork(){
  if(!canCreateWork()){showToast('Your account cannot create work.','error');return;}
  const title=document.getElementById('f-title').value.trim();
  if(!title){showToast('Title is required.','error');return;}
  const assignees=getSelectedMembers();
  if(currentUser.role==='member'&&!assignees.includes(currentUser.id))assignees.push(currentUser.id);
  if(!assignees.length){showToast('Assign at least one member.','error');return;}
  const phaseTasks={};PHASES.forEach(p=>{phaseTasks[p]=getPhaseTasks(p);});
  const phaseChecks={};PHASES.forEach(p=>{phaseChecks[p]=new Array(phaseTasks[p].length).fill(false);});
  const picEl=document.getElementById('f-pic');
  const pic=picEl?parseInt(picEl.value)||currentUser.id:currentUser.id;
  const wtEl=document.getElementById('f-worktype');
  const workType=wtEl?wtEl.value:'regular';
  const recEl=document.getElementById('f-recurrence');
  const recurrence=recEl?recEl.value:'';
  const customDaysEl=document.getElementById('f-custom-days');
  const customDays=customDaysEl?customDaysEl.value:'7';
  pendingCreationId=pendingCreationId||newRecordId();
  const record={id:pendingCreationId,title,
    desc:document.getElementById('f-desc').value.trim(),
    status:document.getElementById('f-status').value,
    phase:0,priority:document.getElementById('f-priority').value,
    assignees,pic,workType,recurrence,customDays,
    startDate:document.getElementById('f-start').value,
     deadline:document.getElementById('f-deadline').value,estimatedHours:Number(document.getElementById('f-effort').value||0),
    tags:document.getElementById('f-tags').value.split(',').map(t=>t.trim()).filter(Boolean),
    files:[],notes:[],phaseTasks,phaseChecks,createdAt:todayStr,createdBy:currentUser.id};
  const existing=works.findIndex(w=>w.id===record.id);if(existing>=0)works[existing]=record;else works.push(record);
  const newWork=record;if(!(await saveRequestsNow()))return;pendingCreationId=null;await linkActionToWork(record.id);showToast('Work created.','success');closeModal();navigate(newWork.status==='upcoming'?'upcoming':'ongoing');
}

async function saveEditWork(id){const w=works.find(x=>x.id===id);const title=document.getElementById('f-title').value.trim();if(!title){showToast('Title is required.','error');return;}const assignees=getSelectedMembers();if(!assignees.length){showToast('Assign at least one member.','error');return;}const phaseTasks={};PHASES.forEach(p=>{phaseTasks[p]=getPhaseTasks(p);});PHASES.forEach(p=>{const old=w.phaseChecks[p]||[];w.phaseChecks[p]=phaseTasks[p].map((_,i)=>old[i]||false);});w.title=title;w.desc=document.getElementById('f-desc').value.trim();w.status=document.getElementById('f-status').value;w.priority=document.getElementById('f-priority').value;w.startDate=document.getElementById('f-start').value;w.deadline=document.getElementById('f-deadline').value;w.estimatedHours=Number(document.getElementById('f-effort').value||0);w.tags=document.getElementById('f-tags').value.split(',').map(t=>t.trim()).filter(Boolean);const _wt2=document.getElementById('f-worktype');if(_wt2)w.workType=_wt2.value;w.pic=Number(document.getElementById('f-pic').value)||currentUser.id;w.recurrence=document.getElementById('f-recurrence').value;w.customDays=document.getElementById('f-custom-days').value||'7';w.assignees=assignees;w.phaseTasks=phaseTasks;const ok=await saveRequestsNow();if(!ok)return;showToast('Work updated!','success');closeModal();openWorkDetail(id);}

// ============================================================
document.addEventListener('click',event=>{document.querySelectorAll('details.footer-more[open]').forEach(menu=>{if(!menu.contains(event.target))menu.open=false;});});
document.addEventListener('keydown',event=>{if(event.key==='Escape')document.querySelectorAll('details.footer-more[open]').forEach(menu=>{menu.open=false;event.stopPropagation();});},true);
