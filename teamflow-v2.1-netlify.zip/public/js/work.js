// WORK ITEM HTML
// ============================================================
function workItemHtml(w){
  const prog=phaseProgress(w),isRR=w.status==='ongoing'&&w.phase===2,isOD=w.status!=='done'&&daysUntil(w.deadline)<0,isLate=w.status==='done'&&w.completedDate&&w.completedDate>w.deadline;
  const cls=isRR?'review-ready':isOD?'overdue':w.status==='done'?'completed':'';
  const phaseLabel=w.status==='done'?'Done':w.status==='upcoming'?'Upcoming':PHASES[w.phase];
  const badgeCls=w.status==='done'?'badge-done':w.status==='upcoming'?'badge-upcoming':`badge-${PHASES[w.phase].toLowerCase()}`;
  const creator=getMember(w.createdBy);
  const recurrenceLabel = w.recurrence ? RECURRENCE_OPTIONS.find(o=>o.value===w.recurrence)?.label : '';
  return`<div class="work-item ${cls}" role="button" tabindex="0" onclick="openWorkDetail(${Number(w.id)})">
    <div style="display:flex;align-items:flex-start;gap:12px;"><div style="flex:1;">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">
        <span class="badge ${badgeCls}">${phaseLabel}</span>`+workTypeBadge(w.workType||'regular')+`<span class="badge badge-priority-${w.priority.toLowerCase()}">${w.priority}</span>
        ${isRR?'<span class="badge" style="background:var(--yellow-dim);color:var(--yellow);">🔍 Review Ready</span>':''}
        ${isOD?'<span class="badge badge-overdue">⚠ Overdue</span>':''}
        ${isLate?'<span class="badge badge-overdue">⏰ Delivered Late</span>':''}
        ${(w.tags||[]).map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}
      </div>
      <div class="work-title">${escapeHtml(w.title)}</div>
    </div></div>
    <div style="margin-top:10px;"><div class="work-desc">${escapeHtml(w.desc)}</div>
      ${w.status!=='upcoming'?`<div style="margin-top:12px;"><div style="display:flex;justify-content:space-between;margin-bottom:4px;"><span style="font-size:11px;color:var(--text3);">Overall Progress</span><span style="font-size:11px;color:var(--text3);">${prog}%</span></div><div class="progress-bar"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div></div>`:''}
    </div>
    <div class="work-item-footer">
      ${assigneesHtml(w.assignees)}<div class="meta-item">📅 ${fmt(w.startDate)}</div><div class="meta-item">🏁 ${fmt(w.deadline)}</div>
      ${w.completedDate?`<div class="meta-item">✅ ${fmt(w.completedDate)}</div>`:''}
      ${deadlineChip(w.deadline,w.status)}
      ${w.files.length?`<div class="meta-item">📎 ${w.files.length} file${w.files.length>1?'s':''}</div>`:''}
      ${w.notes.length?`<div class="meta-item">💬 ${w.notes.length} note${w.notes.length>1?'s':''}</div>`:''}
      ${creator?`<div class="meta-item" style="margin-left:auto;font-size:11px;">by ${escapeHtml(creator.name)}</div>`:''}
    </div>
  </div>`;
}

function getReviewReady(){return works.filter(w=>w.status==='ongoing'&&w.phase===2);}
function getOverdue(){return works.filter(w=>w.status!=='done'&&daysUntil(w.deadline)<0);}
function applyFiltersAndSort(list){
  let r=[...list];
  if(currentFilters.workType)r=r.filter(w=>w.workType===currentFilters.workType);
  if(currentFilters.priority)r=r.filter(w=>w.priority===currentFilters.priority);
  if(currentFilters.phase!=='')r=r.filter(w=>w.phase===parseInt(currentFilters.phase));
  if(currentFilters.pic)r=r.filter(w=>String(w.pic)===String(currentFilters.pic));
  r.sort((a,b)=>{
    switch(currentSort){
      case'title_asc':return a.title.localeCompare(b.title);
      case'title_desc':return b.title.localeCompare(a.title);
      case'deadline_asc':return new Date(a.deadline||'9999')-new Date(b.deadline||'9999');
      case'deadline_desc':return new Date(b.deadline||'0')-new Date(a.deadline||'0');
      case'created_asc':return new Date(a.createdAt||'0')-new Date(b.createdAt||'0');
      case'created_desc':return new Date(b.createdAt||'0')-new Date(a.createdAt||'0');
      case'priority':{const p={High:0,Medium:1,Low:2};return(p[a.priority]||1)-(p[b.priority]||1);}
      default:return 0;
    }
  });
  return r;
}
function buildFilterBar(status){
  const mems=TEAM.filter(m=>m.role!=='admin'&&m.role!=='board');
  return`<div class="filter-bar">`
    +`<input class="search-input" type="text" placeholder="&#128269; Search..." oninput="_fSearch(this.value,'${status}')">`
    +`<select class="filter-select" onchange="currentFilters.workType=this.value;_fRefresh('${status}')">`
    +`<option value="">All Types</option>`
    +`${WORK_TYPES.map(t=>`<option value="${t.value}" ${currentFilters.workType===t.value?'selected':''}>${t.label}</option>`).join('')}`
    +`</select>`
    +`<select class="filter-select" onchange="currentFilters.priority=this.value;_fRefresh('${status}')">`
    +`<option value="">All Priorities</option>`
    +`${PRIORITIES.map(p=>`<option value="${p}" ${currentFilters.priority===p?'selected':''}>${p}</option>`).join('')}`
    +`</select>`
    +`${status==='ongoing'?`
      <select class="filter-select" onchange="currentFilters.phase=this.value;_fRefresh('${status}')">`
      +`<option value="">All Phases</option>`
      +`${PHASES.map((p,i)=>`<option value="${i}" ${currentFilters.phase===String(i)?'selected':''}>${p}</option>`).join('')}`
      +`</select>`:''}`
    +`<select class="filter-select" onchange="currentFilters.pic=this.value;_fRefresh('${status}')">`
    +`<option value="">All PICs</option>`
    +`${mems.map(m=>`<option value="${m.id}" ${currentFilters.pic===String(m.id)?'selected':''}>${escapeHtml(m.name)}</option>`).join('')}`
    +`</select>`
    +`<select class="filter-select" onchange="currentSort=this.value;_fRefresh('${status}')">`
    +`<option value="deadline_asc" ${currentSort==='deadline_asc'?'selected':''}>Deadline &#8593;</option>`
    +`<option value="deadline_desc" ${currentSort==='deadline_desc'?'selected':''}>Deadline &#8595;</option>`
    +`<option value="title_asc" ${currentSort==='title_asc'?'selected':''}>Title A-Z</option>`
    +`<option value="title_desc" ${currentSort==='title_desc'?'selected':''}>Title Z-A</option>`
    +`<option value="created_desc" ${currentSort==='created_desc'?'selected':''}>Newest</option>`
    +`<option value="created_asc" ${currentSort==='created_asc'?'selected':''}>Oldest</option>`
    +`<option value="priority" ${currentSort==='priority'?'selected':''}>Priority</option>`
    +`</select>`
    +`<button class="btn btn-ghost btn-sm" onclick="currentFilters={workType:'',priority:'',phase:'',pic:''};currentSort='deadline_asc';_fSq='';_fRefresh('${status}')">Reset</button>`
    +`</div>`;
}
let _fSq='';
function _fSearch(q,s){_fSq=q;_fRefresh(s);}
function _fRefresh(status){
  const el=document.getElementById('work-list');if(!el)return;
  let list=works.filter(w=>w.status===status);
  if(_fSq)list=list.filter(w=>w.title.toLowerCase().includes(_fSq.toLowerCase())||w.desc.toLowerCase().includes(_fSq.toLowerCase()));
  list=applyFiltersAndSort(list);
  el.innerHTML=list.length?list.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon">&#128269;</div><p>No results.</p></div>';
}
function renderOngoing(){
  _fSq='';
  const rr=getReviewReady();
  let html=buildFilterBar('ongoing');
  if(rr.length>0)html+=`<div class="review-banner"><div style="font-size:22px;">&#128269;</div><div style="flex:1;"><div class="review-banner-title">${rr.length} item${rr.length>1?'s':''} ready for review</div><div class="review-banner-sub">In Review phase</div></div></div>`;
  const _fl=applyFiltersAndSort(works.filter(w=>w.status==='ongoing'));
  html+=`<div id="work-list">${_fl.length?_fl.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon">&#128205;</div><p>No ongoing work.</p></div>'}</div>`;
  document.getElementById('content').innerHTML=html;
}

function renderUpcoming(){
  const list=works.filter(w=>w.status==='upcoming');
  const monthNames=['January','February','March','April','May','June','July','August','September','October','November','December'];
  const yearOptions=Array.from({length:11},(_,index)=>calendarYear-5+index);
  let html=`<div class="card schedule-card" style="margin-bottom:20px;">
    <div class="card-header">
      <div class="card-title">📅 Schedule</div>
      <div class="schedule-controls" style="display:flex;align-items:center;gap:8px;">
        <button class="btn btn-ghost btn-sm" aria-label="Previous month" onclick="changeCalMonth(-1)">◀</button>
        <select class="filter-select" onchange="setCalMonth(this.value)" style="min-width:120px;">
          ${monthNames.map((m,i)=>`<option value="${i}" ${i===calendarMonth?'selected':''}>${m}</option>`).join('')}
        </select>
        <select class="filter-select" onchange="setCalYear(this.value)" style="min-width:80px;">
          ${yearOptions.map(y=>`<option value="${y}" ${y===calendarYear?'selected':''}>${y}</option>`).join('')}
        </select>
        <button class="btn btn-ghost btn-sm" aria-label="Next month" onclick="changeCalMonth(1)">▶</button>
        <button class="btn btn-ghost btn-sm schedule-today" onclick="resetCalToday()">Today</button>

      </div>
    </div>
    ${renderCalendar(calendarYear,calendarMonth)}
    <div class="schedule-legend" style="display:flex;gap:16px;flex-wrap:wrap;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);">
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--primary-dim);border:1px solid var(--primary);"></div> Regular Start</div>
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--primary-dim);border:1px dashed var(--orange);"></div> Ad-hoc Start</div>
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--red-dim);border:1px solid var(--primary);"></div> Regular Deadline</div>
      <div style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text3);"><div style="width:10px;height:10px;border-radius:2px;background:var(--red-dim);border:1px dashed var(--orange);"></div> Ad-hoc Deadline</div>

    </div>
  </div>`;
  html+=`<div class="filter-bar">
    <input class="search-input" type="text" placeholder="🔍 Search..." oninput="filterWorks(this.value,'upcoming')">
    <select class="filter-select" onchange="filterByPriority(this.value,'upcoming')"><option value="">All Priorities</option>${PRIORITIES.map(p=>`<option value="${p}">${p}</option>`).join('')}</select>
  </div>`;
  html+=`<div id="work-list">${list.length?list.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon">📅</div><p>No upcoming work scheduled.</p></div>'}</div>`;
  document.getElementById('content').innerHTML=html;
}
function escapeHtml(value){return String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
function safeExternalHref(value){const url=String(value||'').trim();return ['http','https'].includes(TeamFlowDomain.fileLocationKind(url))?escapeHtml(url):'';}
function linkedFileHtml(file,workId,index,editable){const safeUrl=escapeHtml(file.url),safeHref=safeExternalHref(file.url),label=FILE_TYPES.find(type=>type.type===file.type)?.label||'Others';const action=TeamFlowDomain.fileLocationKind(file.url)==='path'?`<button class="file-link-open" onclick="copyPath(this)" data-path="${safeUrl}" title="Copy path to clipboard">📋 Copy Path</button>`:safeHref?`<a href="${safeHref}" target="_blank" rel="noopener noreferrer" class="file-link-open">Open ↗</a>`:'<span class="file-link-open">Link unavailable</span>';return`<div class="file-link-item"><span style="font-size:16px;">${escapeHtml(file.icon)}</span><div style="flex:1;min-width:0;"><div class="file-link-name">${escapeHtml(file.name)}</div><div class="file-link-url">${safeUrl}</div></div><span class="file-link-type">${escapeHtml(label)}</span>${action}${editable?`<button class="btn btn-danger btn-sm" onclick="removeFile(${Number(workId)},${Number(index)});event.stopPropagation();">✕</button>`:''}</div>`;}

function renderCapacity(){
  const range=TeamFlowDomain.weekRange(todayStr,capacityWeekOffset),totals=new Map(),allocations=new Map();
  TEAM.filter(member=>['member','manager'].includes(member.role)).forEach(member=>totals.set(String(member.id),0));
  works.filter(work=>work.status!=='done').forEach(work=>{
    const weekly=TeamFlowDomain.allocateEffortByWeek(work),hours=weekly[range.start]||0;
    const shares=TeamFlowDomain.allocateEffortByMember(work,TEAM,hours);
    allocations.set(work.id,shares);
    Object.entries(shares).forEach(([id,share])=>{if(totals.has(id))totals.set(id,totals.get(id)+share);});
  });
  const unscheduled=works.filter(work=>work.status!=='done'&&Number(work.estimatedHours)>0&&!Object.keys(TeamFlowDomain.allocateEffortByWeek(work)).length);
  const scheduleWarning=unscheduled.length?`<p role="status" style="font-size:12px;color:var(--yellow);">Choose dates that include a weekday to allocate capacity: ${unscheduled.map(work=>escapeHtml(work.title)).join(', ')}.</p>`:'';
  const members=TEAM.filter(member=>['member','manager'].includes(member.role));
  const overloaded=members.filter(member=>(totals.get(String(member.id))||0)>Number(member.weeklyCapacityHours??40)).length;
  const rows=members.map(member=>{
    const assigned=totals.get(String(member.id))||0,capacity=Number(member.weeklyCapacityHours??40),percent=capacity?Math.round(assigned/capacity*100):(assigned?100:0),over=assigned>capacity;
    const pieces=works.filter(work=>(allocations.get(work.id)?.[String(member.id)]||0)>0);
    return`<div class="capacity-row" style="padding:14px 0;border-bottom:1px solid var(--border);"><div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">${avatarHtml(member,34)}<strong style="flex:1;min-width:0;">${escapeHtml(member.name)}</strong><span style="font-size:12px;font-weight:700;color:${over?'var(--red)':'var(--text2)'};">${assigned.toFixed(1)} / ${capacity} h${over?' · Over capacity':''}</span></div><div class="perf-bar" style="height:10px;"><div class="perf-bar-fill" style="width:${Math.min(100,percent)}%;background:${over?'var(--red)':'var(--primary)'};"></div></div><div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;">${pieces.map(work=>`<span class="tag">${escapeHtml(work.title)} · ${allocations.get(work.id)[String(member.id)].toFixed(1)}h${String(work.pic)===String(member.id)?' · PIC':member.role==='manager'?' · Reviewer':''}</span>`).join('')||'<span style="font-size:11px;color:var(--text3);">No estimated work this week</span>'}</div></div>`;
  }).join('');
  document.getElementById('content').innerHTML=`<div class="section-header"><div><div class="section-title">Weekly Capacity</div><div class="section-sub">Planned effort estimates compared with each member’s weekly capacity.</div></div></div><div class="card" style="margin-bottom:14px;"><div class="card-header"><button class="btn btn-ghost btn-sm" aria-label="Previous week" onclick="shiftCapacityWeek(-1)">◀</button><div style="text-align:center;flex:1;"><strong>${TeamFlowDomain.formatRange(range)}</strong><div style="font-size:11px;color:var(--text3);">${overloaded} member${overloaded===1?'':'s'} over capacity</div></div><button class="btn btn-ghost btn-sm" aria-label="Next week" onclick="shiftCapacityWeek(1)">▶</button></div>${scheduleWarning}${rows||'<div class="empty-state"><p>No team members yet.</p></div>'}</div>`;
}
function shiftCapacityWeek(direction){capacityWeekOffset+=direction;renderCapacity();}

function openDailyNotifications(){
  navigate('daily-digest');
  const section=document.getElementById('daily-notifications');
  if(section)section.scrollIntoView({block:'start'});
}
async function renderNotifications(refresh=true){
  const content=document.getElementById('daily-notifications');
  if(!content)return;
  if(refresh){
    renderNotifications(false);
    const marker=beginPageRefresh(content),generation=editGeneration,userId=currentUser.id;
    try{
      const latest=await fetchNotifications();
      if(marker.isConnected&&document.getElementById('daily-notifications')===content&&currentUser?.id===userId&&generation===editGeneration&&!draftActive&&!hasPendingChanges){
        notificationData=latest;renderNotifications(false);
      }
    }catch(error){if(marker.isConnected){marker.textContent='Refresh failed — showing previous reminders.';return;}}
    finally{if(marker.textContent==='Updating…')marker.remove();}
    return;
  }
  const data=notificationData;
  const reminders=data.preferences?.reminderDays||[3,0];
  const rows=data.notifications.map(item=>{
    const status=item.days<0?`${Math.abs(item.days)} day${Math.abs(item.days)===1?'':'s'} overdue`:item.days===0?'Due today':`Due in ${item.days} day${item.days===1?'':'s'}`;
    return`<button class="digest-row" style="width:100%;text-align:left;${item.read?'opacity:.68;':''}" onclick="openNotification('${escapeHtml(item.id)}',${Number(item.workId)})"><span class="badge ${item.kind==='overdue'?'badge-overdue':item.kind==='due-today'?'badge-priority-high':'badge-upcoming'}">${status}</span><span style="flex:1;min-width:0;overflow-wrap:anywhere;">${escapeHtml(item.title)}</span><span style="font-size:12px;color:var(--text3);">${fmt(item.deadline)}</span></button>`;
  }).join('');
  content.innerHTML=`<div class="section-header"><div><div class="section-title">🔔 Notifications</div></div>${data.notifications.some(item=>!item.read)?'<button class="btn btn-ghost btn-sm" onclick="markAllNotificationsRead()">Mark all read</button>':''}</div><div class="card" style="margin-bottom:14px;"><div class="card-header"><div class="card-title">Reminder timing</div></div><div class="reminder-options" style="display:flex;flex-wrap:wrap;gap:12px;">${[[0,'Due today'],[1,'1 day before'],[3,'3 days before'],[7,'7 days before']].map(([day,label])=>`<label style="display:flex;align-items:center;gap:6px;"><input type="checkbox" value="${day}" ${reminders.includes(day)?'checked':''} style="width:auto;">${label}</label>`).join('')}<button class="btn btn-primary btn-sm" onclick="saveReminderPreferences()">Save preferences</button></div></div><div class="card"><div class="card-header"><div class="card-title">Notifications (${data.notifications.length})</div></div>${rows||'<div class="empty-state"><div class="icon">🎉</div><p>No due reminders right now.</p></div>'}</div>`;
}
let reminderSaveBusy=false;
async function saveReminderPreferences(){
  if(reminderSaveBusy)return;
  reminderSaveBusy=true;
  const finishButton=setButtonBusy(document.activeElement),generation=++editGeneration,userId=currentUser.id;
  const reminderDays=[...document.querySelectorAll('.reminder-options input:checked')].map(input=>Number(input.value));
  setSaveIndicator('saving');
  try{
    const result=await sendJson('notifications',{operation:'preferences',reminderDays});
    if(currentUser?.id!==userId)return;
    if(result.member){const idx=TEAM.findIndex(member=>String(member.id)===String(result.member.id));if(idx>=0)TEAM[idx]=result.member;currentUser=result.member;remoteState.team=remoteState.team.map(member=>String(member.id)===String(result.member.id)?cloneValue(result.member):member);}
    notificationsRequest=null;
    notificationData.preferences={...notificationData.preferences,reminderDays};
    if(generation===editGeneration){draftActive=false;setSaveIndicator('saved');renderNotifications();}
    else setSaveIndicator('pending');
    showToast('Reminder preferences saved.','success');updateBadges();
  }
  catch(error){setSaveIndicator('error');showToast(error.message||'Could not save reminder preferences.','error');}
  finally{reminderSaveBusy=false;finishButton();}
}
async function openNotification(id,workId){
  openWorkDetail(workId);
  try{await sendJson('notifications',{operation:'read',ids:[id]});}
  catch(error){showToast(error.message||'Could not update reminder.','error');}
  notificationsRequest=null;updateBadges();
}
async function markAllNotificationsRead(){
  const finishButton=setButtonBusy(document.activeElement);
  try{await sendJson('notifications',{operation:'read',ids:(notificationData.notifications||[]).map(item=>item.id)});notificationsRequest=null;renderNotifications();updateBadges();}
  catch(error){showToast(error.message||'Could not update reminders.','error');}
  finally{finishButton();}
}
function changeCalMonth(dir){
  calendarMonth+=dir;
  if(calendarMonth>11){calendarMonth=0;calendarYear++;}
  if(calendarMonth<0){calendarMonth=11;calendarYear--;}
  renderUpcoming();
}
function setCalMonth(m){calendarMonth=parseInt(m);renderUpcoming();}
function setCalYear(y){calendarYear=parseInt(y);renderUpcoming();}
function resetCalToday(){calendarMonth=new Date().getMonth();calendarYear=new Date().getFullYear();renderUpcoming();}

function renderHistory(){
  _fSq='';
  const list=works.filter(w=>w.status==='done');
  const onTime=list.filter(w=>w.completedDate&&w.completedDate<=w.deadline);
  const late=list.filter(w=>w.completedDate&&w.completedDate>w.deadline);
  let html=buildFilterBar('done');
  html+=`<div class="grid-3" style="margin-bottom:20px;">`
    +`<div class="stat-card"><div class="stat-label">Total Completed</div><div class="stat-value" style="color:var(--green);">${list.length}</div></div>`
    +`<div class="stat-card"><div class="stat-label">On Time</div><div class="stat-value" style="color:var(--green);">${onTime.length}</div><div class="stat-sub">${list.length?Math.round(onTime.length/list.length*100):0}% success rate</div></div>`
    +`<div class="stat-card"><div class="stat-label">Over Deadline</div><div class="stat-value" style="color:${late.length>0?'var(--red)':'var(--green)'};">  ${late.length}</div></div></div>`;
  const _fd=applyFiltersAndSort(works.filter(w=>w.status==='done'));
  html+=`<div id="work-list">${_fd.length?_fd.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon">&#128193;</div><p>No completed work yet.</p></div>'}</div>`;
  document.getElementById('content').innerHTML=html;
}

function renderCalendar(year,month){
  const fd=(new Date(year,month,1).getDay()+6)%7,dim=new Date(year,month+1,0).getDate(),dn=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  let html=`<div class="cal-grid">${dn.map(d=>`<div class="cal-header">${d}</div>`).join('')}`;
  for(let i=0;i<fd;i++)html+=`<div class="cal-day other-month"></div>`;
  for(let d=1;d<=dim;d++){
    const ds=`${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,isToday=ds===todayStr;
    const dw=works.filter(w=>w.startDate===ds||w.deadline===ds);
    const scheduled=works.filter(w=>w.startDate===ds||w.deadline===ds||(w.status!=='done'&&w.startDate&&w.startDate<=ds&&(!w.deadline||w.deadline>=ds)));
    html+=`<div class="cal-day ${isToday?'today':''}" role="button" tabindex="0" aria-label="${ds}, ${scheduled.length} scheduled work items" onclick="showDayEvents('${ds}')">`;
    html+=`<div class="cal-day-num" style="${isToday?'color:var(--primary);font-weight:800;':''}">${d}</div>`;
    // Show max 2 events
    dw.slice(0,2).forEach(w=>{
      const isDl=w.deadline===ds;
      const isAd=w.workType==='adHoc';
      const bg=isDl?'var(--red-dim)':'var(--primary-dim)';
      const fg=isDl?'var(--red)':'var(--primary)';
      const bdr=isAd?'1px dashed var(--orange)':'1px solid var(--primary)';
      html+=`<div class="cal-event" style="background:${bg};color:${fg};border:${bdr};" title="${escapeHtml(w.title)}${isAd?' [Ad-hoc]':''}">${isDl?'🏁':'▶'} ${escapeHtml(w.title.substring(0,11))}${w.title.length>11?'…':''}</div>`;
    });
    // Show "+N more" if there are more events
    if(dw.length>2){
      html+=`<div class="cal-event" style="background:var(--bg4);color:var(--text3);font-weight:700;text-align:center;">+${dw.length-2} more</div>`;
    }
    html+=`</div>`;
  }
  return html+`</div>`;
}

function showDayEvents(dateStr){
  const starting=works.filter(w=>w.startDate===dateStr);
  const deadlines=works.filter(w=>w.deadline===dateStr);
  const active=works.filter(w=>{
    if(w.status==='done')return false;
    return Boolean(w.startDate&&w.startDate<=dateStr&&(!w.deadline||w.deadline>=dateStr)&&w.startDate!==dateStr&&w.deadline!==dateStr);
  });
  const d=TeamFlowDomain.parseDateKey(dateStr);
  document.getElementById('modal-title').innerHTML='&#128197; '+d.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric',timeZone:'UTC'});
  function wCard(w,isS,isDl){
    const prog=phaseProgress(w),pic=getMember(w.pic||w.createdBy||0);
    const wtB=workTypeBadge(w.workType||'regular');
    return`<div class="work-item" role="button" tabindex="0" style="margin-bottom:0;cursor:pointer;" onclick="closeModal();openWorkDetail(${Number(w.id)})">`
      +`<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">`
      +`${isS?'<span class="badge badge-executing">&#9654; Start</span>':''}`
      +`${isDl?'<span class="badge badge-overdue">&#127937; Deadline</span>':''}`
      +`<span class="badge badge-${w.status==='done'?'done':w.status==='upcoming'?'upcoming':PHASES[w.phase].toLowerCase()}">${w.status==='done'?'Completed':w.status==='upcoming'?'Upcoming':PHASES[w.phase]}</span>`
      +`${wtB}<span class="badge badge-priority-${w.priority.toLowerCase()}">${w.priority}</span></div>`
      +`<div style="font-size:14px;font-weight:700;margin-bottom:6px;">${escapeHtml(w.title)}</div>`
      +`${w.status!=='upcoming'?`<div class="progress-bar" style="margin-bottom:6px;"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div>`:''}`
      +`<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">`
      +`${assigneesHtml(w.assignees)}`
      +`${pic?`<div class="meta-item">&#128100; ${escapeHtml(pic.name)}</div>`:''}`
      +`<span class="meta-item">&#127937; ${fmt(w.deadline)}</span>`
      +`${deadlineChip(w.deadline,w.status)}`
      +`${w.status!=='upcoming'?`<span style="font-size:11px;color:var(--text3);">${prog}%</span>`:''}`
      +`</div></div>`;
  }
  let body='';
  if(starting.length){
    body+=`<div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--primary);margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid var(--primary-dim);">&#9654; Starting Today (${starting.length})</div>`;
    body+=`<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;">${starting.map(w=>wCard(w,true,false)).join('')}</div>`;
  }
  if(deadlines.length){
    body+=`<div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--red);margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid var(--red-dim);">&#127937; Deadlines Today (${deadlines.length})</div>`;
    body+=`<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;">${deadlines.map(w=>wCard(w,false,true)).join('')}</div>`;
  }
  if(active.length){
    body+=`<div style="font-size:12px;font-weight:700;text-transform:uppercase;color:var(--green);margin-bottom:8px;padding-bottom:4px;border-bottom:2px solid var(--green-dim);">&#128260; Active Work (${active.length})</div>`;
    body+=`<div style="display:flex;flex-direction:column;gap:8px;">${active.map(w=>wCard(w,false,false)).join('')}</div>`;
  }
  document.getElementById('modal-body').innerHTML=body||'<div class="empty-state"><p>No work scheduled for this date.</p></div>';
  document.getElementById('modal-footer').innerHTML=`<button class="btn btn-ghost" onclick="closeModal()">Close</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}
function filterWorks(q,status){const el=document.getElementById('work-list');if(!el)return;const f=works.filter(w=>w.status===status&&(w.title.toLowerCase().includes(q.toLowerCase())||w.desc.toLowerCase().includes(q.toLowerCase())));el.innerHTML=f.length?f.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon">🔍</div><p>No results found.</p></div>';}
function filterByPhase(phase){const el=document.getElementById('work-list');if(!el)return;const f=works.filter(w=>w.status==='ongoing'&&(phase===''||w.phase===parseInt(phase)));el.innerHTML=f.length?f.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon">🔍</div><p>No results found.</p></div>';}
function filterByPriority(priority,status){const el=document.getElementById('work-list');if(!el)return;const f=works.filter(w=>w.status===status&&(priority===''||w.priority===priority));el.innerHTML=f.length?f.map(w=>workItemHtml(w)).join(''):'<div class="empty-state"><div class="icon">🔍</div><p>No results found.</p></div>';}

// ============================================================
// WORK DETAIL MODAL
// ============================================================
async function openWorkDetail(id){
  // Show modal immediately with cached data (no delay)
  const w=works.find(x=>x.id===id);if(!w)return;
  const body=document.getElementById('modal-body');
  const sameWork=body.dataset.detailWorkId===String(id)&&Boolean(document.getElementById(`activity-history-${id}`));
  const noteDraft=sameWork?document.getElementById('new-note-text')?.value||'':'';
  const scroll=sameWork?body.scrollTop:0;
  const historyOpen=sameWork&&document.getElementById(`activity-history-${id}`)?.open;
  body.dataset.detailWorkId=String(id);
  const editable=canEdit(w),prog=phaseProgress(w);
  const pic=getMember(w.pic||w.createdBy||0);
  document.getElementById('modal-title').textContent=w.title;
  let phaseHtml=`<div class="phase-track">`;
  PHASES.forEach((p,i)=>{const isDone=i<w.phase||w.status==='done',isActive=i===w.phase&&w.status==='ongoing';phaseHtml+=`<div class="phase-step"><div class="phase-step-inner"><div class="phase-dot ${isDone?'done':isActive?'active':'pending'}">${isDone?'✓':i+1}</div><div class="phase-label ${isDone?'done':isActive?'active':''}">${p}</div></div></div>`;if(i<PHASES.length-1)phaseHtml+=`<div class="phase-line ${isDone?'done':isActive?'active':''}"></div>`;});
  phaseHtml+=`</div>`;
  let pdHtml=`<div class="phase-detail-grid">`;
  PHASES.forEach((p,i)=>{const isDone=i<w.phase||w.status==='done',isActive=i===w.phase&&w.status==='ongoing',tasks=w.phaseTasks[p]||[],checks=w.phaseChecks[p]||[],doneCount=checks.filter(Boolean).length;pdHtml+=`<div class="phase-card ${isActive?'active-phase':isDone?'done-phase':''}"><div class="phase-card-title" style="color:${isDone?'var(--green)':isActive?'var(--primary-light)':'var(--text2)'};">${isDone?'✅':isActive?'🔵':'⬜'} ${p}</div><div style="font-size:11px;color:var(--text3);margin-bottom:6px;">${doneCount}/${tasks.length} tasks</div><ul class="phase-card-items">${tasks.map((item,idx)=>{const checked=checks[idx]||false,canCheck=editable&&(isActive||isDone);return`<li style="${checked?'text-decoration:line-through;color:var(--text3);':''}" ${canCheck?`role="checkbox" aria-checked="${checked}" tabindex="0" onclick="togglePhaseCheck(${id},'${p}',${idx})"`:''}>${checked?'✓ ':''}${escapeHtml(item)}</li>`;}).join('')}</ul></div>`;});
  pdHtml+=`</div>`;
  let aHtml=`<div style="display:flex;flex-wrap:wrap;gap:8px;">`;w.assignees.forEach(aid=>{const m=getMember(aid);if(m)aHtml+=`<div style="display:flex;align-items:center;gap:6px;padding:5px 10px;background:var(--bg3);border-radius:20px;font-size:12px;">${avatarHtml(m,22)} ${escapeHtml(m.name)} ${roleBadge(m.role)}</div>`;});aHtml+=`</div>`;
  let fHtml=w.files.length?w.files.map((f,fi)=>linkedFileHtml(f,id,fi,editable)).join(''):`<div style="font-size:13px;color:var(--text3);">No files linked yet.</div>`;
  let nHtml=w.notes.length
    ?w.notes.map((n,ni)=>{
      const aName=n.authorName||n.author||'Unknown';
      const dStr=fmt(n.createdDate||n.date);
      const eStr=n.editedDate?` &middot; <span style="font-size:10px;color:var(--text3);">Edited ${fmt(n.editedDate)}</span>`:'';
      const canEN=currentUser.role==='admin'||(n.authorId&&n.authorId===currentUser.id)||(aName===currentUser.name&&!n.authorId);
      const eBtn=canEN?`<button class="btn btn-ghost btn-sm" style="margin-left:auto;font-size:10px;padding:2px 6px;" onclick="editNote(${w.id},${ni})">&#9999; Edit</button>`:'';
      return`<div class="note-item" id="note-item-${w.id}-${ni}">`
        +`<div class="note-meta" style="display:flex;align-items:center;"><span>Created by ${escapeHtml(aName)} &middot; ${dStr}${eStr}</span>${eBtn}</div>`
        +`<div class="note-text" style="white-space:pre-wrap;">${escapeHtml(n.text)}</div></div>`;
    }).join('')
    :`<div style="font-size:13px;color:var(--text3);">No notes yet.</div>`;
  document.getElementById('modal-body').innerHTML=`
  <div class="detail-section"><div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;">`+workTypeBadge(w.workType||'regular')+`<span class="badge badge-priority-${w.priority.toLowerCase()}">${escapeHtml(w.priority)} Priority</span>${(w.tags||[]).map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}${deadlineChip(w.deadline,w.status)}</div><div style="font-size:13px;color:var(--text2);line-height:1.7;margin-bottom:12px;white-space:pre-wrap;">${escapeHtml(w.desc)}</div><div style="display:flex;gap:20px;flex-wrap:wrap;"><div class="meta-item">▶ Start: <strong>${fmt(w.startDate)}</strong></div><div class="meta-item">🏁 Deadline: <strong>${fmt(w.deadline)}</strong></div><div class="meta-item">⏱ Estimate: <strong>${Number(w.estimatedHours||0)} h</strong></div>${w.completedDate?`<div class="meta-item">✅ Completed: <strong>${fmt(w.completedDate)}</strong></div>`:''}</div></div>
  <div class="detail-section"><div class="detail-section-title">Phase Progress</div>${phaseHtml}<div style="margin:10px 0 4px;display:flex;justify-content:space-between;"><span style="font-size:12px;color:var(--text3);">Overall</span><span style="font-size:12px;color:var(--text3);">${prog}%</span></div><div class="progress-bar" style="height:8px;"><div class="progress-fill ${prog>=100?'green':prog>=60?'':prog>=30?'yellow':'red'}" style="width:${prog}%"></div></div><div style="font-size:11px;color:var(--text3);margin-top:4px;">Click tasks in active/done phases to check them off</div>${pdHtml}</div>
  <div class="work-save-status" role="status" style="font-size:12px;color:var(--text3);min-height:18px;margin-bottom:12px;">${hasPendingChanges?'Saving…':''}</div>
  <div class="detail-section"><div class="detail-section-title">Team Members</div>${aHtml}
    <div style="margin-top:10px;display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--primary-dim);border-radius:var(--radius-sm);border:1px solid rgba(59,111,212,0.2);">
      <span style="font-size:12px;font-weight:700;color:var(--primary);">👤 PIC:</span>
      ${pic?`${avatarHtml(pic,24)}<span style="font-size:13px;font-weight:600;">${escapeHtml(pic.name)}</span><span style="font-size:11px;color:var(--text3);">(Person in Charge)</span>`:'<span style="font-size:12px;color:var(--text3);">Not assigned</span>'}
    </div>
  </div>
  <div class="detail-section"><div class="detail-section-title">📎 Linked Files & Folders</div><div id="files-list-${id}">${fHtml}</div>${editable?`<button class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="openAddFile(${id})">+ Add File / Folder Link</button>`:''}</div>
  <div class="detail-section"><div class="detail-section-title">💬 Notes & Updates</div><div id="notes-list-${id}">${nHtml}</div>${editable?`<div style="margin-top:10px;"><textarea id="new-note-text" placeholder="Add a note or update..." style="margin-bottom:8px;"></textarea><button class="btn btn-primary btn-sm" onclick="addNote(${id})">Add Note</button></div>`:''}</div>
  <details class="detail-section activity-history" id="activity-history-${id}" ontoggle="if(this.open)loadWorkActivity(${id})"><summary class="detail-section-title">🧾 Activity History</summary><div id="activity-list-${id}" style="font-size:12px;color:var(--text3);">Loading history…</div></details>`;
  let footer='';
  // Join/Leave buttons for members (not done work)
  if(w.status!=='done'){
    const isAssigned=w.assignees.includes(currentUser.id);
    const isPic=w.pic===currentUser.id;
    const hasPendingJoin=joinRequests.find(r=>r.workId===id&&r.userId===currentUser.id&&r.type==='join'&&r.status==='pending');
    const hasPendingLeave=joinRequests.find(r=>r.workId===id&&r.userId===currentUser.id&&r.type==='leave'&&r.status==='pending');
    if(!isAssigned&&currentUser.role==='member'&&!hasPendingJoin){
      footer+=`<button class=\"btn btn-ghost\" onclick=\"requestJoin(${id})\" style=\"border-color:var(--primary);color:var(--primary);\">&#128587; Request to Join</button>`;
    }
    if(hasPendingJoin)footer+=`<span style=\"font-size:12px;color:var(--text3);padding:8px;\">&#9203; Join request pending...</span>`;
    if(isAssigned&&!isPic&&currentUser.role==='member'&&!hasPendingLeave){
      footer+=`<button class=\"btn btn-ghost\" onclick=\"requestLeave(${id})\" style=\"border-color:var(--red);color:var(--red);\">&#128682; Request to Leave</button>`;
    }
    if(hasPendingLeave)footer+=`<span style=\"font-size:12px;color:var(--text3);padding:8px;\">&#9203; Leave request pending...</span>`;
  }
  // Action buttons for editors
  if(canEdit(w)&&(w.status!=='done'||currentUser.role==='admin')){
    if(currentUser.role==='admin'&&w.status==='done'){
      // Admin on completed work: Reopen + Edit
      footer+=`<button class=\"btn btn-ghost\" onclick=\"reopenWork(${id})\" style=\"border-color:var(--yellow);color:var(--yellow);\">&#8617; Reopen Work</button>`;
      footer+=`<button class=\"btn btn-ghost\" onclick=\"openEditNameDesc(${id})\">&#9999; Edit Name/Desc</button>`;
    } else if(w.status==='upcoming'){
      footer+=`<button class=\"btn btn-primary\" onclick=\"startWork(${id})\">&#9654; Start Work</button>`;
      footer+=`<button class=\"btn btn-ghost\" onclick=\"openEditWork(${id})\">&#9999; Edit</button>`;
    } else {
      // Ongoing work: Back + Advance/Complete + Edit
      if(w.phase>0)footer+=`<button class=\"btn btn-ghost\" onclick=\"movePhaseBack(${id})\" style=\"border-color:var(--yellow);color:var(--yellow);\">&#8592; Back to ${PHASES[w.phase-1]}</button>`;
      if(w.phase<PHASES.length-1)footer+=`<button class=\"btn btn-primary\" onclick=\"advancePhase(${id})\">&#8594; Advance to ${PHASES[w.phase+1]}</button>`;
      if(w.phase===PHASES.length-1)footer+=`<button class=\"btn btn-success\" onclick=\"completeWork(${id})\">&#9989; Mark Complete</button>`;
      footer+=`<button class=\"btn btn-ghost\" onclick=\"openEditWork(${id})\">&#9999; Edit</button>`;
    }
  }
  if(currentUser.role==='admin'||currentUser.role==='manager')footer+=`<button class=\"btn btn-danger\" onclick=\"deleteWork(${id})\">&#128465; Delete</button>`;
  footer+=`<button class=\"btn btn-ghost\" onclick=\"closeModal()\">Close</button>`;
  document.getElementById('modal-footer').innerHTML=footer;
  document.getElementById('modal-overlay').style.display='flex';
  const noteInput=document.getElementById('new-note-text');
  if(noteInput)noteInput.value=noteDraft;
  body.scrollTop=scroll;
  if(historyOpen){document.getElementById(`activity-history-${id}`).open=true;loadWorkActivity(id);}
  if(!syncInFlight&&!draftActive&&!hasPendingChanges)backgroundSync();
}
async function loadWorkActivity(workId){
  const target=document.getElementById(`activity-list-${workId}`);if(!target)return;
  if(target.dataset.loading==='true'||target.dataset.loaded==='true')return;
  target.dataset.loading='true';
  try{
    const entries=await apiGet(`activity?workId=${encodeURIComponent(workId)}`);
    if(document.getElementById(`activity-list-${workId}`)!==target)return;
    target.innerHTML=entries.length?entries.map(entry=>`<div style="padding:8px 0;border-bottom:1px solid var(--border);"><div><strong>${escapeHtml(entry.actorName)}</strong> ${escapeHtml(entry.action)} this work</div><div style="color:var(--text3);margin:3px 0;">${new Date(entry.createdAt).toLocaleString()}</div><div>${Object.entries(entry.changedFields||{}).map(([field,change])=>`<span class="tag">${escapeHtml(field)}</span>`).join(' ')||'Record created'}</div></div>`).join(''):'<span>No changes recorded yet.</span>';
    target.dataset.loaded='true';
  }catch{target.textContent='Activity history is not available. Close and expand this section to retry.';}
  finally{delete target.dataset.loading;}
}
function togglePhaseCheck(workId,phase,idx){
  const w=works.find(x=>x.id===workId);if(!w||!canEdit(w))return;
  if(document.querySelector('#modal-body [id^="en-"]')){showToast('Finish editing the note before changing tasks.','info');return;}
  const phaseIndex=PHASES.indexOf(phase),tasks=w.phaseTasks[phase]||[];
  if(!Number.isInteger(idx)||idx<0||idx>=tasks.length||!(phaseIndex<w.phase||w.status==='done'||phaseIndex===w.phase&&w.status==='ongoing'))return;
  if(!w.phaseChecks[phase])w.phaseChecks[phase]=[];
  w.phaseChecks[phase][idx]=!w.phaseChecks[phase][idx];
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  scheduleSave(true);openWorkDetail(workId);
  const task=document.querySelectorAll('.phase-card')[phaseIndex]?.querySelectorAll('li')[idx];
  task?.focus({preventScroll:true});
}
let pendingNote=null;
async function addNote(workId){if(!hasPendingChanges)pendingNote=null;const w=works.find(x=>x.id===workId);const text=document.getElementById('new-note-text').value.trim();if(!text){showToast('Please enter a note.','error');return;}const note={authorId:currentUser.id,authorName:currentUser.name,text,createdDate:todayStr,editedDate:null};if(pendingNote?.workId===workId)w.notes[pendingNote.index]=note;else{pendingNote={workId,index:w.notes.length};w.notes.push(note);}
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  if(!(await saveRequestsNow()))return;
  pendingNote=null;showToast('Note added!','success');
  const notesEl=document.getElementById('notes-list-'+workId);
  if(notesEl){notesEl.innerHTML=w.notes.map((n,ni)=>{
    const aName=n.authorName||n.author||'Unknown';
    const dStr=fmt(n.createdDate||n.date);
    const canEN=currentUser.role==='admin'||(n.authorId&&n.authorId===currentUser.id)||(aName===currentUser.name&&!n.authorId);
    const eBtn=canEN?`<button class="btn btn-ghost btn-sm" style="margin-left:auto;font-size:10px;padding:2px 6px;" onclick="editNote(${w.id},${ni})">&#9999; Edit</button>`:'';
    return`<div class="note-item"><div class="note-meta" style="display:flex;align-items:center;"><span>Created by ${escapeHtml(aName)} &middot; ${dStr}</span>${eBtn}</div><div class="note-text" style="white-space:pre-wrap;">${escapeHtml(n.text)}</div></div>`;
  }).join('');}
  pendingNote=null;const ta=document.getElementById('new-note-text');if(ta)ta.value='';
}
async function removeFile(workId,fi){const w=works.find(x=>x.id===workId);w.files.splice(fi,1);
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  if(!(await saveRequestsNow()))return;
  showToast('File removed.','info');
  const filesEl2=document.getElementById('files-list-'+workId);
  if(filesEl2){const editable=canEdit(w);filesEl2.innerHTML=w.files.length?w.files.map((f,fi2)=>linkedFileHtml(f,workId,fi2,editable)).join(''):'<div style="font-size:13px;color:var(--text3);">No files linked yet.</div>';}
}
async function completeWork(id){
  if(hasPendingChanges){showToast('Save your pending edits before completing work.','error');return;}
  const current=remoteState.works.find(work=>work.id===id);if(!current)return;
  try{
    const result=await sendJson('works',{operation:'complete',id,expectedVersion:current.version});
    works=works.map(work=>work.id===id?result.work:work);remoteState.works=remoteState.works.map(work=>work.id===id?cloneValue(result.work):work);
    if(result.nextWork&&!works.some(work=>work.id===result.nextWork.id)){works.push(result.nextWork);remoteState.works.push(cloneValue(result.nextWork));}
    showToast('Work completed.','success');closeModal();navigate(currentPage);
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.message,'error');}
}
async function advancePhase(id){
  const w=works.find(x=>x.id===id);
  if(w.phase<PHASES.length-1){
    // Auto-complete all tasks in current phase
    const curPhase=PHASES[w.phase];
    if(w.phaseChecks[curPhase]){
      w.phaseChecks[curPhase]=w.phaseChecks[curPhase].map(()=>true);
    }
    w.phase++;
    if(!(await saveRequestsNow()))return;
    showToast('Advanced to '+PHASES[w.phase]+'! Previous phase tasks auto-completed ✅','success');
    closeModal();openWorkDetail(id);
  }
}
async function movePhaseBack(id){
  const w=works.find(x=>x.id===id);
  if(!w||w.phase<=0){showToast('Already at the first phase.','info');return;}
  const oldP=PHASES[w.phase],newP=PHASES[w.phase-1];
  if(!confirm('Move back from '+oldP+' to '+newP+'? Checklist progress will be preserved.'))return;
  w.phase--;
  w.notes.push({authorId:currentUser.id,authorName:currentUser.name,text:'Phase moved back from '+oldP+' to '+newP+' by '+currentUser.name,createdDate:todayStr,editedDate:null});
  if(!(await saveRequestsNow()))return;
  showToast('Moved back to '+newP+'.','info');
  openWorkDetail(id);
}
async function reopenWork(id){
  if(currentUser.role!=='admin'){showToast('Only admin can reopen completed work.','error');return;}
  const w=works.find(x=>x.id===id);
  if(!w)return;
  if(!confirm('Reopen this completed work and set it back to Finalize phase?'))return;
  w.status='ongoing';
  w.phase=PHASES.length-1;
  w.completedDate=null;
  w.notes.push({authorId:currentUser.id,authorName:currentUser.name,text:'Work reopened by '+currentUser.name,createdDate:todayStr,editedDate:null});
  if(!(await saveRequestsNow()))return;
  showToast('Work reopened!','success');
  closeModal();
  navigate('ongoing');
}
async function startWork(id){const w=works.find(x=>x.id===id);w.status='ongoing';w.phase=0;if(!(await saveRequestsNow()))return;showToast('Work started!','success');closeModal();navigate(currentPage);}

async function deleteWork(id){if(!confirm('Delete this work item?'))return;works=works.filter(x=>x.id!==id);if(!(await saveRequestsNow()))return;showToast('Work deleted.','info');closeModal();navigate(currentPage);}

// ============================================================
// ADD FILE
// ============================================================
function openAddFile(workId){document.getElementById('modal-body').dataset.detailWorkId=String(workId);document.getElementById('modal-title').textContent='Add File / Folder Link';document.getElementById('modal-body').innerHTML=`<div class="form-group"><label class="form-label">Name *</label><input id="file-name" type="text" placeholder="e.g. Working Files"></div><div class="form-group"><label class="form-label">URL / Path *</label><input id="file-url" type="text" placeholder="http://dashboard/... or https://... or //fileserver/folder/..."><div class="form-hint">Accepts HTTP/HTTPS links, Windows drive paths and network paths. Windows paths use Copy Path; paste into File Explorer. Drive letters must be mapped on each PC.</div></div><div class="form-group"><label class="form-label">Type</label><select id="file-type">${FILE_TYPES.map(t=>`<option value="${t.type}">${t.icon} ${t.label}</option>`).join('')}</select></div>`;document.getElementById('modal-footer').innerHTML=`<button class="btn btn-primary" onclick="saveFile(${workId})">Add Link</button><button class="btn btn-ghost" onclick="openWorkDetail(${workId})">Cancel</button>`;}
let pendingFile=null;
async function saveFile(workId){if(!hasPendingChanges)pendingFile=null;const w=works.find(x=>x.id===workId);const name=document.getElementById('file-name').value.trim(),url=document.getElementById('file-url').value.trim(),type=document.getElementById('file-type').value;if(!name||!url){showToast('Please fill in all fields.','error');return;}if(!TeamFlowDomain.fileLocationKind(url)){showToast('Enter an HTTP or HTTPS link, a Windows drive path, or a network path.','error');return;}const ft=FILE_TYPES.find(t=>t.type===type);if(!ft){showToast('Choose a valid file type.','error');return;}const file={name,url,icon:ft.icon,type};if(pendingFile?.workId===workId)w.files[pendingFile.index]=file;else{pendingFile={workId,index:w.files.length};w.files.push(file);}
  if(_bgRefreshTimer){clearTimeout(_bgRefreshTimer);_bgRefreshTimer=null;}
  if(!(await saveRequestsNow()))return;
  pendingFile=null;showToast('File link added!','success');
  closeModal();
  openWorkDetail(workId);

  document.getElementById('modal-overlay').style.display='flex';
}

// ============================================================
// ADD / EDIT WORK
// ============================================================
function openAddWork(){if(!hasPendingChanges)pendingCreationId=null;if(!['admin','manager'].includes(currentUser.role)){showToast('Only admins and managers can create work.','error');return;}document.getElementById('modal-title').textContent='Add New Work';renderWorkForm(null);document.getElementById('modal-overlay').style.display='flex';}
function openEditWork(id){const w=works.find(x=>x.id===id);if(!w)return;document.getElementById('modal-body').dataset.detailWorkId=String(id);document.getElementById('modal-title').textContent='Edit Work';renderWorkForm(w);document.getElementById('modal-overlay').style.display='flex';}
function renderWorkForm(w, fromTemplate=null){
  const isEdit=!!w;
  const src=fromTemplate||w||{};
  const phaseEditors=PHASES.map(p=>{
    const tasks=(src.phaseTasks&&src.phaseTasks[p])||DEFAULT_PHASE_TASKS[p];
    return `<div class="phase-task-editor">
      <div class="phase-task-editor-header" onclick="togglePE('${p}')">
        <div class="phase-task-editor-title">📋 ${p} Phase <span style="font-size:11px;color:var(--text3);">(${tasks.length} tasks)</span></div>
        <span id="arrow-${p}" style="color:var(--text3);">▼</span>
      </div>
      <div id="pe-${p}" style="display:none;">
        <div class="phase-task-list" id="ptl-${p}">
          ${tasks.map((t,i)=>`<div class="phase-task-row" id="ptr-${p}-${i}"><input type="text" value="${escapeHtml(t)}" id="pt-${p}-${i}" placeholder="Task description"><button class="remove-task-btn" onclick="removePT('${p}',${i})">✕</button></div>`).join('')}
        </div>
        <button class="add-task-btn" onclick="addPT('${p}')">+ Add Task</button>
      </div>
    </div>`;
  }).join('');

  const templateSelector = !isEdit && templates.length > 0 ? `
    <div class="form-group" style="background:var(--primary-dim);border:1px solid rgba(59,111,212,0.2);border-radius:var(--radius-sm);padding:12px;">
      <label class="form-label">📋 Use a Template</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;">
        ${templates.map(t=>`<button class="btn btn-ghost btn-sm" onclick="applyTemplate(${Number(t.id)})">${escapeHtml(t.icon||'📋')} ${escapeHtml(t.name)}</button>`).join('')}
      </div>
    </div>` : '';

  const recurrenceVal=src.recurrence||'';
  const customDaysVal=src.customDays||'7';
  const picVal=src.pic||currentUser.id;
  const members=TEAM.filter(m=>m.role!=='admin'&&m.role!=='board');

  document.getElementById('modal-body').innerHTML=`
    ${templateSelector}
    <div class="form-group"><label class="form-label" for="f-title">Title *</label><input id="f-title" type="text" value="${escapeHtml(src.title||'')}" placeholder="Project title"></div>
    <div class="form-group"><label class="form-label" for="f-desc">Description</label><textarea id="f-desc" placeholder="Brief description...">${escapeHtml(src.desc||'')}</textarea></div>
    <div class="form-row">
      <div class="form-group"><label class="form-label">Status</label>
        <select id="f-status">
          <option value="upcoming" ${src.status==='upcoming'?'selected':''}>Upcoming</option>
          <option value="ongoing" ${src.status==='ongoing'?'selected':''}>Ongoing</option>
        </select>
      </div>
      <div class="form-group"><label class="form-label">Priority</label>
        <select id="f-priority">${PRIORITIES.map(p=>`<option value="${p}" ${src.priority===p?'selected':''}>${p}</option>`).join('')}</select>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="form-label" for="f-start">Start Date</label><input id="f-start" type="date" value="${escapeHtml(src.startDate||todayStr)}"></div>
      <div class="form-group"><label class="form-label" for="f-deadline">Deadline</label><input id="f-deadline" type="date" value="${escapeHtml(src.deadline||'')}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="form-label" for="f-effort">Estimated effort (hours)</label><input id="f-effort" type="number" min="0" max="10000" step="0.5" value="${Number(src.estimatedHours||0)}"><div class="form-hint">Divided across assignees for capacity planning</div></div>
      <div class="form-group"><label class="form-label" for="f-worktype">Work Type</label><select id="f-worktype">${WORK_TYPES.map(wt=>`<option value="${wt.value}" ${(src.workType||'regular')===wt.value?'selected':''}>${wt.label}</option>`).join('')}</select></div>
    </div>
    <div class="form-group"><label class="form-label" for="f-tags">Tags (comma separated)</label><input id="f-tags" type="text" value="${escapeHtml((src.tags||[]).join(', '))}" placeholder="Design, Marketing, Tech"></div>
    <div class="form-group" style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;">
      <label class="form-label" for="f-recurrence">🔁 Recurrence</label>
      <select id="f-recurrence" onchange="toggleCustomDays(this.value)" style="margin-bottom:8px;">
        ${RECURRENCE_OPTIONS.map(o=>`<option value="${o.value}" ${recurrenceVal===o.value?'selected':''}>${o.label}</option>`).join('')}
      </select>
      <div id="custom-days-row" style="display:${recurrenceVal==='custom'?'flex':'none'};align-items:center;gap:8px;margin-top:6px;">
        <span style="font-size:13px;color:var(--text2);white-space:nowrap;">Repeat every</span>
        <input id="f-custom-days" type="number" min="1" max="365" value="${customDaysVal}" style="width:80px;">
        <span style="font-size:13px;color:var(--text2);">days</span>
      </div>
      <div class="form-hint">When completed, a new occurrence will be automatically created</div>
    </div>
    <div class="form-group"><label class="form-label" for="f-pic">👤 PIC (Person in Charge)</label>
      <select id="f-pic">
        ${members.map(m=>`<option value="${Number(m.id)}" ${picVal===m.id?'selected':''}>${escapeHtml(m.name)} (${escapeHtml(m.role)})</option>`).join('')}
      </select>
      <div class="form-hint">Default: you. The PIC can approve join/leave requests.</div>
    </div>
    <div class="form-group"><label class="form-label">Assign Team Members</label>
      <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:6px;" id="member-chips">
        ${members.map(m=>`<div class="member-chip ${(src.assignees||[]).includes(m.id)?'selected':''}" role="checkbox" aria-checked="${(src.assignees||[]).includes(m.id)}" tabindex="0" onclick="toggleMember(${Number(m.id)})" data-id="${Number(m.id)}">${avatarHtml(m,20)} ${escapeHtml(m.name)}</div>`).join('')}
      </div>
      <div class="form-hint">Admins and managers can create work and manage assignments.</div>
    </div>
    <div class="form-group"><label class="form-label">Phase Tasks <span style="font-size:11px;color:var(--text3);font-weight:400;">(click to expand & customize)</span></label>${phaseEditors}</div>`;

  const saveBtn=isEdit
    ?`<button class="btn btn-primary" onclick="saveEditWork(${w.id})">Save Changes</button>`
    :`<button class="btn btn-primary" onclick="saveNewWork()">Create Work</button>`;
  const templateBtn=!isEdit
    ?`<button class="btn btn-ghost" onclick="saveAsTemplate()" style="border-color:var(--primary);color:var(--primary);">📋 Save as Template</button>`:'';
  document.getElementById('modal-footer').innerHTML=`${saveBtn}${templateBtn}<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>`;
}


function togglePE(p){const el=document.getElementById(`pe-${p}`),ar=document.getElementById(`arrow-${p}`),open=el.style.display==='none';el.style.display=open?'block':'none';ar.textContent=open?'▲':'▼';}
function addPT(p){const list=document.getElementById(`ptl-${p}`),idx=list.querySelectorAll('.phase-task-row').length;const row=document.createElement('div');row.className='phase-task-row';row.id=`ptr-${p}-${idx}`;row.innerHTML=`<input type="text" id="pt-${p}-${idx}" placeholder="New task..."><button class="remove-task-btn" onclick="removePT('${p}',${idx})">✕</button>`;list.appendChild(row);}
function removePT(p,idx){const r=document.getElementById(`ptr-${p}-${idx}`);if(r)r.remove();}
function getPhaseTasks(p){const list=document.getElementById(`ptl-${p}`);if(!list)return[...DEFAULT_PHASE_TASKS[p]];return Array.from(list.querySelectorAll('input[type=text]')).map(i=>i.value.trim()).filter(Boolean);}
function toggleMember(id){const chip=document.querySelector(`.member-chip[data-id="${id}"]`);if(!chip)return;chip.classList.toggle('selected');chip.setAttribute('aria-checked',chip.classList.contains('selected')?'true':'false');}
function getSelectedMembers(){return Array.from(document.querySelectorAll('.member-chip.selected')).map(el=>parseInt(el.dataset.id));}
let pendingCreationId=null;
async function saveNewWork(){
  if(!['admin','manager'].includes(currentUser.role)){showToast('Only admins and managers can create work.','error');return;}
  const title=document.getElementById('f-title').value.trim();
  if(!title){showToast('Title is required.','error');return;}
  const assignees=getSelectedMembers();
  if(!assignees.length){showToast('Assign at least one member.','error');return;}
  const phaseTasks={};PHASES.forEach(p=>{phaseTasks[p]=getPhaseTasks(p);});
  const phaseChecks={};PHASES.forEach(p=>{phaseChecks[p]=new Array(phaseTasks[p].length).fill(false);});
  const picEl=document.getElementById('f-pic');
  const pic=picEl?parseInt(picEl.value)||currentUser.id:currentUser.id;
  const wtEl=document.getElementById('f-worktype');
  const workType=wtEl?wtEl.value:'regular';
  const recEl=document.getElementById('f-recurrence');
  const recurrence=recEl?recEl.value:'';
  const customDaysEl=document.getElementById('f-custom-days');
  const customDays=customDaysEl?customDaysEl.value:'7';
  pendingCreationId=pendingCreationId||newRecordId();
  const record={id:pendingCreationId,title,
    desc:document.getElementById('f-desc').value.trim(),
    status:document.getElementById('f-status').value,
    phase:0,priority:document.getElementById('f-priority').value,
    assignees,pic,workType,recurrence,customDays,
    startDate:document.getElementById('f-start').value,
     deadline:document.getElementById('f-deadline').value,estimatedHours:Number(document.getElementById('f-effort').value||0),
    tags:document.getElementById('f-tags').value.split(',').map(t=>t.trim()).filter(Boolean),
    files:[],notes:[],phaseTasks,phaseChecks,createdAt:todayStr,createdBy:currentUser.id};
  const existing=works.findIndex(w=>w.id===record.id);if(existing>=0)works[existing]=record;else works.push(record);
  const newWork=record;if(!(await saveRequestsNow()))return;pendingCreationId=null;showToast('Work created! 🎉','success');closeModal();navigate(newWork.status==='upcoming'?'upcoming':'ongoing');
}

async function saveEditWork(id){const w=works.find(x=>x.id===id);const title=document.getElementById('f-title').value.trim();if(!title){showToast('Title is required.','error');return;}const assignees=getSelectedMembers();if(!assignees.length){showToast('Assign at least one member.','error');return;}const phaseTasks={};PHASES.forEach(p=>{phaseTasks[p]=getPhaseTasks(p);});PHASES.forEach(p=>{const old=w.phaseChecks[p]||[];w.phaseChecks[p]=phaseTasks[p].map((_,i)=>old[i]||false);});w.title=title;w.desc=document.getElementById('f-desc').value.trim();w.status=document.getElementById('f-status').value;w.priority=document.getElementById('f-priority').value;w.startDate=document.getElementById('f-start').value;w.deadline=document.getElementById('f-deadline').value;w.estimatedHours=Number(document.getElementById('f-effort').value||0);w.tags=document.getElementById('f-tags').value.split(',').map(t=>t.trim()).filter(Boolean);const _wt2=document.getElementById('f-worktype');if(_wt2)w.workType=_wt2.value;w.pic=Number(document.getElementById('f-pic').value)||currentUser.id;w.recurrence=document.getElementById('f-recurrence').value;w.customDays=document.getElementById('f-custom-days').value||'7';w.assignees=assignees;w.phaseTasks=phaseTasks;const ok=await saveRequestsNow();if(!ok)return;showToast('Work updated!','success');closeModal();openWorkDetail(id);}

// ============================================================
