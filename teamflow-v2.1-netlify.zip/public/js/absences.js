'use strict';
// Public holidays and leave. They reduce available hours on the Capacity page; planned hours stay as scheduled, so a clash shows as over capacity.
let absences=[],pendingAbsenceId=null;
const canManageAbsences=()=>Boolean(currentUser)&&['admin','manager'].includes(currentUser.role);
const canAddAbsence=()=>Boolean(currentUser)&&['admin','manager','member'].includes(currentUser.role);
const canRemoveAbsence=entry=>canManageAbsences()||(entry.type==='leave'&&String(entry.memberId)===String(currentUser?.id));
function absenceRange(entry){
  const format=key=>new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}).format(TeamFlowDomain.parseDateKey(key));
  return entry.startDate===entry.endDate?format(entry.startDate):`${format(entry.startDate)} – ${format(entry.endDate)}`;
}
function absenceRowHtml(entry){
  const who=entry.type==='holiday'?'Public holiday':TEAM.find(member=>String(member.id)===String(entry.memberId))?.name||'Former member';
  return`<div class="digest-row"><span style="flex:1;min-width:0;overflow-wrap:anywhere;"><span style="font-weight:600;">${escapeHtml(entry.label||(entry.type==='holiday'?'Public holiday':'Leave'))}</span><br><span style="font-size:12px;color:var(--text3);">${escapeHtml(who)} · ${escapeHtml(absenceRange(entry))}</span></span>${canRemoveAbsence(entry)?`<button type="button" class="btn btn-ghost btn-sm" onclick="removeAbsence(${Number(entry.id)})">Remove</button>`:''}</div>`;
}
function openAbsences(){
  const today=TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE);
  const upcoming=absences.filter(entry=>entry.endDate>=today).sort((a,b)=>a.startDate.localeCompare(b.startDate));
  const people=TEAM.filter(member=>member.active!==false&&['member','manager'].includes(member.role)&&(canManageAbsences()||member.id===currentUser.id));
  const form=canAddAbsence()?`<div class="detail-section"><div class="detail-section-title">Add</div>
    <div class="form-row"><div class="form-group"><label class="form-label" for="ab-type">Type</label><select id="ab-type" onchange="updateAbsenceForm()"><option value="leave">Leave</option>${canManageAbsences()?'<option value="holiday">Public holiday</option>':''}</select></div>
    <div class="form-group" id="ab-member-group"><label class="form-label" for="ab-member">Person</label><select id="ab-member">${people.map(member=>`<option value="${Number(member.id)}" ${member.id===currentUser.id?'selected':''}>${escapeHtml(member.name)}</option>`).join('')}</select></div></div>
    <div class="form-row"><div class="form-group"><label class="form-label" for="ab-start">From</label><input id="ab-start" type="date" value="${today}"></div><div class="form-group"><label class="form-label" for="ab-end">To</label><input id="ab-end" type="date" value="${today}"></div></div>
    <div class="form-group"><label class="form-label" for="ab-label" id="ab-label-text">Note (optional)</label><input id="ab-label" maxlength="120"></div>
    <button type="button" class="btn btn-primary btn-sm" onclick="saveAbsence()">Add</button></div>`:'';
  const modalBody=document.getElementById('modal-body');
  delete modalBody.dataset.detailWorkId;delete modalBody.dataset.detailMeetingId;
  document.getElementById('modal-title').textContent='Leave & Holidays';
  modalBody.innerHTML=`${form}<div class="detail-section"><div class="detail-section-title">Current and Upcoming</div>${upcoming.map(absenceRowHtml).join('')||'<div style="font-size:13px;color:var(--text3);">Nothing recorded.</div>'}</div>`;
  document.getElementById('modal-footer').innerHTML='<button type="button" class="btn btn-ghost" onclick="closeModal()">Close</button>';
  document.getElementById('modal-overlay').style.display='flex';
}
function updateAbsenceForm(){
  const holiday=document.getElementById('ab-type').value==='holiday';
  document.getElementById('ab-member-group').style.display=holiday?'none':'';
  document.getElementById('ab-label-text').textContent=holiday?'Holiday name':'Note (optional)';
}
async function saveAbsence(){
  const type=document.getElementById('ab-type').value,startDate=document.getElementById('ab-start').value,endDate=document.getElementById('ab-end').value,label=document.getElementById('ab-label').value.trim();
  if(!startDate||!endDate||endDate<startDate){showToast('Choose a valid date range.','error');return;}
  if(type==='holiday'&&!label){showToast('Name the public holiday.','error');return;}
  pendingAbsenceId=pendingAbsenceId||newRecordId();
  const finish=setButtonBusy(document.activeElement);
  try{
    const result=await sendJson('absences',{operation:'upsert',absence:{id:pendingAbsenceId,type,startDate,endDate,label,memberId:Number(document.getElementById('ab-member').value)},expectedVersion:0});
    pendingAbsenceId=null;absences=[...absences,result.absence];
    showToast('Added.','success');openAbsences();if(currentPage==='capacity')renderCapacity();
  }catch(error){showToast(error.message,'error');}
  finally{finish();}
}
async function removeAbsence(id){
  const entry=absences.find(item=>item.id===id);if(!entry)return;
  if(!await appConfirm('Remove this entry?'))return;
  try{
    await sendJson('absences',{operation:'delete',id,expectedVersion:entry.version});
    absences=absences.filter(item=>item.id!==id);
    showToast('Removed.','info');openAbsences();if(currentPage==='capacity')renderCapacity();
  }catch(error){showToast(error.message,'error');}
}
async function loadAbsences(){try{absences=(await apiGet('absences')).items||[];}catch{}}
