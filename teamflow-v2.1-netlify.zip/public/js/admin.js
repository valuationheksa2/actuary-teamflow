// ADMIN PANEL
// ============================================================
function renderAdmin(){
  if(currentUser.role!=='admin'){document.getElementById('content').innerHTML='<div class="empty-state"><div class="icon">🔒</div><p>Admin access only.</p></div>';return;}
  let html=`<div class="section-header"><div><div class="section-title">⚙️ Admin Panel</div><div class="section-sub">Manage team members, roles, and access</div></div><button class="btn btn-primary" onclick="openAddMember()">+ Add Member</button></div>`;
  html+=`<div class="card"><div class="card-header"><div class="card-title">👥 Team Members (${TEAM.length})</div></div>`;
  TEAM.forEach(m=>{const aw=works.filter(w=>w.assignees.includes(m.id)&&w.status==='ongoing').length;html+=`<div class="admin-row">${avatarHtml(m,40)}<div style="flex:1;min-width:0;"><div style="display:flex;align-items:center;gap:8px;margin-bottom:2px;"><span style="font-size:14px;font-weight:700;">${escapeHtml(m.name)}</span>${roleBadge(m.role)}</div><div style="font-size:12px;color:var(--text3);">${m.username?'@'+escapeHtml(m.username)+' · ':''}${m.email?escapeHtml(m.email)+' · ':''} ${aw} active project${aw!==1?'s':''}</div></div><div style="display:flex;gap:6px;">${m.id!==currentUser.id?`<button class="btn btn-ghost btn-sm" onclick="openEditMember(${m.id})">✏ Edit</button>`:'<span style="font-size:12px;color:var(--text3);padding:5px 10px;">(You)</span>'}${m.id!==currentUser.id?`<button class="btn btn-danger btn-sm" onclick="deleteMember(${m.id})">🗑</button>`:''}</div></div>`;});
  html+=`</div><div class="grid-3" style="margin-top:16px;"><div class="stat-card"><div class="stat-label">Total Members</div><div class="stat-value" style="color:var(--primary-light);">${TEAM.length}</div></div><div class="stat-card"><div class="stat-label">Managers</div><div class="stat-value" style="color:var(--primary-light);">${TEAM.filter(m=>m.role==='manager').length}</div></div><div class="stat-card"><div class="stat-label">Members</div><div class="stat-value" style="color:var(--green);">${TEAM.filter(m=>m.role==='member').length}</div></div></div>`;
  document.getElementById('content').innerHTML=html;
}
let selectedColor='#5c6ef8';
function selectColor(c){selectedColor=c;document.querySelectorAll('#color-picker [data-color]').forEach(el=>{el.style.border=el.dataset.color===c?'3px solid #fff':'2px solid transparent';el.setAttribute('aria-checked',String(el.dataset.color===c));});}
function colorPicker(current){return`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;" id="color-picker" role="radiogroup" aria-label="Avatar color">${['#5c6ef8','#22c55e','#f59e0b','#ef4444','#a855f7','#06b6d4','#f97316','#ec4899'].map(c=>`<button type="button" role="radio" aria-checked="${current===c}" aria-label="${c}" onclick="selectColor('${c}')" data-color="${c}" style="width:36px;height:36px;border-radius:50%;background:${c};cursor:pointer;border:${current===c?'3px solid #fff':'2px solid transparent'};transition:border 0.2s;"></button>`).join('')}</div>`;}
let pendingMemberId=null;
function openAddMember(){
  if(!hasPendingChanges)pendingMemberId=null;
  selectedColor='#5c6ef8';
  document.getElementById('modal-title').textContent='Add Team Member';
  document.getElementById('modal-body').innerHTML=`
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\">Full Name *</label><input id=\"m-name\" type=\"text\" placeholder=\"e.g. Alex Johnson\"></div>
      <div class=\"form-group\"><label class=\"form-label\">Username *</label><input id=\"m-username\" type=\"text\" placeholder=\"e.g. alex_johnson\"></div>
    </div>
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-email\">Email (optional)</label><input id=\"m-email\" type=\"email\" autocomplete=\"email\" placeholder=\"alex@company.com\"></div>
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-role\">Role</label><select id=\"m-role\"><option value=\"member\">Member</option><option value=\"manager\">Manager</option><option value=\"board\">Board</option><option value=\"admin\">Admin</option></select></div>
    </div>
    <div class=\"form-group\"><label class=\"form-label\" for=\"m-capacity\">Weekly capacity (hours)</label><input id=\"m-capacity\" type=\"number\" min=\"0\" max=\"168\" step=\"1\" value=\"40\"></div>
    <p class=\"form-hint\">After creating the member, generate a setup link and share it privately. The member sets their own password.</p>
    <div class=\"form-group\"><label class=\"form-label\">Avatar Color</label>${colorPicker('#5c6ef8')}</div>`;
  document.getElementById('modal-footer').innerHTML=`<button class=\"btn btn-primary\" onclick=\"saveMember()\">Add Member</button><button class=\"btn btn-ghost\" onclick=\"closeModal()\">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}

async function saveMember(){
  const name=document.getElementById('m-name').value.trim();
  const username=(document.getElementById('m-username')?document.getElementById('m-username').value.trim():'')||name.toLowerCase().replace(/\s+/g,'_');
  const email=document.getElementById('m-email')?document.getElementById('m-email').value.trim():'';
  const capacity=Number(document.getElementById('m-capacity').value);
  const role=document.getElementById('m-role').value;
  if(!name||!username||!Number.isFinite(capacity)||capacity<0||capacity>168){showToast('Enter a name, username, and capacity from 0 to 168 hours.','error');return;}
  if(TEAM.find(m=>m.id!==pendingMemberId&&(m.username||'').toLowerCase()===username.toLowerCase())){showToast('Username already exists.','error');return;}
  pendingMemberId=pendingMemberId||newRecordId();
  const record={id:pendingMemberId,name,username,email,role,color:selectedColor,initials:makeInitials(name),weeklyCapacityHours:capacity,active:true};const index=TEAM.findIndex(m=>m.id===pendingMemberId);if(index>=0)TEAM[index]=record;else TEAM.push(record);
  if(!(await saveRequestsNow()))return;const savedId=pendingMemberId;pendingMemberId=null;showToast(name+' added!','success');closeModal();renderAdmin();openEditMember(savedId);
}


function openEditMember(id){
  const m=TEAM.find(x=>x.id===id);
  document.getElementById('modal-body').dataset.memberId=String(id);
  selectedColor=m.color;
  document.getElementById('modal-title').textContent='Edit Member';
  document.getElementById('modal-body').innerHTML=`
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\">Full Name *</label><input id=\"m-name\" type=\"text\" value=\"${escapeHtml(m.name)}\"></div>
      <div class=\"form-group\"><label class=\"form-label\">Username *</label><input id=\"m-username\" type=\"text\" value=\"${escapeHtml(m.username||m.email||'')}\"></div>
    </div>
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-email\">Email (optional)</label><input id=\"m-email\" type=\"email\" value=\"${escapeHtml(m.email||'')}\"></div>
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-role\">Role</label><select id=\"m-role\"><option value=\"member\" ${m.role==='member'?'selected':''}>Member</option><option value=\"manager\" ${m.role==='manager'?'selected':''}>Manager</option><option value=\"board\" ${m.role==='board'?'selected':''}>Board</option><option value=\"admin\" ${m.role==='admin'?'selected':''}>Admin</option></select></div>
    </div>
    <div class=\"form-group\"><label class=\"form-label\" for=\"m-capacity\">Weekly capacity (hours)</label><input id=\"m-capacity\" type=\"number\" min=\"0\" max=\"168\" step=\"1\" value=\"${Number(m.weeklyCapacityHours??40)}\"></div>
    ${m.mustResetPassword?'<p class=\"form-hint\">Password setup is pending. Generate a setup link and share it privately.</p>':''}
    <div class=\"form-group\"><label class=\"form-label\">Avatar Color</label>${colorPicker(m.color)}</div>`;
  document.getElementById('modal-footer').innerHTML=`<button class=\"btn btn-primary\" onclick=\"saveEditMember(${id})\">Save Changes</button>${m.mustResetPassword?`<button class=\"btn btn-ghost\" onclick=\"sendInvitation(${id})\">Generate Setup Link</button>`:`<button class=\"btn btn-ghost\" onclick=\"sendInvitation(${id},'reset')\">Generate Reset Link</button>`}<button class=\"btn btn-ghost\" onclick=\"closeModal()\">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}

async function saveEditMember(id){
  const m=TEAM.find(x=>x.id===id);
  const name=document.getElementById('m-name').value.trim();
  const username=(document.getElementById('m-username')?document.getElementById('m-username').value.trim():m.username)||name.toLowerCase().replace(/\s+/g,'_');
  const email=document.getElementById('m-email')?document.getElementById('m-email').value.trim():'';
  const capacity=Number(document.getElementById('m-capacity').value);
  if(!name||!username||!Number.isFinite(capacity)||capacity<0||capacity>168){showToast('Enter a name, username, and capacity from 0 to 168 hours.','error');return;}
  const dupU=TEAM.find(x=>(x.username||'').toLowerCase()===username.toLowerCase()&&x.id!==id);
  if(dupU){showToast('Username already in use.','error');return;}
  m.name=name;m.username=username;m.email=email;m.weeklyCapacityHours=capacity;
  m.role=document.getElementById('m-role').value;m.color=selectedColor;m.initials=makeInitials(name);
  if(!(await saveRequestsNow()))return;showToast('Member updated!','success');closeModal();renderAdmin();
}

let accountLinkBusy=false;
async function sendInvitation(id,purpose='invite'){
  if(accountLinkBusy)return;
  if(draftActive||hasPendingChanges){showToast('Save the member changes before generating a link.','info');return;}
  if(purpose==='reset'&&!confirm('Have you verified this member\'s identity? Generating this reset link invalidates their previous setup/reset link.'))return;
  if(purpose==='invite'&&!confirm('Generate a setup link? Any previous setup/reset link for this member will stop working.'))return;
  const target=document.getElementById('modal-body'),generation=editGeneration,userId=currentUser.id;
  document.getElementById('account-link-result')?.remove();
  accountLinkBusy=true;const finish=setButtonBusy(document.activeElement);
  try{
    const result=await sendJson('auth/invitations',{userId:id,purpose});
    if(currentUser?.id!==userId||editGeneration!==generation||target.dataset.memberId!==String(id)||document.getElementById('modal-body')!==target||document.getElementById('modal-title').textContent!=='Edit Member'||document.getElementById('modal-overlay').style.display!=='flex'){showToast('Link generated, but the dialog changed. Reopen the member and generate a replacement.','info');return;}
    const panel=document.createElement('div');panel.id='account-link-result';panel.className='work-update-notice';
    panel.innerHTML=`<label class="form-label" for="generated-account-link">${purpose==='invite'?'Setup':'Password reset'} link</label><textarea id="generated-account-link" readonly autocomplete="off" spellcheck="false" style="width:100%;min-height:80px;">${escapeHtml(result.url)}</textarea><p>Expires ${escapeHtml(new Date(result.expiresAt).toLocaleString())}. Works once. Share privately with this member.</p><button type="button" class="btn btn-ghost btn-sm" onclick="copyPath(this)" data-path="${escapeHtml(result.url)}">Copy Link</button>`;
    target.appendChild(panel);showToast('Link generated. Copy and share it privately.','success');
  }catch(error){showToast(error.message||'Could not generate the link. Try again.','error');}
  finally{accountLinkBusy=false;finish();}
}


async function deleteMember(id){const m=TEAM.find(x=>x.id===id);if(!confirm(`Remove ${escapeHtml(m.name)}? They will lose access immediately.`))return;TEAM=TEAM.filter(x=>x.id!==id);works.forEach(w=>{w.assignees=w.assignees.filter(a=>a!==id);});if(!(await saveRequestsNow()))return;showToast(`${escapeHtml(m.name)} removed.`,'info');renderAdmin();}

// ============================================================
// MODAL HELPERS
// ============================================================
// ── TEMPLATES PAGE ────────────────────────────────────────
function editTemplate(tid){
  if(!['admin','manager'].includes(currentUser.role))return;
  var t=templates.find(function(x){return x.id===tid;});
  if(!t)return;
  document.getElementById('modal-title').textContent='Edit Template';
  var pe='';
  PHASES.forEach(function(p){
    var tasks=(t.phaseTasks&&t.phaseTasks[p])||DEFAULT_PHASE_TASKS[p]||[];
    var taskRows='';
    tasks.forEach(function(tk,i){
      var safeVal=escapeHtml(tk);
      taskRows+='<div class="phase-task-row" id="ptr-'+p+'-'+i+'">'
        +'<input type="text" value="'+safeVal+'" id="pt-'+p+'-'+i+'">'
        +'<button class="remove-task-btn" onclick="removePT(\''+p+'\','+i+')">&#10005;</button>'
        +'</div>';
    });
    pe+='<div class="phase-task-editor">'
      +'<div class="phase-task-editor-header" onclick="togglePE(\''+p+'\')">'
      +'<div class="phase-task-editor-title">&#128203; '+p+'</div>'
      +'<span id="arrow-'+p+'" style="color:var(--text3);">&#9660;</span></div>'
      +'<div id="pe-'+p+'" style="display:none;">'
      +'<div class="phase-task-list" id="ptl-'+p+'">'+taskRows+'</div>'
      +'<button class="add-task-btn" onclick="addPT(\''+p+'\')">+ Add Task</button>'
      +'</div></div>';
  });
  var wts='';
  WORK_TYPES.forEach(function(wt){
    var sel=(t.workType||'regular')===wt.value?' selected':'';
    wts+='<option value="'+wt.value+'"'+sel+'>'+wt.label+'</option>';
  });
  var pris='';
  PRIORITIES.forEach(function(p){
    var sel=t.priority===p?' selected':'';
    pris+='<option value="'+p+'"'+sel+'>'+p+'</option>';
  });
  var recs='';
  RECURRENCE_OPTIONS.forEach(function(o){
    var sel=(t.recurrence||'')===o.value?' selected':'';
    recs+='<option value="'+o.value+'"'+sel+'>'+o.label+'</option>';
  });
  document.getElementById('modal-body').innerHTML=
    '<div class="form-group"><label class="form-label">Template Name *</label>'
    +'<input id="et-name" type="text" value="'+escapeHtml(t.name)+'"></div>'
    +'<div class="form-group"><label class="form-label">Work Title</label>'
    +'<input id="et-title" type="text" value="'+escapeHtml(t.title||'')+'"></div>'
    +'<div class="form-group"><label class="form-label">Description</label>'
    +'<textarea id="et-desc" style="white-space:pre-wrap;">'+escapeHtml(t.desc||'')+'</textarea></div>'
    +'<div class="form-row">'
    +'<div class="form-group"><label class="form-label">Work Type</label>'
    +'<select id="et-wt">'+wts+'</select></div>'
    +'<div class="form-group"><label class="form-label">Priority</label>'
    +'<select id="et-pri">'+pris+'</select></div></div>'
    +'<div class="form-row">'
    +'<div class="form-group"><label class="form-label">Recurrence</label>'
    +'<select id="et-rec">'+recs+'</select></div>'
    +'<div class="form-group"><label class="form-label">Custom Days</label>'
    +'<input id="et-cd" type="number" min="1" max="365" value="'+escapeHtml(t.customDays||7)+'"></div></div>'
    +'<div class="form-group"><label class="form-label">Tags</label>'
    +'<input id="et-tags" type="text" value="'+escapeHtml((t.tags||[]).join(', '))+'"></div>'
    +'<div class="form-group"><label class="form-label">Phase Tasks</label>'+pe+'</div>';
  document.getElementById('modal-footer').innerHTML=
    '<button class="btn btn-primary" onclick="saveEditTemplate('+tid+')">Save Template</button>'
    +'<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>';
  document.getElementById('modal-overlay').style.display='flex';
}

async function saveEditTemplate(tid){
  if(!['admin','manager'].includes(currentUser.role))return;
  const t=templates.find(x=>x.id===tid);if(!t)return;
  const name=document.getElementById('et-name').value.trim();
  if(!name){showToast('Template name required.','error');return;}
  t.name=name;
  t.title=document.getElementById('et-title').value.trim();
  t.desc=document.getElementById('et-desc').value.trim();
  t.workType=document.getElementById('et-wt').value;
  t.priority=document.getElementById('et-pri').value;
  t.recurrence=document.getElementById('et-rec').value;
  t.customDays=document.getElementById('et-cd').value;
  t.tags=document.getElementById('et-tags').value.split(',').map(x=>x.trim()).filter(Boolean);
  const pt={};PHASES.forEach(p=>{pt[p]=getPhaseTasks(p);});t.phaseTasks=pt;
  if(!(await saveRequestsNow()))return;
  showToast('Template updated!','success');
  closeModal();
  renderTemplates();
}
function useTemplate(templateId) {
  if(!['admin','manager'].includes(currentUser.role))return;
  const t = templates.find(x=>x.id===templateId); if(!t) return;
  document.getElementById('modal-title').textContent = 'New Work from Template';
  renderWorkForm(null, t);
  document.getElementById('modal-overlay').style.display = 'flex';

  document.getElementById('modal-overlay').style.display='flex';
}
async function requestJoin(workId) {
  if(!currentUser){showToast('Please log in first.','error');return;}
  const w=works.find(x=>x.id===workId);
  if(!w) return;
  if(w.assignees.includes(currentUser.id)){showToast('You are already assigned to this work.','info');return;}
  const existing=joinRequests.find(r=>r.workId===workId&&r.userId===currentUser.id&&r.status==='pending');
  if(existing){showToast('You already have a pending request for this work.','info');return;}
  joinRequests.push({id:newRecordId(),workId,userId:currentUser.id,type:'join',status:'pending',date:todayStr});
  // Force immediate API save (not debounced) so other devices see it
  if(!(await saveRequestsNow()))return;
  showToast('Join request sent! Waiting for PIC/Manager approval.','success');
  updateRequestsBadge();
  openWorkDetail(workId);
}

async function requestLeave(workId) {
  if(!currentUser){showToast('Please log in first.','error');return;}
  const w=works.find(x=>x.id===workId);
  if(!w) return;
  if(!w.assignees.includes(currentUser.id)){showToast('You are not assigned to this work.','info');return;}
  if(w.pic===currentUser.id){showToast('PIC cannot leave the work. Transfer PIC first.','error');return;}
  const existing=joinRequests.find(r=>r.workId===workId&&r.userId===currentUser.id&&r.status==='pending'&&r.type==='leave');
  if(existing){showToast('You already have a pending leave request.','info');return;}
  joinRequests.push({id:newRecordId(),workId,userId:currentUser.id,type:'leave',status:'pending',date:todayStr});
  if(!(await saveRequestsNow()))return;
  showToast('Leave request sent! Waiting for PIC/Manager approval.','success');
  updateRequestsBadge();
  openWorkDetail(workId);
}

let requestResolutionBusy=false;
async function resolveRequest(reqId,status){
  if(requestResolutionBusy)return;
  if(hasPendingChanges||draftActive){showToast('Save your pending edits before resolving a request.','error');return;}
  requestResolutionBusy=true;editGeneration++;
  const finishButton=setButtonBusy(document.activeElement);setSaveIndicator('saving');
  try{
    const result=await sendJson('works',{operation:'resolve-request',id:reqId,status,expectedVersion:remoteState.versions.joinRequests||1});
    works=works.map(work=>work.id===result.work.id?result.work:work);
    remoteState.works=remoteState.works.map(work=>work.id===result.work.id?cloneValue(result.work):work);
    joinRequests=result.joinRequests;remoteState.collections.joinRequests=cloneValue(joinRequests);remoteState.versions.joinRequests=result.version;
    editGeneration++;setSaveIndicator('saved');
    showToast(status==='approved'?'Request approved!':'Request rejected.','success');updateRequestsBadge();if(currentPage==='requests')renderRequests(false);
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.message,'error');}
  finally{requestResolutionBusy=false;finishButton();}
}
async function approveRequest(reqId){return resolveRequest(reqId,'approved');}
async function rejectRequest(reqId){return resolveRequest(reqId,'rejected');}

function updateRequestsBadge() {
  if(!currentUser) return;
  const isManagerOrAdmin = currentUser.role==='admin'||currentUser.role==='manager';
  const pending = joinRequests.filter(r => {
    if(r.status!=='pending') return false;
    if(isManagerOrAdmin) return true;
    const w = works.find(x=>x.id===r.workId);
    return w && w.pic===currentUser.id;
  });
  const badge=document.getElementById('requests-badge');
  if(!badge) return;
  if(pending.length>0){badge.style.display='';badge.textContent=pending.length;}
  else{badge.style.display='none';}
}

// ── RENDER REQUESTS PAGE ──────────────────────────────────
async function renderRequests(refresh=true) {
  if(currentUser&&currentUser.role==='board'){
    document.getElementById('content').innerHTML='<div class="empty-state"><div class="icon">&#128274;</div><p>Requests are not available for Board users.</p></div>';
    return;
  }
  if(refresh&&!hasPendingChanges&&!draftActive&&!requestResolutionBusy){
    renderRequests(false);
    const marker=beginPageRefresh(document.getElementById('content')),generation=editGeneration,userId=currentUser.id;
    try{
      const latest=await apiGet('works');
      if(marker.isConnected&&currentUser?.id===userId&&!hasPendingChanges&&!draftActive&&!requestResolutionBusy&&generation===editGeneration&&currentPage==='requests'){
        works=latest.data||[];joinRequests=latest.joinRequests||[];remoteState.works=cloneValue(works);
        remoteState.collections.joinRequests=cloneValue(joinRequests);remoteState.versions.joinRequests=latest.versions?.joinRequests||1;
        updateRequestsBadge();renderRequests(false);
      }
    }catch{if(marker.isConnected)showToast('Could not refresh requests. Existing entries are shown.','error');}
    finally{marker.remove();}
    return;
  }
  // Filter requests based on role:
  // Admin/Manager: see all requests
  // Member: see only requests for works where they are PIC
  const isManagerOrAdmin = currentUser.role==='admin'||currentUser.role==='manager';
  const pending = joinRequests.filter(r => {
    if(r.status!=='pending') return false;
    if(isManagerOrAdmin) return true;
    const w = works.find(x=>x.id===r.workId);
    return w && w.pic===currentUser.id;
  });
  const resolved = joinRequests.filter(r => {
    if(r.status==='pending') return false;
    if(isManagerOrAdmin) return true;
    const w = works.find(x=>x.id===r.workId);
    return w && w.pic===currentUser.id;
  });
  let html=`<div class="section-header"><div><div class="section-title">🔔 Join / Leave Requests</div>
    <div class="section-sub">Manage team member requests to join or leave work items</div></div></div>`;

  if(pending.length===0){
    html+=`<div class="empty-state"><div class="icon">✅</div><p>No pending requests</p></div>`;
  } else {
    html+=`<div class="card" style="margin-bottom:20px;"><div class="card-header"><div class="card-title">⏳ Pending Requests (${pending.length})</div></div>`;
    pending.forEach(req=>{
      const w=works.find(x=>x.id===req.workId);
      const user=getMember(req.userId);
      if(!w||!user) return;
      const canApprove=currentUser.role==='admin'||currentUser.role==='manager'||w.pic===currentUser.id;
      html+=`<div class="admin-row">
        ${avatarHtml(user,40)}
        <div style="flex:1;min-width:0;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
            <span style="font-size:14px;font-weight:700;">${escapeHtml(user.name)}</span>
            <span class="badge ${req.type==='join'?'badge-executing':'badge-overdue'}">${req.type==='join'?'🙋 Join Request':'🚪 Leave Request'}</span>
          </div>
          <div style="font-size:13px;color:var(--text2);">Work: <strong>${escapeHtml(w.title)}</strong></div>
          <div style="font-size:11px;color:var(--text3);">Requested on ${fmt(req.date)}</div>
        </div>
        ${canApprove?`<div style="display:flex;gap:6px;">
          <button class="btn btn-success btn-sm" onclick="approveRequest(${req.id})">✅ Approve</button>
          <button class="btn btn-danger btn-sm" onclick="rejectRequest(${req.id})">✕ Reject</button>
        </div>`:`<span style="font-size:12px;color:var(--text3);">Awaiting PIC approval</span>`}
      </div>`;
    });
    html+=`</div>`;
  }

  if(resolved.length>0){
    html+=`<div class="card"><div class="card-header"><div class="card-title">📋 Request History</div></div>`;
    resolved.slice().reverse().slice(0,10).forEach(req=>{
      const w=works.find(x=>x.id===req.workId);
      const user=getMember(req.userId);
      if(!w||!user) return;
      html+=`<div class="digest-row">
        ${avatarHtml(user,28)}
        <span style="flex:1;font-size:13px;">${escapeHtml(user.name)} — ${req.type==='join'?'Join':'Leave'}: <strong>${escapeHtml(w.title)}</strong></span>
        <span class="badge ${req.status==='approved'?'badge-done':'badge-overdue'}">${req.status==='approved'?'✅ Approved':'✕ Rejected'}</span>
        <span style="font-size:11px;color:var(--text3);">${req.approvedByName?'by '+req.approvedByName+' · ':''} ${fmt(req.resolvedDate||req.date)}</span>
      </div>`;
    });
    html+=`</div>`;
  }
  document.getElementById('content').innerHTML=html;
}

// ── PDF EXPORT ────────────────────────────────────────────
function exportToPDF(title, contentHtml) {
  const css = `
    body{font-family:'Segoe UI',sans-serif;padding:30px;color:#1a2535;font-size:13px;margin:0;}
    h1{font-size:22px;font-weight:800;color:#3b6fd4;margin-bottom:4px;}
    h2{font-size:16px;font-weight:700;margin:20px 0 8px;color:#1a2535;border-bottom:2px solid #d0dcea;padding-bottom:4px;}
    table{width:100%;border-collapse:collapse;margin:10px 0;}
    th{background:#3b6fd4;color:#fff;padding:8px;text-align:left;font-size:12px;}
    td{padding:7px 8px;border-bottom:1px solid #e8eef5;font-size:12px;}
    tr:nth-child(even){background:#f8fafc;}
    .stat{display:inline-block;text-align:center;padding:12px 20px;background:#f0f4f8;border-radius:8px;margin:4px;}
    .stat-val{font-size:28px;font-weight:800;color:#3b6fd4;display:block;}
    .stat-label{font-size:11px;color:#8aa0b8;display:block;}
    .footer{margin-top:30px;font-size:11px;color:#8aa0b8;border-top:1px solid #d0dcea;padding-top:10px;}
    @media print{body{padding:15px;}}
  `;
  const dateStr = new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
  const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'+title+'</title><style>'+css+'</style></head><body>'
    + '<h1>'+title+'</h1>'
    + '<div style="font-size:12px;color:#8aa0b8;margin-bottom:20px;">Generated on '+dateStr+'</div>'
    + contentHtml
    + '<div class="footer">Actuarial TeamFlow — Workload Monitor</div>'
    + '</body></html>'
  const blob = new Blob([html], {type: 'text/html'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = title.replace(/[^a-z0-9]/gi,'_')+'_'+new Date().toISOString().split('T')[0]+'.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(()=>URL.revokeObjectURL(url),5000);
  showToast('Report downloaded! Open the file and Ctrl+P to save as PDF.','success');
}


function exportDailyReportPDF() {
  const ongoing=works.filter(w=>w.status==='ongoing');
  const overdue=getOverdue(),rr=getReviewReady();
  const dueSoon=works.filter(w=>w.status!=='done'&&daysUntil(w.deadline)>=0&&daysUntil(w.deadline)<=7);
  let html=`
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">
      <div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div>
      <div class="stat"><div class="stat-val" style="color:#d97706;">${rr.length}</div><div class="stat-label">Review Ready</div></div>
      <div class="stat"><div class="stat-val" style="color:#dc2626;">${overdue.length}</div><div class="stat-label">Overdue</div></div>
      <div class="stat"><div class="stat-val" style="color:#ea580c;">${dueSoon.length}</div><div class="stat-label">Due This Week</div></div>
    </div>`;
  if(overdue.length>0){
    html+=`<h2>🚨 Overdue</h2><table><tr><th>Work</th><th>Phase</th><th>Days Overdue</th><th>Assignees</th></tr>`;
    overdue.forEach(w=>{html+=`<tr><td>${escapeHtml(w.title)}</td><td>${PHASES[w.phase]||'-'}</td><td style="color:#dc2626;">${Math.abs(daysUntil(w.deadline))}d</td><td>${w.assignees.map(id=>escapeHtml(getMember(id)?.name||'')).join(', ')}</td></tr>`;});
    html+=`</table>`;
  }
  if(rr.length>0){
    html+=`<h2>🔍 Ready for Review</h2><table><tr><th>Work</th><th>Deadline</th><th>Assignees</th></tr>`;
    rr.forEach(w=>{html+=`<tr><td>${escapeHtml(w.title)}</td><td>${fmt(w.deadline)}</td><td>${w.assignees.map(id=>escapeHtml(getMember(id)?.name||'')).join(', ')}</td></tr>`;});
    html+=`</table>`;
  }
  html+=`<h2>🔄 All Ongoing Work</h2><table><tr><th>Work</th><th>Phase</th><th>Priority</th><th>Deadline</th><th>Assignees</th></tr>`;
  ongoing.forEach(w=>{html+=`<tr><td>${escapeHtml(w.title)}</td><td>${PHASES[w.phase]}</td><td>${w.priority}</td><td>${fmt(w.deadline)}</td><td>${w.assignees.map(id=>escapeHtml(getMember(id)?.name||'')).join(', ')}</td></tr>`;});
  html+=`</table>`;
  exportToPDF('Daily Report — Actuarial TeamFlow', html);
}

function exportWeeklyReportPDF() {
  const range=TeamFlowDomain.weekRange(todayStr,reportWeekOffset),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done);
  const html=`<p>Period: ${TeamFlowDomain.formatRange(range)} (Monday–Sunday)</p><p>On-time rate uses completed items with a deadline (${rate.onTime.length}/${rate.eligible.length}).</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;"><div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div><div class="stat"><div class="stat-val">${done.length}</div><div class="stat-label">Completed</div></div><div class="stat"><div class="stat-val" style="color:#16a34a;">${rate.onTime.length}</div><div class="stat-label">On time</div></div><div class="stat"><div class="stat-val" style="color:#dc2626;">${rate.late.length}</div><div class="stat-label">Late</div></div><div class="stat"><div class="stat-val">${rate.pct}%</div><div class="stat-label">On-time rate</div></div></div>${reportOngoingTable(ongoing,range)}<h2>Completed work in this week</h2><table><tr><th>Work</th><th>Priority</th><th>Deadline</th><th>Completed</th><th>Status</th></tr>${done.map(work=>{const late=rate.late.includes(work);return`<tr><td>${escapeHtml(work.title)}</td><td>${escapeHtml(work.priority)}</td><td>${fmt(work.deadline)}</td><td>${fmt(work.completedDate)}</td><td>${!work.deadline?'No deadline':late?'Late':'On time'}</td></tr>`;}).join('')}</table>`;
  exportToPDF(`Weekly Report — ${TeamFlowDomain.formatRange(range)}`,html);
}
function exportMonthlyReportPDF() {
  const date=new Date(`${todayStr}T00:00:00Z`),month=TeamFlowDomain.shiftMonth(date.getUTCFullYear(),date.getUTCMonth(),reportMonthOffset),range=TeamFlowDomain.monthRange(month.year,month.month),periodWorks=works.filter(work=>TeamFlowDomain.reportInMonth(work,range)),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done);
  const priorities=PRIORITIES.map(priority=>{const count=periodWorks.filter(work=>work.priority===priority).length;return`<tr><td>${priority}</td><td>${count}</td><td>${periodWorks.length?Math.round(count/periodWorks.length*100):0}%</td></tr>`;}).join('');
  const html=`<p>Period: ${TeamFlowDomain.formatRange(range)}</p><p>Work in period includes scheduled, created or completed items, plus ongoing overdue carryover. On-time rate uses completions with deadlines (${rate.onTime.length}/${rate.eligible.length}).</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;"><div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div><div class="stat"><div class="stat-val">${periodWorks.length}</div><div class="stat-label">Work in period</div></div><div class="stat"><div class="stat-val" style="color:#16a34a;">${done.length}</div><div class="stat-label">Completed</div></div><div class="stat"><div class="stat-val">${rate.pct}%</div><div class="stat-label">On-time rate</div></div></div>${reportOngoingTable(ongoing,range)}<h2>Work by priority</h2><table><tr><th>Priority</th><th>Count</th><th>Share</th></tr>${priorities}</table>`;
  exportToPDF(`Monthly Report — ${TeamFlowDomain.formatRange(range)}`,html);
}
function exportAnnualReportPDF() {
  const range=annualReportRange(),periodWorks=works.filter(work=>TeamFlowDomain.reportInMonth(work,range)),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done);
  const priorities=PRIORITIES.map(priority=>{const count=periodWorks.filter(work=>work.priority===priority).length;return`<tr><td>${priority}</td><td>${count}</td><td>${periodWorks.length?Math.round(count/periodWorks.length*100):0}%</td></tr>`;}).join('');
  const members=TEAM.filter(member=>['member','manager'].includes(member.role)).map(member=>{const assigned=periodWorks.filter(work=>((work.assignees||[]).some(id=>String(id)===String(member.id))||String(work.pic)===String(member.id))),completed=assigned.filter(work=>TeamFlowDomain.reportCompletion(work,range)),memberRate=reportRate(completed);return`<tr><td>${escapeHtml(member.name)}</td><td>${assigned.length}</td><td>${completed.length}</td><td>${assigned.filter(work=>work.status==='ongoing').length}</td><td>${memberRate.onTime.length}</td><td>${memberRate.eligible.length?memberRate.pct+'%':'N/A'}</td></tr>`;}).join('');
  const html=`<p>Period: ${TeamFlowDomain.formatRange(range)}</p><p>Work in period includes scheduled, created or completed items, plus ongoing overdue carryover. On-time rate uses completions with deadlines (${rate.onTime.length}/${rate.eligible.length}).</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;"><div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div><div class="stat"><div class="stat-val">${periodWorks.length}</div><div class="stat-label">Work in period</div></div><div class="stat"><div class="stat-val" style="color:#16a34a;">${done.length}</div><div class="stat-label">Completed</div></div><div class="stat"><div class="stat-val">${rate.pct}%</div><div class="stat-label">On-time rate</div></div></div>${reportOngoingTable(ongoing,range)}<h2>Work by priority</h2><table><tr><th>Priority</th><th>Count</th><th>Share</th></tr>${priorities}</table><h2>Completed work in this year</h2><table><tr><th>Work</th><th>Deadline</th><th>Completed</th><th>Status</th></tr>${done.map(work=>`<tr><td>${escapeHtml(work.title)}</td><td>${fmt(work.deadline)}</td><td>${fmt(work.completedDate)}</td><td>${!work.deadline?'No deadline':rate.late.includes(work)?'Late':'On time'}</td></tr>`).join('')||'<tr><td colspan="4">No completed work in this year.</td></tr>'}</table><h2>Member performance in this year</h2><table><tr><th>Member</th><th>Assigned</th><th>Completed</th><th>Ongoing</th><th>On time</th><th>Rate</th></tr>${members}</table>`;
  exportToPDF(`Annual Report — ${TeamFlowDomain.formatRange(range)}`,html);
}
// ── TEMPLATE FUNCTIONS ────────────────────────────────────
function toggleCustomDays(val){document.getElementById('custom-days-row').style.display=val==='custom'?'flex':'none';}
function applyTemplate(templateId){const t=templates.find(x=>x.id===templateId);if(!t)return;renderWorkForm(null,t);showToast('Template applied!','success');}
async function saveAsTemplate(){
  if(!['admin','manager'].includes(currentUser.role))return;
  const title=document.getElementById('f-title').value.trim();
  if(!title){showToast('Add a title first.','error');return;}
  const phaseTasks={};PHASES.forEach(p=>{phaseTasks[p]=getPhaseTasks(p);});
  const templateName=prompt('Save as template — give it a name:',title);
  if(!templateName) return;
  const icons=['📋','📊','🎨','💼','🔧','📝','🚀','⚙️','📣','🏗'];
  templates.push({id:newRecordId(),name:templateName,icon:icons[templates.length%icons.length],
    title,desc:document.getElementById('f-desc').value.trim(),
    workType:document.getElementById('f-worktype').value,pic:Number(document.getElementById('f-pic').value)||currentUser.id,
    status:document.getElementById('f-status').value,
    priority:document.getElementById('f-priority').value,
    tags:document.getElementById('f-tags').value.split(',').map(t=>t.trim()).filter(Boolean),
    recurrence:document.getElementById('f-recurrence')?.value||'',
     customDays:document.getElementById('f-custom-days')?.value||'7',estimatedHours:Number(document.getElementById('f-effort')?.value||0),
    phaseTasks,assignees:getSelectedMembers(),createdAt:todayStr});
  if(!(await saveRequestsNow()))return;
  showToast('Template saved! 🎉','success');
}
function renderTemplates(){
  if(currentUser&&currentUser.role==='board'){document.getElementById('content').innerHTML='<div class="empty-state"><div class="icon">&#128274;</div><p>Templates are not available for Board users.</p></div>';return;}
  let html=`<div class="section-header"><div><div class="section-title">Work Templates</div><div class="section-sub">Save and reuse work structures</div></div>${['admin','manager'].includes(currentUser.role)?`<button class="btn btn-primary" onclick="openAddWork()">+ New Work</button>`:''}</div>`;
  if(!templates.length){html+=`<div class="empty-state"><div class="icon">📋</div><p style="font-size:15px;font-weight:600;margin-bottom:8px;">No templates yet</p><p style="margin-bottom:20px;">Create a work item and click "Save as Template".</p>${['admin','manager'].includes(currentUser.role)?`<button class="btn btn-primary" onclick="openAddWork()">+ Create Work</button>`:''}</div>`;}
  else{
    html+=`<div class="grid-3">`;
    templates.forEach(t=>{
      const rl=RECURRENCE_OPTIONS.find(o=>o.value===t.recurrence)?.label||'No recurrence';
      html+=`<div class="card"><div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
        <div style="width:42px;height:42px;border-radius:var(--radius-sm);background:var(--primary-dim);border:1px solid rgba(59,111,212,0.2);display:flex;align-items:center;justify-content:center;font-size:20px;">${escapeHtml(t.icon||'📋')}</div>
        <div><div style="font-size:14px;font-weight:700;">${escapeHtml(t.name)}</div><div style="font-size:11px;color:var(--text3);">Created ${fmt(t.createdAt)}</div></div>
      </div>
      ${t.desc?`<div style="font-size:12px;color:var(--text2);margin-bottom:10px;">${escapeHtml(t.desc.substring(0,80))}${t.desc.length>80?'…':''}</div>`:''}
      <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:10px;">
        <span class="badge badge-priority-${['high','medium','low'].includes(String(t.priority).toLowerCase())?String(t.priority).toLowerCase():'medium'}">${escapeHtml(t.priority||'Medium')}</span>
        ${t.recurrence?`<span class="badge" style="background:var(--primary-dim);color:var(--primary);border:1px solid rgba(59,111,212,0.2);">🔁 ${rl}</span>`:''}
        ${(t.tags||[]).map(tag=>`<span class="tag">${escapeHtml(tag)}</span>`).join('')}
      </div>
      <div style="display:${['admin','manager'].includes(currentUser.role)?'flex':'none'};gap:6px;">
        <button class="btn btn-primary btn-sm" style="flex:1;" onclick="useTemplate(${t.id})">Use Template</button>
        <button class="btn btn-ghost btn-sm" onclick="editTemplate(${t.id})">✏</button>
        <button class="btn btn-danger btn-sm" onclick="deleteTemplate(${t.id})">🗑</button>
      </div></div>`;
    });
    html+=`</div>`;
  }
  const recurringWorks=works.filter(w=>w.recurrence&&w.status!=='done');
  if(recurringWorks.length>0){
    html+=`<div style="margin-top:28px;"><div class="section-header"><div><div class="section-title" style="font-size:16px;">🔁 Active Recurring Work</div></div></div>`;
    recurringWorks.forEach(w=>{
      const rl=RECURRENCE_OPTIONS.find(o=>o.value===w.recurrence)?.label||'';
      html+=`<div class="work-item" onclick="openWorkDetail(${w.id})">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">
          <span class="badge badge-${w.status==='upcoming'?'upcoming':PHASES[w.phase].toLowerCase()}">${w.status==='upcoming'?'Upcoming':PHASES[w.phase]}</span>
          <span class="badge" style="background:var(--primary-dim);color:var(--primary);border:1px solid rgba(59,111,212,0.2);">🔁 ${rl}</span>
        </div>
        <div style="font-size:15px;font-weight:700;">${escapeHtml(w.title)}</div>
        <div class="work-item-footer">${assigneesHtml(w.assignees)}<div class="meta-item">🏁 ${fmt(w.deadline)}</div>${deadlineChip(w.deadline,w.status)}</div>
      </div>`;
    });
    html+=`</div>`;
  }
  document.getElementById('content').innerHTML=html;
}
function useTemplate(id){const t=templates.find(x=>x.id===id);if(!t)return;document.getElementById('modal-title').textContent='New Work from Template';renderWorkForm(null,t);document.getElementById('modal-overlay').style.display='flex';}
async function deleteTemplate(id){if(!['admin','manager'].includes(currentUser.role))return;const t=templates.find(x=>x.id===id);if(!t||!confirm('Delete template "'+t.name+'"?'))return;templates=templates.filter(x=>x.id!==id);if(!(await saveRequestsNow()))return;showToast('Template deleted.','info');renderTemplates();}

// ── RECURRENCE HELPERS ────────────────────────────────────
function getNextDate(deadline,recurrence,customDays){
  if(!deadline||!recurrence)return'';
  const d=new Date(deadline);
  switch(recurrence){
    case'weekly':d.setDate(d.getDate()+7);break;
    case'biweekly':d.setDate(d.getDate()+14);break;
    case'monthly':d.setMonth(d.getMonth()+1);break;
    case'quarterly':d.setMonth(d.getMonth()+3);break;
    case'custom':d.setDate(d.getDate()+(parseInt(customDays)||7));break;
    default:return'';
  }
  return d.toISOString().split('T')[0];
}
function getStartFromDeadline(oldStart,oldDeadline,newDeadline){
  if(!oldStart||!oldDeadline||!newDeadline)return newDeadline;
  const dur=new Date(oldDeadline)-new Date(oldStart);
  const ns=new Date(newDeadline);ns.setTime(ns.getTime()-dur);
  return ns.toISOString().split('T')[0];
}


function editNote(workId,noteIdx){
  const w=works.find(x=>x.id===workId);if(!w)return;
  const note=w.notes[noteIdx];if(!note)return;
  const canEdit=currentUser.role==='admin'||(note.authorId&&note.authorId===currentUser.id)||(note.authorName===currentUser.name&&!note.authorId);
  if(!canEdit){showToast('You can only edit your own notes.','error');return;}
  const notesEl=document.getElementById('notes-list-'+workId);if(!notesEl)return;
  const noteEl=notesEl.children[noteIdx];if(!noteEl)return;
  noteEl.innerHTML='<div class="note-meta">'+escapeHtml(note.authorName)+' &middot; '+fmt(note.createdDate||note.date)+'</div>'
    +'<textarea id="en-'+workId+'-'+noteIdx+'" style="width:100%;margin-bottom:6px;min-height:60px;">'+escapeHtml(note.text)+'</textarea>'
    +'<div style="display:flex;gap:6px;"><button class="btn btn-primary btn-sm" onclick="saveEditNote('+workId+','+noteIdx+')">Save</button>'
    +'<button class="btn btn-ghost btn-sm" onclick="openWorkDetail('+workId+')">Cancel</button></div>';
}
async function saveEditNote(workId,noteIdx){
  const w=works.find(x=>x.id===workId);if(!w)return;
  const ta=document.getElementById('en-'+workId+'-'+noteIdx);if(!ta)return;
  const newText=ta.value.trim();if(!newText){showToast('Note cannot be empty.','error');return;}
  w.notes[noteIdx].text=newText;
  w.notes[noteIdx].editedDate=todayStr;
  if(!(await saveRequestsNow()))return;
  showToast('Note updated!','success');
  openWorkDetail(workId);
}
function copyPath(btn) {
  var path = btn.getAttribute('data-path');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(path).then(function() {
      var orig = btn.textContent;
      btn.textContent = '✅ Copied!';
      btn.style.color = 'var(--green)';
      setTimeout(function() { btn.textContent = orig; btn.style.color = ''; }, 2000);
    }).catch(function(){showToast('Could not copy automatically. Select the displayed path and copy it manually.','error');});
  } else {
    var ta = document.createElement('textarea');
    ta.value = path; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy');
    document.body.removeChild(ta);
    var orig = btn.textContent;
    btn.textContent = '✅ Copied!'; btn.style.color = 'var(--green)';
    setTimeout(function() { btn.textContent = orig; btn.style.color = ''; }, 2000);
  }
}

// ── MY PROFILE ────────────────────────────────────────────
