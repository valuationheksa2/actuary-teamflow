// ADMIN PANEL
// ============================================================
function renderAdmin(){
  if(currentUser.role!=='admin'){document.getElementById('content').innerHTML='<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-lock"/></svg></div><p>Admin access only.</p></div>';return;}
  let html='';
  const roleCount=role=>TEAM.filter(m=>m.role===role).length;
  html+=`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:12px;margin-bottom:16px;">${[['Total Members',TEAM.length,'var(--primary-light)'],['Admins',roleCount('admin'),'var(--purple)'],['Managers',roleCount('manager'),'var(--primary)'],['Members',roleCount('member'),'var(--green)'],['Board',roleCount('board'),'var(--text2)']].map(([label,count,color])=>`<div class="stat-card"><div class="stat-label">${label}</div><div class="stat-value" style="color:${color};">${count}</div></div>`).join('')}</div>`;
  html+=`<div class="card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-users"/></svg> Team Members (${TEAM.length})</div></div>`;
  membersInRoleOrder().forEach(m=>{const aw=works.filter(w=>w.assignees.includes(m.id)&&w.status==='ongoing').length;html+=`<div class="admin-row">${avatarHtml(m,40)}<div style="flex:1;min-width:0;"><div style="display:flex;align-items:center;gap:8px;margin-bottom:2px;"><span style="font-size:13px;font-weight:700;">${escapeHtml(m.name)}</span>${roleBadge(m.role)}</div><div style="font-size:12px;color:var(--text3);">${m.username?'@'+escapeHtml(m.username)+' · ':''}${m.email?escapeHtml(m.email)+' · ':''} ${aw} active project${aw!==1?'s':''}</div></div><div style="display:flex;gap:6px;">${m.id!==currentUser.id?`<button class="btn btn-ghost btn-sm" onclick="openEditMember(${m.id})"><svg class="ui-icon" aria-hidden="true"><use href="#i-pencil"/></svg> Edit</button>`:'<span style="font-size:12px;color:var(--text3);padding:5px 10px;">(You)</span>'}${m.id!==currentUser.id?`<button class="btn btn-danger btn-sm" onclick="deleteMember(${m.id})"><svg class="ui-icon" aria-hidden="true"><use href="#i-trash"/></svg></button>`:''}</div></div>`;});
  html+=`</div>`;
  html+=tagAdminHtml();
  document.getElementById('content').innerHTML=html;
}
function tagAdminHtml(){
  const defaults=new Set(tagOptions.map(option=>option.name.toLocaleLowerCase())),usage=new Map();
  [...works,...templates].forEach(item=>(item.tags||[]).forEach(tag=>{const name=String(tag).trim(),key=name.toLocaleLowerCase();if(name&&name.length<=40&&!name.includes(',')&&!defaults.has(key))usage.set(key,{name:usage.get(key)?.name||name,count:(usage.get(key)?.count||0)+1});}));
  const suggestions=[...usage.values()].sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name)).slice(0,12);
  const rows=tagOptions.map(option=>`<div class="tag-admin-row"><span class="tag" style="font-size:12px;">${escapeHtml(option.name)}</span><span style="flex:1;"></span><button type="button" class="btn btn-ghost btn-sm" aria-label="Remove ${escapeHtml(option.name)}" onclick="removeTagOption(${Number(option.id)})">Remove</button></div>`).join('')||'<p style="font-size:12px;color:var(--text3);">No default tags yet.</p>';
  return`<div class="card" style="margin-top:16px;"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-tag"/></svg> Default Tags (${tagOptions.length})</div></div>
    <p class="form-hint" style="margin-bottom:10px;">Shown as quick picks in the work and template forms. Everyone can still type custom tags.</p>
    <div style="display:flex;gap:8px;"><input id="new-tag-name" type="text" maxlength="40" placeholder="New tag, e.g. IFRS 17" aria-label="New default tag" onkeydown="if(event.key==='Enter')addTagOption()"><button type="button" class="btn btn-primary btn-sm" onclick="addTagOption()">Add Tag</button></div>
    ${suggestions.length?`<div style="margin-top:12px;"><div class="form-hint" style="margin-bottom:6px;">Tags already in use. Select one to add it:</div><div class="tag-picker">${suggestions.map(item=>`<button type="button" class="tag-option" data-tag="${escapeHtml(item.name)}" onclick="addTagOption(this.dataset.tag)">+ ${escapeHtml(item.name)} <span style="color:var(--text3);">(${item.count})</span></button>`).join('')}</div></div>`:''}
    <div id="tag-admin-list" style="margin-top:16px;border-top:1px solid var(--border);">${rows}</div>
  </div>`;
}
async function addTagOption(value){
  if(currentUser.role!=='admin')return;
  const input=document.getElementById('new-tag-name'),name=String(value??input?.value??'').trim();
  if(!name||name.length>40||name.includes(',')){showToast('Enter a tag of up to 40 characters without commas.','error');return;}
  if(tagOptions.some(option=>option.name.toLocaleLowerCase()===name.toLocaleLowerCase())){showToast('That tag is already in the list.','info');return;}
  tagOptions=[...tagOptions,{id:newRecordId(),name}];
  if(!(await saveRequestsNow()))return;
  showToast('Tag "'+name+'" added.','success');renderAdmin();document.getElementById('new-tag-name')?.focus();
}
async function removeTagOption(id){
  if(currentUser.role!=='admin')return;
  const option=tagOptions.find(item=>item.id===id);if(!option)return;
  if(!await appConfirm('Remove "'+option.name+'" from the default tags? Existing work keeps its tags.'))return;
  tagOptions=tagOptions.filter(item=>item.id!==id);
  if(!(await saveRequestsNow()))return;
  showToast('Tag removed.','info');renderAdmin();
}
let selectedColor='#34507F';
function selectColor(c){selectedColor=c;document.querySelectorAll('#color-picker [data-color]').forEach(el=>{el.style.border=el.dataset.color===c?'3px solid #fff':'2px solid transparent';el.setAttribute('aria-checked',String(el.dataset.color===c));});}
function colorPicker(saved){const current=avatarColor(saved);return`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px;" id="color-picker" role="radiogroup" aria-label="Avatar color">${AVATAR_COLORS.map(({hex:c,name})=>`<button type="button" role="radio" aria-checked="${current===c}" aria-label="${name}" title="${name}" onclick="selectColor('${c}')" data-color="${c}" style="width:36px;height:36px;border-radius:50%;background:${c};cursor:pointer;border:${current===c?'3px solid #fff':'2px solid transparent'};transition:border 0.2s;"></button>`).join('')}</div>`;}
let pendingMemberId=null;
function openAddMember(){
  if(!hasPendingChanges)pendingMemberId=null;
  selectedColor=AVATAR_COLORS[0].hex;
  document.getElementById('modal-title').textContent='Add Team Member';
  document.getElementById('modal-body').innerHTML=`
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\">Full Name *</label><input id=\"m-name\" type=\"text\" placeholder=\"e.g. Alex Johnson\"></div>
      <div class=\"form-group\"><label class=\"form-label\">Username *</label><input id=\"m-username\" type=\"text\" placeholder=\"e.g. alex_johnson\"></div>
    </div>
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-email\">Email (optional)</label><input id=\"m-email\" type=\"email\" autocomplete=\"email\" placeholder=\"alex@company.com\"></div>
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-role\">Role</label><select id=\"m-role\"><option value=\"member\">Member</option><option value=\"manager\">Manager</option><option value=\"board\">Board</option><option value=\"admin\">Admin</option></select></div>
    </div>
    <div class=\"form-group\"><label class=\"form-label\" for=\"m-capacity\">Weekly capacity (hours)</label><input id=\"m-capacity\" type=\"number\" min=\"0\" max=\"168\" step=\"1\" value=\"40\"></div>
    <p class=\"form-hint\">After creating the member, generate a setup link and share it privately. The member sets their own password.</p>
    <div class=\"form-group\"><label class=\"form-label\">Avatar Color</label>${colorPicker('#5c6ef8')}</div>`;
  document.getElementById('modal-footer').innerHTML=`<button class=\"btn btn-primary\" onclick=\"saveMember()\">Add Member</button><button class=\"btn btn-ghost\" onclick=\"closeModal()\">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}

async function saveMember(){
  const name=document.getElementById('m-name').value.trim();
  const username=(document.getElementById('m-username')?document.getElementById('m-username').value.trim():'')||name.toLowerCase().replace(/\s+/g,'_');
  const email=document.getElementById('m-email')?document.getElementById('m-email').value.trim():'';
  const capacity=Number(document.getElementById('m-capacity').value);
  const role=document.getElementById('m-role').value;
  if(!name||!username||!Number.isFinite(capacity)||capacity<0||capacity>168){showToast('Enter a name, username, and capacity from 0 to 168 hours.','error');return;}
  if(TEAM.find(m=>m.id!==pendingMemberId&&(m.username||'').toLowerCase()===username.toLowerCase())){showToast('Username already exists.','error');return;}
  pendingMemberId=pendingMemberId||newRecordId();
  const record={id:pendingMemberId,name,username,email,role,color:selectedColor,initials:makeInitials(name),weeklyCapacityHours:capacity,active:true};const index=TEAM.findIndex(m=>m.id===pendingMemberId);if(index>=0)TEAM[index]=record;else TEAM.push(record);
  if(!(await saveRequestsNow()))return;const savedId=pendingMemberId;pendingMemberId=null;showToast(name+' added!','success');closeModal();renderAdmin();openEditMember(savedId);
}


function openEditMember(id){
  const m=TEAM.find(x=>x.id===id);
  document.getElementById('modal-body').dataset.memberId=String(id);
  selectedColor=avatarColor(m.color);
  document.getElementById('modal-title').textContent='Edit Member';
  document.getElementById('modal-body').innerHTML=`
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\">Full Name *</label><input id=\"m-name\" type=\"text\" value=\"${escapeHtml(m.name)}\"></div>
      <div class=\"form-group\"><label class=\"form-label\">Username *</label><input id=\"m-username\" type=\"text\" value=\"${escapeHtml(m.username||m.email||'')}\"></div>
    </div>
    <div class=\"form-row\">
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-email\">Email (optional)</label><input id=\"m-email\" type=\"email\" value=\"${escapeHtml(m.email||'')}\"></div>
      <div class=\"form-group\"><label class=\"form-label\" for=\"m-role\">Role</label><select id=\"m-role\"><option value=\"member\" ${m.role==='member'?'selected':''}>Member</option><option value=\"manager\" ${m.role==='manager'?'selected':''}>Manager</option><option value=\"board\" ${m.role==='board'?'selected':''}>Board</option><option value=\"admin\" ${m.role==='admin'?'selected':''}>Admin</option></select></div>
    </div>
    <div class=\"form-group\"><label class=\"form-label\" for=\"m-capacity\">Weekly capacity (hours)</label><input id=\"m-capacity\" type=\"number\" min=\"0\" max=\"168\" step=\"1\" value=\"${Number(m.weeklyCapacityHours??40)}\"></div>
    ${m.mustResetPassword?'<p class=\"form-hint\">Password setup is pending. Generate a setup link and share it privately.</p>':''}
    <div class=\"form-group\"><label class=\"form-label\">Avatar Color</label>${colorPicker(m.color)}</div>`;
  document.getElementById('modal-footer').innerHTML=`<button class=\"btn btn-primary\" onclick=\"saveEditMember(${id})\">Save Changes</button>${m.mustResetPassword?`<button class=\"btn btn-ghost\" onclick=\"sendInvitation(${id})\">Generate Setup Link</button>`:`<button class=\"btn btn-ghost\" onclick=\"sendInvitation(${id},'reset')\">Generate Reset Link</button>`}<button class=\"btn btn-ghost\" onclick=\"closeModal()\">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}

async function saveEditMember(id){
  const m=TEAM.find(x=>x.id===id);
  const name=document.getElementById('m-name').value.trim();
  const username=(document.getElementById('m-username')?document.getElementById('m-username').value.trim():m.username)||name.toLowerCase().replace(/\s+/g,'_');
  const email=document.getElementById('m-email')?document.getElementById('m-email').value.trim():'';
  const capacity=Number(document.getElementById('m-capacity').value);
  if(!name||!username||!Number.isFinite(capacity)||capacity<0||capacity>168){showToast('Enter a name, username, and capacity from 0 to 168 hours.','error');return;}
  const dupU=TEAM.find(x=>(x.username||'').toLowerCase()===username.toLowerCase()&&x.id!==id);
  if(dupU){showToast('Username already in use.','error');return;}
  m.name=name;m.username=username;m.email=email;m.weeklyCapacityHours=capacity;
  m.role=document.getElementById('m-role').value;m.color=selectedColor;m.initials=makeInitials(name);
  if(!(await saveRequestsNow()))return;showToast('Member updated!','success');closeModal();renderAdmin();
}

let accountLinkBusy=false;
async function sendInvitation(id,purpose='invite'){
  if(accountLinkBusy)return;
  if(draftActive||hasPendingChanges){showToast('Save the member changes before generating a link.','info');return;}
  if(purpose==='reset'&&!await appConfirm('Have you verified this member\'s identity? Generating this reset link invalidates their previous setup/reset link.'))return;
  if(purpose==='invite'&&!await appConfirm('Generate a setup link? Any previous setup/reset link for this member will stop working.'))return;
  const target=document.getElementById('modal-body'),generation=editGeneration,userId=currentUser.id;
  document.getElementById('account-link-result')?.remove();
  accountLinkBusy=true;const finish=setButtonBusy(document.activeElement);
  try{
    const result=await sendJson('auth/invitations',{userId:id,purpose});
    if(currentUser?.id!==userId||editGeneration!==generation||target.dataset.memberId!==String(id)||document.getElementById('modal-body')!==target||document.getElementById('modal-title').textContent!=='Edit Member'||document.getElementById('modal-overlay').style.display!=='flex'){showToast('Link generated, but the dialog changed. Reopen the member and generate a replacement.','info');return;}
    const panel=document.createElement('div');panel.id='account-link-result';panel.className='work-update-notice';
    panel.innerHTML=`<label class="form-label" for="generated-account-link">${purpose==='invite'?'Setup':'Password reset'} link</label><textarea id="generated-account-link" readonly autocomplete="off" spellcheck="false" style="width:100%;min-height:80px;">${escapeHtml(result.url)}</textarea><p>Expires ${escapeHtml(new Date(result.expiresAt).toLocaleString())}. Works once. Share privately with this member.</p><button type="button" class="btn btn-ghost btn-sm" onclick="copyPath(this)" data-path="${escapeHtml(result.url)}">Copy Link</button>`;
    target.appendChild(panel);showToast('Link generated. Copy and share it privately.','success');
  }catch(error){showToast(error.message||'Could not generate the link. Try again.','error');}
  finally{accountLinkBusy=false;finish();}
}


async function deleteMember(id){const m=TEAM.find(x=>x.id===id);if(!await appConfirm(`Remove ${m.name}? They will lose access immediately.`))return;TEAM=TEAM.filter(x=>x.id!==id);works.forEach(w=>{w.assignees=w.assignees.filter(a=>a!==id);});if(!(await saveRequestsNow()))return;showToast(`${escapeHtml(m.name)} removed.`,'info');renderAdmin();}

// ============================================================
// MODAL HELPERS
// ============================================================
// ── TEMPLATES PAGE ────────────────────────────────────────
function canCreateWork(){return !!currentUser&&['admin','manager','member'].includes(currentUser.role);}
function canEditTemplate(template){return !!currentUser&&!!template&&(['admin','manager'].includes(currentUser.role)||(currentUser.role==='member'&&template.createdBy!=null&&String(template.createdBy)===String(currentUser.id)));}
function templateCreatorAssignable(template){return currentUser?.role==='admin'&&!!template&&!(template.createdBy!=null&&TEAM.some(m=>String(m.id)===String(template.createdBy)));}
// Icons come from this fixed set so templates match the rest of the app. Older templates saved an emoji, shown as its closest match.
const TEMPLATE_ICONS=[['clipboard','Checklist'],['chart','Report'],['trend','Trend'],['calculator','Calculation'],['scale','Reserving'],['shield','Risk'],['database','Data'],['file','Document'],['folder','Folder'],['briefcase','Business'],['users','Team'],['calendar','Periodic'],['search','Review'],['note','Notes'],['flag','Milestone'],['gear','Process']];
const LEGACY_TEMPLATE_ICONS={'📋':'clipboard','📊':'chart','📈':'trend','🧮':'calculator','💼':'briefcase','🔍':'search','📝':'note','🔧':'gear','⚙️':'gear','⚙':'gear','🚀':'flag','📣':'users','🏗':'briefcase','🎨':'note'};
function templateIconKey(template){
  const key=template?.iconKey||LEGACY_TEMPLATE_ICONS[template?.icon];
  return TEMPLATE_ICONS.some(([value])=>value===key)?key:'clipboard';
}
// Colours come from the same muted set as avatars; anything else falls back to the first (Navy).
function templateIconColor(template){return AVATAR_COLORS.some(color=>color.hex===template?.iconColor)?template.iconColor:AVATAR_COLORS[0].hex;}
function templateIconHtml(template){return`<svg class="ui-icon" aria-hidden="true" style="color:${templateIconColor(template)};"><use href="#i-${templateIconKey(template)}"/></svg>`;}
let selectedTemplateIcon='clipboard',selectedTemplateColor=AVATAR_COLORS[0].hex;
function selectTemplateColor(hex){
  selectedTemplateColor=hex;
  document.querySelectorAll('#template-color-picker [data-color]').forEach(button=>{const active=button.dataset.color===hex;button.classList.toggle('selected',active);button.setAttribute('aria-checked',String(active));});
  document.querySelectorAll('#template-icon-picker .template-icon-option').forEach(button=>{button.style.color=hex;});
}
function selectTemplateIcon(key){
  selectedTemplateIcon=key;
  document.querySelectorAll('#template-icon-picker [data-icon]').forEach(button=>{const active=button.dataset.icon===key;button.classList.toggle('selected',active);button.setAttribute('aria-checked',String(active));});
}
function templateIconPickerHtml(template){
  selectedTemplateIcon=templateIconKey(template);selectedTemplateColor=templateIconColor(template);
  return`<div class="form-group"><label class="form-label">Icon color</label><div id="template-color-picker" class="template-icon-picker" role="radiogroup" aria-label="Template icon color">${AVATAR_COLORS.map(({hex,name})=>`<button type="button" role="radio" class="template-color-option ${hex===selectedTemplateColor?'selected':''}" aria-checked="${hex===selectedTemplateColor}" aria-label="${name}" title="${name}" data-color="${hex}" style="background:${hex};" onclick="selectTemplateColor('${hex}')"></button>`).join('')}</div></div><div class="form-group"><label class="form-label">Icon</label><div id="template-icon-picker" class="template-icon-picker" role="radiogroup" aria-label="Template icon">${TEMPLATE_ICONS.map(([key,label])=>`<button type="button" role="radio" class="template-icon-option ${key===selectedTemplateIcon?'selected':''}" aria-checked="${key===selectedTemplateIcon}" aria-label="${label}" title="${label}" data-icon="${key}" style="color:${selectedTemplateColor};" onclick="selectTemplateIcon('${key}')"><svg class="ui-icon" aria-hidden="true"><use href="#i-${key}"/></svg></button>`).join('')}</div></div>`;
}
function editTemplate(tid){
  var t=templates.find(function(x){return x.id===tid;});
  if(!canEditTemplate(t))return;
  document.getElementById('modal-title').textContent='Edit Template';
  var pe='';
  PHASES.forEach(function(p){
    var tasks=(t.phaseTasks&&t.phaseTasks[p])||DEFAULT_PHASE_TASKS[p]||[];
    var taskRows='';
    tasks.forEach(function(tk,i){
      var safeVal=escapeHtml(tk);
      taskRows+='<div class="phase-task-row" id="ptr-'+p+'-'+i+'">'
        +'<input type="text" value="'+safeVal+'" id="pt-'+p+'-'+i+'">'
        +'<button class="remove-task-btn" onclick="removePT(\''+p+'\','+i+')"><svg class="ui-icon" aria-hidden="true"><use href="#i-x"/></svg></button>'
        +'</div>';
    });
    pe+='<div class="phase-task-editor">'
      +'<div class="phase-task-editor-header" onclick="togglePE(\''+p+'\')">'
      +'<div class="phase-task-editor-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg> '+p+'</div>'
      +'<span id="arrow-'+p+'" style="color:var(--text3);">&#9660;</span></div>'
      +'<div id="pe-'+p+'" style="display:none;">'
      +'<div class="phase-task-list" id="ptl-'+p+'">'+taskRows+'</div>'
      +'<button class="add-task-btn" onclick="addPT(\''+p+'\')">+ Add Task</button>'
      +'</div></div>';
  });
  var wts='';
  WORK_TYPES.forEach(function(wt){
    var sel=(t.workType||'regular')===wt.value?' selected':'';
    wts+='<option value="'+wt.value+'"'+sel+'>'+wt.label+'</option>';
  });
  var pris='';
  PRIORITIES.forEach(function(p){
    var sel=t.priority===p?' selected':'';
    pris+='<option value="'+p+'"'+sel+'>'+p+'</option>';
  });
  var recs='';
  RECURRENCE_OPTIONS.forEach(function(o){
    var sel=(t.recurrence||'')===o.value?' selected':'';
    recs+='<option value="'+o.value+'"'+sel+'>'+o.label+'</option>';
  });
  var creatorPicker='';
  if(templateCreatorAssignable(t)){
    var people=TEAM.filter(function(m){return m.active!==false&&m.role!=='board';});
    creatorPicker='<div class="form-group" style="background:var(--yellow-dim);border:1px solid var(--yellow);border-radius:var(--radius-sm);padding:12px;">'
      +'<label class="form-label" for="et-creator">Template creator</label>'
      +'<select id="et-creator"><option value="">'+(t.createdBy!=null?'Creator unavailable (removed account)':'Not recorded')+'</option>'
      +people.map(function(m){return '<option value="'+Number(m.id)+'">'+escapeHtml(m.name)+' ('+escapeHtml(m.role)+')</option>';}).join('')
      +'</select><div class="form-hint">Only administrators can assign a creator, and only while it is missing.</div></div>';
  }
  document.getElementById('modal-body').innerHTML=creatorPicker+templateIconPickerHtml(t)+
    '<div class="form-group"><label class="form-label">Template Name *</label>'
    +'<input id="et-name" type="text" value="'+escapeHtml(t.name)+'"></div>'
    +'<div class="form-group"><label class="form-label">Work Title</label>'
    +'<input id="et-title" type="text" value="'+escapeHtml(t.title||'')+'"></div>'
    +'<div class="form-group"><label class="form-label">Description</label>'
    +'<textarea id="et-desc" style="white-space:pre-wrap;">'+escapeHtml(t.desc||'')+'</textarea></div>'
    +'<div class="form-row">'
    +'<div class="form-group"><label class="form-label">Work Type</label>'
    +'<select id="et-wt">'+wts+'</select></div>'
    +'<div class="form-group"><label class="form-label">Priority</label>'
    +'<select id="et-pri">'+pris+'</select></div></div>'
    +'<div class="form-row">'
    +'<div class="form-group"><label class="form-label">Recurrence</label>'
    +'<select id="et-rec">'+recs+'</select></div>'
    +'<div class="form-group"><label class="form-label">Custom Days</label>'
    +'<input id="et-cd" type="number" min="1" max="365" value="'+escapeHtml(t.customDays||7)+'"></div></div>'
    +'<div class="form-group"><label class="form-label" for="et-effort">Estimated effort (hours)</label>'
    +'<input id="et-effort" type="number" min="0" max="10000" step="0.5" value="'+Number(t.estimatedHours||0)+'"><div class="form-hint">Used as the estimated effort for work created from this template.</div></div>'
    +'<div class="form-group"><label class="form-label">Tags</label>'
    +'<input id="et-tags" type="text" value="'+escapeHtml((t.tags||[]).join(', '))+'" oninput="syncTagPicker(\'et-tags\')">'+tagPickerHtml('et-tags',t.tags)+'</div>'
    +'<div class="form-group"><label class="form-label">Phase Tasks</label>'+pe+'</div>';
  document.getElementById('modal-footer').innerHTML=
    '<button class="btn btn-primary" onclick="saveEditTemplate('+tid+')">Save Template</button>'
    +'<button class="btn btn-ghost" onclick="closeModal()">Cancel</button>';
  document.getElementById('modal-overlay').style.display='flex';
}

async function saveEditTemplate(tid){
  const t=templates.find(x=>x.id===tid);if(!canEditTemplate(t))return;
  const name=document.getElementById('et-name').value.trim();
  if(!name||name.length>200){showToast('Template name is required and must be 200 characters or fewer.','error');return;}
  const estimatedHours=Number(document.getElementById('et-effort').value||0);
  if(!Number.isFinite(estimatedHours)||estimatedHours<0||estimatedHours>10000){showToast('Estimated hours must be between 0 and 10,000.','error');return;}
  t.estimatedHours=estimatedHours;
  t.name=name;
  t.iconKey=selectedTemplateIcon;t.iconColor=selectedTemplateColor;delete t.icon;
  t.title=document.getElementById('et-title').value.trim();
  t.desc=document.getElementById('et-desc').value.trim();
  t.workType=document.getElementById('et-wt').value;
  t.priority=document.getElementById('et-pri').value;
  t.recurrence=document.getElementById('et-rec').value;
  t.customDays=document.getElementById('et-cd').value;
  t.tags=document.getElementById('et-tags').value.split(',').map(x=>x.trim()).filter(Boolean);
  const creatorId=Number(document.getElementById('et-creator')?.value||0);
  if(creatorId&&templateCreatorAssignable(t))t.createdBy=creatorId;
  const pt={};PHASES.forEach(p=>{pt[p]=getPhaseTasks(p);});t.phaseTasks=pt;
  if(!(await saveRequestsNow()))return;
  showToast('Template updated!','success');
  closeModal();
  renderTemplates();
}
async function requestJoin(workId) {
  if(!currentUser){showToast('Please log in first.','error');return;}
  const w=works.find(x=>x.id===workId);
  if(!w) return;
  if(w.assignees.includes(currentUser.id)){showToast('You are already assigned to this work.','info');return;}
  const existing=joinRequests.find(r=>r.workId===workId&&r.userId===currentUser.id&&r.status==='pending');
  if(existing){showToast('You already have a pending request for this work.','info');return;}
  joinRequests.push({id:newRecordId(),workId,userId:currentUser.id,type:'join',status:'pending',date:todayStr});
  // Force immediate API save (not debounced) so other devices see it
  if(!(await saveRequestsNow()))return;
  showToast('Join request sent! Waiting for PIC/Manager approval.','success');
  updateRequestsBadge();
  openWorkDetail(workId);
}

async function requestLeave(workId) {
  if(!currentUser){showToast('Please log in first.','error');return;}
  const w=works.find(x=>x.id===workId);
  if(!w) return;
  if(!w.assignees.includes(currentUser.id)){showToast('You are not assigned to this work.','info');return;}
  if(w.pic===currentUser.id){showToast('PIC cannot leave the work. Transfer PIC first.','error');return;}
  const existing=joinRequests.find(r=>r.workId===workId&&r.userId===currentUser.id&&r.status==='pending'&&r.type==='leave');
  if(existing){showToast('You already have a pending leave request.','info');return;}
  joinRequests.push({id:newRecordId(),workId,userId:currentUser.id,type:'leave',status:'pending',date:todayStr});
  if(!(await saveRequestsNow()))return;
  showToast('Leave request sent! Waiting for PIC/Manager approval.','success');
  updateRequestsBadge();
  openWorkDetail(workId);
}

let requestResolutionBusy=false;
async function resolveRequest(reqId,status){
  if(requestResolutionBusy)return;
  if(hasPendingChanges||draftActive){showToast('Save your pending edits before resolving a request.','error');return;}
  requestResolutionBusy=true;editGeneration++;
  const finishButton=setButtonBusy(document.activeElement);setSaveIndicator('saving');
  try{
    const result=await sendJson('works',{operation:'resolve-request',id:reqId,status,expectedVersion:remoteState.versions.joinRequests||1});
    works=works.map(work=>work.id===result.work.id?result.work:work);
    remoteState.works=remoteState.works.map(work=>work.id===result.work.id?cloneValue(result.work):work);
    joinRequests=result.joinRequests;remoteState.collections.joinRequests=cloneValue(joinRequests);remoteState.versions.joinRequests=result.version;
    editGeneration++;setSaveIndicator('saved');
    showToast(status==='approved'?'Request approved!':'Request rejected.','success');updateRequestsBadge();if(currentPage==='requests')renderRequests(false);
  }catch(error){setSaveIndicator(error.status===409?'conflict':'error');showToast(error.message,'error');}
  finally{requestResolutionBusy=false;finishButton();}
}
async function approveRequest(reqId){return resolveRequest(reqId,'approved');}
async function rejectRequest(reqId){return resolveRequest(reqId,'rejected');}

function updateRequestsBadge() {
  if(!currentUser) return;
  const isManagerOrAdmin = currentUser.role==='admin'||currentUser.role==='manager';
  const pending = joinRequests.filter(r => {
    if(r.status!=='pending') return false;
    if(isManagerOrAdmin) return true;
    const w = works.find(x=>x.id===r.workId);
    return w && w.pic===currentUser.id;
  });
  const badge=document.getElementById('requests-badge');
  if(!badge) return;
  if(pending.length>0){badge.style.display='';badge.textContent=pending.length;}
  else{badge.style.display='none';}
}

// ── RENDER REQUESTS PAGE ──────────────────────────────────
async function renderRequests(refresh=true) {
  if(currentUser&&currentUser.role==='board'){
    document.getElementById('content').innerHTML='<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-lock"/></svg></div><p>Requests are not available for Board users.</p></div>';
    return;
  }
  if(refresh&&!hasPendingChanges&&!draftActive&&!requestResolutionBusy){
    renderRequests(false);
    // Background sync keeps the data current; this only asks it to check now (it downloads just what changed).
    const marker=beginPageRefresh(document.getElementById('content'));
    try{await backgroundSync({force:true});}
    catch{if(marker.isConnected)showToast('Could not refresh requests. Existing entries are shown.','error');}
    finally{marker.remove();}
    return;
  }
  // Filter requests based on role:
  // Admin/Manager: see all requests
  // Member: see only requests for works where they are PIC
  const isManagerOrAdmin = currentUser.role==='admin'||currentUser.role==='manager';
  const pending = joinRequests.filter(r => {
    if(r.status!=='pending') return false;
    if(isManagerOrAdmin) return true;
    const w = works.find(x=>x.id===r.workId);
    return w && w.pic===currentUser.id;
  });
  const resolved = joinRequests.filter(r => {
    if(r.status==='pending') return false;
    if(isManagerOrAdmin) return true;
    const w = works.find(x=>x.id===r.workId);
    return w && w.pic===currentUser.id;
  });
  let html='';

  if(pending.length===0){
    html+=`<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg></div><p>No pending requests</p></div>`;
  } else {
    html+=`<div class="card" style="margin-bottom:20px;"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-hourglass"/></svg> Pending Requests (${pending.length})</div></div>`;
    pending.forEach(req=>{
      const w=works.find(x=>x.id===req.workId);
      const user=getMember(req.userId);
      if(!w||!user) return;
      const canApprove=currentUser.role==='admin'||currentUser.role==='manager'||w.pic===currentUser.id;
      html+=`<div class="admin-row">
        ${avatarHtml(user,40)}
        <div style="flex:1;min-width:0;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
            <span style="font-size:13px;font-weight:700;">${escapeHtml(user.name)}</span>
            <span class="badge ${req.type==='join'?'badge-executing':'badge-overdue'}">${req.type==='join'?'<svg class="ui-icon" aria-hidden="true"><use href="#i-hand"/></svg> Join Request':'<svg class="ui-icon" aria-hidden="true"><use href="#i-door"/></svg> Leave Request'}</span>
          </div>
          <div style="font-size:13px;color:var(--text2);">Work: <strong>${escapeHtml(w.title)}</strong></div>
          <div style="font-size:11px;color:var(--text3);">Requested on ${fmt(req.date)}</div>
        </div>
        ${canApprove?`<div style="display:flex;gap:6px;">
          <button class="btn btn-success btn-sm" onclick="approveRequest(${req.id})"><svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Approve</button>
          <button class="btn btn-danger btn-sm" onclick="rejectRequest(${req.id})"><svg class="ui-icon" aria-hidden="true"><use href="#i-x"/></svg> Reject</button>
        </div>`:`<span style="font-size:12px;color:var(--text3);">Awaiting PIC approval</span>`}
      </div>`;
    });
    html+=`</div>`;
  }

  if(resolved.length>0){
    html+=`<div class="card"><div class="card-header"><div class="card-title"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg> Request History</div></div>`;
    resolved.slice().reverse().slice(0,10).forEach(req=>{
      const w=works.find(x=>x.id===req.workId);
      const user=getMember(req.userId);
      if(!w||!user) return;
      html+=`<div class="digest-row">
        ${avatarHtml(user,28)}
        <span style="flex:1;font-size:13px;">${escapeHtml(user.name)} — ${req.type==='join'?'Join':'Leave'}: <strong>${escapeHtml(w.title)}</strong></span>
        <span class="badge ${req.status==='approved'?'badge-done':'badge-overdue'}">${req.status==='approved'?'<svg class="ui-icon" aria-hidden="true"><use href="#i-check-circle"/></svg> Approved':'<svg class="ui-icon" aria-hidden="true"><use href="#i-x"/></svg> Rejected'}</span>
        <span style="font-size:11px;color:var(--text3);">${req.approvedByName?'by '+req.approvedByName+' · ':''} ${fmt(req.resolvedDate||req.date)}</span>
      </div>`;
    });
    html+=`</div>`;
  }
  document.getElementById('content').innerHTML=html;
}

// ── PDF EXPORT ────────────────────────────────────────────
// Exports are opened from a downloaded file, so the tab icon has to travel inside the file.
const EXPORT_ICON='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAG/klEQVR42n2Xa6xUVxXHf2vvMzNn7ot7cy20BcFeWhtISyXUPnw0tSZGtC2KiaYW2ya+amLqh8b4iQ8lNtEQE21sVGz0Q6Px0SZF+qIXbYgFIqkhSDU8LqC3EjBw4c69zJw5r738cM7MnHncnuRkzpyz1t7r8d9r/ZdQuMKwqaraeSECKCD0Xdp6rwXZ97jydUUMlUqlLdx+aIZNBc1fSHYL2QaqIGaJRVsGG1QU0Y4x2l5CQB0gaC7vV3xpG9AMAwXJN9du20Ta1vd52mNAFpCifkGv5ZCCqoJkRkgYhaqqSO9GPUoUjesywuXvTLe+5pEzZkCKFHXZN0+d5t+0x9v8V6U7lK2UoLnXhY1b+iJQrmS2R82u5dpyAjjFKNoHlG54aCcIUsBHLwBbuqq4KCY6coTGH/6IOjcYoJLhwWSOdRbUbmx25LXoeedWVZzLfkkTTMUnuXqV4KmnSV6fRqNoYHok/++1Ip+FVxC0H4j0YkNJ85CULVgrOCyxeFx96yDJz3dRvv8zVB7dhsRxJy2tI51HRFSRoBmoMYYCRJfYNFNyqhgRymUPcMwtxpy7HOBfucSKl1+kXvYZuvkmhrY8gMQR2osPBUz2rN0GDMJBsdgIqkqlZEicMn2ixusnFomdksQJn7wO7q+fxtxzD97oKBo2c/DKe9QmRYJmQ42xAyLQsjozxKniWcOZuQaP/+40h2YDHrx1gomhEg9vmuRD7x/FK5eRJEaSBDGmS39QRXWag3DpM16MguBZ+Mbzx3nz6GXWjFvumxpi38kFRsqG0bJQ1RDfANZmGFHXpU8L5oU9DDnsMiO1p0B38KC5+J2rhyGOOHGuzrHzdb52xziP/PYsW399muffvsKpS03KVqlWLIjJl+w53oUKKkHQUGNNAfjFsHWUNDeqZIVf7p9l5/Qspy+EbN50DZ/bMMHB2YjpmYBrRz3uWD3C1g1j3Ds1ghUhShxmQC1wXSDsQr/016NWCBUqZUOtHvLcX8+x/ZVZPFtixwPXs3b5GGfnQvYcr1NPDB+f8nniI5NcN1omShQj3T2iBwMDcVqoOa12qjSaMUPlEk9++oPs/uY6krBJrSHs2BvxwlFl6y3DJGnK4dmQp/ZdZL6Z4NlWIrUICUx3R+vpgoVIaH5sUDDG0IwT1MXcOTVO1cJ41VALUoII0hTmGwmiyjsXIl76Zw3PE5z2OAV4nZz3dlHta/3OKcaAXy7hlyvUGnW+9auj1BYinpk+w3OP3cqZuYhnD/wPTS21IAGEI/9twiYwYtrrthLtdee85X2nFKfOIQJ+pQRYIGXm3DwvHX6XXX/5N6cuRRDDqvFlxGnMky+cwpbKjI9UaIaQiEeUphn424QnO3tO816Q05j2cRME5xTBUfV9QDk5e5G9b/+HV//+Lgdn5lmoOxAPVHh08018Z/MU237xDo0gYcIz1APBCNSThPXvWwbG4FyCMQVnRfEo8CDJbUmdo+qXAeWVA/9i156j/PnYeepzQaY7MgymxNoPjPD9r2xiYtjjsz88xPlFx/BolUYjxPeVBWCsavn8hnFSp1jTz7A8cIDt6ntV3+cfM+f47k+neePwWTAl8EqsvXGSJ76wkUacEkXC5g+v5jf7T/OTPTPg+3jDFYIwwi+XSGJhvh6xc8s6Vk8OETRTrDEFYtFqxwWy6RCsCD978QDf3vkqLgIZr2ZJSRO2f/l2fj99hivzDZ793n089KN9nDy5QGnFWJbTMMarCM0woVGP+MHD63nk7pUEYZJ5XwR2boPXOpSqDmst87U6bxw6xdqVE9QTpZk4RGHj+pUs1mNe230MYsefPrqGId/DDhnEpRgjuFSJ5iImlw/z469vZNvH1hBECdYMpnpZKe6qhIqIoVQqE0VNaoshsXOUrGFsxGeuFvDVp19jfLjKlk/cwOPP7KculiQVCJXKqM9D997I9i/extS1ywjCCCsMrrCDS3Em5JxircEak2NGURGs8QDY+7fjfGnHy9QuNmB8mKnrJ3jwrike+9Q6bpu6BlxKEKVYz5BXnx6WJe0WL40gUGtNp9rkKNUCOVGE2mKDYzMX2P3WCd48eo4bVk5y9y2ruGv9Sm6/eQVjw0NAShAmCC02Lh3a3sXvM0KqTpEgCFSEjED0saHONb8QcHkxoFqpsGr5GNbz2iFNkpgoTjGGTtfrpfhdXVZwLjNMmlGoaZLgeV7uuebyhfFMHZ61GGtBlShOSJ22A2ZEMnmhPYL1NTWki6KlSYK1+fEPmoG6JMErlZaYjFxhQpCc4GphfqTNqFsO9Edd2lFJkgRjDFW/2mEJQTPQNP+QlUtZIh3SPQP2NrOlGrsI6hzqHMZaqn5V+iaQMGxq6hyqrjB+s/SI3pdfBoa+ZaiIwVpDpdwZz/8PyC6sXCNekB0AAAAASUVORK5CYII=';
// Every PDF export asks first, so a stray click never drops a file into Downloads.
async function exportToPDF(title, contentHtml) {
  const ok = await enqueueAppDialog({ title: 'Export PDF', acceptLabel: 'Export', message: `Export “${title}”? A report file will download. Open it and press Ctrl+P to save it as a PDF.` });
  if (!ok) return;
  const css = `
    *{-webkit-print-color-adjust:exact;print-color-adjust:exact;}
    body{font-family:'Segoe UI',system-ui,sans-serif;padding:32px;color:#1a2535;font-size:13px;line-height:1.5;margin:0;background:#fff;}
    .brand{display:flex;align-items:center;gap:8px;margin-bottom:20px;padding-bottom:12px;border-bottom:2px solid #2b55a4;font-size:13px;font-weight:700;color:#2b55a4;}
    .brand img{width:20px;height:20px;border-radius:5px;}
    h1{font-size:22px;font-weight:700;color:#1a2535;margin:0 0 4px;}
    .meta{font-size:12px;color:#52647a;margin-bottom:20px;}
    h2{font-size:16px;font-weight:700;margin:24px 0 8px;padding-left:10px;border-left:3px solid #2b55a4;line-height:1.25;color:#1a2535;}
    p{margin:0 0 8px;color:#4a6080;}
    p strong{color:#1a2535;font-weight:600;}
    table{width:100%;border-collapse:collapse;margin:8px 0 16px;}
    th{padding:9px 10px;text-align:left;font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#2b55a4;background:#e9effa;border-bottom:1px solid #c5d4ec;white-space:nowrap;}
    th:first-child{border-top-left-radius:8px;}
    th:last-child{border-top-right-radius:8px;}
    td{padding:8px 10px;border-bottom:1px solid #e8eef5;font-size:12px;color:#4a6080;}
    td:first-child{color:#1a2535;font-weight:600;}
    tbody tr:nth-child(even) td{background:#f8fafd;}
    tr{break-inside:avoid;}
    thead{display:table-header-group;}
    .stat{flex:1 1 110px;display:inline-block;box-sizing:border-box;min-width:110px;padding:12px 16px;background:#f4f7fc;border:1px solid #dbe5f3;border-radius:12px;margin:0;break-inside:avoid;}
    .stat-val{font-size:22px;font-weight:700;line-height:1.2;color:#1a2535;display:block;font-variant-numeric:tabular-nums;}
    .stat-label{margin-top:2px;font-size:11px;font-weight:600;color:#52647a;display:block;}
    .footer{margin-top:32px;font-size:11px;color:#52647a;border-top:1px solid #d0dcea;padding-top:10px;}
    @media print{body{padding:16px;}}
  `;
  const dateStr = new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
  const html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>'+title+'</title><link rel="icon" type="image/png" href="'+EXPORT_ICON+'"><style>'+css+'</style></head><body>'
    + '<div class="brand"><img src="'+EXPORT_ICON+'" alt="">Actuarial TeamFlow</div>'
    + '<h1>'+title+'</h1>'
    + '<div class="meta">Generated on '+dateStr+'</div>'
    + contentHtml
    + '<div class="footer">Actuarial TeamFlow — Workload Monitor</div>'
    + '</body></html>'
  const blob = new Blob([html], {type: 'text/html'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = title.replace(/[^a-z0-9]/gi,'_')+'_'+new Date().toISOString().split('T')[0]+'.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(()=>URL.revokeObjectURL(url),5000);
  showToast('Report downloaded! Open the file and Ctrl+P to save as PDF.','success');
}


function exportDailyReportPDF() {
  const ongoing=works.filter(w=>w.status==='ongoing');
  const overdue=getOverdue(),rr=getReviewReady();
  const dueSoon=works.filter(w=>w.status!=='done'&&daysUntil(w.deadline)>=0&&daysUntil(w.deadline)<=7),trend=onTimeTrend();
  let html=`
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">
      <div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div>
      <div class="stat"><div class="stat-val">${rr.length}</div><div class="stat-label">Review Ready</div></div>
      <div class="stat"><div class="stat-val"${overdue.length?' style="color:#dc2626;"':''}>${overdue.length}</div><div class="stat-label">Overdue</div></div>
      <div class="stat"><div class="stat-val">${dueSoon.length}</div><div class="stat-label">Due This Week</div></div>
      <div class="stat"><div class="stat-val"${trend.rate!==null&&trend.rate<75?' style="color:#dc2626;"':''}>${trend.rate===null?'—':trend.rate+'%'}</div><div class="stat-label">On-time Rate · 12 months${trend.delta?` (${trend.delta>0?'+':''}${trend.delta}% vs last month)`:''}</div></div>
    </div>`;
  if(overdue.length>0){
    html+=`<h2>Overdue</h2><table><tr><th>Work</th><th>Phase</th><th>Days Overdue</th><th>Assignees</th></tr>`;
    overdue.forEach(w=>{html+=`<tr><td>${escapeHtml(w.title)}</td><td>${PHASES[w.phase]||'-'}</td><td style="color:#dc2626;">${Math.abs(daysUntil(w.deadline))}d</td><td>${w.assignees.map(id=>escapeHtml(getMember(id)?.name||'')).join(', ')}</td></tr>`;});
    html+=`</table>`;
  }
  if(rr.length>0){
    html+=`<h2>Ready for Review</h2><table><tr><th>Work</th><th>Deadline</th><th>Assignees</th></tr>`;
    rr.forEach(w=>{html+=`<tr><td>${escapeHtml(w.title)}</td><td>${fmt(w.deadline)}</td><td>${w.assignees.map(id=>escapeHtml(getMember(id)?.name||'')).join(', ')}</td></tr>`;});
    html+=`</table>`;
  }
  html+=`<h2>All Ongoing Work</h2><table><tr><th>Work</th><th>Phase</th><th>Priority</th><th>Deadline</th><th>Assignees</th></tr>`;
  ongoing.forEach(w=>{html+=`<tr><td>${escapeHtml(w.title)}</td><td>${PHASES[w.phase]}</td><td>${w.priority}</td><td>${fmt(w.deadline)}</td><td>${w.assignees.map(id=>escapeHtml(getMember(id)?.name||'')).join(', ')}</td></tr>`;});
  html+=`</table>`;
  exportToPDF('Dashboard Report — Actuarial TeamFlow', html);
}

function exportWeeklyReportPDF() {
  const range=TeamFlowDomain.weekRange(todayStr,reportWeekOffset),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done);
  const html=`<p>Period: ${TeamFlowDomain.formatRange(range)} (Monday–Sunday)</p><p>On-time rate uses completed items with a deadline (${rate.onTime.length}/${rate.eligible.length}).</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;"><div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div><div class="stat"><div class="stat-val">${done.length}</div><div class="stat-label">Completed</div></div><div class="stat"><div class="stat-val">${rate.onTime.length}</div><div class="stat-label">On time</div></div><div class="stat"><div class="stat-val"${rate.late.length?' style="color:#dc2626;"':''}>${rate.late.length}</div><div class="stat-label">Late</div></div><div class="stat"><div class="stat-val"${rate.pct<60?' style="color:#dc2626;"':''}>${rate.pct}%</div><div class="stat-label">On-time rate</div></div></div>${reportOngoingTable(ongoing,range)}<h2>Completed work in this week</h2>${effortSummaryText(done)}<table><tr><th>Work</th><th>Priority</th><th>Deadline</th><th>Completed</th><th>Est. hours</th><th>Actual hours</th><th>Status</th></tr>${done.map(work=>{const late=rate.late.includes(work);return`<tr><td>${escapeHtml(work.title)}</td><td>${escapeHtml(work.priority)}</td><td>${fmt(work.deadline)}</td><td>${fmt(work.completedDate)}</td>${effortCells(work)}<td>${!work.deadline?'No deadline':late?'Late':'On time'}</td></tr>`;}).join('')}</table>`;
  exportToPDF(`Weekly Report — ${TeamFlowDomain.formatRange(range)}`,html);
}
function exportMonthlyReportPDF() {
  const date=new Date(`${todayStr}T00:00:00Z`),month=TeamFlowDomain.shiftMonth(date.getUTCFullYear(),date.getUTCMonth(),reportMonthOffset),range=TeamFlowDomain.monthRange(month.year,month.month),periodWorks=works.filter(work=>TeamFlowDomain.reportInMonth(work,range)),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done);
  const priorities=PRIORITIES.map(priority=>{const count=periodWorks.filter(work=>work.priority===priority).length;return`<tr><td>${priority}</td><td>${count}</td><td>${periodWorks.length?Math.round(count/periodWorks.length*100):0}%</td></tr>`;}).join('');
  const html=`<p>Period: ${TeamFlowDomain.formatRange(range)}</p><p>Work in period includes completions during the period and started work still unfinished at period end. On-time rate uses completions with deadlines (${rate.onTime.length}/${rate.eligible.length}).</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;"><div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div><div class="stat"><div class="stat-val">${periodWorks.length}</div><div class="stat-label">Work in period</div></div><div class="stat"><div class="stat-val">${done.length}</div><div class="stat-label">Completed</div></div><div class="stat"><div class="stat-val"${rate.pct<60?' style="color:#dc2626;"':''}>${rate.pct}%</div><div class="stat-label">On-time rate</div></div></div>${reportOngoingTable(ongoing,range)}${reportCompletedTable(done,rate)}<h2>Work by priority</h2><table><tr><th>Priority</th><th>Count</th><th>Share</th></tr>${priorities}</table>`;
  exportToPDF(`Monthly Report — ${TeamFlowDomain.formatRange(range)}`,html);
}
function exportAnnualReportPDF() {
  const range=annualReportRange(),periodWorks=works.filter(work=>TeamFlowDomain.reportInMonth(work,range)),done=works.filter(work=>TeamFlowDomain.reportCompletion(work,range)),ongoing=reportOngoingWorks(range),rate=reportRate(done);
  const priorities=PRIORITIES.map(priority=>{const count=periodWorks.filter(work=>work.priority===priority).length;return`<tr><td>${priority}</td><td>${count}</td><td>${periodWorks.length?Math.round(count/periodWorks.length*100):0}%</td></tr>`;}).join('');
  const members=TEAM.filter(member=>['member','manager'].includes(member.role)).map(member=>{const assigned=periodWorks.filter(work=>((work.assignees||[]).some(id=>String(id)===String(member.id))||String(work.pic)===String(member.id))),completed=assigned.filter(work=>TeamFlowDomain.reportCompletion(work,range)),memberRate=reportRate(completed);return`<tr><td>${escapeHtml(member.name)}</td><td>${assigned.length}</td><td>${completed.length}</td><td>${assigned.filter(work=>TeamFlowDomain.reportOngoing(work,range)).length}</td><td>${memberRate.onTime.length}</td><td>${memberRate.eligible.length?memberRate.pct+'%':'N/A'}</td><td>${formatHours(memberActualHours(member,completed))}</td></tr>`;}).join('');
  const html=`<p>Period: ${TeamFlowDomain.formatRange(range)}</p><p>Work in period includes completions during the period and started work still unfinished at period end. On-time rate uses completions with deadlines (${rate.onTime.length}/${rate.eligible.length}).</p><div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;"><div class="stat"><div class="stat-val">${ongoing.length}</div><div class="stat-label">Ongoing</div></div><div class="stat"><div class="stat-val">${periodWorks.length}</div><div class="stat-label">Work in period</div></div><div class="stat"><div class="stat-val">${done.length}</div><div class="stat-label">Completed</div></div><div class="stat"><div class="stat-val"${rate.pct<60?' style="color:#dc2626;"':''}>${rate.pct}%</div><div class="stat-label">On-time rate</div></div></div>${reportOngoingTable(ongoing,range)}<h2>Work by priority</h2><table><tr><th>Priority</th><th>Count</th><th>Share</th></tr>${priorities}</table><h2>Completed work in this year</h2>${effortSummaryText(done)}<table><tr><th>Work</th><th>Deadline</th><th>Completed</th><th>Est. hours</th><th>Actual hours</th><th>Status</th></tr>${done.map(work=>`<tr><td>${escapeHtml(work.title)}</td><td>${fmt(work.deadline)}</td><td>${fmt(work.completedDate)}</td>${effortCells(work)}<td>${!work.deadline?'No deadline':rate.late.includes(work)?'Late':'On time'}</td></tr>`).join('')||'<tr><td colspan="6">No completed work in this year.</td></tr>'}</table><h2>Member performance in this year</h2><table><tr><th>Member</th><th>Assigned</th><th>Completed</th><th>Ongoing</th><th>On time</th><th>Rate</th><th>Actual hours</th></tr>${members}</table>`;
  exportToPDF(`Annual Report — ${TeamFlowDomain.formatRange(range)}`,html);
}
// ── TEMPLATE FUNCTIONS ────────────────────────────────────
function toggleCustomDays(val){document.getElementById('custom-days-row').style.display=val==='custom'?'flex':'none';}
function applyTemplate(templateId){const t=templates.find(x=>x.id===templateId);if(!t)return;renderWorkForm(null,t);showToast('Template applied!','success');}
async function saveAsTemplate(){
  if(!canCreateWork())return;
  const title=document.getElementById('f-title').value.trim();
  if(!title){showToast('Add a title first.','error');return;}
  const estimatedHours=Number(document.getElementById('f-effort')?.value||0);
  if(!Number.isFinite(estimatedHours)||estimatedHours<0||estimatedHours>10000){showToast('Estimated hours must be between 0 and 10,000.','error');return;}
  const phaseTasks={};PHASES.forEach(p=>{phaseTasks[p]=getPhaseTasks(p);});
  const templateName=await appPrompt('Save as template — give it a name:',title,templateIconPickerHtml(null));
  if(!templateName||!templateName.trim()) return;
  if(templateName.trim().length>200){showToast('Template name must be 200 characters or fewer.','error');return;}
  templates.push({id:newRecordId(),name:templateName.trim(),iconKey:selectedTemplateIcon,iconColor:selectedTemplateColor,
    title,desc:document.getElementById('f-desc').value.trim(),
    workType:document.getElementById('f-worktype').value,pic:Number(document.getElementById('f-pic').value)||currentUser.id,
    status:document.getElementById('f-status').value,
    priority:document.getElementById('f-priority').value,
    tags:document.getElementById('f-tags').value.split(',').map(t=>t.trim()).filter(Boolean),
    recurrence:document.getElementById('f-recurrence')?.value||'',
     customDays:document.getElementById('f-custom-days')?.value||'7',estimatedHours,
    phaseTasks,assignees:getSelectedMembers(),createdAt:todayStr,createdBy:currentUser.id});
  if(!(await saveRequestsNow()))return;
  showToast('Template saved.','success');
}
const templateSearchQueries=new Map();
const templateExpandedUsers=new Set();
function renderTemplates(){
  if(currentUser&&currentUser.role==='board'){document.getElementById('content').innerHTML='<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-lock"/></svg></div><p>Templates are not available for Board users.</p></div>';return;}
  const searchValue=templateSearchQueries.get(String(currentUser?.id))||'';
  let html=`<div class="template-toolbar"><label class="work-search-control template-search"><span class="sr-only">Search templates</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></svg><input id="template-search" class="search-input" type="search" placeholder="Search templates by name, description, tag or creator" value="${escapeHtml(searchValue)}" oninput="filterTemplates(this.value)"></label>${canCreateWork()?`<button type="button" class="btn btn-primary" onclick="openAddWork()">+ New Work</button>`:''}</div>`;
  if(!templates.length){html+=`<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg></div><p style="font-size:16px;font-weight:600;margin-bottom:8px;">No templates yet</p><p style="margin-bottom:20px;">Create a work item and click "Save as Template".</p>${canCreateWork()?`<button class="btn btn-primary" onclick="openAddWork()">+ Create Work</button>`:''}</div>`;}
  else{
    html+=`<div class="grid-3" id="template-results">`;
    // Newest first, so a template you just saved is on screen rather than behind "Show more".
    [...templates].sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||''))).forEach(t=>{
      const creator=t.createdBy!=null?getMember(t.createdBy):null;
      const creatorLabel=creator?'by '+creator.name:t.createdBy!=null?'· Creator unavailable':'· Creator not recorded';
      const rl=RECURRENCE_OPTIONS.find(o=>o.value===t.recurrence)?.label||'No recurrence';
      const taskCount=Object.values(t.phaseTasks||{}).reduce((sum,tasks)=>sum+(Array.isArray(tasks)?tasks.length:0),0);
      const priority=escapeHtml(t.priority||'Medium');
      const facts=[`${Number(t.estimatedHours||0)} h estimate`,`${priority} priority`,t.recurrence?escapeHtml(rl):'',taskCount?`${taskCount} task${taskCount===1?'':'s'}`:''].filter(Boolean).join(' · ');
      const tags=t.tags||[];
      html+=`<div class="card template-card" data-template-id="${Number(t.id)}">
        <div class="template-card-head"><div class="template-card-icon" style="background:${templateIconColor(t)}1A;">${templateIconHtml(t)}</div><div class="template-card-title">${escapeHtml(t.name)}</div><div class="template-card-actions">${canEditTemplate(t)?`<button type="button" class="template-icon-btn" aria-label="Edit template" title="Edit template" onclick="editTemplate(${Number(t.id)})"><svg class="ui-icon" aria-hidden="true"><use href="#i-pencil"/></svg></button>`:''}${['admin','manager'].includes(currentUser.role)?`<button type="button" class="template-icon-btn danger" aria-label="Delete template" title="Delete template" onclick="deleteTemplate(${Number(t.id)})"><svg class="ui-icon" aria-hidden="true"><use href="#i-trash"/></svg></button>`:''}</div></div>
        <div class="template-card-desc">${t.desc?escapeHtml(t.desc):'<span style="color:var(--text3);">No description</span>'}</div>
        <div class="template-card-facts">${facts}</div>
        ${tags.length?`<div class="template-card-tags">${tags.slice(0,3).map(tag=>`<span class="tag">${escapeHtml(tag)}</span>`).join('')}${tags.length>3?`<span class="template-more">+${tags.length-3}</span>`:''}</div>`:''}
        <div class="template-card-foot"><div class="template-card-by">${creator?escapeHtml(creator.name):escapeHtml(creatorLabel.replace(/^· /,''))}<br>${fmt(t.createdAt)}${!creator&&currentUser.role==='admin'?` · <button type="button" class="template-link-btn" onclick="editTemplate(${Number(t.id)})">Assign creator</button>`:''}</div>${canCreateWork()?`<button type="button" class="btn btn-primary btn-sm" onclick="useTemplate(${Number(t.id)})">Use Template</button>`:''}</div>
      </div>`;
    });
    html+=`</div><div class="template-expand-controls"><button type="button" id="template-expand" class="btn btn-ghost btn-sm" aria-controls="template-results" aria-expanded="false" onclick="toggleTemplateExpansion()" hidden>Show more templates</button></div>`;
  }
  html+=`<div id="template-search-empty" class="empty-state" hidden><p>No templates match your search.</p></div>`;
  const recurringWorks=works.filter(w=>w.recurrence&&w.status!=='done');
  if(recurringWorks.length>0){
    html+=`<div id="recurring-list" style="margin-top:28px;scroll-margin-top:16px;"><div class="section-header"><div><div class="section-title" style="font-size:16px;"><svg class="ui-icon" aria-hidden="true"><use href="#i-repeat"/></svg> Active Recurring Work</div></div></div>`;
    listPageSlice('recurring',recurringWorks).forEach(w=>{
      const rl=RECURRENCE_OPTIONS.find(o=>o.value===w.recurrence)?.label||'';
      html+=`<div class="work-item" onclick="openWorkDetail(${w.id})">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;">
          <span class="badge badge-${w.status==='upcoming'?'upcoming':PHASES[w.phase].toLowerCase()}">${w.status==='upcoming'?'Upcoming':PHASES[w.phase]}</span>
          <span class="badge" style="background:var(--primary-dim);color:var(--primary);border:1px solid rgba(59,111,212,0.2);"><svg class="ui-icon" aria-hidden="true"><use href="#i-repeat"/></svg> ${rl}</span>
        </div>
        <div style="font-size:16px;font-weight:700;">${escapeHtml(w.title)}</div>
        <div class="work-item-footer">${assigneesHtml(w.assignees)}<div class="meta-item"><svg class="ui-icon" aria-hidden="true"><use href="#i-flag"/></svg> ${fmt(w.deadline)}</div>${deadlineChip(w.deadline,w.status)}</div>
      </div>`;
    });
    html+=listPagerHtml('recurring',recurringWorks.length,'recurring work')+`</div>`;
  }
  document.getElementById('content').innerHTML=html;
  filterTemplates(searchValue);
}
function toggleTemplateExpansion(){
  const key=String(currentUser?.id);
  if(templateExpandedUsers.has(key))templateExpandedUsers.delete(key);else templateExpandedUsers.add(key);
  filterTemplates(templateSearchQueries.get(key)||'');
  const button=document.getElementById('template-expand');
  if(button&&!button.hidden)button.focus({preventScroll:true});
}
function filterTemplates(value){
  const key=String(currentUser?.id),query=String(value||'').trim().toLocaleLowerCase();
  if(String(value||'')!==(templateSearchQueries.get(key)||''))templateExpandedUsers.delete(key);
  templateSearchQueries.set(key,String(value||''));
  const grid=document.getElementById('template-results');
  const columns=grid?Math.max(1,getComputedStyle(grid).gridTemplateColumns.split(/\s+/).length):1;
  const limit=columns*3,expanded=templateExpandedUsers.has(key);
  const byId=new Map(templates.map(template=>[String(template.id),template]));
  let matches=0;
  document.querySelectorAll('#template-results [data-template-id]').forEach(card=>{
    const template=byId.get(card.dataset.templateId);
    const creator=template?.createdBy!=null?getMember(template.createdBy):null;
    const searchable=[template?.name,template?.title,template?.desc,...(template?.tags||[]),creator?.name].filter(Boolean).join(' ').toLocaleLowerCase();
    const match=!query||searchable.includes(query);
    card.hidden=!match||(!expanded&&matches>=limit);
    if(match)matches++;
  });
  const empty=document.getElementById('template-search-empty');
  if(empty)empty.hidden=!templates.length||matches>0;
  const button=document.getElementById('template-expand');
  if(button){button.hidden=matches<=limit;button.setAttribute('aria-expanded',String(expanded));button.textContent=expanded?'Show less':'Show more templates ('+(matches-limit)+')';}
}
window.addEventListener('resize',()=>{if(currentPage==='templates')filterTemplates(templateSearchQueries.get(String(currentUser?.id))||'');});
function useTemplate(id){if(!canCreateWork())return;const t=templates.find(x=>x.id===id);if(!t)return;document.getElementById('modal-title').textContent='New Work from Template';renderWorkForm(null,t);document.getElementById('modal-overlay').style.display='flex';}
async function deleteTemplate(id){if(!['admin','manager'].includes(currentUser.role))return;const t=templates.find(x=>x.id===id);if(!t||!await appConfirm('Delete template "'+t.name+'"?'))return;templates=templates.filter(x=>x.id!==id);if(!(await saveRequestsNow()))return;showToast('Template deleted.','info');renderTemplates();}

// ── RECURRENCE HELPERS ────────────────────────────────────
function getNextDate(deadline,recurrence,customDays){
  if(!deadline||!recurrence)return'';
  const d=new Date(deadline);
  switch(recurrence){
    case'weekly':d.setDate(d.getDate()+7);break;
    case'biweekly':d.setDate(d.getDate()+14);break;
    case'monthly':d.setMonth(d.getMonth()+1);break;
    case'quarterly':d.setMonth(d.getMonth()+3);break;
    case'custom':d.setDate(d.getDate()+(parseInt(customDays)||7));break;
    default:return'';
  }
  return d.toISOString().split('T')[0];
}
function getStartFromDeadline(oldStart,oldDeadline,newDeadline){
  if(!oldStart||!oldDeadline||!newDeadline)return newDeadline;
  const dur=new Date(oldDeadline)-new Date(oldStart);
  const ns=new Date(newDeadline);ns.setTime(ns.getTime()-dur);
  return ns.toISOString().split('T')[0];
}


function editNote(workId,noteIdx){
  const w=works.find(x=>x.id===workId);if(!w)return;
  const note=w.notes[noteIdx];if(!note)return;
  const canEdit=currentUser.role==='admin'||(note.authorId&&note.authorId===currentUser.id)||(note.authorName===currentUser.name&&!note.authorId);
  if(!canEdit){showToast('You can only edit your own notes.','error');return;}
  const notesEl=document.getElementById('notes-list-'+workId);if(!notesEl)return;
  const noteEl=notesEl.children[noteIdx];if(!noteEl)return;
  noteEl.innerHTML='<div class="note-meta">'+escapeHtml(note.authorName)+' &middot; '+fmt(note.createdDate||note.date)+'</div>'
    +'<textarea id="en-'+workId+'-'+noteIdx+'" maxlength="1000" data-count style="width:100%;margin-bottom:6px;min-height:60px;">'+escapeHtml(note.text)+'</textarea>'
    +'<div style="display:flex;gap:6px;"><button class="btn btn-primary btn-sm" onclick="saveEditNote('+workId+','+noteIdx+')">Save</button>'
    +'<button class="btn btn-ghost btn-sm" onclick="openWorkDetail('+workId+')">Cancel</button></div>';
}
async function saveEditNote(workId,noteIdx){
  const w=works.find(x=>x.id===workId);if(!w)return;
  const ta=document.getElementById('en-'+workId+'-'+noteIdx);if(!ta)return;
  const newText=ta.value.trim();if(!newText){showToast('Note cannot be empty.','error');return;}
  w.notes[noteIdx].text=newText;
  w.notes[noteIdx].editedDate=todayStr;
  if(!(await saveRequestsNow()))return;
  showToast('Note updated!','success');
  openWorkDetail(workId);
}
function copyPath(btn) {
  var path = btn.getAttribute('data-path');
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(path).then(function() {
      var orig = btn.textContent;
      btn.textContent = 'Copied!';
      btn.style.color = 'var(--green)';
      setTimeout(function() { btn.textContent = orig; btn.style.color = ''; }, 2000);
    }).catch(function(){showToast('Could not copy automatically. Select the displayed path and copy it manually.','error');});
  } else {
    var ta = document.createElement('textarea');
    ta.value = path; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); document.execCommand('copy');
    document.body.removeChild(ta);
    var orig = btn.textContent;
    btn.textContent = 'Copied!'; btn.style.color = 'var(--green)';
    setTimeout(function() { btn.textContent = orig; btn.style.color = ''; }, 2000);
  }
}

// ── MY PROFILE ────────────────────────────────────────────
