let profilePhotoDraft="",profilePhotoBusy=false,profilePhotoGeneration=0;
const PROFILE_TABS=[['profile','Profile'],['notifications','Notifications'],['security','Security']];
function openMyProfile() {
  const m = currentUser;
  if(!m)return;
  profilePhotoDraft=safeProfilePhoto(m.profilePhoto);profilePhotoBusy=false;profilePhotoGeneration++;
  const role=m.role.charAt(0).toUpperCase()+m.role.slice(1),notifications=notificationSettingsHtml(m);
  const tabs=PROFILE_TABS.filter(([key])=>key!=='notifications'||notifications);
  document.querySelector('#modal-overlay .modal')?.classList.add('modal-profile');
  document.getElementById('modal-title').textContent = 'My Profile';
  document.getElementById('modal-body').innerHTML = `
    <div class="pf">
      <div class="pf-hero">
        <div class="pf-avatar-wrap">
          <div id="profile-photo-preview" class="profile-photo-preview pf-avatar">${avatarHtml(m,76)}</div>
          <button type="button" class="pf-avatar-edit" aria-label="Upload photo" onclick="document.getElementById('profile-photo-file').click()"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></button>
        </div>
        <div class="pf-identity">
          <div class="pf-name">${escapeHtml(m.name)}</div>
          <div class="pf-meta"><span class="pf-role pf-role-${escapeHtml(m.role)}">${escapeHtml(role)}</span><span>@${escapeHtml(m.username||m.email)}</span></div>
          <div class="pf-photo-actions"><input id="profile-photo-file" type="file" accept="image/jpeg,image/png,image/webp" hidden onchange="chooseProfilePhoto(this)"><button type="button" class="pf-link" onclick="document.getElementById('profile-photo-file').click()">Upload photo</button><button id="profile-photo-remove" type="button" class="pf-link pf-link-muted" onclick="removeProfilePhoto()" ${profilePhotoDraft?'':'hidden'}>Remove</button><span id="profile-photo-status" class="pf-hint" role="status">JPG, PNG or WebP · up to 5 MB</span></div>
        </div>
      </div>
      <div class="pf-tabs" role="tablist" aria-label="Profile sections">${tabs.map(([key,label],index)=>`<button type="button" role="tab" id="pf-tab-${key}" class="pf-tab${index?'':' active'}" aria-selected="${!index}" aria-controls="pf-panel-${key}" onclick="switchProfileTab('${key}')">${label}</button>`).join('')}</div>
      <div class="pf-panels">
      <section class="pf-panel active" id="pf-panel-profile" role="tabpanel" aria-labelledby="pf-tab-profile">
        <div class="pf-grid">
          <div class="pf-field"><label for="p-name">Full name</label><input id="p-name" type="text" value="${escapeHtml(m.name)}"></div>
          <div class="pf-field"><label for="p-username">Username</label><div class="pf-affix"><span>@</span><input id="p-username" type="text" value="${escapeHtml(m.username||'')}"></div></div>
          <div class="pf-field"><label for="p-email">Email <em>optional</em></label><input id="p-email" type="email" value="${escapeHtml(m.email||'')}" placeholder="name@company.com"></div>
          <div class="pf-field"><label for="p-capacity">Weekly capacity</label><div class="pf-affix pf-affix-end"><input id="p-capacity" type="number" min="0" max="168" value="${Number(m.weeklyCapacityHours??40)}"><span>hours / week</span></div></div>
        </div>
        <div class="pf-grid">
          <div class="pf-field"><label>Avatar color</label>${colorPicker(m.color)}</div>
          <div class="pf-field pf-lang"><label>Help language</label>${helpLangSwitchHtml()}</div>
        </div>
      </section>
      ${notifications?`<section class="pf-panel" id="pf-panel-notifications" role="tabpanel" aria-labelledby="pf-tab-notifications">${notifications}</section>`:''}
      <section class="pf-panel" id="pf-panel-security" role="tabpanel" aria-labelledby="pf-tab-security">
        <p class="pf-intro">Change your password. Other signed-in sessions will be signed out.</p>
        <div class="pf-field"><label for="p-current-pass">Current password</label><input id="p-current-pass" type="password" autocomplete="current-password"></div>
        <div class="pf-grid">
          <div class="pf-field"><label for="p-new-pass">New password</label><input id="p-new-pass" type="password" autocomplete="new-password"></div>
          <div class="pf-field"><label for="p-confirm-pass">Confirm new password</label><input id="p-confirm-pass" type="password" autocomplete="new-password"></div>
        </div>
        <div class="pf-hint">Use at least 6 characters. Leave these empty to keep your current password.</div>
      </section>
      </div>
    </div>`;
  selectedColor = avatarColor(m.color);
  document.getElementById('modal-footer').innerHTML = `
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    <button id="profile-save-button" class="btn btn-primary" onclick="saveMyProfile()">Save changes</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}
function switchProfileTab(key){
  document.querySelectorAll('.pf-tab').forEach(tab=>{const on=tab.id==='pf-tab-'+key;tab.classList.toggle('active',on);tab.setAttribute('aria-selected',String(on));});
  document.querySelectorAll('.pf-panel').forEach(panel=>{const on=panel.id==='pf-panel-'+key;panel.classList.toggle('active',on);panel.inert=!on;panel.setAttribute('aria-hidden',String(!on));});
  const shown=document.getElementById('pf-panel-'+key);
  if(shown&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches)shown.animate([{opacity:0,transform:'translateY(6px)'},{opacity:1,transform:'none'}],{duration:240,easing:'cubic-bezier(.16,1,.3,1)'});
}

function renderProfilePhotoPreview(){
  const element=document.getElementById('profile-photo-preview');
  if(element)element.innerHTML=avatarHtml({...currentUser,profilePhoto:profilePhotoDraft},76);
  const remove=document.getElementById('profile-photo-remove');if(remove)remove.hidden=!profilePhotoDraft;
}
function removeProfilePhoto(){
  profilePhotoGeneration++;profilePhotoDraft='';profilePhotoBusy=false;draftActive=true;editGeneration++;
  const file=document.getElementById('profile-photo-file');if(file)file.value='';
  const save=document.getElementById('profile-save-button');if(save)save.disabled=false;
  const status=document.getElementById('profile-photo-status');if(status)status.textContent='Photo removed. Save Changes to apply.';
  renderProfilePhotoPreview();
}
async function chooseProfilePhoto(input){
  const file=input.files?.[0];if(!file)return;
  const generation=++profilePhotoGeneration,userId=currentUser?.id,preview=document.getElementById('profile-photo-preview');
  const status=document.getElementById('profile-photo-status'),save=document.getElementById('profile-save-button');
  const stillOpen=()=>generation===profilePhotoGeneration&&currentUser?.id===userId&&preview===document.getElementById('profile-photo-preview');
  let bitmap;
  try{
    if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Choose a JPG, PNG or WebP image.');
    if(file.size>5*1024*1024)throw new Error('Choose an image smaller than 5 MB.');
    profilePhotoBusy=true;if(save)save.disabled=true;if(status)status.textContent='Preparing photo…';
    bitmap=await createImageBitmap(file);
    if(!stillOpen())return;
    if(!bitmap.width||!bitmap.height||bitmap.width*bitmap.height>40000000)throw new Error('Choose an image with smaller dimensions.');
    const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;
    const context=canvas.getContext('2d');if(!context)throw new Error('Could not prepare your photo.');
    context.fillStyle='#fff';context.fillRect(0,0,256,256);context.imageSmoothingQuality='high';
    const side=Math.min(bitmap.width,bitmap.height);
    context.drawImage(bitmap,(bitmap.width-side)/2,(bitmap.height-side)/2,side,side,0,0,256,256);
    let photo='';for(const quality of [.85,.7,.55,.4]){photo=canvas.toDataURL('image/jpeg',quality);if(photo.length<=87000)break;}
    if(!safeProfilePhoto(photo)||photo.length>87000)throw new Error('Could not resize this photo. Choose another image.');
    profilePhotoDraft=photo;draftActive=true;editGeneration++;renderProfilePhotoPreview();
    if(status)status.textContent='Photo ready. Save Changes to apply.';
  }catch(error){if(stillOpen()){showToast(error.message||'Could not read this image.','error');if(status)status.textContent='JPG, PNG or WebP · up to 5 MB';}}
  finally{bitmap?.close();if(stillOpen()){profilePhotoBusy=false;if(save)save.disabled=false;input.value='';}}
}
async function saveMyProfile() {
  if(profilePhotoBusy){showToast('Wait for your photo to finish preparing.','error');return;}
  const m = TEAM.find(x => x.id === currentUser.id);
  if(!m) return;

  const name = document.getElementById('p-name').value.trim();
  const username = document.getElementById('p-username').value.trim();
  const email = document.getElementById('p-email').value.trim();
  const currentPass = document.getElementById('p-current-pass').value;
  const newPass = document.getElementById('p-new-pass').value;
  const confirmPass = document.getElementById('p-confirm-pass').value;
  const capacity=Number(document.getElementById('p-capacity').value);

  if(!name || !username || !Number.isFinite(capacity)||capacity<0||capacity>168) { showToast('Enter your name, username, and capacity from 0 to 168 hours.', 'error'); return; }

  // Check username uniqueness
  const dupU = TEAM.find(x => (x.username||'').toLowerCase() === username.toLowerCase() && x.id !== m.id);
  if(dupU) { showToast('Username already taken.', 'error'); return; }

  if(currentPass || newPass || confirmPass) {
    if(!currentPass||newPass.length<6||newPass!==confirmPass)switchProfileTab('security');
    if(!currentPass) { showToast('Enter your current password to change it.', 'error'); return; }
    if(newPass.length < 6) { showToast('New password must be at least 6 characters.', 'error'); return; }
    if(newPass !== confirmPass) { showToast('New passwords do not match.', 'error'); return; }
  }

  // Update profile
  m.name = name;
  m.username = username;
  m.email = email;
  m.weeklyCapacityHours=capacity;
  m.color = selectedColor;
  m.initials = makeInitials(name);
  m.profilePhoto = profilePhotoDraft;
  if(document.getElementById('p-notify-panel'))m.notificationPreferences=Object.fromEntries(NOTIFY_TYPES.map(type=>{const box=document.getElementById('p-notify-'+type.key);return[type.key,box?box.checked:notificationPreference(m,type.key)];}));
  if(document.getElementById('p-notify-panel'))m.notificationPreferences.reviewReady=m.notificationPreferences.workUpdates;

  // Update currentUser reference
  currentUser = m;

  // Update sidebar display
  updateSidebarAvatar(m);
  document.getElementById('sb-name').textContent = m.name;

  if(!(await saveRequestsNow()))return;
  if(newPass){
    try{const result=await sendJson('auth/change-password',{currentPassword:currentPass,password:newPass});await loadWorkspace(result.user);showToast('Profile and password updated. Other sessions were signed out.','success');}
    catch(error){showToast(error.message||'Password could not be changed.','error');return;}
  }else{
    showToast('Profile updated.','success');closeModal();
  }
}


// ── MOBILE MENU ───────────────────────────────────────────
function toggleMobileMenu() {
  try {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobile-overlay');
    if(!sidebar) return;
    const isOpen = sidebar.classList.contains('mobile-open');
    const button=document.getElementById('hamburger-btn');
    if(isOpen) {
      sidebar.classList.remove('mobile-open');
      if(overlay) overlay.classList.remove('show');
      if(button)button.setAttribute('aria-expanded','false');
    } else {
      sidebar.classList.add('mobile-open');
      if(overlay) overlay.classList.add('show');
      if(button)button.setAttribute('aria-expanded','true');
    }
  } catch(e) {}
}
function closeMobileMenu() {
  try {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobile-overlay');
    const button=document.getElementById('hamburger-btn');
    if(sidebar) sidebar.classList.remove('mobile-open');
    if(overlay) overlay.classList.remove('show');
    if(button)button.setAttribute('aria-expanded','false');
  } catch(e) {}
}

function openEditNameDesc(id){
  const w=works.find(x=>x.id===id);if(!w)return;
  const body=document.getElementById('modal-body');body.dataset.detailWorkId=String(id);
  const done=w.status==='done'&&currentUser.role==='admin';
  document.getElementById('modal-title').textContent=done?'Edit Completed Work':'Edit Name & Description';
  body.innerHTML=`<div class="form-group"><label class="form-label" for="end-title">Work Title *</label><input id="end-title" type="text" maxlength="120" data-count value="${escapeHtml(w.title)}"></div><div class="form-group"><label class="form-label" for="end-desc">Description</label><textarea id="end-desc" maxlength="2000" data-count style="white-space:pre-wrap;min-height:100px;">${escapeHtml(w.desc||'')}</textarea></div>`
    +(done?`<div class="form-row"><div class="form-group"><label class="form-label" for="end-estimate">Estimated effort (hours)</label><input id="end-estimate" type="number" min="0" max="10000" step="0.5" value="${Number(w.estimatedHours||0)}"></div><div class="form-group"><label class="form-label" for="end-actual">Actual effort (hours)</label><input id="end-actual" type="number" min="0" max="10000" step="0.5" value="${w.actualHours!=null?Number(w.actualHours):''}" placeholder="Not recorded"></div></div><div class="form-group"><label class="form-label" for="end-completed">Completion date</label><input id="end-completed" type="date" value="${escapeHtml(w.completedDate||'')}" max="${TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE)}"><div class="form-hint">Changes reports, on-time rate and weekly capacity for this work.</div></div>`:'');
  document.getElementById('modal-footer').innerHTML=`<button class="btn btn-primary" onclick="saveEditNameDesc(${Number(id)})">Save</button><button class="btn btn-ghost" onclick="openWorkDetail(${Number(id)})">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}
async function saveEditNameDesc(id){
  const w=works.find(x=>x.id===id);if(!w)return;
  const title=document.getElementById('end-title').value.trim();
  if(!title){showToast('Title is required.','error');return;}
  const estimateInput=document.getElementById('end-estimate');
  if(estimateInput){
    const estimate=Number(estimateInput.value||0),actualRaw=document.getElementById('end-actual').value.trim(),actual=Number(actualRaw),completed=document.getElementById('end-completed').value;
    const today=TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE);
    if(!Number.isFinite(estimate)||estimate<0||estimate>10000){showToast('Estimated hours must be between 0 and 10,000.','error');return;}
    if(actualRaw!==''&&(!Number.isFinite(actual)||actual<0||actual>10000)){showToast('Actual hours must be between 0 and 10,000.','error');return;}
    if(!TeamFlowDomain.parseDateKey(completed)||completed>today){showToast('Choose a completion date that is not in the future.','error');return;}
    w.estimatedHours=estimate;w.completedDate=completed;
    if(actualRaw==='')delete w.actualHours;else w.actualHours=actual;
  }
  w.title=title;w.desc=document.getElementById('end-desc').value;
  if(!(await saveRequestsNow()))return;
  showToast('Updated!','success');openWorkDetail(id);
}
function toggleSection(sectionId){
  var body=document.getElementById(sectionId);
  var arrId=sectionId.replace('sec-','arr-');
  var arr=document.getElementById(arrId);
  if(!body)return;
  var collapsed=body.classList.contains('collapsed');
  if(collapsed){body.classList.remove('collapsed');if(arr)arr.classList.remove('collapsed');}
  else{body.classList.add('collapsed');if(arr)arr.classList.add('collapsed');}
  document.getElementById('hdr-'+sectionId.replace('sec-',''))?.setAttribute('aria-expanded',String(collapsed));
  try{var state=JSON.parse(localStorage.getItem('sidebar_state')||'{}');
  if(!collapsed){state[sectionId]=true;}else{delete state[sectionId];}
  localStorage.setItem('sidebar_state',JSON.stringify(state));}catch(e){}
}
function restoreSidebarState(){
  try{var state=JSON.parse(localStorage.getItem('sidebar_state')||'{}');Object.keys(state).forEach(function(id){if(state[id]===true){var body=document.getElementById(id);var arr=document.getElementById(id.replace('sec-','arr-'));if(body)body.classList.add('collapsed');if(arr)arr.classList.add('collapsed');}});}catch(e){}
}
function renderChangelog(){
  var versions=[
    {ver:'2.5',date:'Nov 2026',title:'Window Title Bar, Past Meetings & Holiday-aware Capacity',items:[
      'Text fields have shorter limits that the forms now enforce, with a counter as you get close: titles 120 characters, work descriptions and meeting agendas 2,000, notes 1,000, minutes 5,000, action points 300 and feedback 1,500. Existing longer text is kept.',
      'The installed app has a new title bar, like ActuarialPro: Back and Forward, Toggle sidebar, File / Edit / View / Help menus with keyboard shortcuts, Find in page, zoom, and Quick open (Ctrl+K) to jump to any page, work item, meeting or action. The sync status sits on the right.',
      'Meetings that already took place can be recorded afterwards, for a meeting you forgot to schedule or an impromptu one. They are marked “Recorded afterwards”, send no invites or reminders, and the minutes can be added straight away.',
      'Public holidays no longer leave hours on a day nobody works: planned hours are spread over the remaining working days between start date and deadline. Each person’s share also skips their own leave.',
      'Search in the title bar: select it or press Ctrl+K and a search panel opens in the middle of the window, with Recently opened, your work and upcoming meetings shown before you type. Type mine, overdue, review or today to filter, and press Tab to switch between All, Pages, Work, Meetings and Actions.',
      'Smoother motion: pages, cards and dialogs ease in, tabs and the sidebar highlight slide, progress bars glide when a task or phase changes, and dashboard counters count up when a page opens. Reduce motion in the installed app’s View menu, or in your system settings, switches this off.',
      'Teammates who are online appear as small avatars in the title bar; select them to open Team. Team shows who is online, or when each person was last active, and lists up to four current projects with a link to the rest. Select a person to open their profile: current and upcoming work, overdue items, on-time rate, leave and recently completed work.',
      'Capacity is more compact and shows how far over someone is: the bar stretches past a marker at their capacity and the percentage sits beside the hours. Public holidays are noted once for the week, leave is shown per person, and each person’s work items fold away under the bar.',
      'The Dashboard shows the on-time rate over the last 12 months, with the change against last month, in place of the completed count, which only ever went up. The Dashboard PDF includes it too.',
      'Faster: after the first visit the app opens from this device instead of downloading itself again, shared changes download only what changed rather than all the team’s work, and Requests and Feedback no longer reload everything when opened. Feedback and Active Recurring Work now show 10 per page.',
      'Help & Guide covers everything new, and every tutorial opens in a floating panel you can move, resize and keep open while you work, with pictures and a Show me button that points out each control.',
      'Help & Guide, tutorial steps and Changelog can be read in Bahasa Indonesia: choose it under Help language in My Profile, or in the installed app’s View menu. Menus, buttons and exported reports stay in English.',
      'Edit and Delete in work detail moved into the ⋯ menu, so the main action stands out. The “new version” Reload button now always reloads.',
      'The installed app’s title bar has a deeper colour and keeps its size when you zoom the page. The search box stays in the middle of the window, and online teammates sit next to the Help menu. Every Export PDF now asks before it downloads, and the Saved note left the page header because the title bar already shows it.',
    ]},
    {ver:'2.4',date:'Nov 2026',title:'Review Sign-off, Meetings & Performance',items:[
      'Review sign-off: work in Review needs an approval from the PIC, a manager or an administrator before it can move on. Send Back returns it to Executing with a required comment, and every decision stays on record, including in Audit Report. A PIC approving their own work is labelled PIC self-review.',
      'Waiting for Your Sign-off on the Dashboard lists what needs your decision, oldest first, and the PIC is now alerted when someone else moves their work to Review.',
      'New Meetings page: schedule meetings with attendees, agenda, room or link, linked work and files; keep minutes and action points; and turn an action point into a work item. Upcoming and Past lists have pages.',
      'Meeting reminders: alerts for invites, changes and cancellations, a reminder within the hour before, an in-app banner, Add to Calendar, and Today’s Meetings on the Dashboard. Board members can be invited to meetings.',
      'Performance Analysis on completed work: a score, time in each phase, the slowest phase, and notes on what went well and what to improve.',
      'Team Performance in Audit Report: time per phase, on-time delivery, effort against estimate, review waits and first-time approvals, compared with the previous period, with breakdowns by work type, priority and tag. Export PDF saves it, and administrators also see figures by person, which stay out of the PDF.',
      'Leave and public holidays in Capacity reduce available hours for that week.',
      'Activity History now describes notes and file links added, edited or removed, assignees and PIC by name, recurrence and tags. Creation entries are simpler.',
      'Work detail has tabs, opens at the top, and keeps its action buttons visible as you scroll. Selecting a work chip in Capacity opens that work.',
      'Selecting the “ready for review” banner on Ongoing now shows those items.',
      'A cleaner look: one icon style and one set of text sizes throughout, more professional avatar colours, coloured sidebar icons, a slimmer scrollbar, calmer totals and alert banners, and redesigned template cards with a choice of icon and colour.',
      'New dropdown, date picker and start-time picker with a soft, consistent style. Work card descriptions now show one line, and they and calendar titles are cut between whole words. The full text stays in work detail.',
      'Exported reports have a new look that matches the app.',
      'Help & Guide now has step-by-step tutorials for every feature, and sections here and in Changelog can be collapsed.',
      'Daily Report is removed because it repeated the Dashboard. Export PDF is now on the Dashboard.',
      'Notification settings are simplified to three switches: work ready for your review is now part of Updates on your work.',
      'Sign Out shows that it is working, changing assignees right after adding a note no longer fails, and Manage Assignees no longer warns about pending edits after you cancel a form.',
    ]},
    {ver:'2.3',date:'Oct 2026',title:'Conversations, Alerts & Search',items:[
      'New notes alert everyone working on the work (except the author) and show a green unread badge on the work card until you open it.',
      'Daily alerts now include work due today as well as overdue work.',
      'The PIC is alerted when someone else moves their work to another phase or completes it.',
      'Search finds work by assignee, PIC, tags, phase, priority, notes and file names, in any word order.',
      'A skeleton screen replaces the loading spinner so the app feels faster.',
      'Activity History now says which phase work moved to and which tasks were checked or unchecked, plus status, deadline and hours changes.',
      'After an update, people who have not switched on notifications on a device are taken to the notification settings once.',
      'Recurring work now starts with a TeamFlow note explaining how it was created, and keeps the original creator.',
      'Staying signed in or being signed out automatically no longer switches off alerts on a device; only Sign Out does.',
      'A banner announces new versions; Reload updates TeamFlow without closing every window.',
    ]},
    {ver:'2.2',date:'Oct 2026',title:'Automation, Actual Effort & Notifications',items:[
      'Upcoming work starts automatically (Ongoing, Planning phase) once its start date arrives.',
      'Mark Complete asks for actual effort hours, prefilled with the estimate; cards and details show actual vs estimated.',
      'Weekly capacity keeps completed work in the weeks it ran, using actual hours.',
      'Admins can correct the estimate, actual effort and completion date of completed work.',
      'Audit reports and PDF exports compare actual and estimated hours for completed work, including each person\'s share of actual hours in the Annual Report.',
      'Admins can assign a creator to templates whose creator is missing or removed.',
      'Admin-managed default tags appear as quick picks in work and template forms; custom tags still work.',
      'Desktop notifications for review-ready and overdue work, including when TeamFlow is closed (web push), with per-person settings in My Profile.',
    ]},
    {ver:'2.1',date:'Oct 2026',title:'Capacity, Collaboration & Reporting',items:[
      'Members can create work, edit their own templates, and manage assignees as creator or PIC.',
      'Templates include estimated hours, creator details, and search.',
      'Profile photo upload and refreshed team cards.',
      'Dashboard redesign with deadline sorting, priority badges, and updated workload colors.',
      'Responsive filters saved separately for each user and page; refresh preserves scroll position.',
      'Weekly capacity and paginated work and activity history.',
      'Lower-cost background sync with shared read caching and coordinated tabs.',
      'Calendar date details include completed work within its original schedule.',
      'Improved report counts, historical completion flags, compact controls, and PDF exports.',
      'Daily Report rendering fix, account setup/reset links, and updated Help & Guide.',
    ]},
    {ver:'2.0',date:'Sep 2026',title:'Major Feature Update',items:[
      'Work Type Classification (Regular / Ad-hoc) with color-coded badges',
      'Move Phase Back — return work to previous phase with system note',
      'Multiline description support with Enter key formatting',
      'Editable Notes — authors and admins can edit notes with timestamp',
      'Improved Sort & Filter — 7 sort options + 4 filters on Ongoing & History',
      'Board Role — executive view-only access with note-adding capability',
      'Admin can edit completed work name/description + Reopen Work button',
      'Full Template Editor — edit all fields including phase tasks',
      'Calendar Enhancement — 3-section date modal (Starting/Deadlines/Active)',
      'Prevent overlay close on Add/Edit Work and Add File Link modals',
      'Templates & Requests pages hidden from Board role',
      'Changelog, Help & Guide, and Feedback pages added',
    ]},
    {ver:'1.5',date:'Sep 2026',title:'Workflow & Collaboration',items:[
      'Join/Leave request system with PIC/Manager approval workflow',
      'PIC (Person in Charge) field on all work items',
      'Daily Report page with PDF export',
      'Weekly & Monthly Audit Reports with PDF export',
      'Username-based login (no email required)',
      'Work Templates — save and reuse work structures',
      'Recurring Work — weekly, biweekly, monthly, quarterly, custom intervals',
      'Calendar view with month picker in Upcoming page',
      'Auto-advance phase tasks when moving to next phase',
      'Copy Path button for internal network file links',
    ]},
    {ver:'1.0',date:'Sep 2026',title:'Initial Release',items:[
      'Ongoing, Upcoming, and History work pages',
      'Work phases: Planning to Executing to Review to Finalize',
      'Customizable phase tasks per work item',
      'Role-based access: Admin, Manager, Member',
      'File/folder links per work item (Google Drive, Figma, internal paths)',
      'Notes & Updates on work items',
      'Team management with Admin panel',
      'Daily digest with overdue alerts and review-ready highlights',
      'Session persistence — stay logged in on refresh',
      'Mobile responsive with hamburger menu',
      'PWA support — add to home screen as app',
    ]},
  ];
  var html='';
  versions.forEach(function(v,index){
    html+='<details class="card collapsible-card"'+(index===0?' open':'')+'><summary><div style="display:flex;align-items:center;gap:12px;flex:1;min-width:0;"><div style="background:var(--primary);color:#fff;border-radius:var(--radius-sm);padding:4px 10px;font-size:13px;font-weight:700;">v'+v.ver+'</div><div style="font-size:13px;font-weight:700;">'+v.title+'</div><div style="font-size:12px;color:var(--text3);margin-left:auto;">'+v.date+'</div></summary><ul style="margin:0;padding-left:20px;">';
    v.items.forEach(function(item){html+='<li'+longTextLang(item)+' style="font-size:13px;color:var(--text2);margin-bottom:6px;">'+longText(item)+'</li>';});
    html+='</ul></details>';
  });
  document.getElementById('content').innerHTML=html;
}
function renderHelp(){
  var sections=[
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-pin"/></svg>',title:'Work Management',items:[
      '<strong>Add Work</strong> — Admins, managers, and members can create work from Ongoing, Upcoming, or Templates. Set dates, estimated hours, work type, recurrence, PIC, assignees, and phase tasks. Members are automatically assigned to work they create.',
      '<strong>Work Types</strong> — Regular uses a solid blue border; Ad-hoc uses a dashed orange border.',
      '<strong>Phases</strong> — Planning → Executing → Review → Finalize. Use work-detail actions to advance or return to a previous phase.',
      '<strong>Work Detail</strong> — Opening a work item shows its details with tabs: Overview (phases, sign-off, team and files), Notes, Meetings, Performance on completed work, and History. The action buttons stay visible at the bottom as you scroll; Edit and Delete are in the ⋯ menu beside them.',
      '<strong>Review Sign-off</strong> — Items waiting on you show on the dashboard, oldest first. Work in Review needs a decision before it can move on. The PIC, a manager or an administrator can Approve (comment optional) or Send Back to Executing (comment required). A PIC deciding on their own work is recorded as PIC self-review. Every decision stays on the work, in Activity History and in the Audit Report; work returning to Review needs a new decision.',
      '<strong>Performance Analysis</strong> — Completed work shows a score out of 100 from fixed rules: Delivery (40), Effort vs estimate (20), Rework (20) and Review wait (20). Delivery uses the deadline set when work started, so later extensions don’t erase lateness. Measures without data are left out and the score shows in grey as partial. A PIC approving their own work earns no Review wait or Rework points. It also shows time in each phase, leaving out weekends, and flags the slowest phase. The score is indicative: use it to decide where to look, not to assess people. Work finished before detailed history began in v2.3 gets a partial analysis.',
      '<strong>Automatic Start</strong> — Upcoming work moves to Ongoing (Planning phase) automatically within an hour of its start date arriving in the team timezone. Start Work still starts it early.',
      '<strong>Completing Work</strong> — Mark Complete asks for the actual effort in hours, prefilled with the estimate. Completed cards show actual / estimated hours. Admins can correct the title, description, estimate, actual effort and completion date with Edit Completed Work.',
      '<strong>Tags</strong> — Pick from the default tags set by Admin, or type your own separated by commas. Admins manage the default list in Admin Panel → Default Tags.',
      '<strong>Edit Work</strong> — Estimated effort and work type share a row on wider screens. PIC follows recurrence. Save changes to update assignments and capacity.',
      '<strong>Files &amp; Notes</strong> — Attach web links or Windows and network paths from the Overview tab, and add notes on the Notes tab where your role permits. Use Copy Path for Windows and network paths.',
      '<strong>History Tab</strong> — The History tab shows who changed a work item and when: phase moves, ticked tasks, status, dates, hours, priority, tags, sign-off decisions, notes and file links added, edited or removed, assignees added or removed, PIC and recurrence. Creation entries show no detail, and entries older than these details only list the fields that changed.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-search"/></svg>',title:'Search &amp; Filters',items:[
      '<strong>Search Work</strong> — Smart search looks through titles, descriptions, tags, assignee and PIC names, phase, priority, notes and linked file names. Type several words in any order, for example "sam ifrs review". Combine search with work type, priority, PIC, and the available phase filter.',
      '<strong>Title Bar Search</strong> — In the installed app, select the search box in the title bar, or press Ctrl+K. A search panel opens in the middle of the window, with results grouped into pages, work, meetings and actions, and before you type it lists Recently opened, your work and upcoming meetings. Add mine, overdue, review or today to filter, press Tab to switch between All, Pages, Work, Meetings and Actions, and Enter to open the highlighted result.',
      '<strong>Sorting</strong> — Order by deadline, title, or creation date. Phase filtering is available on Ongoing.',
      '<strong>Ready for Review</strong> — On Ongoing, select the “ready for review” banner to show only work in Review, and select it again to show everything. It uses the Phase filter, so Reset also clears it.',
      '<strong>Independent Choices</strong> — Each account and page keeps its own search, filters, and sorting in this browser. Choices survive navigation, refresh, and reload; they are not shared with other users or devices.',
      '<strong>Reset</strong> — The arrow icon beside the filters clears only the current account and page. Controls wrap automatically on smaller screens.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-users"/></svg>',title:'Accounts &amp; Roles',items:[
      '<strong>Admin</strong> — Manages team accounts, default tags and work, including completed-work edits and reopening. Can sign off work, and can edit or cancel any meeting.',
      '<strong>Manager</strong> — Creates and manages work, assignments, templates, and join/leave approvals. Signs off work in Review, and records anyone’s leave and public holidays.',
      '<strong>Member</strong> — Creates work and meetings, edits permitted fields on assigned work or work they own as PIC, and edits templates they created. The work creator or PIC can change assignees; members request to join or leave other work. Records their own leave.',
      '<strong>Board</strong> — Read-only access, including reports and Team Performance. Can be invited to meetings and gets their reminders, but cannot create or edit work or meetings, add notes or minutes, or sign off.',
      '<strong>PIC</strong> — Responsible for the work, assignee changes, and join/leave approvals. Can sign off their own work, recorded as PIC self-review. Only admins and managers can transfer the PIC. PIC effort weighting takes precedence over role.',
      '<strong>Passwords</strong> — Sign in with your username and password. Contact Admin for a single-use reset link valid for 30 minutes. Initial invitation links last 24 hours and can be used once.',
      '<strong>My Profile</strong> — Update your name, username, email, weekly capacity, and avatar color. Upload a JPG, PNG, or WebP photo up to 5 MB, preview it, then Save Changes. Photos are cropped and resized automatically; Remove photo restores initials. Passwords require at least 6 characters; changing one signs out other sessions.',
      '<strong>Notifications</strong> — In My Profile, select Turn on for this device to allow notifications; each browser or installed app asks separately. Then choose your alerts: updates on your work (new notes, phase changes, and work ready for your review), meetings, and work due today or overdue (once a day).',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg>',title:'Schedule &amp; Calendar',items:[
      '<strong>Upcoming</strong> — The month calendar appears above the work search and filters. Use the chevron buttons, month/year selectors, or Today to navigate.',
      '<strong>Weeks</strong> — Calendar columns run Monday–Sunday, matching Capacity and weekly Audit reports.',
      '<strong>Flag Fills</strong> — Light blue marks a start date; red marks a deadline.',
      '<strong>Flag Borders</strong> — Solid blue identifies Regular work; dashed orange identifies Ad-hoc work, for both starts and deadlines.',
      '<strong>Date Details</strong> — Click a date to view Starting Today, Deadlines Today, Active Work, and Completed Work. Completed work remains visible throughout its original start-to-deadline range; the start and deadline dates stay in their respective sections.',
      '<strong>History</strong> — Calendar date details show the current completed status even for selected dates before the actual completion date. Open a card to inspect the work.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-calendar"/></svg>',title:'Meetings',items:[
      '<strong>Schedule</strong> — Admins, managers and members can create a meeting with + New Meeting in the top bar, or from a work item’s Meetings tab, which links that work. Times use Jakarta GMT +7.',
      '<strong>Linked Work</strong> — A meeting can link to several work items or none. It shows on each linked work and stays available after that work is completed.',
      '<strong>Meetings Page</strong> — Upcoming and Past lists show 10 meetings per page, each with its time, place, organizer, attendees and links. Your meetings for today also show on the Dashboard.',
      '<strong>Reminders</strong> — Attendees get an alert when invited, when the time or place changes, and when a meeting is cancelled, plus a reminder within the hour before, which can arrive anywhere from a few minutes to an hour ahead. A banner also shows in the app during the last hour. Turn these alerts on or off in My Profile → Notifications.',
      '<strong>Add to Calendar</strong> — Downloads a calendar file so your phone or computer can raise its own alarm 15 minutes before.',
      '<strong>Minutes &amp; Action Points</strong> — Attendees, the organizer and administrators can record minutes and action points, and link files and folders. Create Work turns an action point into a work item and links it to the meeting. Only the organizer or an administrator can edit or cancel a meeting. Everyone signed in can read meetings, except that Board cannot make changes.',
      '<strong>Record Afterwards</strong> — For a meeting you forgot to schedule or an impromptu one, create it with its real date and time. Once that time has passed, the button changes to Record Meeting: it is saved as held and marked Recorded afterwards, sends no invites or reminders, and you can add the minutes straight away.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-scale"/></svg>',title:'Weekly Capacity',items:[
      '<strong>Included People</strong> — Weekly capacity shows members and managers.',
      '<strong>Set Capacity</strong> — Set weekly hours in My Profile, or use Admin → Edit Member to manage team capacity.',
      '<strong>Estimate Work</strong> — Enter total estimated hours on a work item. Capacity compares planned effort with availability.',
      '<strong>Completed Work</strong> — Completed work stays in capacity for the weeks it actually ran, from start date to completion date, using its actual hours (or the estimate if none was recorded). Its chips are labelled Done.',
      '<strong>Weekday Split</strong> — Hours are spread evenly across the working days from start through deadline, inclusive. Weekends and public holidays receive no hours, and each person’s share also skips their own leave. If every weekday in the range is a day off, the hours stay on those days and show as over capacity. Work with no scheduled weekdays is flagged for date adjustment.',
      '<strong>Effort Shares</strong> — Shares are normalized so the total estimate stays unchanged; the PIC is included even if not separately assigned.',
      '<strong>Example</strong> — A 10-hour individual share scheduled Oct 3–7, 2026 falls entirely in Oct 5–7 because Oct 3–4 is a weekend.',
      '<strong>Leave &amp; Holidays</strong> — Anyone can record their own leave. Managers and administrators can record anyone’s leave and public holidays. These reduce available hours for that week, and planned hours move to the other working days between the work’s start date and deadline.',
      '<strong>Navigate</strong> — Use the chevron buttons to inspect each Monday–Sunday week. The line under the dates says how many people are over capacity and names any public holiday that week.',
      '<strong>Reading a Row</strong> — Each person shows planned hours against the hours they have that week, with the percentage beside them and a Leave tag when they are away. Past their limit, the bar runs on in red after a marker, so you can see how far over they are.',
      '<strong>Open Work</strong> — Select N work items under a person’s bar to show the work behind their hours, then select an item to open it.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg>',title:'Dashboard Report',items:[
      '<strong>Contents</strong> — Export PDF on the Dashboard downloads the Dashboard Report: the totals, including the on-time rate over the last 12 months and its change against last month, then overdue, review-ready and ongoing work, and upcoming deadlines.',
      '<strong>Export</strong> — Export PDF asks you to confirm, then downloads a printable report. Open the downloaded file and use Print → Save as PDF.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-chart"/></svg>',title:'Dashboard, Audit &amp; History',items:[
      '<strong>Dashboard</strong> — The totals show first, then alerts for overdue and review-ready work, then Waiting for Your Sign-off (oldest first, red from 3 days in Review) and Today’s Meetings. The totals include the on-time rate over the last 12 months: work completed by its deadline as a share of completed work that had one, with the change against last month. It turns red below 75%. Below are six active work items sorted by earliest deadline. Phase/priority summaries, Due Soon, and Team Workload share a balanced layout. View capacity opens Capacity; workload summaries include active members and managers.',
      '<strong>Team Performance</strong> — In Audit Report, admins, managers and Board can see a summary, time per phase, on-time delivery, effort against estimate, review waits and first-time approvals, compared with the previous period, plus breakdowns by work type, priority and tag, and the longest-running items. Phase figures only count work with a full, believable history. Export PDF saves the report. Administrators also see figures by person, which are left out of the PDF.',
      '<strong>Team &amp; Profiles</strong> — Team shows who is online, or when each person was last active, and up to four current projects. Select a person to open their profile: ongoing work, work they lead as PIC, overdue items, on-time rate, upcoming work, leave and recently completed work. In the installed app, teammates who are online also appear as small avatars in the title bar.',
      '<strong>Sign-off in Reports</strong> — Completed work in Audit Report shows who approved it, labelled when it was a PIC self-review, and the exported PDF includes it. Work completed before sign-off began shows no approval.',
      '<strong>Weekly Audit</strong> — Uses Monday–Sunday weeks. Completed work is grouped by completion date within the selected period.',
      '<strong>Annual Audit</strong> — Uses January–December of the selected year and includes member and manager performance for assignments and PIC responsibilities. Use the centered chevrons to change years; Export PDF beside the title includes member performance.',
      '<strong>Monthly Audit</strong> — Uses the selected calendar month. Date ranges use the team time zone, Jakarta GMT +7.',
      '<strong>Ongoing Work</strong> — Past reports count work started by period end and not completed until afterward, including overdue carryover. Current-period reports include every item marked ongoing, even if its planned start date is later. Upcoming work is excluded.',
      '<strong>Period Totals</strong> — Monthly and annual Work in period equals Completed plus Ongoing. Creation date does not determine inclusion; work starting later is excluded unless it is already marked ongoing in the current period.',
      '<strong>Completed Later</strong> — Work finished after a historical cutoff stays in that period’s ongoing count. Its row shows Completed with the actual date and 100% progress. Other phase/progress values show current work details.',
      '<strong>Reporting Cutoff</strong> — Past periods use their end date. Current periods use today; upcoming periods do not project unfinished work or overdue dates into the future.',
      '<strong>Actual vs Estimated</strong> — Completed-work sections show each item\'s actual / estimated hours and a total with the % difference. Totals only include items with actual hours recorded. The Annual Report shows each person\'s share of actual hours, split with the same PIC / member / manager weights as capacity.',
      '<strong>On-time Rate</strong> — Period completions with a deadline are eligible. The rate is the number completed on or before the deadline divided by eligible completions.',
      '<strong>History &amp; Performance</strong> — History contains completed work; Annual Report includes member-level summaries. Use the weekly/monthly/annual arrows to change report periods.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-clipboard"/></svg>',title:'Templates, Recurrence &amp; Requests',items:[
      '<strong>Templates</strong> — Admins, managers, and members can save and reuse work structures, phase tasks, and estimated hours. Members edit only templates they created; admins and managers can edit all templates. Cards show the creator and creation date. Use the search bar to find templates by name, description, tag, or creator. When a creator is not recorded or was removed, Admin can select Assign creator.',
      '<strong>Template Icons</strong> — Choose an icon and a colour when saving a template, or later with the pencil on its card. Agreeing what each colour means, such as one per type of work, keeps the page easy to scan.',
      '<strong>Recurrence</strong> — Choose a recurrence in the work form. Completing the work creates its next occurrence. Active Recurring Work on Templates lists 10 series per page.',
      '<strong>Join / Leave</strong> — Members request to join active work or leave an assignment; PICs and managers review requests on the Requests page. PICs cannot request to leave their own work.',
    ]},
    {icon:'<svg class="ui-icon" aria-hidden="true"><use href="#i-save"/></svg>',title:'Saving &amp; Accessibility',items:[
      '<strong>Install App</strong> — In Chrome, choose Cast, save, and share → Install page as app. When a new version is released, a banner offers Reload; select it to update without closing your windows.',
      '<strong>Title Bar</strong> — The installed app has its own title bar with Back and Forward, Toggle sidebar, File / Edit / View / Help menus with their keyboard shortcuts, search (Ctrl+K), Find in page (Ctrl+F), zoom and the sync status. If an older install still shows Chrome’s bar, close every TeamFlow window and open it again.',
      '<strong>Fast Start</strong> — After the first visit, the app itself loads from this device, so it opens quickly even on a slow connection, and a reconnect page shows when you are offline. Sign-in, shared work, feedback and saving still need an internet connection.',
      '<strong>Automatic Refresh</strong> — Shared changes are checked every 30 seconds while the page is visible, and only what changed is downloaded. Refresh preserves your scroll position; open forms pause shared refresh while you edit.',
      '<strong>Saving</strong> — Task checkmarks update immediately while saving. Wait for Saved before leaving. If saving fails, edits are kept; use Retry for a connection error, or resolve a save conflict.',
      '<strong>Text Limits</strong> — Titles take up to 120 characters, work descriptions and meeting agendas 2,000, notes 1,000, minutes 5,000, action points 300 and feedback 1,500. A counter appears as you get close. Text saved before these limits is kept.',
      '<strong>Conflicting Edits</strong> — If someone changed the same record, your edits are kept. Select Review conflict to choose a version for each field both people changed, or use the latest saved version.',
      '<strong>Tutorials</strong> — Each Help section starts with step-by-step tutorials. A tutorial opens in a floating panel that stays open while you try the steps: drag it by its header, resize it from the corner (double-click the corner to reset), or minimise it. Take me there opens the right page, Show me points out the control, and selecting a picture enlarges it. On a phone it opens as a sheet at the bottom.',
      '<strong>Help Language</strong> — Help & Guide descriptions, tutorial steps and Changelog can be read in English or Bahasa Indonesia. Choose it under Help language in My Profile, or in the installed app’s View menu. Menus, buttons and exported reports stay in English, and the choice is remembered on this device.',
      '<strong>Keyboard &amp; Mobile</strong> — Use Tab to move through controls and Enter or Space to activate buttons. Visible focus and reduced-motion support help navigation; the mobile menu opens from the top bar.',
    ]},
  ];
  var html='';
  sections.forEach(function(s){
    html+='<details class="card collapsible-card"><summary><span style="font-size:22px;">'+s.icon+'</span><div style="flex:1;min-width:0;font-size:16px;font-weight:700;">'+s.title+'</div></summary>'+helpTutorialsHtml(s.title)+'<ul style="margin:0;padding-left:20px;">';
    s.items.forEach(function(item){html+='<li'+longTextLang(item)+' style="font-size:13px;color:var(--text2);margin-bottom:8px;line-height:1.5;">'+longText(item)+'</li>';});
    html+='</ul></details>';
  });
  document.getElementById('content').innerHTML=html;
}
// Shared 10-per-page pager for simple lists (feedback, active recurring work). Pages are kept per list for the session.
const LIST_PAGE_SIZE=10,listPages={};
function listPageSlice(key,items){const pages=Math.max(1,Math.ceil(items.length/LIST_PAGE_SIZE));listPages[key]=Math.min(Math.max(1,listPages[key]||1),pages);const start=(listPages[key]-1)*LIST_PAGE_SIZE;return items.slice(start,start+LIST_PAGE_SIZE);}
function listPagerHtml(key,total,label){
  if(total<=LIST_PAGE_SIZE)return'';
  const pages=Math.ceil(total/LIST_PAGE_SIZE),page=listPages[key]||1,start=(page-1)*LIST_PAGE_SIZE;
  return`<nav class="history-pagination" aria-label="${label} pages"><span role="status">Showing ${start+1}–${Math.min(start+LIST_PAGE_SIZE,total)} of ${total}</span><div class="history-page-controls"><button type="button" class="btn btn-ghost btn-sm" onclick="changeListPage('${key}',${page-1})" ${page===1?'disabled':''} aria-label="Previous ${label} page">Previous</button><span>Page ${page} of ${pages}</span><button type="button" class="btn btn-ghost btn-sm" onclick="changeListPage('${key}',${page+1})" ${page===pages?'disabled':''} aria-label="Next ${label} page">Next</button></div></nav>`;
}
function changeListPage(key,page){
  listPages[key]=Math.max(1,page);
  if(key==='feedback'){renderFeedback(false);document.getElementById('feedback-list')?.scrollIntoView({block:'start'});}
  else if(key==='recurring'){renderTemplates();document.getElementById('recurring-list')?.scrollIntoView({block:'start'});}
}
let feedbackBusy=false;
let pendingFeedbackId=null;
async function renderFeedback(refresh=true){
  const content=document.getElementById('content');
  if(refresh&&!hasPendingChanges&&!draftActive&&!feedbackBusy){
    renderFeedback(false);
    // Background sync keeps the data current; this only asks it to check now (it downloads just what changed).
    const marker=beginPageRefresh(content);
    try{await backgroundSync({force:true});}
    catch(error){if(marker.isConnected)showToast('Could not refresh feedback. Existing entries are shown.','error');}
    finally{marker.remove();}
    return;
  }
  var cats=['Bug Report','Suggestion','Compliment','Other'];
  var statuses={open:{label:'Open',color:'var(--primary)'},noted:{label:'Noted',color:'var(--yellow)'},inprogress:{label:'In Progress',color:'var(--orange)'},done:{label:'Done',color:'var(--green)'}};
  var html='';
  if(currentUser.role!=='board')html+='<div class="card" style="margin-bottom:20px;"><div class="card-title" style="margin-bottom:12px;"><svg class="ui-icon" aria-hidden="true"><use href="#i-pen"/></svg> Submit Feedback</div>'
    +'<div class="form-row"><div class="form-group"><label class="form-label" for="fb-cat">Category</label>'
    +'<select id="fb-cat" class="app-select">'+cats.map(function(c){return'<option>'+c+'</option>';}).join('')+'</select></div>'
    +'<div class="form-group"><label class="form-label" for="fb-name">Your Name</label>'
    +'<input id="fb-name" class="app-input" type="text" maxlength="120" autocomplete="name" value="'+escapeHtml(currentUser?currentUser.name:'')+'" placeholder="Your name"></div></div>'
    +'<div class="form-group"><label class="form-label">Feedback *</label>'
    +'<textarea id="fb-text" maxlength="1500" data-count placeholder="Describe your feedback, suggestion, or issue..." style="min-height:80px;"></textarea></div>'
    +'<button class="btn btn-primary" onclick="submitFeedback()">Submit Feedback</button></div>';
  if(!feedbackItems.length){
    html+='<div class="empty-state"><div class="icon"><svg class="ui-icon" aria-hidden="true"><use href="#i-message"/></svg></div><p>No feedback yet. Be the first to share!</p></div>';
  } else {
    var feedbackAll=feedbackItems.slice().reverse();
    html+='<div id="feedback-list" style="display:flex;flex-direction:column;gap:12px;scroll-margin-top:16px;">';
    listPageSlice('feedback',feedbackAll).forEach(function(fb){
      var st=statuses[fb.status]||statuses.open;
      var isAdmin=currentUser&&['admin','manager'].includes(currentUser.role);
      var adminBtns=isAdmin?('<div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap;">'
        +'<button class="btn btn-ghost btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'noted\')"><svg class="ui-icon" aria-hidden="true"><use href="#i-eye"/></svg> Noted</button>'
        +'<button class="btn btn-ghost btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'inprogress\')" style="color:var(--orange);"><svg class="ui-icon" aria-hidden="true"><use href="#i-wrench"/></svg> In Progress</button>'
        +'<button class="btn btn-success btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'done\')"><svg class="ui-icon" aria-hidden="true"><use href="#i-check"/></svg> Done</button>'
        +'<button class="btn btn-danger btn-sm" onclick="deleteFeedback('+Number(fb.id)+')"><svg class="ui-icon" aria-hidden="true"><use href="#i-trash"/></svg></button>'
        +'</div>'):'';
      html+='<div class="card"><div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;">'
        +'<span class="badge" style="background:var(--primary-dim);color:var(--primary);border:1px solid rgba(59,111,212,0.2);">'+escapeHtml(fb.category)+'</span>'
        +'<span class="badge" style="background:rgba(0,0,0,0.05);color:'+st.color+';">'+st.label+'</span>'
        +'<span style="font-size:12px;color:var(--text3);margin-left:auto;">'+escapeHtml(fb.author)+' &middot; '+fmt(fb.date)+'</span>'
        +'</div><div style="font-size:13px;color:var(--text);line-height:1.6;white-space:pre-wrap;">'+escapeHtml(fb.text)+'</div>'+adminBtns+'</div>';
    });
    html+='</div>'+listPagerHtml('feedback',feedbackAll.length,'feedback');
  }
  document.getElementById('content').innerHTML=html;
}
async function submitFeedback(){
  if(feedbackBusy)return;
  const text=document.getElementById('fb-text').value.trim();
  if(!text||text.length>1500){showToast('Enter feedback of 1–1,500 characters.','error');return;}
  if(currentUser.role==='board'){showToast('Board accounts have read-only access.','error');return;}
  const entry={id:pendingFeedbackId||newRecordId(),category:document.getElementById('fb-cat').value,author:document.getElementById('fb-name').value.trim()||currentUser.name,authorId:currentUser.id,text,date:todayStr,status:'open'};
  feedbackBusy=true;
  pendingFeedbackId=entry.id;
  feedbackItems=feedbackItems.filter(item=>item.id!==entry.id);feedbackItems.push(entry);
  try{if(await saveRequestsNow()){showToast('Feedback submitted.','success');pendingFeedbackId=null;draftActive=false;await renderFeedback();}}
  finally{feedbackBusy=false;}
}
async function setFeedbackStatus(id,status){
  if(feedbackBusy||!['admin','manager'].includes(currentUser.role))return;
  const fb=feedbackItems.find(item=>item.id===id);if(!fb)return;
  feedbackBusy=true;fb.status=status;
  try{if(await saveRequestsNow()){await renderFeedback();showToast('Feedback updated.','success');}}
  finally{feedbackBusy=false;}
}
async function deleteFeedback(id){
  if(feedbackBusy||!['admin','manager'].includes(currentUser.role)||!await appConfirm('Delete this feedback?'))return;
  feedbackBusy=true;feedbackItems=feedbackItems.filter(item=>item.id!==id);
  try{if(await saveRequestsNow()){await renderFeedback();showToast('Feedback deleted.','success');}}
  finally{feedbackBusy=false;}
}
function closeModal(){const modalBody=document.getElementById('modal-body');if(modalBody){modalBody._unreadAtOpen=null;delete modalBody.dataset.detailWorkId;delete modalBody.dataset.detailMeetingId;}document.getElementById('account-link-result')?.remove();document.querySelector('#modal-overlay .modal')?.classList.remove('modal-profile');document.getElementById('modal-overlay').style.display='none';if(!hasPendingChanges)draftActive=false;}
function closeModalOnOverlay(e){
  if(e.target!==document.getElementById('modal-overlay'))return;
  const title=(document.getElementById('modal-title').textContent||'');
  const prot=['Leave & Holidays','New Meeting','Edit Meeting','Approve Review','Send Back from Review','Add New Work','Edit Work','New Work from Template','Add File / Folder Link','Edit Template','Complete Work','Edit Completed Work'];
  if(prot.some(t=>title.includes(t)))return;
  closeModal();
}

// ── DESKTOP NOTIFICATIONS ─────────────────────────────────
// Shown while TeamFlow is open or running as an installed app; each device keeps its own record of what it already showed.
const NOTIFY_TYPES=[
  {key:'workUpdates',label:'Updates on your work',hint:'New notes, phase changes, and work ready for your review.',roles:['admin','manager','member']},
  {key:'meetings',label:'Meetings',hint:'Invites, changes, cancellations, and a reminder within the hour before.',roles:['admin','manager','member','board']},
  {key:'overdueToday',label:'Due today & overdue',hint:'Daily at 10:30, for work due today or overdue.',roles:['admin','manager','member']},
]
const NOTIFY_STATE_PREFIX='teamflow_notified_v1:';
function notificationPreference(member,key){return member?.notificationPreferences?.[key]!==false;}
function desktopNotificationState(){return typeof Notification==='undefined'?'unsupported':Notification.permission;}
// Each device can be switched off on its own; the browser permission itself can only be changed in browser settings.
const DEVICE_NOTIFY_OFF_PREFIX='teamflow_device_notify_off:';
function deviceNotificationsOff(){try{return !!currentUser&&localStorage.getItem(DEVICE_NOTIFY_OFF_PREFIX+currentUser.id)==='1';}catch{return false;}}
function setDeviceNotificationsOff(off){try{if(off)localStorage.setItem(DEVICE_NOTIFY_OFF_PREFIX+currentUser.id,'1');else localStorage.removeItem(DEVICE_NOTIFY_OFF_PREFIX+currentUser.id);}catch{}}
function deviceNotificationsOn(){return desktopNotificationState()==='granted'&&!deviceNotificationsOff();}
function desktopNotificationStatusText(){
  const state=desktopNotificationState();
  if(state==='unsupported')return'This browser does not support desktop notifications.';
  if(state==='denied')return'Blocked by this browser. Allow notifications for TeamFlow in the browser\'s site settings, then switch this on.';
  if(state==='default'||deviceNotificationsOff())return'Off. Switch on to get alerts on this computer or phone.';
  return pushSubscribed?'On, including when TeamFlow is closed.':'On while TeamFlow is open.';
}
function desktopNotificationActionsHtml(){
  return deviceNotificationsOn()?'<button type="button" class="btn btn-ghost btn-sm" onclick="sendTestNotification()">Send a test</button>':'';
}
function notificationSettingsHtml(member){
  const types=NOTIFY_TYPES.filter(type=>type.roles.includes(member.role));
  if(!types.length)return'';
  const blocked=['denied','unsupported'].includes(desktopNotificationState());
  return`<div id="p-notify-panel">
    <div class="pf-device"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg><div class="pf-device-text"><strong>Notifications on this device</strong><span id="p-notify-status" role="status">${desktopNotificationStatusText()}</span></div><span class="pf-switch"><input type="checkbox" id="p-device-notify" aria-label="Notifications on this device" ${deviceNotificationsOn()?'checked':''} ${blocked?'disabled':''} onchange="toggleDeviceNotifications(this)"><span aria-hidden="true"></span></span></div>
    <div id="p-notify-actions" class="pf-device-actions">${desktopNotificationActionsHtml()}</div>
    <div class="pf-list">${types.map(type=>`<label class="pf-switch-row"><span class="pf-switch-text"><strong>${type.label}</strong><span>${type.hint}</span></span><span class="pf-switch"><input type="checkbox" id="p-notify-${type.key}" ${notificationPreference(member,type.key)?'checked':''}><span aria-hidden="true"></span></span></label>`).join('')}</div>
  </div>`;
}
function refreshNotificationPanel(){
  const status=document.getElementById('p-notify-status'),actions=document.getElementById('p-notify-actions'),toggle=document.getElementById('p-device-notify');
  if(status)status.textContent=desktopNotificationStatusText();
  if(actions)actions.innerHTML=desktopNotificationActionsHtml();
  if(toggle){toggle.checked=deviceNotificationsOn();toggle.disabled=['denied','unsupported'].includes(desktopNotificationState());}
}
async function toggleDeviceNotifications(input){
  input.disabled=true;
  try{
    if(input.checked){
      setDeviceNotificationsOff(false);
      if(desktopNotificationState()==='default'){try{await Notification.requestPermission();}catch{}}
      if(desktopNotificationState()==='granted'){await ensurePushSubscription(true);showToast('Notifications are on for this device.','success');checkDesktopNotifications();}
      else showToast('The browser did not allow notifications for TeamFlow.','error');
    }else{
      setDeviceNotificationsOff(true);await removePushSubscription();
      showToast('Notifications are off for this device.','info');
    }
  }finally{refreshNotificationPanel();}
}
// ── Web push: lets the server alert this device while TeamFlow is closed ──
let pushSubscribed=false,pushCheckedFor=null;
function base64UrlToBytes(value){const padded=(value+'='.repeat((4-value.length%4)%4)).replace(/-/g,'+').replace(/_/g,'/');return Uint8Array.from(atob(padded),char=>char.charCodeAt(0));}
async function pushRegistration(){
  if(typeof navigator==='undefined'||!navigator.serviceWorker||typeof PushManager==='undefined')return null;
  try{return await navigator.serviceWorker.getRegistration()||null;}catch{return null;}
}
async function ensurePushSubscription(force=false){
  if(!currentUser||!deviceNotificationsOn())return false;
  if(!force&&pushCheckedFor===currentUser.id)return pushSubscribed;
  pushCheckedFor=currentUser.id;pushSubscribed=false;
  const registration=await pushRegistration();if(!registration)return false;
  try{
    const {publicKey}=await apiGet('push');if(!publicKey)return false;
    const subscription=await registration.pushManager.getSubscription()||await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:base64UrlToBytes(publicKey)});
    await sendJson('push',{operation:'subscribe',subscription:subscription.toJSON()});
    pushSubscribed=true;
  }catch(error){console.warn('Push subscription unavailable:',error.message);}
  return pushSubscribed;
}
async function removePushSubscription(){
  const registration=await pushRegistration();
  try{
    const subscription=registration&&await registration.pushManager.getSubscription();
    if(subscription){try{await sendJson('push',{operation:'unsubscribe',endpoint:subscription.endpoint});}catch{}await subscription.unsubscribe();}
  }catch{}
  pushSubscribed=false;pushCheckedFor=null;
}
async function sendTestNotification(){
  if(pushSubscribed){
    try{const result=await sendJson('push',{operation:'test'});if(result.delivered){showToast('Test sent from the server. It should appear in a moment.','success');return;}}catch{}
    showToast('The server could not reach this device; showing a local test instead.','info');
  }
  showDesktopNotification('TeamFlow notifications are working','You will see review-ready and overdue alerts here.','teamflow-test-'+Date.now()+'-'+(++testNotificationCount),null);}
let testNotificationCount=0;
async function showDesktopNotification(title,body,tag,workId){
  if(!deviceNotificationsOn())return;
  const options={body,tag,renotify:Boolean(tag),icon:'/icon-192.png',badge:'/icon-192.png',data:{workId:workId??null}};
  try{
    const registration=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration();
    if(registration){await registration.showNotification(title,options);return;}
  }catch{}
  try{const note=new Notification(title,options);note.onclick=()=>{window.focus();if(workId!=null)openWorkFromNotification(workId);note.close();};}catch{}
}
function openWorkFromNotification(workId){
  const id=Number(workId);
  if(!currentUser)return;
  if(works.some(work=>work.id===id))openWorkDetail(id);
  else showToast('That work item is no longer available.','info');
}
function readNotifyState(){try{return JSON.parse(localStorage.getItem(NOTIFY_STATE_PREFIX+currentUser.id)||'null')||{};}catch{return{};}}
function writeNotifyState(state){try{localStorage.setItem(NOTIFY_STATE_PREFIX+currentUser.id,JSON.stringify(state));}catch{}}
function listTitles(items){return items.slice(0,3).map(work=>work.title).join(', ')+(items.length>3?` and ${items.length-3} more`:'');}
// Moving work to Review yourself shouldn't alert you about it on this device.
function markReviewSeen(workId){const state=readNotifyState();state.reviewReady=[...(state.reviewReady||[]),workId];writeNotifyState(state);}
function checkDesktopNotifications(){
  if(!currentUser||!deviceNotificationsOn())return;
  const me=TEAM.find(member=>member.id===currentUser.id)||currentUser,state=readNotifyState();
  // With web push active, the server sends these alerts; showing them here too would duplicate them.
  const show=pushSubscribed?()=>{}:showDesktopNotification;
  const today=TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE);
  const inReview=works.filter(work=>work.status==='ongoing'&&work.phase===2);
  if(['admin','manager','member'].includes(me.role)&&notificationPreference(me,'reviewReady')){
    const seen=new Set(state.reviewReady||[]),fresh=inReview.filter(work=>!seen.has(work.id)&&(me.role!=='member'||String(work.pic)===String(me.id)));
    if(fresh.length===1)show('Ready for review',fresh[0].title,'review-'+fresh[0].id,fresh[0].id);
    else if(fresh.length>1)show(`${fresh.length} items ready for review`,listTitles(fresh),'review-batch',null);
  }
  // Leaving Review clears the record, so work that returns to Review notifies again.
  state.reviewReady=inReview.map(work=>work.id);
  // Meetings starting within the hour, for devices without web push.
  if(notificationPreference(me,'meetings')){
    const reminded=new Set(state.meetingsReminded||[]),soon=meetings.filter(meeting=>meeting.status!=='cancelled'&&isMyMeeting(meeting)&&Date.parse(meeting.startsAt)>Date.now()&&Date.parse(meeting.startsAt)-Date.now()<=3600000);
    for(const meeting of soon)if(!reminded.has(`${meeting.id}:${meeting.startsAt}`))show('Meeting soon',`${meeting.title} starts at ${meeting.startTime}`,'meeting-'+meeting.id,null);
    state.meetingsReminded=soon.map(meeting=>`${meeting.id}:${meeting.startsAt}`);
  }
  // New notes since this device last alerted (only used when web push is unavailable).
  if(notificationPreference(me,'workUpdates')){
    const noted=state.notes||{};
    for(const work of works){
      const fresh=unreadNotes(work).filter(note=>note.createdAt>(noted[work.id]||''));
      if(fresh.length){const note=fresh[fresh.length-1];show(`<svg class="ui-icon" aria-hidden="true"><use href="#i-message"/></svg> ${note.authorName||'Someone'} · ${work.title}`,String(note.text||'').slice(0,140),'note-'+work.id,work.id);noted[work.id]=note.createdAt;}
    }
    state.notes=noted;
  }
  if(notificationPreference(me,'overdueToday')&&state.overdueDate!==today){
    const mine=works.filter(work=>work.status!=='done'&&work.deadline&&work.deadline<=today&&(String(work.pic)===String(me.id)||(work.assignees||[]).some(id=>String(id)===String(me.id))));
    const dueToday=mine.filter(work=>work.deadline===today),late=mine.filter(work=>work.deadline<today);
    if(mine.length===1)show(dueToday.length?'Due today':'Overdue work',dueToday.length?`${mine[0].title} is due today.`:`${mine[0].title} was due ${fmt(mine[0].deadline)}.`,'deadlines-'+today,mine[0].id);
    else if(mine.length>1)show([dueToday.length&&`${dueToday.length} due today`,late.length&&`${late.length} overdue`].filter(Boolean).join(', ').replace(/^./,c=>c.toUpperCase()),listTitles([...dueToday,...late]),'deadlines-'+today,null);
    state.overdueDate=today;
  }
  writeNotifyState(state);
}
let notificationLinkHandled=false;
// After each release: people who have not turned notifications on for this device are taken to the settings once.
// Bump with every release (and add a matching Changelog entry): people who still have notifications off are asked again once per release.
const APP_VERSION='2.5';
const NOTIFY_PROMPT_PREFIX='teamflow_notify_prompt_version:';
let notifyPromptChecked=false;
function maybePromptNotificationSetup(){
  if(notifyPromptChecked||!currentUser)return;
  if(desktopNotificationState()==='unsupported'||!NOTIFY_TYPES.some(type=>type.roles.includes(currentUser.role))){notifyPromptChecked=true;return;}
  let alreadyAsked=false;try{alreadyAsked=localStorage.getItem(NOTIFY_PROMPT_PREFIX+currentUser.id)===APP_VERSION;}catch{}
  if(alreadyAsked||deviceNotificationsOn()){notifyPromptChecked=true;return;}
  // Never interrupt an open dialog or unsaved edits; the next sync tries again.
  if(document.getElementById('modal-overlay')?.style.display==='flex'||hasPendingChanges||draftActive)return;
  notifyPromptChecked=true;
  try{localStorage.setItem(NOTIFY_PROMPT_PREFIX+currentUser.id,APP_VERSION);}catch{}
  openMyProfile();switchProfileTab('notifications');
  const panel=document.getElementById('p-notify-panel');
  if(panel){const hint=document.createElement('div');hint.className='pf-welcome';hint.innerHTML='<strong>Never miss an update.</strong> Switch on notifications for this device to get alerts about new notes, deadlines and phase changes, even when TeamFlow is closed.';panel.prepend(hint);}
}
async function afterWorkspaceSync(){
  await ensurePushSubscription();
  checkDesktopNotifications();
  maybePromptNotificationSetup();
  if(notificationLinkHandled||!currentUser||typeof location==='undefined')return;
  notificationLinkHandled=true;
  const params=new URLSearchParams(location.search),workId=params.get('work'),meetingId=params.get('meeting');
  if(meetingId){params.delete('meeting');history.replaceState(null,'',location.pathname+(params.toString()?'?'+params:'')+location.hash);openMeetingFromNotification(meetingId);}
  if(!workId)return;
  params.delete('work');history.replaceState(null,'',location.pathname+(params.toString()?'?'+params:'')+location.hash);
  openWorkFromNotification(workId);
}
if(typeof navigator!=='undefined'&&navigator.serviceWorker)navigator.serviceWorker.addEventListener('message',event=>{if(event.data?.type==='teamflow-open-work')openWorkFromNotification(event.data.workId);if(event.data?.type==='teamflow-open-meeting')openMeetingFromNotification(event.data.meetingId);});
setInterval(()=>{if(currentUser)checkDesktopNotifications();},10*60*1000);

// ============================================================
