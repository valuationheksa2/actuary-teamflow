let profilePhotoDraft="",profilePhotoBusy=false,profilePhotoGeneration=0;
function openMyProfile() {
  const m = currentUser;
  if(!m)return;
  profilePhotoDraft=safeProfilePhoto(m.profilePhoto);profilePhotoBusy=false;profilePhotoGeneration++;
  document.getElementById('modal-title').textContent = '👤 My Profile';
  document.getElementById('modal-body').innerHTML = `
    <div style="display:flex;align-items:center;gap:16px;padding:16px;background:var(--bg3);border-radius:var(--radius);margin-bottom:20px;border:1px solid var(--border);">
      <div id="profile-photo-preview" class="profile-photo-preview">${avatarHtml(m,64)}</div>
      <div>
        <div style="font-size:16px;font-weight:700;">${escapeHtml(m.name)}</div>
        <div style="font-size:12px;color:var(--text3);">${escapeHtml(m.role.charAt(0).toUpperCase()+m.role.slice(1))} · @${escapeHtml(m.username||m.email)}</div>
      </div>
    </div>
    <div class="profile-photo-controls"><input id="profile-photo-file" type="file" accept="image/jpeg,image/png,image/webp" hidden onchange="chooseProfilePhoto(this)"><button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('profile-photo-file').click()">Upload photo</button><button id="profile-photo-remove" type="button" class="btn btn-ghost btn-sm" onclick="removeProfilePhoto()" ${profilePhotoDraft?'':'hidden'}>Remove photo</button><span id="profile-photo-status" class="form-hint" role="status">JPG, PNG or WebP · up to 5 MB</span></div>
    <div class="form-group"><label class="form-label" for="p-name">Full Name</label><input id="p-name" type="text" value="${escapeHtml(m.name)}"></div>
    <div class="form-group"><label class="form-label" for="p-username">Username</label><input id="p-username" type="text" value="${escapeHtml(m.username||'')}"></div>
    <div class="form-group"><label class="form-label" for="p-email">Email (optional)</label><input id="p-email" type="email" value="${escapeHtml(m.email||'')}"></div>
    <div class="form-group"><label class="form-label" for="p-capacity">Weekly capacity (hours)</label><input id="p-capacity" type="number" min="0" max="168" value="${Number(m.weeklyCapacityHours??40)}"></div>
    <div style="background:var(--bg3);border:1px solid var(--border);border-radius:var(--radius-sm);padding:14px;margin-bottom:16px;">
      <div style="font-size:12px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px;">Change Password</div>
      <div class="form-group" style="margin-bottom:10px;"><label class="form-label">Current Password</label><input id="p-current-pass" type="password" placeholder="Enter current password"></div>
      <div class="form-group" style="margin-bottom:10px;"><label class="form-label">New Password</label><input id="p-new-pass" type="password" placeholder="Enter new password"></div>
      <div class="form-group" style="margin-bottom:0;"><label class="form-label">Confirm New Password</label><input id="p-confirm-pass" type="password" autocomplete="new-password" placeholder="Confirm new password"><div class="form-hint">Use at least 6 characters. Other active sessions will be signed out.</div></div>
    </div>
    <div class="form-group"><label class="form-label">Avatar Color</label>${colorPicker(m.color)}</div>`;
  selectedColor = m.color;
  document.getElementById('modal-footer').innerHTML = `
    <button id="profile-save-button" class="btn btn-primary" onclick="saveMyProfile()">Save Changes</button>
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>`;
  document.getElementById('modal-overlay').style.display = 'flex';

  document.getElementById('modal-overlay').style.display='flex';
}

function renderProfilePhotoPreview(){
  const element=document.getElementById('profile-photo-preview');
  if(element)element.innerHTML=avatarHtml({...currentUser,profilePhoto:profilePhotoDraft},64);
  const remove=document.getElementById('profile-photo-remove');if(remove)remove.hidden=!profilePhotoDraft;
}
function removeProfilePhoto(){
  profilePhotoGeneration++;profilePhotoDraft='';profilePhotoBusy=false;draftActive=true;editGeneration++;
  const file=document.getElementById('profile-photo-file');if(file)file.value='';
  const save=document.getElementById('profile-save-button');if(save)save.disabled=false;
  const status=document.getElementById('profile-photo-status');if(status)status.textContent='Photo removed. Save Changes to apply.';
  renderProfilePhotoPreview();
}
async function chooseProfilePhoto(input){
  const file=input.files?.[0];if(!file)return;
  const generation=++profilePhotoGeneration,userId=currentUser?.id,preview=document.getElementById('profile-photo-preview');
  const status=document.getElementById('profile-photo-status'),save=document.getElementById('profile-save-button');
  const stillOpen=()=>generation===profilePhotoGeneration&&currentUser?.id===userId&&preview===document.getElementById('profile-photo-preview');
  let bitmap;
  try{
    if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Choose a JPG, PNG or WebP image.');
    if(file.size>5*1024*1024)throw new Error('Choose an image smaller than 5 MB.');
    profilePhotoBusy=true;if(save)save.disabled=true;if(status)status.textContent='Preparing photo…';
    bitmap=await createImageBitmap(file);
    if(!stillOpen())return;
    if(!bitmap.width||!bitmap.height||bitmap.width*bitmap.height>40000000)throw new Error('Choose an image with smaller dimensions.');
    const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;
    const context=canvas.getContext('2d');if(!context)throw new Error('Could not prepare your photo.');
    context.fillStyle='#fff';context.fillRect(0,0,256,256);context.imageSmoothingQuality='high';
    const side=Math.min(bitmap.width,bitmap.height);
    context.drawImage(bitmap,(bitmap.width-side)/2,(bitmap.height-side)/2,side,side,0,0,256,256);
    let photo='';for(const quality of [.85,.7,.55,.4]){photo=canvas.toDataURL('image/jpeg',quality);if(photo.length<=87000)break;}
    if(!safeProfilePhoto(photo)||photo.length>87000)throw new Error('Could not resize this photo. Choose another image.');
    profilePhotoDraft=photo;draftActive=true;editGeneration++;renderProfilePhotoPreview();
    if(status)status.textContent='Photo ready. Save Changes to apply.';
  }catch(error){if(stillOpen()){showToast(error.message||'Could not read this image.','error');if(status)status.textContent='JPG, PNG or WebP · up to 5 MB';}}
  finally{bitmap?.close();if(stillOpen()){profilePhotoBusy=false;if(save)save.disabled=false;input.value='';}}
}
async function saveMyProfile() {
  if(profilePhotoBusy){showToast('Wait for your photo to finish preparing.','error');return;}
  const m = TEAM.find(x => x.id === currentUser.id);
  if(!m) return;

  const name = document.getElementById('p-name').value.trim();
  const username = document.getElementById('p-username').value.trim();
  const email = document.getElementById('p-email').value.trim();
  const currentPass = document.getElementById('p-current-pass').value;
  const newPass = document.getElementById('p-new-pass').value;
  const confirmPass = document.getElementById('p-confirm-pass').value;
  const capacity=Number(document.getElementById('p-capacity').value);

  if(!name || !username || !Number.isFinite(capacity)||capacity<0||capacity>168) { showToast('Enter your name, username, and capacity from 0 to 168 hours.', 'error'); return; }

  // Check username uniqueness
  const dupU = TEAM.find(x => (x.username||'').toLowerCase() === username.toLowerCase() && x.id !== m.id);
  if(dupU) { showToast('Username already taken.', 'error'); return; }

  if(currentPass || newPass || confirmPass) {
    if(!currentPass) { showToast('Enter your current password to change it.', 'error'); return; }
    if(newPass.length < 6) { showToast('New password must be at least 6 characters.', 'error'); return; }
    if(newPass !== confirmPass) { showToast('New passwords do not match.', 'error'); return; }
  }

  // Update profile
  m.name = name;
  m.username = username;
  m.email = email;
  m.weeklyCapacityHours=capacity;
  m.color = selectedColor;
  m.initials = makeInitials(name);
  m.profilePhoto = profilePhotoDraft;

  // Update currentUser reference
  currentUser = m;

  // Update sidebar display
  updateSidebarAvatar(m);
  document.getElementById('sb-name').textContent = m.name;

  if(!(await saveRequestsNow()))return;
  if(newPass){
    try{const result=await sendJson('auth/change-password',{currentPassword:currentPass,password:newPass});await loadWorkspace(result.user);showToast('Profile and password updated. Other sessions were signed out.','success');}
    catch(error){showToast(error.message||'Password could not be changed.','error');return;}
  }else{
    showToast('Profile updated.','success');closeModal();
  }
}


// ── MOBILE MENU ───────────────────────────────────────────
function toggleMobileMenu() {
  try {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobile-overlay');
    if(!sidebar) return;
    const isOpen = sidebar.classList.contains('mobile-open');
    const button=document.getElementById('hamburger-btn');
    if(isOpen) {
      sidebar.classList.remove('mobile-open');
      if(overlay) overlay.classList.remove('show');
      if(button)button.setAttribute('aria-expanded','false');
    } else {
      sidebar.classList.add('mobile-open');
      if(overlay) overlay.classList.add('show');
      if(button)button.setAttribute('aria-expanded','true');
    }
  } catch(e) {}
}
function closeMobileMenu() {
  try {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobile-overlay');
    const button=document.getElementById('hamburger-btn');
    if(sidebar) sidebar.classList.remove('mobile-open');
    if(overlay) overlay.classList.remove('show');
    if(button)button.setAttribute('aria-expanded','false');
  } catch(e) {}
}

function openEditNameDesc(id){var w=works.find(function(x){return x.id===id;});if(!w)return;document.getElementById('modal-body').dataset.detailWorkId=String(id);document.getElementById('modal-title').textContent='Edit Name & Description';var tv=escapeHtml(w.title);var dv=escapeHtml(w.desc||'');document.getElementById('modal-body').innerHTML='<div class="form-group"><label class="form-label" for="end-title">Work Title *</label><input id="end-title" type="text" value="'+tv+'"></div><div class="form-group"><label class="form-label" for="end-desc">Description</label><textarea id="end-desc" style="white-space:pre-wrap;min-height:100px;">'+dv+'</textarea></div>';document.getElementById('modal-footer').innerHTML='<button class="btn btn-primary" onclick="saveEditNameDesc('+Number(id)+')">Save</button><button class="btn btn-ghost" onclick="closeModal()">Cancel</button>';document.getElementById('modal-overlay').style.display='flex';}
async function saveEditNameDesc(id){var w=works.find(function(x){return x.id===id;});if(!w)return;var title=document.getElementById('end-title').value.trim();if(!title){showToast('Title is required.','error');return;}w.title=title;w.desc=document.getElementById('end-desc').value;if(!(await saveRequestsNow()))return;showToast('Updated!','success');closeModal();}
function toggleSection(sectionId){
  var body=document.getElementById(sectionId);
  var arrId=sectionId.replace('sec-','arr-');
  var arr=document.getElementById(arrId);
  if(!body)return;
  var collapsed=body.classList.contains('collapsed');
  if(collapsed){body.classList.remove('collapsed');if(arr)arr.classList.remove('collapsed');}
  else{body.classList.add('collapsed');if(arr)arr.classList.add('collapsed');}
  document.getElementById('hdr-'+sectionId.replace('sec-',''))?.setAttribute('aria-expanded',String(collapsed));
  try{var state=JSON.parse(localStorage.getItem('sidebar_state')||'{}');
  if(!collapsed){state[sectionId]=true;}else{delete state[sectionId];}
  localStorage.setItem('sidebar_state',JSON.stringify(state));}catch(e){}
}
function restoreSidebarState(){
  try{var state=JSON.parse(localStorage.getItem('sidebar_state')||'{}');Object.keys(state).forEach(function(id){if(state[id]===true){var body=document.getElementById(id);var arr=document.getElementById(id.replace('sec-','arr-'));if(body)body.classList.add('collapsed');if(arr)arr.classList.add('collapsed');}});}catch(e){}
}
function renderChangelog(){
  var versions=[
    {ver:'2.1',date:'Oct 2026',title:'Capacity, Collaboration & Reporting',items:[
      'Members can create work, edit their own templates, and manage assignees as creator or PIC.',
      'Templates include estimated hours, creator details, and search.',
      'Profile photo upload and refreshed team cards.',
      'Dashboard redesign with deadline sorting, priority badges, and updated workload colors.',
      'Responsive filters saved separately for each user and page; refresh preserves scroll position.',
      'Weekly capacity, due reminders, and work activity history.',
      'Calendar date details include completed work within its original schedule.',
      'Improved report counts, historical completion flags, compact controls, and PDF exports.',
      'Daily Report rendering fix, account setup/reset links, and updated Help & Guide.',
    ]},
    {ver:'2.0',date:'Sep 2026',title:'Major Feature Update',items:[
      'Work Type Classification (Regular / Ad-hoc) with color-coded badges',
      'Move Phase Back — return work to previous phase with system note',
      'Multiline description support with Enter key formatting',
      'Editable Notes — authors and admins can edit notes with timestamp',
      'Improved Sort & Filter — 7 sort options + 4 filters on Ongoing & History',
      'Board Role — executive view-only access with note-adding capability',
      'Admin can edit completed work name/description + Reopen Work button',
      'Full Template Editor — edit all fields including phase tasks',
      'Calendar Enhancement — 3-section date modal (Starting/Deadlines/Active)',
      'Prevent overlay close on Add/Edit Work and Add File Link modals',
      'Templates & Requests pages hidden from Board role',
      'Changelog, Help & Guide, and Feedback pages added',
    ]},
    {ver:'1.5',date:'Sep 2026',title:'Workflow & Collaboration',items:[
      'Join/Leave request system with PIC/Manager approval workflow',
      'PIC (Person in Charge) field on all work items',
      'Daily Report page with PDF export',
      'Weekly & Monthly Audit Reports with PDF export',
      'Username-based login (no email required)',
      'Work Templates — save and reuse work structures',
      'Recurring Work — weekly, biweekly, monthly, quarterly, custom intervals',
      'Calendar view with month picker in Upcoming page',
      'Auto-advance phase tasks when moving to next phase',
      'Copy Path button for internal network file links',
    ]},
    {ver:'1.0',date:'Sep 2026',title:'Initial Release',items:[
      'Ongoing, Upcoming, and History work pages',
      'Work phases: Planning to Executing to Review to Finalize',
      'Customizable phase tasks per work item',
      'Role-based access: Admin, Manager, Member',
      'File/folder links per work item (Google Drive, Figma, internal paths)',
      'Notes & Updates on work items',
      'Team management with Admin panel',
      'Daily digest with overdue alerts and review-ready highlights',
      'Session persistence — stay logged in on refresh',
      'Mobile responsive with hamburger menu',
      'PWA support — add to home screen as app',
      'WhatsApp bot for daily/weekly digest notifications',
    ]},
  ];
  var html='<div class="section-header"><div><div class="section-title">&#128203; Changelog</div><div class="section-sub">Version history and feature updates</div></div></div>';
  versions.forEach(function(v){
    html+='<div class="card" style="margin-bottom:16px;"><div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;"><div style="background:var(--primary);color:#fff;border-radius:var(--radius-sm);padding:4px 10px;font-size:13px;font-weight:700;">v'+v.ver+'</div><div style="font-size:14px;font-weight:700;">'+v.title+'</div><div style="font-size:12px;color:var(--text3);margin-left:auto;">'+v.date+'</div></div><ul style="margin:0;padding-left:20px;">';
    v.items.forEach(function(item){html+='<li style="font-size:13px;color:var(--text2);margin-bottom:6px;">'+item+'</li>';});
    html+='</ul></div>';
  });
  document.getElementById('content').innerHTML=html;
}
function renderHelp(){
  var sections=[
    {icon:'&#128205;',title:'Work Management',items:[
      '<strong>Add Work</strong> — Admins, managers, and members can create work from Ongoing, Upcoming, or Templates. Set dates, estimated hours, work type, recurrence, PIC, assignees, and phase tasks. Members are automatically assigned to work they create.',
      '<strong>Work Types</strong> — Regular uses a solid blue border; Ad-hoc uses a dashed orange border.',
      '<strong>Phases</strong> — Planning → Executing → Review → Finalize. Use work-detail actions to advance or return to a previous phase.',
      '<strong>Edit Work</strong> — Estimated effort and work type share a row on wider screens. PIC follows recurrence. Save changes to update assignments and capacity.',
      '<strong>Files &amp; Notes</strong> — Attach external links or internal paths, and add notes where your role permits. Use Copy Path for internal network links.',
      '<strong>Activity History</strong> — Expand Activity History inside a work item to load its recorded creation and changes, including the actor, time, and changed fields.',
    ]},
    {icon:'&#128269;',title:'Search &amp; Filters',items:[
      '<strong>Search Work</strong> — Search titles and descriptions on Ongoing, Upcoming, or History. Combine search with work type, priority, PIC, and the available phase filter.',
      '<strong>Sorting</strong> — Order by deadline, title, or creation date. Phase filtering is available on Ongoing.',
      '<strong>Independent Choices</strong> — Each account and page keeps its own search, filters, and sorting in this browser. Choices survive navigation, refresh, and reload; they are not shared with other users or devices.',
      '<strong>Reset</strong> — Clears only the current account and page. Controls wrap automatically on smaller screens.',
    ]},
    {icon:'&#128101;',title:'Accounts &amp; Roles',items:[
      '<strong>Admin</strong> — Manages team accounts and work, including completed-work edits and reopening.',
      '<strong>Manager</strong> — Creates and manages work, assignments, templates, and join/leave approvals.',
      '<strong>Member</strong> — Creates work, edits permitted fields on assigned work or work they own as PIC, and edits templates they created. The work creator or PIC can change assignees; members request to join or leave other work.',
      '<strong>Board</strong> — Read-only access. Cannot create, edit, or add notes to work.',
      '<strong>PIC</strong> — Responsible for the work, assignee changes, and join/leave approvals. Only admins and managers can transfer the PIC. PIC effort weighting takes precedence over role.',
      '<strong>Passwords</strong> — Sign in with your username and password. Contact Admin for a single-use reset link valid for 30 minutes. Initial invitation links last 24 hours and can be used once.',
      '<strong>My Profile</strong> — Update your name, username, email, weekly capacity, and avatar color. Upload a JPG, PNG, or WebP photo up to 5 MB, preview it, then Save Changes. Photos are cropped and resized automatically; Remove photo restores initials. Passwords require at least 6 characters; changing one signs out other sessions.',
    ]},
    {icon:'&#128197;',title:'Schedule &amp; Calendar',items:[
      '<strong>Upcoming</strong> — The month calendar appears above the work search and filters. Use the chevron buttons, month/year selectors, or Today to navigate.',
      '<strong>Weeks</strong> — Calendar columns run Monday–Sunday, matching Capacity and weekly Audit reports.',
      '<strong>Flag Fills</strong> — Light blue marks a start date; red marks a deadline.',
      '<strong>Flag Borders</strong> — Solid blue identifies Regular work; dashed orange identifies Ad-hoc work, for both starts and deadlines.',
      '<strong>Date Details</strong> — Click a date to view Starting Today, Deadlines Today, Active Work, and Completed Work. Completed work remains visible throughout its original start-to-deadline range; the start and deadline dates stay in their respective sections.',
      '<strong>History</strong> — Calendar date details show the current completed status even for selected dates before the actual completion date. Open a card to inspect the work.',
    ]},
    {icon:'&#9878;',title:'Weekly Capacity',items:[
      '<strong>Included People</strong> — Weekly capacity shows members and managers.',
      '<strong>Set Capacity</strong> — Set weekly hours in My Profile, or use Admin → Edit Member to manage team capacity.',
      '<strong>Estimate Work</strong> — Enter total estimated hours on a work item. Capacity compares planned effort with availability; it does not record actual time.',
      '<strong>Weekday Split</strong> — Hours are spread evenly across Monday–Friday dates from start through deadline, inclusive. Weekends receive no hours; work with no scheduled weekdays is flagged for date adjustment.',
      '<strong>Effort Shares</strong> — Shares are normalized so the total estimate stays unchanged; the PIC is included even if not separately assigned.',
      '<strong>Example</strong> — A 10-hour individual share scheduled Oct 3–7, 2026 falls entirely in Oct 5–7 because Oct 3–4 is a weekend.',
      '<strong>Navigate</strong> — Use the chevron buttons to inspect each Monday–Sunday week. Red bars and Over capacity labels indicate excess planned hours.',
    ]},
    {icon:'&#128276;',title:'Daily Report &amp; Reminders',items:[
      '<strong>Daily Report</strong> — Review ongoing work, review-ready items, overdue work, and upcoming deadlines in one page.',
      '<strong>Notifications</strong> — The notification list is inside Daily Report. Click the top-bar bell or Dashboard Reminders to jump to it.',
      '<strong>Reminder Timing</strong> — Select due today, 1, 3, or 7 days before, then Save preferences. Overdue reminders are also shown.',
      '<strong>Read Status</strong> — Open a notification to mark it read and view its work item, or use Mark all read.',
      '<strong>Export</strong> — Export PDF downloads a printable report. Open the downloaded file and use Print → Save as PDF.',
    ]},
    {icon:'&#128202;',title:'Dashboard, Audit &amp; History',items:[
      '<strong>Dashboard</strong> — Six active work items are sorted by earliest deadline and show phase and priority badges. Phase/priority summaries, Due Soon, and Team Workload share a balanced layout. View capacity opens Capacity; workload summaries include active members and managers.',
      '<strong>Weekly Audit</strong> — Uses Monday–Sunday weeks. Completed work is grouped by completion date within the selected period.',
      '<strong>Annual Audit</strong> — Uses January–December of the selected year and includes member and manager performance for assignments and PIC responsibilities. Use the centered chevrons to change years; Export PDF beside the title includes member performance.',
      '<strong>Monthly Audit</strong> — Uses the selected calendar month. Date ranges use the team timezone, defaulting to Asia/Bangkok.',
      '<strong>Ongoing Work</strong> — Past reports count work started by period end and not completed until afterward, including overdue carryover. Current-period reports include every item marked ongoing, even if its planned start date is later. Upcoming work is excluded.',
      '<strong>Period Totals</strong> — Monthly and annual Work in period equals Completed plus Ongoing. Creation date does not determine inclusion; work starting later is excluded unless it is already marked ongoing in the current period.',
      '<strong>Completed Later</strong> — Work finished after a historical cutoff stays in that period’s ongoing count. Its row shows Completed with the actual date and 100% progress. Other phase/progress values show current work details.',
      '<strong>Reporting Cutoff</strong> — Past periods use their end date. Current periods use today; upcoming periods do not project unfinished work or overdue dates into the future.',
      '<strong>On-time Rate</strong> — Period completions with a deadline are eligible. The rate is the number completed on or before the deadline divided by eligible completions.',
      '<strong>History &amp; Performance</strong> — History contains completed work; Annual Report includes member-level summaries. Use the weekly/monthly/annual arrows to change report periods.',
    ]},
    {icon:'&#128203;',title:'Templates, Recurrence &amp; Requests',items:[
      '<strong>Templates</strong> — Admins, managers, and members can save and reuse work structures, phase tasks, and estimated hours. Members edit only templates they created; admins and managers can edit all templates. Cards show the creator and creation date. Use the search bar to find templates by name, description, tag, or creator.',
      '<strong>Recurrence</strong> — Choose a recurrence in the work form. Completing the work creates its next occurrence.',
      '<strong>Join / Leave</strong> — Members request to join active work or leave an assignment; PICs and managers review requests. PICs cannot request to leave their own work.',
    ]},
    {icon:'&#128190;',title:'Saving &amp; Accessibility',items:[
      '<strong>Install App</strong> — In Chrome, choose Cast, save, and share → Install page as app. Close and reopen app windows after an update.',
      '<strong>Offline</strong> — A reconnect page is available offline. Sign-in, shared work, feedback, and saving require an internet connection.',
      '<strong>Automatic Refresh</strong> — Shared changes are checked every 30 seconds while the page is visible. Refresh preserves your scroll position; open forms pause shared refresh while you edit.',
      '<strong>Saving</strong> — Task checkmarks update immediately while saving. Wait for Saved before leaving. If saving fails, edits are kept; use Retry for a connection error, or resolve a save conflict.',
      '<strong>Conflicting Edits</strong> — If someone changed the same record, reconcile with the latest version before retrying. Keep a copy of your edits before refreshing.',
      '<strong>Keyboard &amp; Mobile</strong> — Use Tab to move through controls and Enter or Space to activate buttons. Visible focus and reduced-motion support help navigation; the mobile menu opens from the top bar.',
    ]},
  ];
  var html='<div class="section-header"><div><div class="section-title">&#10067; Help &amp; Guide</div><div class="section-sub">Quick reference for all features</div></div></div>';
  sections.forEach(function(s){
    html+='<div class="card" style="margin-bottom:16px;"><div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;"><span style="font-size:20px;">'+s.icon+'</span><div style="font-size:15px;font-weight:700;">'+s.title+'</div></div><ul style="margin:0;padding-left:20px;">';
    s.items.forEach(function(item){html+='<li style="font-size:13px;color:var(--text2);margin-bottom:8px;line-height:1.5;">'+item+'</li>';});
    html+='</ul></div>';
  });
  document.getElementById('content').innerHTML=html;
}
let feedbackBusy=false;
let pendingFeedbackId=null;
async function renderFeedback(refresh=true){
  const content=document.getElementById('content');
  if(refresh&&!hasPendingChanges&&!draftActive&&!feedbackBusy){
    renderFeedback(false);
    const marker=beginPageRefresh(content),generation=editGeneration,userId=currentUser.id;
    try{
      const latest=await apiGet('works');
      if(!marker.isConnected||currentUser?.id!==userId||currentPage!=='feedback'||generation!==editGeneration||hasPendingChanges||draftActive||feedbackBusy)return;
      feedbackItems=latest.feedbackItems||[];
      remoteState.collections.feedbackItems=cloneValue(feedbackItems);
      remoteState.versions.feedbackItems=latest.versions?.feedbackItems||1;
      renderFeedback(false);
    }catch(error){if(marker.isConnected)showToast('Could not refresh feedback. Existing entries are shown.','error');}
    finally{marker.remove();}
    return;
  }
  var cats=['Bug Report','Suggestion','Compliment','Other'];
  var statuses={open:{label:'Open',color:'var(--primary)'},noted:{label:'Noted',color:'var(--yellow)'},inprogress:{label:'In Progress',color:'var(--orange)'},done:{label:'Done',color:'var(--green)'}};
  var html='<div class="section-header"><div><div class="section-title">&#128172; Feedback</div><div class="section-sub">Share your thoughts, suggestions, or report issues</div></div></div>';
  if(currentUser.role!=='board')html+='<div class="card" style="margin-bottom:20px;"><div class="card-title" style="margin-bottom:12px;">&#9997; Submit Feedback</div>'
    +'<div class="form-row"><div class="form-group"><label class="form-label" for="fb-cat">Category</label>'
    +'<select id="fb-cat" class="app-select">'+cats.map(function(c){return'<option>'+c+'</option>';}).join('')+'</select></div>'
    +'<div class="form-group"><label class="form-label" for="fb-name">Your Name</label>'
    +'<input id="fb-name" class="app-input" type="text" maxlength="120" autocomplete="name" value="'+escapeHtml(currentUser?currentUser.name:'')+'" placeholder="Your name"></div></div>'
    +'<div class="form-group"><label class="form-label">Feedback *</label>'
    +'<textarea id="fb-text" placeholder="Describe your feedback, suggestion, or issue..." style="min-height:80px;"></textarea></div>'
    +'<button class="btn btn-primary" onclick="submitFeedback()">Submit Feedback</button></div>';
  if(!feedbackItems.length){
    html+='<div class="empty-state"><div class="icon">&#128172;</div><p>No feedback yet. Be the first to share!</p></div>';
  } else {
    html+='<div style="display:flex;flex-direction:column;gap:12px;">';
    feedbackItems.slice().reverse().forEach(function(fb){
      var st=statuses[fb.status]||statuses.open;
      var isAdmin=currentUser&&['admin','manager'].includes(currentUser.role);
      var adminBtns=isAdmin?('<div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap;">'
        +'<button class="btn btn-ghost btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'noted\')">&#128065; Noted</button>'
        +'<button class="btn btn-ghost btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'inprogress\')" style="color:var(--orange);">&#128295; In Progress</button>'
        +'<button class="btn btn-success btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'done\')">&#10003; Done</button>'
        +'<button class="btn btn-danger btn-sm" onclick="deleteFeedback('+Number(fb.id)+')">&#128465;</button>'
        +'</div>'):'';
      html+='<div class="card"><div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;">'
        +'<span class="badge" style="background:var(--primary-dim);color:var(--primary);border:1px solid rgba(59,111,212,0.2);">'+escapeHtml(fb.category)+'</span>'
        +'<span class="badge" style="background:rgba(0,0,0,0.05);color:'+st.color+';">'+st.label+'</span>'
        +'<span style="font-size:12px;color:var(--text3);margin-left:auto;">'+escapeHtml(fb.author)+' &middot; '+fmt(fb.date)+'</span>'
        +'</div><div style="font-size:14px;color:var(--text);line-height:1.6;white-space:pre-wrap;">'+escapeHtml(fb.text)+'</div>'+adminBtns+'</div>';
    });
    html+='</div>';
  }
  document.getElementById('content').innerHTML=html;
}
async function submitFeedback(){
  if(feedbackBusy)return;
  const text=document.getElementById('fb-text').value.trim();
  if(!text||text.length>3000){showToast('Enter feedback of 1–3,000 characters.','error');return;}
  if(currentUser.role==='board'){showToast('Board accounts have read-only access.','error');return;}
  const entry={id:pendingFeedbackId||newRecordId(),category:document.getElementById('fb-cat').value,author:document.getElementById('fb-name').value.trim()||currentUser.name,authorId:currentUser.id,text,date:todayStr,status:'open'};
  feedbackBusy=true;
  pendingFeedbackId=entry.id;
  feedbackItems=feedbackItems.filter(item=>item.id!==entry.id);feedbackItems.push(entry);
  try{if(await saveRequestsNow()){showToast('Feedback submitted.','success');pendingFeedbackId=null;draftActive=false;await renderFeedback();}}
  finally{feedbackBusy=false;}
}
async function setFeedbackStatus(id,status){
  if(feedbackBusy||!['admin','manager'].includes(currentUser.role))return;
  const fb=feedbackItems.find(item=>item.id===id);if(!fb)return;
  feedbackBusy=true;fb.status=status;
  try{if(await saveRequestsNow()){await renderFeedback();showToast('Feedback updated.','success');}}
  finally{feedbackBusy=false;}
}
async function deleteFeedback(id){
  if(feedbackBusy||!['admin','manager'].includes(currentUser.role)||!await appConfirm('Delete this feedback?'))return;
  feedbackBusy=true;feedbackItems=feedbackItems.filter(item=>item.id!==id);
  try{if(await saveRequestsNow()){await renderFeedback();showToast('Feedback deleted.','success');}}
  finally{feedbackBusy=false;}
}
function closeModal(){document.getElementById('account-link-result')?.remove();document.getElementById('modal-overlay').style.display='none';if(!hasPendingChanges)draftActive=false;}
function closeModalOnOverlay(e){
  if(e.target!==document.getElementById('modal-overlay'))return;
  const title=(document.getElementById('modal-title').textContent||'');
  const prot=['Add New Work','Edit Work','New Work from Template','Add File / Folder Link','Edit Template'];
  if(prot.some(t=>title.includes(t)))return;
  closeModal();
}

// ============================================================
