let profilePhotoDraft="",profilePhotoBusy=false,profilePhotoGeneration=0;
const PROFILE_TABS=[['profile','Profile'],['notifications','Notifications'],['security','Security']];
function openMyProfile() {
  const m = currentUser;
  if(!m)return;
  profilePhotoDraft=safeProfilePhoto(m.profilePhoto);profilePhotoBusy=false;profilePhotoGeneration++;
  const role=m.role.charAt(0).toUpperCase()+m.role.slice(1),notifications=notificationSettingsHtml(m);
  const tabs=PROFILE_TABS.filter(([key])=>key!=='notifications'||notifications);
  document.querySelector('#modal-overlay .modal')?.classList.add('modal-profile');
  document.getElementById('modal-title').textContent = 'My Profile';
  document.getElementById('modal-body').innerHTML = `
    <div class="pf">
      <div class="pf-hero">
        <div class="pf-avatar-wrap">
          <div id="profile-photo-preview" class="profile-photo-preview pf-avatar">${avatarHtml(m,76)}</div>
          <button type="button" class="pf-avatar-edit" aria-label="Upload photo" onclick="document.getElementById('profile-photo-file').click()"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></button>
        </div>
        <div class="pf-identity">
          <div class="pf-name">${escapeHtml(m.name)}</div>
          <div class="pf-meta"><span class="pf-role pf-role-${escapeHtml(m.role)}">${escapeHtml(role)}</span><span>@${escapeHtml(m.username||m.email)}</span></div>
          <div class="pf-photo-actions"><input id="profile-photo-file" type="file" accept="image/jpeg,image/png,image/webp" hidden onchange="chooseProfilePhoto(this)"><button type="button" class="pf-link" onclick="document.getElementById('profile-photo-file').click()">Upload photo</button><button id="profile-photo-remove" type="button" class="pf-link pf-link-muted" onclick="removeProfilePhoto()" ${profilePhotoDraft?'':'hidden'}>Remove</button><span id="profile-photo-status" class="pf-hint" role="status">JPG, PNG or WebP · up to 5 MB</span></div>
        </div>
      </div>
      <div class="pf-tabs" role="tablist" aria-label="Profile sections">${tabs.map(([key,label],index)=>`<button type="button" role="tab" id="pf-tab-${key}" class="pf-tab${index?'':' active'}" aria-selected="${!index}" aria-controls="pf-panel-${key}" onclick="switchProfileTab('${key}')">${label}</button>`).join('')}</div>
      <div class="pf-panels">
      <section class="pf-panel active" id="pf-panel-profile" role="tabpanel" aria-labelledby="pf-tab-profile">
        <div class="pf-grid">
          <div class="pf-field"><label for="p-name">Full name</label><input id="p-name" type="text" value="${escapeHtml(m.name)}"></div>
          <div class="pf-field"><label for="p-username">Username</label><div class="pf-affix"><span>@</span><input id="p-username" type="text" value="${escapeHtml(m.username||'')}"></div></div>
          <div class="pf-field"><label for="p-email">Email <em>optional</em></label><input id="p-email" type="email" value="${escapeHtml(m.email||'')}" placeholder="name@company.com"></div>
          <div class="pf-field"><label for="p-capacity">Weekly capacity</label><div class="pf-affix pf-affix-end"><input id="p-capacity" type="number" min="0" max="168" value="${Number(m.weeklyCapacityHours??40)}"><span>hours / week</span></div></div>
        </div>
        <div class="pf-field"><label>Avatar color</label>${colorPicker(m.color)}</div>
      </section>
      ${notifications?`<section class="pf-panel" id="pf-panel-notifications" role="tabpanel" aria-labelledby="pf-tab-notifications">${notifications}</section>`:''}
      <section class="pf-panel" id="pf-panel-security" role="tabpanel" aria-labelledby="pf-tab-security">
        <p class="pf-intro">Change your password. Other signed-in sessions will be signed out.</p>
        <div class="pf-field"><label for="p-current-pass">Current password</label><input id="p-current-pass" type="password" autocomplete="current-password"></div>
        <div class="pf-grid">
          <div class="pf-field"><label for="p-new-pass">New password</label><input id="p-new-pass" type="password" autocomplete="new-password"></div>
          <div class="pf-field"><label for="p-confirm-pass">Confirm new password</label><input id="p-confirm-pass" type="password" autocomplete="new-password"></div>
        </div>
        <div class="pf-hint">Use at least 6 characters. Leave these empty to keep your current password.</div>
      </section>
      </div>
    </div>`;
  selectedColor = m.color;
  document.getElementById('modal-footer').innerHTML = `
    <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    <button id="profile-save-button" class="btn btn-primary" onclick="saveMyProfile()">Save changes</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}
function switchProfileTab(key){
  document.querySelectorAll('.pf-tab').forEach(tab=>{const on=tab.id==='pf-tab-'+key;tab.classList.toggle('active',on);tab.setAttribute('aria-selected',String(on));});
  document.querySelectorAll('.pf-panel').forEach(panel=>{const on=panel.id==='pf-panel-'+key;panel.classList.toggle('active',on);panel.inert=!on;panel.setAttribute('aria-hidden',String(!on));});
}

function renderProfilePhotoPreview(){
  const element=document.getElementById('profile-photo-preview');
  if(element)element.innerHTML=avatarHtml({...currentUser,profilePhoto:profilePhotoDraft},76);
  const remove=document.getElementById('profile-photo-remove');if(remove)remove.hidden=!profilePhotoDraft;
}
function removeProfilePhoto(){
  profilePhotoGeneration++;profilePhotoDraft='';profilePhotoBusy=false;draftActive=true;editGeneration++;
  const file=document.getElementById('profile-photo-file');if(file)file.value='';
  const save=document.getElementById('profile-save-button');if(save)save.disabled=false;
  const status=document.getElementById('profile-photo-status');if(status)status.textContent='Photo removed. Save Changes to apply.';
  renderProfilePhotoPreview();
}
async function chooseProfilePhoto(input){
  const file=input.files?.[0];if(!file)return;
  const generation=++profilePhotoGeneration,userId=currentUser?.id,preview=document.getElementById('profile-photo-preview');
  const status=document.getElementById('profile-photo-status'),save=document.getElementById('profile-save-button');
  const stillOpen=()=>generation===profilePhotoGeneration&&currentUser?.id===userId&&preview===document.getElementById('profile-photo-preview');
  let bitmap;
  try{
    if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Choose a JPG, PNG or WebP image.');
    if(file.size>5*1024*1024)throw new Error('Choose an image smaller than 5 MB.');
    profilePhotoBusy=true;if(save)save.disabled=true;if(status)status.textContent='Preparing photo…';
    bitmap=await createImageBitmap(file);
    if(!stillOpen())return;
    if(!bitmap.width||!bitmap.height||bitmap.width*bitmap.height>40000000)throw new Error('Choose an image with smaller dimensions.');
    const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;
    const context=canvas.getContext('2d');if(!context)throw new Error('Could not prepare your photo.');
    context.fillStyle='#fff';context.fillRect(0,0,256,256);context.imageSmoothingQuality='high';
    const side=Math.min(bitmap.width,bitmap.height);
    context.drawImage(bitmap,(bitmap.width-side)/2,(bitmap.height-side)/2,side,side,0,0,256,256);
    let photo='';for(const quality of [.85,.7,.55,.4]){photo=canvas.toDataURL('image/jpeg',quality);if(photo.length<=87000)break;}
    if(!safeProfilePhoto(photo)||photo.length>87000)throw new Error('Could not resize this photo. Choose another image.');
    profilePhotoDraft=photo;draftActive=true;editGeneration++;renderProfilePhotoPreview();
    if(status)status.textContent='Photo ready. Save Changes to apply.';
  }catch(error){if(stillOpen()){showToast(error.message||'Could not read this image.','error');if(status)status.textContent='JPG, PNG or WebP · up to 5 MB';}}
  finally{bitmap?.close();if(stillOpen()){profilePhotoBusy=false;if(save)save.disabled=false;input.value='';}}
}
async function saveMyProfile() {
  if(profilePhotoBusy){showToast('Wait for your photo to finish preparing.','error');return;}
  const m = TEAM.find(x => x.id === currentUser.id);
  if(!m) return;

  const name = document.getElementById('p-name').value.trim();
  const username = document.getElementById('p-username').value.trim();
  const email = document.getElementById('p-email').value.trim();
  const currentPass = document.getElementById('p-current-pass').value;
  const newPass = document.getElementById('p-new-pass').value;
  const confirmPass = document.getElementById('p-confirm-pass').value;
  const capacity=Number(document.getElementById('p-capacity').value);

  if(!name || !username || !Number.isFinite(capacity)||capacity<0||capacity>168) { showToast('Enter your name, username, and capacity from 0 to 168 hours.', 'error'); return; }

  // Check username uniqueness
  const dupU = TEAM.find(x => (x.username||'').toLowerCase() === username.toLowerCase() && x.id !== m.id);
  if(dupU) { showToast('Username already taken.', 'error'); return; }

  if(currentPass || newPass || confirmPass) {
    if(!currentPass||newPass.length<6||newPass!==confirmPass)switchProfileTab('security');
    if(!currentPass) { showToast('Enter your current password to change it.', 'error'); return; }
    if(newPass.length < 6) { showToast('New password must be at least 6 characters.', 'error'); return; }
    if(newPass !== confirmPass) { showToast('New passwords do not match.', 'error'); return; }
  }

  // Update profile
  m.name = name;
  m.username = username;
  m.email = email;
  m.weeklyCapacityHours=capacity;
  m.color = selectedColor;
  m.initials = makeInitials(name);
  m.profilePhoto = profilePhotoDraft;
  if(document.getElementById('p-notify-panel'))m.notificationPreferences=Object.fromEntries(NOTIFY_TYPES.map(type=>{const box=document.getElementById('p-notify-'+type.key);return[type.key,box?box.checked:notificationPreference(m,type.key)];}));

  // Update currentUser reference
  currentUser = m;

  // Update sidebar display
  updateSidebarAvatar(m);
  document.getElementById('sb-name').textContent = m.name;

  if(!(await saveRequestsNow()))return;
  if(newPass){
    try{const result=await sendJson('auth/change-password',{currentPassword:currentPass,password:newPass});await loadWorkspace(result.user);showToast('Profile and password updated. Other sessions were signed out.','success');}
    catch(error){showToast(error.message||'Password could not be changed.','error');return;}
  }else{
    showToast('Profile updated.','success');closeModal();
  }
}


// ── MOBILE MENU ───────────────────────────────────────────
function toggleMobileMenu() {
  try {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobile-overlay');
    if(!sidebar) return;
    const isOpen = sidebar.classList.contains('mobile-open');
    const button=document.getElementById('hamburger-btn');
    if(isOpen) {
      sidebar.classList.remove('mobile-open');
      if(overlay) overlay.classList.remove('show');
      if(button)button.setAttribute('aria-expanded','false');
    } else {
      sidebar.classList.add('mobile-open');
      if(overlay) overlay.classList.add('show');
      if(button)button.setAttribute('aria-expanded','true');
    }
  } catch(e) {}
}
function closeMobileMenu() {
  try {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobile-overlay');
    const button=document.getElementById('hamburger-btn');
    if(sidebar) sidebar.classList.remove('mobile-open');
    if(overlay) overlay.classList.remove('show');
    if(button)button.setAttribute('aria-expanded','false');
  } catch(e) {}
}

function openEditNameDesc(id){
  const w=works.find(x=>x.id===id);if(!w)return;
  const body=document.getElementById('modal-body');body.dataset.detailWorkId=String(id);
  const done=w.status==='done'&&currentUser.role==='admin';
  document.getElementById('modal-title').textContent=done?'Edit Completed Work':'Edit Name & Description';
  body.innerHTML=`<div class="form-group"><label class="form-label" for="end-title">Work Title *</label><input id="end-title" type="text" value="${escapeHtml(w.title)}"></div><div class="form-group"><label class="form-label" for="end-desc">Description</label><textarea id="end-desc" style="white-space:pre-wrap;min-height:100px;">${escapeHtml(w.desc||'')}</textarea></div>`
    +(done?`<div class="form-row"><div class="form-group"><label class="form-label" for="end-estimate">Estimated effort (hours)</label><input id="end-estimate" type="number" min="0" max="10000" step="0.5" value="${Number(w.estimatedHours||0)}"></div><div class="form-group"><label class="form-label" for="end-actual">Actual effort (hours)</label><input id="end-actual" type="number" min="0" max="10000" step="0.5" value="${w.actualHours!=null?Number(w.actualHours):''}" placeholder="Not recorded"></div></div><div class="form-group"><label class="form-label" for="end-completed">Completion date</label><input id="end-completed" type="date" value="${escapeHtml(w.completedDate||'')}" max="${TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE)}"><div class="form-hint">Changes reports, on-time rate and weekly capacity for this work.</div></div>`:'');
  document.getElementById('modal-footer').innerHTML=`<button class="btn btn-primary" onclick="saveEditNameDesc(${Number(id)})">Save</button><button class="btn btn-ghost" onclick="openWorkDetail(${Number(id)})">Cancel</button>`;
  document.getElementById('modal-overlay').style.display='flex';
}
async function saveEditNameDesc(id){
  const w=works.find(x=>x.id===id);if(!w)return;
  const title=document.getElementById('end-title').value.trim();
  if(!title){showToast('Title is required.','error');return;}
  const estimateInput=document.getElementById('end-estimate');
  if(estimateInput){
    const estimate=Number(estimateInput.value||0),actualRaw=document.getElementById('end-actual').value.trim(),actual=Number(actualRaw),completed=document.getElementById('end-completed').value;
    const today=TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE);
    if(!Number.isFinite(estimate)||estimate<0||estimate>10000){showToast('Estimated hours must be between 0 and 10,000.','error');return;}
    if(actualRaw!==''&&(!Number.isFinite(actual)||actual<0||actual>10000)){showToast('Actual hours must be between 0 and 10,000.','error');return;}
    if(!TeamFlowDomain.parseDateKey(completed)||completed>today){showToast('Choose a completion date that is not in the future.','error');return;}
    w.estimatedHours=estimate;w.completedDate=completed;
    if(actualRaw==='')delete w.actualHours;else w.actualHours=actual;
  }
  w.title=title;w.desc=document.getElementById('end-desc').value;
  if(!(await saveRequestsNow()))return;
  showToast('Updated!','success');openWorkDetail(id);
}
function toggleSection(sectionId){
  var body=document.getElementById(sectionId);
  var arrId=sectionId.replace('sec-','arr-');
  var arr=document.getElementById(arrId);
  if(!body)return;
  var collapsed=body.classList.contains('collapsed');
  if(collapsed){body.classList.remove('collapsed');if(arr)arr.classList.remove('collapsed');}
  else{body.classList.add('collapsed');if(arr)arr.classList.add('collapsed');}
  document.getElementById('hdr-'+sectionId.replace('sec-',''))?.setAttribute('aria-expanded',String(collapsed));
  try{var state=JSON.parse(localStorage.getItem('sidebar_state')||'{}');
  if(!collapsed){state[sectionId]=true;}else{delete state[sectionId];}
  localStorage.setItem('sidebar_state',JSON.stringify(state));}catch(e){}
}
function restoreSidebarState(){
  try{var state=JSON.parse(localStorage.getItem('sidebar_state')||'{}');Object.keys(state).forEach(function(id){if(state[id]===true){var body=document.getElementById(id);var arr=document.getElementById(id.replace('sec-','arr-'));if(body)body.classList.add('collapsed');if(arr)arr.classList.add('collapsed');}});}catch(e){}
}
function renderChangelog(){
  var versions=[
    {ver:'2.2',date:'Oct 2026',title:'Automation, Actual Effort & Notifications',items:[
      'Upcoming work starts automatically (Ongoing, Planning phase) once its start date arrives.',
      'Mark Complete asks for actual effort hours, prefilled with the estimate; cards and details show actual vs estimated.',
      'Weekly capacity keeps completed work in the weeks it ran, using actual hours.',
      'Admins can correct the estimate, actual effort and completion date of completed work.',
      'Audit reports and PDF exports compare actual and estimated hours for completed work, including each person\'s share of actual hours in the Annual Report.',
      'Admins can assign a creator to templates whose creator is missing or removed.',
      'Admin-managed default tags appear as quick picks in work and template forms; custom tags still work.',
      'Desktop notifications for review-ready and overdue work, including when TeamFlow is closed (web push), with per-person settings in My Profile.',
    ]},
    {ver:'2.1',date:'Oct 2026',title:'Capacity, Collaboration & Reporting',items:[
      'Members can create work, edit their own templates, and manage assignees as creator or PIC.',
      'Templates include estimated hours, creator details, and search.',
      'Profile photo upload and refreshed team cards.',
      'Dashboard redesign with deadline sorting, priority badges, and updated workload colors.',
      'Responsive filters saved separately for each user and page; refresh preserves scroll position.',
      'Weekly capacity and paginated work and activity history.',
      'Lower-cost background sync with shared read caching and coordinated tabs.',
      'Calendar date details include completed work within its original schedule.',
      'Improved report counts, historical completion flags, compact controls, and PDF exports.',
      'Daily Report rendering fix, account setup/reset links, and updated Help & Guide.',
    ]},
    {ver:'2.0',date:'Sep 2026',title:'Major Feature Update',items:[
      'Work Type Classification (Regular / Ad-hoc) with color-coded badges',
      'Move Phase Back — return work to previous phase with system note',
      'Multiline description support with Enter key formatting',
      'Editable Notes — authors and admins can edit notes with timestamp',
      'Improved Sort & Filter — 7 sort options + 4 filters on Ongoing & History',
      'Board Role — executive view-only access with note-adding capability',
      'Admin can edit completed work name/description + Reopen Work button',
      'Full Template Editor — edit all fields including phase tasks',
      'Calendar Enhancement — 3-section date modal (Starting/Deadlines/Active)',
      'Prevent overlay close on Add/Edit Work and Add File Link modals',
      'Templates & Requests pages hidden from Board role',
      'Changelog, Help & Guide, and Feedback pages added',
    ]},
    {ver:'1.5',date:'Sep 2026',title:'Workflow & Collaboration',items:[
      'Join/Leave request system with PIC/Manager approval workflow',
      'PIC (Person in Charge) field on all work items',
      'Daily Report page with PDF export',
      'Weekly & Monthly Audit Reports with PDF export',
      'Username-based login (no email required)',
      'Work Templates — save and reuse work structures',
      'Recurring Work — weekly, biweekly, monthly, quarterly, custom intervals',
      'Calendar view with month picker in Upcoming page',
      'Auto-advance phase tasks when moving to next phase',
      'Copy Path button for internal network file links',
    ]},
    {ver:'1.0',date:'Sep 2026',title:'Initial Release',items:[
      'Ongoing, Upcoming, and History work pages',
      'Work phases: Planning to Executing to Review to Finalize',
      'Customizable phase tasks per work item',
      'Role-based access: Admin, Manager, Member',
      'File/folder links per work item (Google Drive, Figma, internal paths)',
      'Notes & Updates on work items',
      'Team management with Admin panel',
      'Daily digest with overdue alerts and review-ready highlights',
      'Session persistence — stay logged in on refresh',
      'Mobile responsive with hamburger menu',
      'PWA support — add to home screen as app',
    ]},
  ];
  var html='<div class="section-header"><div><div class="section-title">&#128203; Changelog</div><div class="section-sub">Version history and feature updates</div></div></div>';
  versions.forEach(function(v){
    html+='<div class="card" style="margin-bottom:16px;"><div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;"><div style="background:var(--primary);color:#fff;border-radius:var(--radius-sm);padding:4px 10px;font-size:13px;font-weight:700;">v'+v.ver+'</div><div style="font-size:14px;font-weight:700;">'+v.title+'</div><div style="font-size:12px;color:var(--text3);margin-left:auto;">'+v.date+'</div></div><ul style="margin:0;padding-left:20px;">';
    v.items.forEach(function(item){html+='<li style="font-size:13px;color:var(--text2);margin-bottom:6px;">'+item+'</li>';});
    html+='</ul></div>';
  });
  document.getElementById('content').innerHTML=html;
}
function renderHelp(){
  var sections=[
    {icon:'&#128205;',title:'Work Management',items:[
      '<strong>Add Work</strong> — Admins, managers, and members can create work from Ongoing, Upcoming, or Templates. Set dates, estimated hours, work type, recurrence, PIC, assignees, and phase tasks. Members are automatically assigned to work they create.',
      '<strong>Work Types</strong> — Regular uses a solid blue border; Ad-hoc uses a dashed orange border.',
      '<strong>Phases</strong> — Planning → Executing → Review → Finalize. Use work-detail actions to advance or return to a previous phase.',
      '<strong>Automatic Start</strong> — Upcoming work moves to Ongoing (Planning phase) automatically within an hour of its start date arriving in the team timezone. Start Work still starts it early.',
      '<strong>Completing Work</strong> — Mark Complete asks for the actual effort in hours, prefilled with the estimate. Completed cards show actual / estimated hours. Admins can correct the title, description, estimate, actual effort and completion date with Edit Completed Work.',
      '<strong>Tags</strong> — Pick from the default tags set by Admin, or type your own separated by commas. Admins manage the default list in Admin Panel → Default Tags.',
      '<strong>Edit Work</strong> — Estimated effort and work type share a row on wider screens. PIC follows recurrence. Save changes to update assignments and capacity.',
      '<strong>Files &amp; Notes</strong> — Attach external links or internal paths, and add notes where your role permits. Use Copy Path for internal network links.',
      '<strong>Activity History</strong> — Expand Activity History inside a work item to load its recorded creation and changes, including the actor, time, and changed fields.',
    ]},
    {icon:'&#128269;',title:'Search &amp; Filters',items:[
      '<strong>Search Work</strong> — Search titles and descriptions on Ongoing, Upcoming, or History. Combine search with work type, priority, PIC, and the available phase filter.',
      '<strong>Sorting</strong> — Order by deadline, title, or creation date. Phase filtering is available on Ongoing.',
      '<strong>Independent Choices</strong> — Each account and page keeps its own search, filters, and sorting in this browser. Choices survive navigation, refresh, and reload; they are not shared with other users or devices.',
      '<strong>Reset</strong> — Clears only the current account and page. Controls wrap automatically on smaller screens.',
    ]},
    {icon:'&#128101;',title:'Accounts &amp; Roles',items:[
      '<strong>Admin</strong> — Manages team accounts and work, including completed-work edits and reopening.',
      '<strong>Manager</strong> — Creates and manages work, assignments, templates, and join/leave approvals.',
      '<strong>Member</strong> — Creates work, edits permitted fields on assigned work or work they own as PIC, and edits templates they created. The work creator or PIC can change assignees; members request to join or leave other work.',
      '<strong>Board</strong> — Read-only access. Cannot create, edit, or add notes to work.',
      '<strong>PIC</strong> — Responsible for the work, assignee changes, and join/leave approvals. Only admins and managers can transfer the PIC. PIC effort weighting takes precedence over role.',
      '<strong>Passwords</strong> — Sign in with your username and password. Contact Admin for a single-use reset link valid for 30 minutes. Initial invitation links last 24 hours and can be used once.',
      '<strong>My Profile</strong> — Update your name, username, email, weekly capacity, and avatar color. Upload a JPG, PNG, or WebP photo up to 5 MB, preview it, then Save Changes. Photos are cropped and resized automatically; Remove photo restores initials. Passwords require at least 6 characters; changing one signs out other sessions.',
      '<strong>Notifications</strong> — In My Profile, choose which alerts you want: work ready for review (admins and managers) and overdue work where you are the PIC or an assignee (once a day). Select Turn on for this device to allow desktop notifications; each browser or installed app asks separately. Alerts also arrive while TeamFlow is closed, as long as the browser is running in the background (iPhone: add TeamFlow to the Home Screen first). Overdue alerts are sent at 10:30 Jakarta time. Signing out stops alerts on that device.',
    ]},
    {icon:'&#128197;',title:'Schedule &amp; Calendar',items:[
      '<strong>Upcoming</strong> — The month calendar appears above the work search and filters. Use the chevron buttons, month/year selectors, or Today to navigate.',
      '<strong>Weeks</strong> — Calendar columns run Monday–Sunday, matching Capacity and weekly Audit reports.',
      '<strong>Flag Fills</strong> — Light blue marks a start date; red marks a deadline.',
      '<strong>Flag Borders</strong> — Solid blue identifies Regular work; dashed orange identifies Ad-hoc work, for both starts and deadlines.',
      '<strong>Date Details</strong> — Click a date to view Starting Today, Deadlines Today, Active Work, and Completed Work. Completed work remains visible throughout its original start-to-deadline range; the start and deadline dates stay in their respective sections.',
      '<strong>History</strong> — Calendar date details show the current completed status even for selected dates before the actual completion date. Open a card to inspect the work.',
    ]},
    {icon:'&#9878;',title:'Weekly Capacity',items:[
      '<strong>Included People</strong> — Weekly capacity shows members and managers.',
      '<strong>Set Capacity</strong> — Set weekly hours in My Profile, or use Admin → Edit Member to manage team capacity.',
      '<strong>Estimate Work</strong> — Enter total estimated hours on a work item. Capacity compares planned effort with availability.',
      '<strong>Completed Work</strong> — Completed work stays in capacity for the weeks it actually ran, from start date to completion date, using its actual hours (or the estimate if none was recorded). Its chips are labelled Done.',
      '<strong>Weekday Split</strong> — Hours are spread evenly across Monday–Friday dates from start through deadline, inclusive. Weekends receive no hours; work with no scheduled weekdays is flagged for date adjustment.',
      '<strong>Effort Shares</strong> — Shares are normalized so the total estimate stays unchanged; the PIC is included even if not separately assigned.',
      '<strong>Example</strong> — A 10-hour individual share scheduled Oct 3–7, 2026 falls entirely in Oct 5–7 because Oct 3–4 is a weekend.',
      '<strong>Navigate</strong> — Use the chevron buttons to inspect each Monday–Sunday week. Red bars and Over capacity labels indicate excess planned hours.',
    ]},
    {icon:'&#128203;',title:'Daily Report',items:[
      '<strong>Daily Report</strong> — Review ongoing work, review-ready items, overdue work, and upcoming deadlines in one page.',
      '<strong>Export</strong> — Export PDF downloads a printable report. Open the downloaded file and use Print → Save as PDF.',
    ]},
    {icon:'&#128202;',title:'Dashboard, Audit &amp; History',items:[
      '<strong>Dashboard</strong> — Six active work items are sorted by earliest deadline and show phase and priority badges. Phase/priority summaries, Due Soon, and Team Workload share a balanced layout. View capacity opens Capacity; workload summaries include active members and managers.',
      '<strong>Weekly Audit</strong> — Uses Monday–Sunday weeks. Completed work is grouped by completion date within the selected period.',
      '<strong>Annual Audit</strong> — Uses January–December of the selected year and includes member and manager performance for assignments and PIC responsibilities. Use the centered chevrons to change years; Export PDF beside the title includes member performance.',
      '<strong>Monthly Audit</strong> — Uses the selected calendar month. Date ranges use the team timezone, defaulting to Asia/Bangkok.',
      '<strong>Ongoing Work</strong> — Past reports count work started by period end and not completed until afterward, including overdue carryover. Current-period reports include every item marked ongoing, even if its planned start date is later. Upcoming work is excluded.',
      '<strong>Period Totals</strong> — Monthly and annual Work in period equals Completed plus Ongoing. Creation date does not determine inclusion; work starting later is excluded unless it is already marked ongoing in the current period.',
      '<strong>Completed Later</strong> — Work finished after a historical cutoff stays in that period’s ongoing count. Its row shows Completed with the actual date and 100% progress. Other phase/progress values show current work details.',
      '<strong>Reporting Cutoff</strong> — Past periods use their end date. Current periods use today; upcoming periods do not project unfinished work or overdue dates into the future.',
      '<strong>Actual vs Estimated</strong> — Completed-work sections show each item\'s actual / estimated hours and a total with the % difference. Totals only include items with actual hours recorded. The Annual Report shows each person\'s share of actual hours, split with the same PIC / member / manager weights as capacity.',
      '<strong>On-time Rate</strong> — Period completions with a deadline are eligible. The rate is the number completed on or before the deadline divided by eligible completions.',
      '<strong>History &amp; Performance</strong> — History contains completed work; Annual Report includes member-level summaries. Use the weekly/monthly/annual arrows to change report periods.',
    ]},
    {icon:'&#128203;',title:'Templates, Recurrence &amp; Requests',items:[
      '<strong>Templates</strong> — Admins, managers, and members can save and reuse work structures, phase tasks, and estimated hours. Members edit only templates they created; admins and managers can edit all templates. Cards show the creator and creation date. Use the search bar to find templates by name, description, tag, or creator. When a creator is not recorded or was removed, Admin can select Assign creator.',
      '<strong>Recurrence</strong> — Choose a recurrence in the work form. Completing the work creates its next occurrence.',
      '<strong>Join / Leave</strong> — Members request to join active work or leave an assignment; PICs and managers review requests. PICs cannot request to leave their own work.',
    ]},
    {icon:'&#128190;',title:'Saving &amp; Accessibility',items:[
      '<strong>Install App</strong> — In Chrome, choose Cast, save, and share → Install page as app. Close and reopen app windows after an update.',
      '<strong>Offline</strong> — A reconnect page is available offline. Sign-in, shared work, feedback, and saving require an internet connection.',
      '<strong>Automatic Refresh</strong> — Shared changes are checked every 30 seconds while the page is visible. Refresh preserves your scroll position; open forms pause shared refresh while you edit.',
      '<strong>Saving</strong> — Task checkmarks update immediately while saving. Wait for Saved before leaving. If saving fails, edits are kept; use Retry for a connection error, or resolve a save conflict.',
      '<strong>Conflicting Edits</strong> — If someone changed the same record, reconcile with the latest version before retrying. Keep a copy of your edits before refreshing.',
      '<strong>Keyboard &amp; Mobile</strong> — Use Tab to move through controls and Enter or Space to activate buttons. Visible focus and reduced-motion support help navigation; the mobile menu opens from the top bar.',
    ]},
  ];
  var html='<div class="section-header"><div><div class="section-title">&#10067; Help &amp; Guide</div><div class="section-sub">Quick reference for all features</div></div></div>';
  sections.forEach(function(s){
    html+='<div class="card" style="margin-bottom:16px;"><div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;"><span style="font-size:20px;">'+s.icon+'</span><div style="font-size:15px;font-weight:700;">'+s.title+'</div></div><ul style="margin:0;padding-left:20px;">';
    s.items.forEach(function(item){html+='<li style="font-size:13px;color:var(--text2);margin-bottom:8px;line-height:1.5;">'+item+'</li>';});
    html+='</ul></div>';
  });
  document.getElementById('content').innerHTML=html;
}
let feedbackBusy=false;
let pendingFeedbackId=null;
async function renderFeedback(refresh=true){
  const content=document.getElementById('content');
  if(refresh&&!hasPendingChanges&&!draftActive&&!feedbackBusy){
    renderFeedback(false);
    const marker=beginPageRefresh(content),generation=editGeneration,userId=currentUser.id;
    try{
      const latest=await apiGet('works');
      if(!marker.isConnected||currentUser?.id!==userId||currentPage!=='feedback'||generation!==editGeneration||hasPendingChanges||draftActive||feedbackBusy)return;
      feedbackItems=latest.feedbackItems||[];
      remoteState.collections.feedbackItems=cloneValue(feedbackItems);
      remoteState.versions.feedbackItems=latest.versions?.feedbackItems||1;
      renderFeedback(false);
    }catch(error){if(marker.isConnected)showToast('Could not refresh feedback. Existing entries are shown.','error');}
    finally{marker.remove();}
    return;
  }
  var cats=['Bug Report','Suggestion','Compliment','Other'];
  var statuses={open:{label:'Open',color:'var(--primary)'},noted:{label:'Noted',color:'var(--yellow)'},inprogress:{label:'In Progress',color:'var(--orange)'},done:{label:'Done',color:'var(--green)'}};
  var html='<div class="section-header"><div><div class="section-title">&#128172; Feedback</div><div class="section-sub">Share your thoughts, suggestions, or report issues</div></div></div>';
  if(currentUser.role!=='board')html+='<div class="card" style="margin-bottom:20px;"><div class="card-title" style="margin-bottom:12px;">&#9997; Submit Feedback</div>'
    +'<div class="form-row"><div class="form-group"><label class="form-label" for="fb-cat">Category</label>'
    +'<select id="fb-cat" class="app-select">'+cats.map(function(c){return'<option>'+c+'</option>';}).join('')+'</select></div>'
    +'<div class="form-group"><label class="form-label" for="fb-name">Your Name</label>'
    +'<input id="fb-name" class="app-input" type="text" maxlength="120" autocomplete="name" value="'+escapeHtml(currentUser?currentUser.name:'')+'" placeholder="Your name"></div></div>'
    +'<div class="form-group"><label class="form-label">Feedback *</label>'
    +'<textarea id="fb-text" placeholder="Describe your feedback, suggestion, or issue..." style="min-height:80px;"></textarea></div>'
    +'<button class="btn btn-primary" onclick="submitFeedback()">Submit Feedback</button></div>';
  if(!feedbackItems.length){
    html+='<div class="empty-state"><div class="icon">&#128172;</div><p>No feedback yet. Be the first to share!</p></div>';
  } else {
    html+='<div style="display:flex;flex-direction:column;gap:12px;">';
    feedbackItems.slice().reverse().forEach(function(fb){
      var st=statuses[fb.status]||statuses.open;
      var isAdmin=currentUser&&['admin','manager'].includes(currentUser.role);
      var adminBtns=isAdmin?('<div style="display:flex;gap:6px;margin-top:10px;flex-wrap:wrap;">'
        +'<button class="btn btn-ghost btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'noted\')">&#128065; Noted</button>'
        +'<button class="btn btn-ghost btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'inprogress\')" style="color:var(--orange);">&#128295; In Progress</button>'
        +'<button class="btn btn-success btn-sm" onclick="setFeedbackStatus('+Number(fb.id)+',\'done\')">&#10003; Done</button>'
        +'<button class="btn btn-danger btn-sm" onclick="deleteFeedback('+Number(fb.id)+')">&#128465;</button>'
        +'</div>'):'';
      html+='<div class="card"><div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;">'
        +'<span class="badge" style="background:var(--primary-dim);color:var(--primary);border:1px solid rgba(59,111,212,0.2);">'+escapeHtml(fb.category)+'</span>'
        +'<span class="badge" style="background:rgba(0,0,0,0.05);color:'+st.color+';">'+st.label+'</span>'
        +'<span style="font-size:12px;color:var(--text3);margin-left:auto;">'+escapeHtml(fb.author)+' &middot; '+fmt(fb.date)+'</span>'
        +'</div><div style="font-size:14px;color:var(--text);line-height:1.6;white-space:pre-wrap;">'+escapeHtml(fb.text)+'</div>'+adminBtns+'</div>';
    });
    html+='</div>';
  }
  document.getElementById('content').innerHTML=html;
}
async function submitFeedback(){
  if(feedbackBusy)return;
  const text=document.getElementById('fb-text').value.trim();
  if(!text||text.length>3000){showToast('Enter feedback of 1–3,000 characters.','error');return;}
  if(currentUser.role==='board'){showToast('Board accounts have read-only access.','error');return;}
  const entry={id:pendingFeedbackId||newRecordId(),category:document.getElementById('fb-cat').value,author:document.getElementById('fb-name').value.trim()||currentUser.name,authorId:currentUser.id,text,date:todayStr,status:'open'};
  feedbackBusy=true;
  pendingFeedbackId=entry.id;
  feedbackItems=feedbackItems.filter(item=>item.id!==entry.id);feedbackItems.push(entry);
  try{if(await saveRequestsNow()){showToast('Feedback submitted.','success');pendingFeedbackId=null;draftActive=false;await renderFeedback();}}
  finally{feedbackBusy=false;}
}
async function setFeedbackStatus(id,status){
  if(feedbackBusy||!['admin','manager'].includes(currentUser.role))return;
  const fb=feedbackItems.find(item=>item.id===id);if(!fb)return;
  feedbackBusy=true;fb.status=status;
  try{if(await saveRequestsNow()){await renderFeedback();showToast('Feedback updated.','success');}}
  finally{feedbackBusy=false;}
}
async function deleteFeedback(id){
  if(feedbackBusy||!['admin','manager'].includes(currentUser.role)||!await appConfirm('Delete this feedback?'))return;
  feedbackBusy=true;feedbackItems=feedbackItems.filter(item=>item.id!==id);
  try{if(await saveRequestsNow()){await renderFeedback();showToast('Feedback deleted.','success');}}
  finally{feedbackBusy=false;}
}
function closeModal(){document.getElementById('account-link-result')?.remove();document.querySelector('#modal-overlay .modal')?.classList.remove('modal-profile');document.getElementById('modal-overlay').style.display='none';if(!hasPendingChanges)draftActive=false;}
function closeModalOnOverlay(e){
  if(e.target!==document.getElementById('modal-overlay'))return;
  const title=(document.getElementById('modal-title').textContent||'');
  const prot=['Add New Work','Edit Work','New Work from Template','Add File / Folder Link','Edit Template','Complete Work','Edit Completed Work'];
  if(prot.some(t=>title.includes(t)))return;
  closeModal();
}

// ── DESKTOP NOTIFICATIONS ─────────────────────────────────
// Shown while TeamFlow is open or running as an installed app; each device keeps its own record of what it already showed.
const NOTIFY_TYPES=[
  {key:'reviewReady',label:'Work ready for review',hint:'When work reaches the Review phase.',roles:['admin','manager']},
  {key:'overdueToday',label:'Overdue work',hint:'Once a day, for overdue work where you are the PIC or an assignee.',roles:['admin','manager','member']},
];
const NOTIFY_STATE_PREFIX='teamflow_notified_v1:';
function notificationPreference(member,key){return member?.notificationPreferences?.[key]!==false;}
function desktopNotificationState(){return typeof Notification==='undefined'?'unsupported':Notification.permission;}
// Each device can be switched off on its own; the browser permission itself can only be changed in browser settings.
const DEVICE_NOTIFY_OFF_PREFIX='teamflow_device_notify_off:';
function deviceNotificationsOff(){try{return !!currentUser&&localStorage.getItem(DEVICE_NOTIFY_OFF_PREFIX+currentUser.id)==='1';}catch{return false;}}
function setDeviceNotificationsOff(off){try{if(off)localStorage.setItem(DEVICE_NOTIFY_OFF_PREFIX+currentUser.id,'1');else localStorage.removeItem(DEVICE_NOTIFY_OFF_PREFIX+currentUser.id);}catch{}}
function deviceNotificationsOn(){return desktopNotificationState()==='granted'&&!deviceNotificationsOff();}
function desktopNotificationStatusText(){
  const state=desktopNotificationState();
  if(state==='unsupported')return'This browser does not support desktop notifications.';
  if(state==='denied')return'Blocked by this browser. Allow notifications for TeamFlow in the browser\'s site settings, then switch this on.';
  if(state==='default'||deviceNotificationsOff())return'Off. Switch on to get alerts on this computer or phone.';
  return pushSubscribed?'On, including when TeamFlow is closed.':'On while TeamFlow is open.';
}
function desktopNotificationActionsHtml(){
  return deviceNotificationsOn()?'<button type="button" class="btn btn-ghost btn-sm" onclick="sendTestNotification()">Send a test</button>':'';
}
function notificationSettingsHtml(member){
  const types=NOTIFY_TYPES.filter(type=>type.roles.includes(member.role));
  if(!types.length)return'';
  const blocked=['denied','unsupported'].includes(desktopNotificationState());
  return`<div id="p-notify-panel">
    <div class="pf-device"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg><div class="pf-device-text"><strong>Notifications on this device</strong><span id="p-notify-status" role="status">${desktopNotificationStatusText()}</span></div><span class="pf-switch"><input type="checkbox" id="p-device-notify" aria-label="Notifications on this device" ${deviceNotificationsOn()?'checked':''} ${blocked?'disabled':''} onchange="toggleDeviceNotifications(this)"><span aria-hidden="true"></span></span></div>
    <div id="p-notify-actions" class="pf-device-actions">${desktopNotificationActionsHtml()}</div>
    <div class="pf-list">${types.map(type=>`<label class="pf-switch-row"><span class="pf-switch-text"><strong>${type.label}</strong><span>${type.hint}</span></span><span class="pf-switch"><input type="checkbox" id="p-notify-${type.key}" ${notificationPreference(member,type.key)?'checked':''}><span aria-hidden="true"></span></span></label>`).join('')}</div>
  </div>`;
}
function refreshNotificationPanel(){
  const status=document.getElementById('p-notify-status'),actions=document.getElementById('p-notify-actions'),toggle=document.getElementById('p-device-notify');
  if(status)status.textContent=desktopNotificationStatusText();
  if(actions)actions.innerHTML=desktopNotificationActionsHtml();
  if(toggle){toggle.checked=deviceNotificationsOn();toggle.disabled=['denied','unsupported'].includes(desktopNotificationState());}
}
async function toggleDeviceNotifications(input){
  input.disabled=true;
  try{
    if(input.checked){
      setDeviceNotificationsOff(false);
      if(desktopNotificationState()==='default'){try{await Notification.requestPermission();}catch{}}
      if(desktopNotificationState()==='granted'){await ensurePushSubscription(true);showToast('Notifications are on for this device.','success');checkDesktopNotifications();}
      else showToast('The browser did not allow notifications for TeamFlow.','error');
    }else{
      setDeviceNotificationsOff(true);await removePushSubscription();
      showToast('Notifications are off for this device.','info');
    }
  }finally{refreshNotificationPanel();}
}
// ── Web push: lets the server alert this device while TeamFlow is closed ──
let pushSubscribed=false,pushCheckedFor=null;
function base64UrlToBytes(value){const padded=(value+'='.repeat((4-value.length%4)%4)).replace(/-/g,'+').replace(/_/g,'/');return Uint8Array.from(atob(padded),char=>char.charCodeAt(0));}
async function pushRegistration(){
  if(typeof navigator==='undefined'||!navigator.serviceWorker||typeof PushManager==='undefined')return null;
  try{return await navigator.serviceWorker.getRegistration()||null;}catch{return null;}
}
async function ensurePushSubscription(force=false){
  if(!currentUser||!deviceNotificationsOn())return false;
  if(!force&&pushCheckedFor===currentUser.id)return pushSubscribed;
  pushCheckedFor=currentUser.id;pushSubscribed=false;
  const registration=await pushRegistration();if(!registration)return false;
  try{
    const {publicKey}=await apiGet('push');if(!publicKey)return false;
    const subscription=await registration.pushManager.getSubscription()||await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:base64UrlToBytes(publicKey)});
    await sendJson('push',{operation:'subscribe',subscription:subscription.toJSON()});
    pushSubscribed=true;
  }catch(error){console.warn('Push subscription unavailable:',error.message);}
  return pushSubscribed;
}
async function removePushSubscription(){
  const registration=await pushRegistration();
  try{
    const subscription=registration&&await registration.pushManager.getSubscription();
    if(subscription){try{await sendJson('push',{operation:'unsubscribe',endpoint:subscription.endpoint});}catch{}await subscription.unsubscribe();}
  }catch{}
  pushSubscribed=false;pushCheckedFor=null;
}
async function sendTestNotification(){
  if(pushSubscribed){
    try{const result=await sendJson('push',{operation:'test'});if(result.delivered){showToast('Test sent from the server. It should appear in a moment.','success');return;}}catch{}
    showToast('The server could not reach this device; showing a local test instead.','info');
  }
  showDesktopNotification('TeamFlow notifications are working','You will see review-ready and overdue alerts here.','teamflow-test-'+Date.now()+'-'+(++testNotificationCount),null);}
let testNotificationCount=0;
async function showDesktopNotification(title,body,tag,workId){
  if(!deviceNotificationsOn())return;
  const options={body,tag,renotify:Boolean(tag),icon:'/icon-192.png',badge:'/icon-192.png',data:{workId:workId??null}};
  try{
    const registration=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration();
    if(registration){await registration.showNotification(title,options);return;}
  }catch{}
  try{const note=new Notification(title,options);note.onclick=()=>{window.focus();if(workId!=null)openWorkFromNotification(workId);note.close();};}catch{}
}
function openWorkFromNotification(workId){
  const id=Number(workId);
  if(!currentUser)return;
  if(works.some(work=>work.id===id))openWorkDetail(id);
  else showToast('That work item is no longer available.','info');
}
function readNotifyState(){try{return JSON.parse(localStorage.getItem(NOTIFY_STATE_PREFIX+currentUser.id)||'null')||{};}catch{return{};}}
function writeNotifyState(state){try{localStorage.setItem(NOTIFY_STATE_PREFIX+currentUser.id,JSON.stringify(state));}catch{}}
function listTitles(items){return items.slice(0,3).map(work=>work.title).join(', ')+(items.length>3?` and ${items.length-3} more`:'');}
function checkDesktopNotifications(){
  if(!currentUser||!deviceNotificationsOn())return;
  const me=TEAM.find(member=>member.id===currentUser.id)||currentUser,state=readNotifyState();
  // With web push active, the server sends these alerts; showing them here too would duplicate them.
  const show=pushSubscribed?()=>{}:showDesktopNotification;
  const today=TeamFlowDomain.dateKeyInZone(new Date(),TEAM_TIME_ZONE);
  const inReview=works.filter(work=>work.status==='ongoing'&&work.phase===2);
  if(['admin','manager'].includes(me.role)&&notificationPreference(me,'reviewReady')){
    const seen=new Set(state.reviewReady||[]),fresh=inReview.filter(work=>!seen.has(work.id));
    if(fresh.length===1)show('Ready for review',fresh[0].title,'review-'+fresh[0].id,fresh[0].id);
    else if(fresh.length>1)show(`${fresh.length} items ready for review`,listTitles(fresh),'review-batch',null);
  }
  // Leaving Review clears the record, so work that returns to Review notifies again.
  state.reviewReady=inReview.map(work=>work.id);
  if(notificationPreference(me,'overdueToday')&&state.overdueDate!==today){
    const mine=works.filter(work=>work.status!=='done'&&work.deadline&&work.deadline<today&&(String(work.pic)===String(me.id)||(work.assignees||[]).some(id=>String(id)===String(me.id))));
    if(mine.length===1)show('Overdue work',`${mine[0].title} was due ${fmt(mine[0].deadline)}.`,'overdue-'+today,mine[0].id);
    else if(mine.length>1)show(`${mine.length} overdue items`,listTitles(mine),'overdue-'+today,null);
    state.overdueDate=today;
  }
  writeNotifyState(state);
}
let notificationLinkHandled=false;
async function afterWorkspaceSync(){
  await ensurePushSubscription();
  checkDesktopNotifications();
  if(notificationLinkHandled||!currentUser||typeof location==='undefined')return;
  notificationLinkHandled=true;
  const params=new URLSearchParams(location.search),workId=params.get('work');
  if(!workId)return;
  params.delete('work');history.replaceState(null,'',location.pathname+(params.toString()?'?'+params:'')+location.hash);
  openWorkFromNotification(workId);
}
if(typeof navigator!=='undefined'&&navigator.serviceWorker)navigator.serviceWorker.addEventListener('message',event=>{if(event.data?.type==='teamflow-open-work')openWorkFromNotification(event.data.workId);});
setInterval(()=>{if(currentUser)checkDesktopNotifications();},10*60*1000);

// ============================================================
