'use strict';

const {MemoryStore}=require('../scripts/memory-store');

function memberRecord(member, version = 1) {
  return JSON.stringify({ data: member, version, updatedAt: new Date().toISOString() });
}

async function sessionEvent(member, store, method = 'GET', path = '/') {
  const { createSession } = require('../netlify/functions/lib/auth-core');
  const session = await createSession(member, store);
  return {
    httpMethod: method,
    path,
    headers: { cookie: session.cookie['Set-Cookie'].split(';')[0] },
    body: '',
  };
}

module.exports = { MemoryStore, memberRecord, sessionEvent };
