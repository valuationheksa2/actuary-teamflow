'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { MemoryStore, memberRecord, sessionEvent } = require('./helpers');
const authCore = require('../netlify/functions/lib/auth-core');
const records = require('../netlify/functions/lib/records');
const http = require('../netlify/functions/lib/http');
const auth = require('../netlify/functions/auth');
const team = require('../netlify/functions/team');
const works = require('../netlify/functions/works');
const digest = require('../netlify/functions/digest');
const { appendActivity } = require('../netlify/functions/lib/activity-log');

const validMember = (overrides = {}) => ({
  id: 4, name: 'Test Manager', email: 'manager@example.test', username: 'manager', role: 'manager',
  active: true, authVersion: 1, passwordHash: 'scrypt$test$not-a-real-hash', weeklyCapacityHours: 40, ...overrides,
});

test('passwords are scrypt-hashed and verification does not accept a mismatch', async () => {
  const encoded = await authCore.passwordHash('A long and unique password 2026!');
  assert.match(encoded, /^scrypt\$/);
  assert.equal(await authCore.verifyPassword('A long and unique password 2026!', encoded), true);
  assert.equal(await authCore.verifyPassword('wrong password', encoded), false);
  assert.equal(JSON.stringify(encoded).includes('A long and unique password'), false);
});

test('old sessions stop working immediately after the password generation changes', async () => {
  const user = validMember();
  const store = new MemoryStore({ 'v2:member:4': memberRecord(user) });
  const event = await sessionEvent(user, store);
  assert.equal((await authCore.sessionUser(event, store)).id, user.id);
  await store.set('v2:member:4', memberRecord({ ...user, authVersion: 2 }, 2));
  assert.equal(await authCore.sessionUser(event, store), null);
});

test('unauthenticated team, work, and digest requests are rejected', async () => {
  const store = new MemoryStore();
  const event = { httpMethod: 'GET', path: '/.netlify/functions/team', headers: {}, queryStringParameters: {} };
  for (const handler of [team._test.handle, works._test.handle, digest._test.handle]) {
    await assert.rejects(handler(event, store), error => error.statusCode === 401);
  }
});

test('team responses omit password hashes and password fields', async () => {
  const user = validMember({ passwordHash: 'scrypt$private$hash', password: 'legacy-secret' });
  const store = new MemoryStore({ 'v2:member:4': memberRecord(user) });
  const event = await sessionEvent(user, store, 'GET', '/.netlify/functions/team');
  const response = await team._test.handle(event, store);
  const payload = JSON.parse(response.body);
  assert.equal(response.statusCode, 200);
  assert.equal(payload[0].password, undefined);
  assert.equal(payload[0].passwordHash, undefined);
  assert.equal(JSON.stringify(payload).includes('legacy-secret'), false);
});

test('non-admins cannot create team accounts and stale record versions conflict', async () => {
  const user = validMember();
  const store = new MemoryStore({ 'v2:member:4': memberRecord(user) });
  const event = await sessionEvent(user, store, 'POST', '/.netlify/functions/team');
  event.body = JSON.stringify({ operation: 'upsert', member: { id: 5, name: 'New Person', email: 'new@example.test', username: 'new', role: 'member' }, expectedVersion: 0 });
  await assert.rejects(team._test.handle(event, store), error => error.statusCode === 403);

  await store.set('v2:work:17', memberRecord({ id: 17, title: 'Quarter close' }, 3));
  await assert.rejects(records.saveRecord('work', { id: 17, title: 'Changed' }, 2, store), error => error.statusCode === 409);
});

test('work validation rejects active links and malformed nested records', () => {
  const { normalizeWork } = works._test;
  assert.equal(normalizeWork({ id: 1, title: 'Valid', files: [{ name: 'Plan', url: 'https://example.test/plan', type: 'doc' }] }).files.length, 1);
  assert.equal(normalizeWork({ id: 1, title: 'Valid', files: [{ name: 'Share', url: '//fileserver/team', type: 'internal' }] }).files.length, 1);
  assert.throws(() => normalizeWork({ id: 1, title: 'Invalid', files: [{ name: 'Bad', url: 'javascript:alert(1)', type: 'doc' }] }), error => error.statusCode === 400);
  assert.throws(() => normalizeWork({ id: 1, title: 'Invalid', notes: [null] }), error => error.statusCode === 400);
});

test('members can update their own note but cannot change work assignments', async () => {
  const user = validMember({ id: 4, role: 'member' });
  const current = { id: 17, title: 'Quarter close', status: 'ongoing', priority: 'Medium', phase: 0, pic: 4, assignees: [4], notes: [], files: [], tags: [], phaseTasks: {}, phaseChecks: {}, estimatedHours: 2 };
  const store = new MemoryStore({ 'v2:member:4': memberRecord(user), 'v2:work:17': memberRecord(current) });
  const event = await sessionEvent(user, store, 'POST', '/.netlify/functions/works');
  event.body = JSON.stringify({ operation: 'upsert', expectedVersion: 1, work: { ...current, assignees: [4, 8] } });
  const denied = await works._test.handle(event, store);
  assert.equal(denied.statusCode, 403);

  event.body = JSON.stringify({ operation: 'upsert', expectedVersion: 1, work: { ...current, notes: [{ authorId: 4, authorName: user.name, text: 'Updated from fixture', createdDate: '2026-09-29' }] } });
  const saved = await works._test.handle(event, store);
  assert.equal(saved.statusCode, 200);
  assert.match((await store.get('v2:work:17')), /Updated from fixture/);
});

test('team normalization validates usernames and derives safe initials and colors', () => {
  const { normalizeMember } = team._test;
  assert.throws(() => normalizeMember({ id: 1, name: 'Alex Smith', email: 'alex@example.test', username: 'bad name', role: 'member' }), error => error.statusCode === 400);
  const member = normalizeMember({ id: 1, name: ' Alex Smith ', email: 'ALEX@example.test', username: 'alex', role: 'member', initials: '<svg>', color: 'red' });
  assert.equal(member.name, 'Alex Smith');
  assert.equal(member.initials, 'AS');
  assert.equal(member.color, '#5c6ef8');
});

test('activity history records changed field names without copying field values', async () => {
  const store = new MemoryStore();
  const entry = await appendActivity(store, 17, { id: 4, name: 'Test Member' }, 'updated', { title: 'Private old title' }, { title: 'Private new title' });
  assert.deepEqual(entry.changedFields, { title: true });
  const stored = JSON.stringify([...store.values.values()]);
  assert.equal(stored.includes('Private old title'), false);
  assert.equal(stored.includes('Private new title'), false);
});

test('reset links are rejected after expiry or first use', async () => {
  const token = 'single-use-reset-token';
  const key = `auth:reset:${authCore.sha256(token)}`;
  const store = new MemoryStore({
    [key]: JSON.stringify({ userId: 4, expiresAt: Date.now() - 1 }),
  });
  assert.equal(await auth._test.readResetToken(store, token), null);
  await store.set(key, JSON.stringify({ userId: 4, expiresAt: Date.now() + 30_000, usedAt: Date.now() }));
  assert.equal(await auth._test.readResetToken(store, token), null);
});

test('CORS allows only configured exact origins and API responses carry security headers', () => {
  assert.equal(http.originAllowed({ headers: { origin: 'https://actuaryteamflow.netlify.app' } }), true);
  assert.equal(http.originAllowed({ headers: { origin: 'https://attacker.example' } }), false);
  const response = http.response({ headers: { origin: 'https://actuaryteamflow.netlify.app' } }, 200, { ok: true });
  assert.equal(response.headers['Access-Control-Allow-Origin'], 'https://actuaryteamflow.netlify.app');
  assert.equal(response.headers['X-Frame-Options'], 'DENY');
  assert.match(response.headers['Content-Security-Policy'], /frame-ancestors 'none'/);
});
