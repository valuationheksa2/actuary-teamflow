'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {MemoryStore,memberRecord,sessionEvent}=require('./helpers');
const records=require('../netlify/functions/lib/records');
const works=require('../netlify/functions/works')._test;
const team=require('../netlify/functions/team')._test;
const {startDueWork}=require('../netlify/functions/auto-start');
const domain=require('../public/js/domain');
const person=(role,id)=>({id,role,name:role+' '+id,email:role+id+'@example.test',username:role+id,active:true,passwordHash:'fixture',authVersion:1});
const seeded=users=>new MemoryStore(Object.fromEntries(users.map(u=>['v2:member:'+u.id,memberRecord(u)])));
async function post(user,store,body){const event=await sessionEvent(user,store,'POST','/api/works');event.body=JSON.stringify(body);const result=await works.handle(event,store);return{status:result.statusCode,body:JSON.parse(result.body)};}

test('auto-start moves due upcoming work to Ongoing / Planning and leaves future work alone',async()=>{
 const store=new MemoryStore();
 await records.saveRecord('work',{id:1,title:'Due',status:'upcoming',phase:0,startDate:'2026-10-14'},0,store);
 await records.saveRecord('work',{id:2,title:'Late start',status:'upcoming',phase:0,startDate:'2026-10-01'},0,store);
 await records.saveRecord('work',{id:3,title:'Future',status:'upcoming',phase:0,startDate:'2026-10-15'},0,store);
 await records.saveRecord('work',{id:4,title:'No date',status:'upcoming',phase:0},0,store);
 assert.deepEqual((await startDueWork(store,'2026-10-14')).sort(),[1,2]);
 assert.equal((await records.currentRecord('work',1,store)).status,'ongoing');
 assert.equal((await records.currentRecord('work',1,store)).phase,0);
 assert.equal((await records.currentRecord('work',3,store)).status,'upcoming');
 assert.equal((await records.currentRecord('work',4,store)).status,'upcoming');
 assert.deepEqual(await startDueWork(store,'2026-10-14'),[]);
});

test('completing work records actual hours, defaulting to the estimate, and recurrences start without them',async()=>{
 const admin=person('admin',1),store=seeded([admin]);
 await records.saveRecord('work',{id:10,title:'Close',status:'ongoing',phase:3,pic:1,assignees:[1],estimatedHours:12,startDate:'2026-10-01',deadline:'2026-10-07',recurrence:'monthly',phaseChecks:{},phaseTasks:{}},0,store);
 await records.saveRecord('work',{id:11,title:'Review',status:'ongoing',phase:3,pic:1,assignees:[1],estimatedHours:8,phaseChecks:{},phaseTasks:{}},0,store);
 const first=await post(admin,store,{operation:'complete',id:10,expectedVersion:1,actualHours:15.5});
 assert.equal(first.status,200);assert.equal(first.body.work.actualHours,15.5);assert.equal(first.body.nextWork.actualHours,undefined);
 const second=await post(admin,store,{operation:'complete',id:11,expectedVersion:1});
 assert.equal(second.body.work.actualHours,8);
 await records.saveRecord('work',{id:12,title:'Bad',status:'ongoing',phase:3,pic:1,assignees:[1],phaseChecks:{},phaseTasks:{}},0,store);
 await assert.rejects(post(admin,store,{operation:'complete',id:12,expectedVersion:1,actualHours:-1}),error=>error.statusCode===400);
});

test('completed work stays in capacity for the weeks it ran, using actual hours',()=>{
 const done={status:'done',startDate:'2026-10-05',deadline:'2026-10-30',completedDate:'2026-10-09',estimatedHours:40,actualHours:10};
 assert.deepEqual(domain.allocateCapacityByWeek(done),{'2026-10-05':10});
 assert.deepEqual(domain.allocateCapacityByWeek({...done,actualHours:undefined}),{'2026-10-05':40});
 assert.deepEqual(domain.allocateCapacityByWeek({...done,completedDate:'2026-10-02'}),{'2026-09-28':10});
 const open={status:'ongoing',startDate:'2026-10-05',deadline:'2026-10-09',estimatedHours:20};
 assert.deepEqual(domain.allocateCapacityByWeek(open),domain.allocateEffortByWeek(open));
});

test('only admins can assign a creator, and only when it is missing or removed',async()=>{
 const admin=person('admin',1),manager=person('manager',2),member=person('member',3),store=seeded([admin,manager,member]);
 const items=[{id:1,name:'Legacy',createdAt:'2026-01-01'},{id:2,name:'Removed owner',createdBy:99,createdAt:'2026-01-01'},{id:3,name:'Owned',createdBy:3,createdAt:'2026-01-01'}];
 await records.saveCollection(store,'templates',items,1);
 const update=(user,changes)=>post(user,store,{operation:'collection',name:'templates',items:items.map(t=>changes[t.id]?{...t,createdBy:changes[t.id]}:t),baseItems:items,expectedVersion:2});
 assert.equal((await update(manager,{1:2})).status,403);
 assert.equal((await update(admin,{3:2})).status,403);
 assert.equal((await update(admin,{1:5})).status,403);
 const saved=await update(admin,{1:2,2:3});
 assert.equal(saved.status,200);
 assert.equal(saved.body.items.find(t=>t.id===1).createdBy,2);assert.equal(saved.body.items.find(t=>t.id===2).createdBy,3);
});

test('default tags are shared with everyone but only admins can change them',async()=>{
 const admin=person('admin',1),manager=person('manager',2),store=seeded([admin,manager]);
 assert.equal((await post(manager,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'},{id:2,name:'ifrs 17'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'A,B'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'},{id:2,name:'Reserving'}],baseItems:[],expectedVersion:1})).status,200);
 const workspace=await records.readWorkspace(store,{force:true});
 assert.deepEqual(workspace.tagOptions.map(t=>t.name),['IFRS 17','Reserving']);assert.equal(workspace.versions.tagOptions,2);
});

test('web push: subscriptions follow the latest account, review-ready and overdue alerts respect settings',async()=>{
 const push=require('../netlify/functions/lib/push');const pushHandler=require('../netlify/functions/push')._test.handle;
 const {sendOverdueAlerts}=require('../netlify/functions/overdue-alerts');
 process.env.VAPID_PUBLIC_KEY='test-public';process.env.VAPID_PRIVATE_KEY='test-private';
 const sent=[];push._setTransport(async(subscription,body)=>{if(subscription.endpoint.endsWith('gone'))throw Object.assign(new Error('gone'),{statusCode:410});sent.push([subscription.endpoint,JSON.parse(body)]);});
 try{
  const admin=person('admin',1),manager={...person('manager',2),notificationPreferences:{reviewReady:false,overdueToday:true}},member=person('member',3),store=seeded([admin,manager,member]);
  const sub=endpoint=>({endpoint:'https://push.example.test/'+endpoint,keys:{p256dh:'p',auth:'a'}});
  const subscribe=async(user,subscription)=>{const event=await sessionEvent(user,store,'POST','/api/push');event.body=JSON.stringify({operation:'subscribe',subscription});return(await pushHandler(event,store)).statusCode;};
  assert.equal(await subscribe(admin,sub('admin')),200);assert.equal(await subscribe(manager,sub('manager')),200);
  assert.equal(await subscribe(member,sub('shared')),200);assert.equal(await subscribe(admin,sub('shared')),200);
  assert.equal(await subscribe(member,sub('gone')),200);
  await assert.rejects(subscribe(member,{endpoint:'http://insecure',keys:{}}),error=>error.statusCode===400);
  assert.equal((await push.listSubscriptions(store)).find(row=>row.subscription.endpoint.endsWith('shared')).userId,1);
  // Member moves work into Review: admin is notified on both devices, manager opted out.
  await records.saveRecord('work',{id:20,title:'Reserve review',status:'ongoing',phase:1,pic:3,assignees:[3],estimatedHours:4,deadline:'2026-10-01',phaseChecks:{},phaseTasks:{}},0,store);
  const work={...(await records.currentRecord('work',20,store)),phase:2};delete work.version;
  assert.equal((await post(member,store,{operation:'upsert',work,expectedVersion:1})).status,200);
  assert.deepEqual(sent.map(([endpoint])=>endpoint.split('/').pop()).sort(),['admin','shared']);assert.equal(sent[0][1].tag,'review-20');
  sent.length=0;
  // Overdue: PIC member's only device is expired and gets removed; manager has no overdue work.
  assert.equal(await sendOverdueAlerts(store,'2026-10-14'),0);
  assert.ok(!(await push.listSubscriptions(store)).some(row=>row.subscription.endpoint.endsWith('gone')));
  await records.saveRecord('work',{id:21,title:'Old close',status:'ongoing',phase:1,pic:2,assignees:[2],deadline:'2026-10-10'},0,store);
  assert.equal(await sendOverdueAlerts(store,'2026-10-14'),1);assert.equal(sent[0][1].title,'Overdue work');
 }finally{push._setTransport(null);delete process.env.VAPID_PUBLIC_KEY;delete process.env.VAPID_PRIVATE_KEY;}
});

test('admins can correct estimate, actual hours and completion date on completed work; members cannot',async()=>{
 const admin=person('admin',1),member=person('member',3),store=seeded([admin,member]);
 await records.saveRecord('work',{id:30,title:'Done',status:'done',phase:4,pic:3,assignees:[3],estimatedHours:10,actualHours:12,completedDate:'2026-10-05',phaseChecks:{},phaseTasks:{}},0,store);
 const edit=async(user,changes,version)=>{const work={...(await records.currentRecord('work',30,store)),...changes};delete work.version;return post(user,store,{operation:'upsert',work,expectedVersion:version});};
 assert.equal((await edit(member,{actualHours:5},1)).status,403);
 assert.equal((await edit(admin,{completedDate:'2999-01-01'},1)).status,400);
 assert.equal((await edit(admin,{completedDate:'2026-02-30'},1)).status,400);
 const saved=await edit(admin,{estimatedHours:14,actualHours:9.5,completedDate:'2026-10-03'},1);
 assert.equal(saved.status,200);assert.equal(saved.body.work.estimatedHours,14);assert.equal(saved.body.work.actualHours,9.5);assert.equal(saved.body.work.completedDate,'2026-10-03');
});

test('note, phase-change, completion and due-today alerts reach the right people',async()=>{
 const push=require('../netlify/functions/lib/push');const pushHandler=require('../netlify/functions/push')._test.handle;const {sendOverdueAlerts}=require('../netlify/functions/overdue-alerts');const reads=require('../netlify/functions/reads')._test.handle;
 process.env.VAPID_PUBLIC_KEY='t';process.env.VAPID_PRIVATE_KEY='t';
 const sent=[];push._setTransport(async(sub,body)=>{sent.push([sub.endpoint.split('/').pop(),JSON.parse(body)]);});
 try{
  const admin=person('admin',1),manager=person('manager',2),a=person('member',3),b=person('member',4),c=person('member',5),store=seeded([admin,manager,a,b,c]);
  for(const [u,e] of [[a,'a'],[b,'b'],[c,'c'],[manager,'m']]){const ev=await sessionEvent(u,store,'POST','/api/push');ev.body=JSON.stringify({operation:'subscribe',subscription:{endpoint:'https://p.test/'+e,keys:{p256dh:'p',auth:'a'}}});await pushHandler(ev,store);}
  await records.saveRecord('work',{id:40,title:'Close',status:'ongoing',phase:0,pic:3,assignees:[3,4],estimatedHours:5,startDate:'2026-10-01',deadline:'2026-10-14',notes:[],phaseChecks:{},phaseTasks:{}},0,store);
  const who=()=>sent.map(([e])=>e).sort().join();
  const fresh=async()=>{const w=await records.currentRecord('work',40,store);const version=w.version;delete w.version;return {w,version};};
  // Note from member b: PIC a is alerted; b (author) and c (not involved) are not.
  let {w,version}=await fresh();
  let r=await post(b,store,{operation:'upsert',work:{...w,notes:[{authorId:4,authorName:'member 4',text:'Please check the totals',createdDate:'2026-10-14',editedDate:null}]},expectedVersion:version});
  assert.equal(r.status,200);assert.equal(who(),'a');assert.match(sent[0][1].title,/member 4/);assert.equal(sent[0][1].body,'Please check the totals');
  assert.ok((await records.currentRecord('work',40,store)).notes[0].createdAt,'server stamps the note time');
  // Phase move by member b alerts the PIC.
  sent.length=0;({w,version}=await fresh());
  r=await post(b,store,{operation:'upsert',work:{...w,phase:1},expectedVersion:version});assert.equal(who(),'a');assert.equal(sent[0][1].title,'Phase changed');
  // Someone else moving it to Review alerts the PIC once with review-ready, plus the manager; a non-PIC member hears nothing.
  sent.length=0;({w,version}=await fresh());
  await post(b,store,{operation:'upsert',work:{...w,phase:2},expectedVersion:version});
  assert.deepEqual(sent.filter(([e])=>e==='a').map(([,payload])=>payload.title),['Ready for review']);assert.ok(sent.some(([e])=>e==='m'));assert.ok(!sent.some(([e])=>e==='b'||e==='c'));
  ({w,version}=await fresh());await post(b,store,{operation:'upsert',work:{...w,phase:1},expectedVersion:version});
  // The PIC moving their own work to Review alerts nobody about the phase, but the manager still gets review-ready.
  sent.length=0;({w,version}=await fresh());
  await post(a,store,{operation:'upsert',work:{...w,phase:2},expectedVersion:version});
  assert.ok(!sent.some(([e])=>e==='a'),'PIC is not alerted about their own move');assert.ok(sent.some(([e])=>e==='m'),'manager gets review-ready');
  // Completion by someone else alerts the PIC.
  ({version}=await fresh());await post(a,store,{operation:'review',id:40,decision:'approved',expectedVersion:version});
  sent.length=0;({version}=await fresh());
  await post(b,store,{operation:'complete',id:40,expectedVersion:version,actualHours:4});assert.equal(who(),'a');assert.equal(sent[0][1].title,'Work completed');
  // Daily alert: due today and overdue in one message; future work is left out.
  sent.length=0;
  await records.saveRecord('work',{id:41,title:'Today job',status:'ongoing',phase:1,pic:4,assignees:[4],deadline:'2026-10-20',phaseChecks:{},phaseTasks:{}},0,store);
  await records.saveRecord('work',{id:42,title:'Late job',status:'ongoing',phase:1,pic:4,assignees:[4],deadline:'2026-10-18',phaseChecks:{},phaseTasks:{}},0,store);
  await records.saveRecord('work',{id:43,title:'Future job',status:'ongoing',phase:1,pic:4,assignees:[4],deadline:'2026-10-25',phaseChecks:{},phaseTasks:{}},0,store);
  await sendOverdueAlerts(store,'2026-10-20');const mine=sent.filter(([e])=>e==='b');
  assert.equal(mine.length,1);assert.match(mine[0][1].title,/1 due today, 1 overdue/);assert.ok(!mine[0][1].body.includes('Future'));
  // Unread markers only move forward and belong to one person.
  const mark=async(u,workId,seenAt)=>{const ev=await sessionEvent(u,store,'POST','/api/reads');ev.body=JSON.stringify({workId,seenAt});return JSON.parse((await reads(ev,store)).body);};
  assert.equal((await mark(a,'40','2026-10-20T05:00:00.000Z')).seen['40'],'2026-10-20T05:00:00.000Z');
  assert.equal((await mark(a,'40','2026-10-20T01:00:00.000Z')).seen['40'],'2026-10-20T05:00:00.000Z');
  const ev=await sessionEvent(b,store,'GET','/api/reads');assert.deepEqual(JSON.parse((await reads(ev,store)).body).seen,{});
 }finally{push._setTransport(null);delete process.env.VAPID_PUBLIC_KEY;delete process.env.VAPID_PRIVATE_KEY;}
});

test('recurring work is created by TeamFlow with an explanatory first note and keeps its original creator',async()=>{
 const admin=person('admin',1),member=person('member',3),store=seeded([admin,member]);
 await records.saveRecord('work',{id:50,title:'Monthly close',status:'ongoing',phase:3,pic:3,assignees:[3],createdBy:3,estimatedHours:8,recurrence:'monthly',startDate:'2026-10-01',deadline:'2026-10-31',notes:[{authorId:3,authorName:'member 3',text:'old note',createdDate:'2026-10-02'}],phaseChecks:{},phaseTasks:{}},0,store);
 const r=await post(admin,store,{operation:'complete',id:50,expectedVersion:1,actualHours:9});
 const next=r.body.nextWork;
 assert.equal(next.notes.length,1);assert.equal(next.notes[0].system,true);assert.equal(next.notes[0].authorName,'TeamFlow');
 assert.match(next.notes[0].text,/Created automatically.*Monthly close.*every month/);assert.equal(next.createdBy,3);
 const history=await require('../netlify/functions/lib/activity-log').readActivity(store,next.id);
 assert.equal(history[0].actorName,'TeamFlow (recurring work)');assert.equal(history[0].action,'created');
});

test('smart search matches people, tags, phase, notes and any word order',()=>{
 const vm=require('node:vm'),fs=require('node:fs');
 const ctx={TEAM:[{id:3,name:'Jordan Kim'},{id:4,name:'Sam Rivera'}],PHASES:['Planning','Executing','Review','Finalize'],WORK_TYPES:[{value:'regular',label:'Regular'}],RECURRENCE_OPTIONS:[],currentUser:{id:3}};
 ctx.getMember=id=>ctx.TEAM.find(m=>m.id===id);
 vm.createContext(ctx);
 const source=fs.readFileSync('public/js/work.js','utf8'),from=source.indexOf('function workSearchText'),to=source.indexOf('function applyFiltersAndSort');
 vm.runInContext(source.slice(from,to),ctx);
 const w={title:'Reserve review',desc:'Quarter end',tags:['IFRS 17'],assignees:[3],pic:4,status:'ongoing',phase:2,priority:'High',workType:'regular',notes:[{text:'Check the CSM roll-forward',authorName:'Sam Rivera'}],files:[{name:'Workpaper'}]};
 for(const q of ['jordan','SAM','ifrs','review high','roll-forward','workpaper','jordan reserve','Review'])assert.ok(ctx.workMatchesSearch(w,q),q);
 for(const q of ['taylor','jordan finalize','nothing here'])assert.ok(!ctx.workMatchesSearch(w,q),q);
});

test('notification preferences are self-editable and normalized to known switches',()=>{
 const member=team.normalizeMember({id:3,name:'Member',role:'member',username:'member',notificationPreferences:{reviewReady:false,overdueToday:'yes',extra:true}});
 assert.deepEqual(member.notificationPreferences,{reviewReady:false,overdueToday:true,workUpdates:true,meetings:true});
 assert.throws(()=>team.normalizeMember({id:3,name:'Member',role:'member',username:'member',notificationPreferences:[]}),/Notification settings/);
});

test('activity history says which phase moved and which tasks were checked',async()=>{
 const {appendActivity,readActivity}=require('../netlify/functions/lib/activity-log');const store=new MemoryStore();
 const before={status:'ongoing',phase:0,phaseTasks:{Planning:['Scope','Data'],Executing:['Build']},phaseChecks:{Planning:[true,false],Executing:[false]},deadline:'2026-10-20',notes:[]};
 const after={...before,phase:1,phaseChecks:{Planning:[true,true],Executing:[false]},deadline:'2026-10-25',notes:[{text:'x'}]};
 await appendActivity(store,7,{id:1,name:'Avery'},'updated',before,after);
 const [entry]=await readActivity(store,7);
 assert.deepEqual(entry.details,['Phase: Planning → Executing','Planning: checked “Data”','Deadline: 2026-10-20 → 2026-10-25','Note added: “x”']);
 await appendActivity(store,8,{id:1,name:'Avery'},'created',{},after);
 assert.deepEqual((await readActivity(store,8))[0].details,[]);
});

test('the notification prompt version matches the newest Changelog release',()=>{
 const source=require('node:fs').readFileSync('public/js/ui.js','utf8');
 const version=source.match(/const APP_VERSION='([\d.]+)'/)[1],newest=source.match(/\{ver:'([\d.]+)'/)[1];
 assert.equal(version,newest,'bump APP_VERSION together with the Changelog');
});

test('a quick second save never strips the written-time stamp from earlier notes',async()=>{
 const admin=person('admin',1),member=person('member',3),store=seeded([admin,member]);
 const note=(text,createdAt)=>({authorId:3,authorName:'member 3',text,createdDate:'2026-10-28',editedDate:null,...(createdAt?{createdAt}:{})});
 await records.saveRecord('work',{id:60,title:'Notes',status:'ongoing',phase:1,pic:3,assignees:[3],notes:[note('wow','2026-10-28T03:00:00.000Z')],phaseChecks:{},phaseTasks:{}},0,store);
 // The second save comes from a copy that never received the stamp on "wow".
 const w=await records.currentRecord('work',60,store);const version=w.version;delete w.version;
 const r=await post(member,store,{operation:'upsert',work:{...w,notes:[note('wow'),note('test')]},expectedVersion:version});
 assert.equal(r.status,200);
 assert.equal(r.body.work.notes[0].createdAt,'2026-10-28T03:00:00.000Z','earlier note keeps its stamp');
 assert.ok(r.body.work.notes[1].createdAt>'2026-10-28T03:00:00.000Z','new note is stamped by the server');
});

test('activity history names the notes and file links that were added, edited or removed',async()=>{
 const {appendActivity,readActivity}=require('../netlify/functions/lib/activity-log');const store=new MemoryStore();
 const n=(text,createdAt)=>({authorId:1,authorName:'Avery',text,createdAt});
 const before={notes:[n('old','t1'),n('gone','t2')],files:[{name:'Sheet',url:'https://a.test/x',type:'sheet'},{name:'Old',url:'https://a.test/z',type:'doc'}]};
 const after={notes:[n('new','t1'),n('fresh','t3')],files:[{name:'Reserving sheet',url:'https://a.test/x',type:'sheet'},{name:'Memo',url:'https://a.test/y',type:'doc'}]};
 await appendActivity(store,9,{id:1,name:'Avery'},'updated',before,after);
 assert.deepEqual((await readActivity(store,9))[0].details,[
  'Note edited by Avery: “old” → “new”','Note added by Avery: “fresh”','Note deleted by Avery: “gone”',
  'File link renamed: “Sheet” → “Reserving sheet”','File link added: “Memo”','File link removed: “Old”']);
});

test('activity history names assignees and PIC changes, and creation lists no detail',async()=>{
 const {appendActivity,readActivity}=require('../netlify/functions/lib/activity-log');const store=new MemoryStore();
 const members=[{id:1,name:'Avery'},{id:2,name:'Morgan'},{id:3,name:'Jordan'}];
 await appendActivity(store,11,{id:1,name:'Avery'},'updated',{assignees:[1,2],pic:2,recurrence:null},{assignees:[1,3],pic:3,recurrence:'weekly'},members);
 assert.deepEqual((await readActivity(store,11))[0].details,['Assignees added: Jordan','Assignees removed: Morgan','PIC: Morgan → Jordan','Recurrence: none → weekly']);
 await appendActivity(store,12,{id:1,name:'Avery'},'created',{},{assignees:[1],pic:1,title:'T'},members);
 assert.deepEqual((await readActivity(store,12))[0].details,[]);
});

test('review sign-off: who can decide, the Review gate, and the record it leaves',async()=>{
 const admin=person('admin',1),manager=person('manager',2),pic=person('member',3),assignee=person('member',4),board=person('board',5),store=seeded([admin,manager,pic,assignee,board]);
 const base={id:70,title:'IFRS 17 results review',status:'ongoing',phase:2,pic:3,assignees:[3,4,2],createdBy:3,phaseChecks:{},phaseTasks:{},notes:[],files:[]};
 await records.saveRecord('work',base,0,store);
 const read=()=>records.currentRecord('work',70,store);
 const body=async(extra)=>{const w=await read();const version=w.version;delete w.version;return{w,version,...extra};};
 const status=(user,payload)=>post(user,store,payload).then(r=>r.status,error=>error.statusCode);
 // Advancing, completing or forging an approval does not get past Review.
 let {w,version}=await body();
 assert.equal(await status(pic,{operation:'upsert',work:{...w,phase:3},expectedVersion:version}),409);
 assert.equal(await status(admin,{operation:'complete',id:70,expectedVersion:version}),409);
 assert.equal(await status(pic,{operation:'upsert',work:{...w,phase:3,reviewApproved:true,reviews:[{decision:'approved'}]},expectedVersion:version}),409);
 // A member who is not the PIC and the board can't decide; send-back needs a comment.
 assert.equal(await status(assignee,{operation:'review',id:70,decision:'approved',expectedVersion:version}),403);
 assert.equal(await status(board,{operation:'review',id:70,decision:'approved',expectedVersion:version}),403);
 assert.equal(await status(manager,{operation:'review',id:70,decision:'sent_back',comment:'  ',expectedVersion:version}),400);
 // Send back returns to Executing and keeps the record, and a save can't erase it.
 await post(manager,store,{operation:'review',id:70,decision:'sent_back',comment:'Reconcile the CSM roll-forward',expectedVersion:version});
 ({w,version}=await body());
 assert.equal(w.phase,1);assert.equal(w.reviews[0].selfReview,false);assert.equal(w.reviews[0].actorName,manager.name);
 await post(pic,store,{operation:'upsert',work:{...w,reviews:[]},expectedVersion:version});
 assert.equal((await read()).reviews.length,1);
 // Returning to Review needs a new decision; the PIC can approve, labelled self-review, and then advance.
 ({w,version}=await body());await post(pic,store,{operation:'upsert',work:{...w,phase:2},expectedVersion:version});
 ({w,version}=await body());assert.equal(w.reviewApproved,undefined);
 await post(pic,store,{operation:'review',id:70,decision:'approved',expectedVersion:version});
 ({w,version}=await body());assert.equal(w.reviewApproved,true);assert.equal(w.reviews[1].selfReview,true);
 assert.equal(await status(pic,{operation:'review',id:70,decision:'approved',expectedVersion:version}),409);
 await post(assignee,store,{operation:'upsert',work:{...w,phase:3},expectedVersion:version});
 ({w,version}=await body());assert.equal(w.phase,3);assert.equal(w.reviewApproved,true);
 // Moving back into Review from Finalize clears the approval but not the history.
 await post(pic,store,{operation:'upsert',work:{...w,phase:2},expectedVersion:version});
 ({w,version}=await body());assert.equal(w.reviewApproved,undefined);assert.equal(w.reviews.length,2);
 assert.equal(await status(pic,{operation:'upsert',work:{...w,phase:3},expectedVersion:version}),409);
 const {readActivity}=require('../netlify/functions/lib/activity-log');
 const details=(await readActivity(store,70)).flatMap(entry=>entry.details||[]);
 assert.ok(details.includes('Sent back to Executing: “Reconcile the CSM roll-forward”'));assert.ok(details.includes('Approved (PIC self-review)'));
});

test('work already past Review is not held back, and a recurring copy starts with no sign-off',async()=>{
 const admin=person('admin',1),store=seeded([admin]);
 await records.saveRecord('work',{id:71,title:'Legacy',status:'ongoing',phase:3,pic:1,assignees:[1],phaseChecks:{},phaseTasks:{}},0,store);
 assert.equal((await post(admin,store,{operation:'complete',id:71,expectedVersion:1,actualHours:1})).status,200);
 await records.saveRecord('work',{id:72,title:'Monthly',status:'ongoing',phase:3,pic:1,assignees:[1],recurrence:'monthly',deadline:'2026-10-31',startDate:'2026-10-01',reviewApproved:true,reviews:[{decision:'approved',actorName:'A',date:'2026-10-20'}],phaseChecks:{},phaseTasks:{}},0,store);
 const r=await post(admin,store,{operation:'complete',id:72,expectedVersion:1,actualHours:1});
 const next=r.body.nextWork;
 assert.equal(next.reviews,undefined);assert.equal(next.reviewApproved,undefined);
});

test('performance analysis rebuilds phase time, review wait, rework and score from the activity log',()=>{
 const domain=require('../public/js/domain');
 // 7-8 Nov 2026 is a weekend, so it is left out of elapsed time.
 assert.equal(domain.daysExcludingWeekends('2026-11-06T00:00:00Z','2026-11-09T00:00:00Z','UTC'),1);
 assert.equal(domain.daysExcludingWeekends('2026-11-05T00:00:00Z','2026-11-10T00:00:00Z','UTC'),3);
 const work={deadline:'2026-11-20',completedDate:'2026-11-20',estimatedHours:40,actualHours:42,pic:3,reviews:[{decision:'sent_back'},{decision:'approved',selfReview:false}]};
 const at=day=>`2026-11-${String(day).padStart(2,'0')}T00:00:00.000Z`;
 const entries=[
  {action:'created',createdAt:at(2),details:[]},
  {action:'updated',createdAt:at(3),details:['Phase: Planning → Executing'],changedFields:{phase:true}},
  {action:'updated',createdAt:at(5),details:['Phase: Executing → Review'],changedFields:{phase:true}},
  {action:'sent back',createdAt:at(12),details:['Phase: Review → Executing','Sent back to Executing: “Fix”'],changedFields:{phase:true}},
  {action:'updated',createdAt:at(13),details:['Phase: Executing → Review'],changedFields:{phase:true}},
  {action:'approved',createdAt:at(16),details:['Approved'],changedFields:{reviews:true}},
  {action:'updated',createdAt:at(17),details:['Phase: Review → Finalize'],changedFields:{phase:true}},
  {action:'completed',createdAt:at(20),details:['Status: Ongoing → Completed'],changedFields:{status:true}},
 ];
 const result=domain.workPerformance(work,entries,'UTC');
 assert.deepEqual(Object.fromEntries(result.phases.map(phase=>[phase.name,phase.days])),{Planning:1,Executing:3,Review:7,Finalize:3});
 assert.equal(result.bottleneck.name,'Review');assert.equal(result.rework,1);assert.equal(result.reworkDays,1);
 // Review waits: 5 days (5th to 12th, less a weekend), then 1 day (13th to 16th, less a weekend), averaged.
 assert.equal(result.reviewWait,3);assert.equal(result.waitRounds,2);
 assert.deepEqual(Object.fromEntries(result.components.map(item=>[item.label,item.points])),{Delivery:40,'Effort vs estimate':20,Rework:10,'Review wait':16});
 assert.equal(result.score,86);
 assert.ok(result.improve.some(note=>note.startsWith('Review took')));
});

test('performance analysis stays honest when history is missing or phases were moved in one go',()=>{
 const domain=require('../public/js/domain');
 const work={deadline:'2026-11-10',completedDate:'2026-11-12',estimatedHours:10,actualHours:10};
 // History from before detailed logging: the phase moved, but with no detail line.
 const legacy=domain.workPerformance(work,[{action:'created',createdAt:'2026-11-02T00:00:00Z'},{action:'updated',createdAt:'2026-11-03T00:00:00Z',changedFields:{phase:true}},{action:'completed',createdAt:'2026-11-12T00:00:00Z',details:['Status: Ongoing → Completed'],changedFields:{status:true}}],'UTC');
 assert.equal(legacy.phasesKnown,false);assert.equal(legacy.bottleneck,null);
 assert.deepEqual(legacy.components.map(item=>item.label),['Delivery','Effort vs estimate']);
 assert.equal(legacy.score,Math.round((30+20)/60*100));
 // Phases advanced within minutes: timing isn't trusted for the bottleneck or the review wait.
 const at=minute=>`2026-11-12T08:${String(minute).padStart(2,'0')}:00Z`;
 const rushed=domain.workPerformance(work,[
  {action:'created',createdAt:'2026-11-02T00:00:00Z'},
  {action:'updated',createdAt:at(1),details:['Phase: Planning → Executing'],changedFields:{phase:true}},
  {action:'updated',createdAt:at(2),details:['Phase: Executing → Review'],changedFields:{phase:true}},
  {action:'approved',createdAt:at(3),details:['Approved'],changedFields:{reviews:true}},
  {action:'updated',createdAt:at(4),details:['Phase: Review → Finalize'],changedFields:{phase:true}},
  {action:'completed',createdAt:at(5),details:['Status: Ongoing → Completed'],changedFields:{status:true}},
 ],'UTC');
 assert.equal(rushed.timingReliable,false);assert.equal(rushed.bottleneck,null);
 assert.ok(!rushed.components.some(item=>item.label==='Review wait'));
 // No usable measures: no score rather than a made-up one.
 assert.equal(domain.workPerformance({},[],'UTC').score,null);
});

test('performance score leaves out self-review, and uses the deadline set when work started',()=>{
 const domain=require('../public/js/domain');
 const at=day=>`2026-11-${String(day).padStart(2,'0')}T00:00:00.000Z`;
 const flow=[
  {action:'created',createdAt:at(2),details:[]},
  {action:'updated',createdAt:at(3),details:['Phase: Planning → Executing'],changedFields:{phase:true}},
  {action:'updated',createdAt:at(5),details:['Phase: Executing → Review'],changedFields:{phase:true}},
  {action:'approved',createdAt:at(5),details:['Approved'],changedFields:{reviews:true}},
  {action:'updated',createdAt:at(6),details:['Phase: Review → Finalize'],changedFields:{phase:true}},
  {action:'completed',createdAt:at(12),details:['Status: Ongoing → Completed'],changedFields:{status:true}},
 ];
 // The PIC approving their own work earns no Review wait or Rework points, and it's labelled.
 const self=domain.workPerformance({deadline:'2026-11-20',completedDate:'2026-11-12',estimatedHours:8,actualHours:8,reviews:[{decision:'approved',selfReview:true}]},flow,'UTC');
 assert.deepEqual(self.components.map(item=>item.label),['Delivery','Effort vs estimate']);
 assert.equal(self.selfReviewed,true);assert.equal(self.available,60);
 assert.ok(self.improve.some(note=>note.includes('no independent review')));
 assert.ok(!self.good.some(note=>/Review/.test(note)));
 // An independent approval keeps both measures.
 const independent=domain.workPerformance({deadline:'2026-11-20',completedDate:'2026-11-12',estimatedHours:8,actualHours:8,reviews:[{decision:'approved',selfReview:false}]},flow,'UTC');
 assert.ok(independent.components.some(item=>item.label==='Review wait'));
 // Extending the deadline after the start doesn't erase lateness. 10 Nov to 12 Nov is 2 working days late.
 const moved=[...flow,{action:'updated',createdAt:at(4),details:['Deadline: 2026-11-10 → 2026-11-13'],changedFields:{deadline:true}},{action:'updated',createdAt:at(8),details:['Deadline: 2026-11-13 → 2026-11-20'],changedFields:{deadline:true}}];
 const late=domain.workPerformance({deadline:'2026-11-20',completedDate:'2026-11-12',estimatedHours:8,actualHours:8},moved,'UTC');
 assert.equal(late.originalDeadline,'2026-11-10');assert.equal(late.deadlineMoves,2);
 assert.equal(late.components.find(item=>item.label==='Delivery').points,30);
 assert.ok(late.improve.some(note=>note.includes('after the original deadline')));
 assert.ok(late.improve.some(note=>note.includes('Deadline moved 2 times')));
 // Replanning before the work started, and adding a first deadline, don't count as moves.
 const replanned=domain.workPerformance({deadline:'2026-11-20',completedDate:'2026-11-12'},[
  {action:'created',createdAt:at(1),details:[]},
  {action:'updated',createdAt:at(1),details:['Deadline: 2026-11-05 → 2026-11-15'],changedFields:{deadline:true}},
  {action:'started',createdAt:at(2),details:['Status: Upcoming → Ongoing'],changedFields:{status:true}},
  {action:'updated',createdAt:at(3),details:['Deadline: none → 2026-11-20'],changedFields:{deadline:true}},
 ],'UTC');
 assert.equal(replanned.deadlineMoves,0);assert.equal(replanned.originalDeadline,'2026-11-20');
 // A deadline change with no detail can't be traced, so it's flagged rather than assumed.
 const unknown=domain.workPerformance({deadline:'2026-11-20',completedDate:'2026-11-12'},[{action:'updated',createdAt:at(3),changedFields:{deadline:true}}],'UTC');
 assert.equal(unknown.deadlineHistoryKnown,false);
});

test('meetings: permissions, attendee alerts, and validation',async()=>{
 const meetings=require('../netlify/functions/meetings')._test,push=require('../netlify/functions/lib/push'),pushHandler=require('../netlify/functions/push')._test.handle;process.env.VAPID_PUBLIC_KEY='t';process.env.VAPID_PRIVATE_KEY='t';
 const admin=person('admin',1),manager=person('manager',2),a=person('member',3),b=person('member',4),board=person('board',5),store=seeded([admin,manager,a,b,board]);
 const sent=[];push._setTransport(async(subscription,payload)=>{sent.push([subscription.endpoint.split('/').pop(),JSON.parse(payload)]);});
 try{
  for(const [u,e] of [[manager,'m'],[a,'a'],[b,'b']]){const ev=await sessionEvent(u,store,'POST','/api/push');ev.body=JSON.stringify({operation:'subscribe',subscription:{endpoint:'https://p.test/'+e,keys:{p256dh:'p',auth:'a'}}});await pushHandler(ev,store);}
  const call=async(user,body)=>{const event=await sessionEvent(user,store,'POST','/api/meetings');event.body=JSON.stringify(body);const result=await meetings.handle(event,store);return{status:result.statusCode,body:JSON.parse(result.body)};};
  const status=(user,body)=>call(user,body).then(r=>r.status,error=>error.statusCode);
  const future=new Date(Date.now()+3*86400000).toISOString().slice(0,10);
  const base={id:501,title:'IFRS 17 results review',date:future,startTime:'14:00',durationMinutes:60,location:'Room 3B',attendees:[3],linkedWorkIds:[]};
  // Board can read but not write; bad input is refused.
  assert.equal(await status(board,{operation:'upsert',meeting:base,expectedVersion:0}),403);
  assert.equal(await status(a,{operation:'upsert',meeting:{...base,date:'2020-01-01'},expectedVersion:0}),400);
  assert.equal(await status(a,{operation:'upsert',meeting:{...base,startTime:'25:00'},expectedVersion:0}),400);
  assert.equal(await status(a,{operation:'upsert',meeting:{...base,attendees:[5]},expectedVersion:0}),400);
  assert.equal(await status(a,{operation:'upsert',meeting:{...base,linkedWorkIds:[999]},expectedVersion:0}),400);
  // Creating invites everyone except the organizer, and the time is stored in the team zone.
  sent.length=0;
  let r=await call(manager,{operation:'upsert',meeting:{...base,attendees:[3,4]},expectedVersion:0});
  assert.equal(r.status,201);assert.equal(r.body.meeting.organizerId,2);assert.equal(r.body.meeting.startsAt,`${future}T07:00:00.000Z`);
  assert.deepEqual(sent.map(([e])=>e).sort(),['a','b']);assert.equal(sent[0][1].title,'Meeting invite');assert.equal(sent[0][1].meetingId,501);
  // Only the organizer or an admin can edit or cancel; attendees can write minutes; others can't.
  assert.equal(await status(a,{operation:'upsert',meeting:{...base,title:'Changed'},expectedVersion:1}),403);
  assert.equal(await status(a,{operation:'cancel',id:501,expectedVersion:1}),403);
  assert.equal(await status(board,{operation:'minutes',id:501,minutes:'x',expectedVersion:1}),403);
  r=await call(a,{operation:'minutes',id:501,minutes:'Agreed the CSM movement.',expectedVersion:1});assert.equal(r.body.meeting.minutes,'Agreed the CSM movement.');
  assert.equal(await status(manager,{operation:'minutes',id:501,minutes:'stale',expectedVersion:1}),409);
  // Removing an attendee and adding none: the removed person hears, and a time change alerts those remaining.
  sent.length=0;
  r=await call(manager,{operation:'upsert',meeting:{...base,attendees:[3],startTime:'15:00'},expectedVersion:2});
  assert.deepEqual(Object.fromEntries(sent.map(([e,p])=>[e,p.title])),{a:'Meeting changed',b:'Removed from meeting'});
  assert.equal(r.body.meeting.minutes,'Agreed the CSM movement.');
  // Cancelling alerts attendees and stops further edits.
  sent.length=0;
  r=await call(admin,{operation:'cancel',id:501,expectedVersion:3});assert.equal(r.body.meeting.status,'cancelled');
  assert.ok(sent.some(([e,p])=>e==='a'&&p.title==='Meeting cancelled'));
  assert.equal(await status(admin,{operation:'upsert',meeting:base,expectedVersion:4}),409);
 }finally{push._setTransport(null);}
});

test('meeting reminders: inside the window once, skipping cancelled and short-notice meetings',async()=>{
 const {sendMeetingReminders}=require('../netlify/functions/meeting-reminders');
 const meetings=require('../netlify/functions/meetings')._test,push=require('../netlify/functions/lib/push'),pushHandler=require('../netlify/functions/push')._test.handle;process.env.VAPID_PUBLIC_KEY='t';process.env.VAPID_PRIVATE_KEY='t';
 const manager=person('manager',2),a=person('member',3),optedOut={...person('member',4),notificationPreferences:{meetings:false}},store=seeded([manager,a,optedOut]);
 const sent=[];push._setTransport(async(subscription,payload)=>{sent.push([subscription.endpoint.split('/').pop(),JSON.parse(payload)]);});
 try{
  for(const [u,e] of [[manager,'m'],[a,'a'],[optedOut,'o']]){const ev=await sessionEvent(u,store,'POST','/api/push');ev.body=JSON.stringify({operation:'subscribe',subscription:{endpoint:'https://p.test/'+e,keys:{p256dh:'p',auth:'a'}}});await pushHandler(ev,store);}
  const now=Date.parse('2026-11-10T06:00:00.000Z'),minutes=value=>new Date(now+value*60000).toISOString();
  const meeting=(id,startsAt,extra={})=>records.saveRecord('meeting',{id,title:'M'+id,date:'2026-11-10',startTime:'14:00',durationMinutes:60,startsAt,organizerId:2,attendees:[3,4],status:'scheduled',...extra},0,store);
  await meeting(1,minutes(60));await meeting(2,minutes(64));await meeting(3,minutes(66));await meeting(4,minutes(-5));
  await meeting(5,minutes(30),{status:'cancelled'});await meeting(6,minutes(30),{reminderSentAt:minutes(-10)});
  await sendMeetingReminders(store,now);
  // Meetings 1 and 2 reach the organizer and attendee; the opted-out attendee gets nothing.
  assert.deepEqual(sent.map(([e,p])=>`${e}:${p.meetingId}`).sort(),['a:1','a:2','m:1','m:2']);
  assert.equal(sent[0][1].title,'Meeting soon');
  // The next hourly run doesn't repeat them, and picks up the one that has come into the window.
  sent.length=0;await sendMeetingReminders(store,now+5*60000);
  assert.deepEqual([...new Set(sent.map(([,p])=>p.meetingId))],[3]);
  // Moving a meeting clears the marker, so it gets a fresh reminder at the new time.
  const event=await sessionEvent(manager,store,'POST','/api/meetings');
  const current=await records.currentRecord('meeting',1,store);
  const moved=new Date(Date.now()+3*86400000).toISOString().slice(0,10);
  event.body=JSON.stringify({operation:'upsert',meeting:{...current,date:moved,version:undefined},expectedVersion:current.version});
  const saved=JSON.parse((await meetings.handle(event,store)).body).meeting;
  assert.equal(saved.reminderSentAt,undefined);
  // Booked inside the window: the invite gives the time, so no separate reminder follows.
  const soon=new Date(Date.now()+30*60000),local=require('../public/js/domain');
  const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Bangkok',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(soon);
  const short=await sessionEvent(manager,store,'POST','/api/meetings');
  short.body=JSON.stringify({operation:'upsert',meeting:{id:7,title:'Short notice',date:local.dateKeyInZone(soon,'Asia/Bangkok'),startTime:parts,durationMinutes:30,attendees:[3]},expectedVersion:0});
  assert.ok(JSON.parse((await meetings.handle(short,store)).body).meeting.reminderSentAt);
 }finally{push._setTransport(null);}
});

test('meeting calendar file and team-zone time are correct',()=>{
 const domain=require('../public/js/domain');
 assert.equal(domain.zonedTimeToIso('2026-11-05','14:00','Asia/Jakarta'),'2026-11-05T07:00:00.000Z');
 assert.equal(domain.zonedTimeToIso('2026-11-05','00:30','Asia/Jakarta'),'2026-11-04T17:30:00.000Z');
 const ics=domain.meetingIcs({id:9,title:'IFRS 17, results; review',startsAt:'2026-11-05T07:00:00.000Z',durationMinutes:90,location:'Room 3B',agenda:'Line one\nLine two'},new Date('2026-11-01T00:00:00Z'));
 assert.ok(ics.includes('DTSTART:20261105T070000Z\r\n'));assert.ok(ics.includes('DTEND:20261105T083000Z\r\n'));
 assert.ok(ics.includes('SUMMARY:IFRS 17\\, results\\; review\r\n'));assert.ok(ics.includes('DESCRIPTION:Line one\\nLine two\r\n'));
 assert.ok(ics.includes('TRIGGER:-PT15M'));assert.ok(ics.startsWith('BEGIN:VCALENDAR'));assert.ok(ics.endsWith('END:VCALENDAR\r\n'));
});

test('review queue age is tracked by the server and can not be forged',async()=>{
 const admin=person('admin',1),a=person('member',3),store=seeded([admin,a]);
 await records.saveRecord('work',{id:80,title:'Queue',status:'ongoing',phase:1,pic:3,assignees:[3],phaseChecks:{},phaseTasks:{}},0,store);
 const read=()=>records.currentRecord('work',80,store);
 let w=await read(),version=w.version;delete w.version;
 await post(a,store,{operation:'upsert',work:{...w,phase:2,reviewEnteredAt:'2000-01-01T00:00:00.000Z'},expectedVersion:version});
 const entered=(await read()).reviewEnteredAt;
 assert.ok(entered>'2020');
 // A later save in Review keeps the original time, and a send-back clears it.
 w=await read();version=w.version;delete w.version;
 await post(a,store,{operation:'upsert',work:{...w,desc:'Edited',reviewEnteredAt:'2030-01-01T00:00:00.000Z'},expectedVersion:version});
 assert.equal((await read()).reviewEnteredAt,entered);
 w=await read();
 await post(admin,store,{operation:'review',id:80,decision:'sent_back',comment:'Fix',expectedVersion:w.version});
 assert.equal((await read()).reviewEnteredAt,undefined);
});

test('week availability removes public holidays and the person’s own leave, without double counting',()=>{
 const domain=require('../public/js/domain');
 const absences=[{type:'holiday',label:'National holiday',startDate:'2026-11-09',endDate:'2026-11-09'},{type:'leave',memberId:3,startDate:'2026-11-09',endDate:'2026-11-11'},{type:'leave',memberId:4,startDate:'2026-11-13',endDate:'2026-11-20'}];
 // Monday 9 Nov is a holiday and also Jordan's leave; it only counts once.
 assert.deepEqual(domain.weekAvailability(3,'2026-11-09',absences),{available:2,holidays:['National holiday'],holidayDays:1,leaveDays:2});
 assert.deepEqual(domain.weekAvailability(4,'2026-11-09',absences),{available:3,holidays:['National holiday'],holidayDays:1,leaveDays:1});
 assert.equal(domain.weekAvailability(9,'2026-11-16',absences).available,5);
});

test('leave and holidays: holidays are manager-only, and members only change their own leave',async()=>{
 const handler=require('../netlify/functions/absences')._test.handle;
 const manager=person('manager',2),a=person('member',3),b=person('member',4),board=person('board',5),store=seeded([manager,a,b,board]);
 const call=async(user,body)=>{const event=await sessionEvent(user,store,'POST','/api/absences');event.body=JSON.stringify(body);const result=await handler(event,store);return{status:result.statusCode,body:JSON.parse(result.body)};};
 const status=(user,body)=>call(user,body).then(r=>r.status,error=>error.statusCode);
 const leave={id:1,type:'leave',memberId:3,startDate:'2026-11-09',endDate:'2026-11-10'};
 assert.equal(await status(a,{operation:'upsert',absence:{...leave,memberId:4},expectedVersion:0}),403);
 assert.equal(await status(a,{operation:'upsert',absence:{id:2,type:'holiday',label:'H',startDate:'2026-11-09',endDate:'2026-11-09'},expectedVersion:0}),403);
 assert.equal(await status(board,{operation:'upsert',absence:leave,expectedVersion:0}),403);
 assert.equal(await status(a,{operation:'upsert',absence:{...leave,endDate:'2026-11-01'},expectedVersion:0}),400);
 assert.equal(await status(manager,{operation:'upsert',absence:{id:2,type:'holiday',startDate:'2026-11-09',endDate:'2026-11-09'},expectedVersion:0}),400);
 assert.equal(await status(a,{operation:'upsert',absence:leave,expectedVersion:0}),201);
 assert.equal(await status(b,{operation:'delete',id:1,expectedVersion:1}),403);
 assert.equal(await status(manager,{operation:'upsert',absence:{id:2,type:'holiday',label:'H',startDate:'2026-11-09',endDate:'2026-11-09'},expectedVersion:0}),201);
 assert.equal(await status(a,{operation:'delete',id:2,expectedVersion:1}),403);
 assert.equal(await status(a,{operation:'delete',id:1,expectedVersion:1}),200);
 assert.equal(await records.currentRecord('absence',1,store),null);
});

test('team bottleneck summary averages only believable timelines, and is limited to managers and board',async()=>{
 const domain=require('../public/js/domain');
 const perf=(days,extra={})=>({timingReliable:true,phasesKnown:true,totalDays:days.reduce((a,b)=>a+b,0),phases:['Planning','Executing','Review','Finalize'].map((name,i)=>({name,days:days[i]})),bottleneck:null,reviewWait:null,rework:0,selfReviewed:false,...extra});
 const summary=domain.summarizePerformance([
  {id:1,title:'A',perf:perf([1,4,5,0],{reviewWait:4,rework:1,bottleneck:{name:'Review'}})},
  {id:2,title:'B',perf:perf([1,2,1,0],{reviewWait:2})},
  {id:3,title:'C',perf:perf([100,0,0,0],{timingReliable:false})},
  {id:4,title:'D',perf:{...perf([0,0,0,0]),timingReliable:false,phasesKnown:false}},
  {id:5,title:'E',perf:perf([0,1,1,0],{reviewWait:0,selfReviewed:true})},
 ]);
 assert.equal(summary.completed,5);assert.equal(summary.analyzed,3);
 assert.equal(summary.phases[2].days,(5+1+1)/3);
 assert.equal(summary.averageReviewWait,3);assert.equal(summary.selfReviewed,1);
 assert.equal(summary.reworked,1);assert.equal(summary.knownCount,4);
 assert.deepEqual(summary.slowest.map(row=>row.id),[1,2,5]);
 const handler=require('../netlify/functions/activity')._test.handle;
 const manager=person('manager',2),a=person('member',3),store=seeded([manager,a]);
 const today=domain.dateKeyInZone(new Date(),'Asia/Bangkok');
 await records.saveRecord('work',{id:90,title:'Done',status:'done',phase:4,completedDate:today,deadline:today,pic:3,assignees:[3]},0,store);
 const ask=async user=>{const event=await sessionEvent(user,store,'GET','/api/activity');event.queryStringParameters={bottlenecks:'1',days:'30'};return handler(event,store).then(r=>r,error=>({statusCode:error.statusCode}));};
 assert.equal((await ask(a)).statusCode,403);
 const allowed=await ask(manager);assert.equal(allowed.statusCode,200);assert.equal(JSON.parse(allowed.body).completed,1);
});

test('meeting action points: attendees edit them, and linking work also links the meeting',async()=>{
 const meetings=require('../netlify/functions/meetings')._test;
 const manager=person('manager',2),a=person('member',3),b=person('member',4),store=seeded([manager,a,b]);
 await records.saveRecord('work',{id:95,title:'Work',status:'ongoing',phase:0,pic:3,assignees:[3]},0,store);
 await records.saveRecord('meeting',{id:60,title:'M',date:'2030-01-01',startTime:'10:00',durationMinutes:30,startsAt:'2030-01-01T03:00:00.000Z',organizerId:2,attendees:[3],linkedWorkIds:[],status:'scheduled'},0,store);
 const call=async(user,body)=>{const event=await sessionEvent(user,store,'POST','/api/meetings');event.body=JSON.stringify(body);const result=await meetings.handle(event,store);return{status:result.statusCode,body:JSON.parse(result.body)};};
 const status=(user,body)=>call(user,body).then(r=>r.status,error=>error.statusCode);
 const action={id:1,text:'Confirm rate tables',ownerId:3,workId:null};
 assert.equal(await status(b,{operation:'actions',id:60,actions:[action],expectedVersion:1}),403);
 assert.equal(await status(a,{operation:'actions',id:60,actions:[{...action,text:' '}],expectedVersion:1}),400);
 assert.equal(await status(a,{operation:'actions',id:60,actions:[{...action,workId:999}],expectedVersion:1}),400);
 let r=await call(a,{operation:'actions',id:60,actions:[action],expectedVersion:1});assert.deepEqual(r.body.meeting.linkedWorkIds,[]);
 r=await call(a,{operation:'actions',id:60,actions:[{...action,workId:95}],expectedVersion:2});
 assert.equal(r.body.meeting.actions[0].workId,95);assert.deepEqual(r.body.meeting.linkedWorkIds,[95]);
});

test('meeting file links: attendees add them, paths are validated, and edits keep them',async()=>{
 const meetings=require('../netlify/functions/meetings')._test;
 const manager=person('manager',2),a=person('member',3),b=person('member',4),store=seeded([manager,a,b]);
 await records.saveRecord('meeting',{id:61,title:'M',date:'2030-01-01',startTime:'10:00',durationMinutes:30,startsAt:'2030-01-01T03:00:00.000Z',organizerId:2,attendees:[3],linkedWorkIds:[],status:'scheduled'},0,store);
 const call=async(user,body)=>{const event=await sessionEvent(user,store,'POST','/api/meetings');event.body=JSON.stringify(body);const result=await meetings.handle(event,store);return{status:result.statusCode,body:JSON.parse(result.body)};};
 const status=(user,body)=>call(user,body).then(r=>r.status,error=>error.statusCode);
 const file={name:'Results pack',url:'//fileserver/ifrs17/q3',type:'folder'};
 assert.equal(await status(b,{operation:'files',id:61,files:[file],expectedVersion:1}),403);
 assert.equal(await status(a,{operation:'files',id:61,files:[{...file,url:'javascript:alert(1)'}],expectedVersion:1}),400);
 assert.equal(await status(a,{operation:'files',id:61,files:[{...file,name:' '}],expectedVersion:1}),400);
 let r=await call(a,{operation:'files',id:61,files:[{...file,type:'constructor'}],expectedVersion:1});
 assert.equal(r.body.meeting.files[0].type,'others');assert.equal(r.body.meeting.files[0].icon,'🔖');
 r=await call(a,{operation:'files',id:61,files:[file],expectedVersion:2});assert.equal(r.body.meeting.files[0].icon,'📁');
 // Editing the meeting's details keeps its files.
 const future=new Date(Date.now()+3*86400000).toISOString().slice(0,10);
 r=await call(manager,{operation:'upsert',meeting:{id:61,title:'Renamed',date:future,startTime:'10:00',durationMinutes:30,attendees:[3],linkedWorkIds:[]},expectedVersion:3});
 assert.equal(r.body.meeting.files.length,1);
});
