'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {MemoryStore,memberRecord,sessionEvent}=require('./helpers');
const records=require('../netlify/functions/lib/records');
const works=require('../netlify/functions/works')._test;
const team=require('../netlify/functions/team')._test;
const {startDueWork}=require('../netlify/functions/auto-start');
const domain=require('../public/js/domain');
const person=(role,id)=>({id,role,name:role+' '+id,email:role+id+'@example.test',username:role+id,active:true,passwordHash:'fixture',authVersion:1});
const seeded=users=>new MemoryStore(Object.fromEntries(users.map(u=>['v2:member:'+u.id,memberRecord(u)])));
async function post(user,store,body){const event=await sessionEvent(user,store,'POST','/api/works');event.body=JSON.stringify(body);const result=await works.handle(event,store);return{status:result.statusCode,body:JSON.parse(result.body)};}

test('auto-start moves due upcoming work to Ongoing / Planning and leaves future work alone',async()=>{
 const store=new MemoryStore();
 await records.saveRecord('work',{id:1,title:'Due',status:'upcoming',phase:0,startDate:'2026-10-14'},0,store);
 await records.saveRecord('work',{id:2,title:'Late start',status:'upcoming',phase:0,startDate:'2026-10-01'},0,store);
 await records.saveRecord('work',{id:3,title:'Future',status:'upcoming',phase:0,startDate:'2026-10-15'},0,store);
 await records.saveRecord('work',{id:4,title:'No date',status:'upcoming',phase:0},0,store);
 assert.deepEqual((await startDueWork(store,'2026-10-14')).sort(),[1,2]);
 assert.equal((await records.currentRecord('work',1,store)).status,'ongoing');
 assert.equal((await records.currentRecord('work',1,store)).phase,0);
 assert.equal((await records.currentRecord('work',3,store)).status,'upcoming');
 assert.equal((await records.currentRecord('work',4,store)).status,'upcoming');
 assert.deepEqual(await startDueWork(store,'2026-10-14'),[]);
});

test('completing work records actual hours, defaulting to the estimate, and recurrences start without them',async()=>{
 const admin=person('admin',1),store=seeded([admin]);
 await records.saveRecord('work',{id:10,title:'Close',status:'ongoing',phase:3,pic:1,assignees:[1],estimatedHours:12,startDate:'2026-10-01',deadline:'2026-10-07',recurrence:'monthly',phaseChecks:{},phaseTasks:{}},0,store);
 await records.saveRecord('work',{id:11,title:'Review',status:'ongoing',phase:3,pic:1,assignees:[1],estimatedHours:8,phaseChecks:{},phaseTasks:{}},0,store);
 const first=await post(admin,store,{operation:'complete',id:10,expectedVersion:1,actualHours:15.5});
 assert.equal(first.status,200);assert.equal(first.body.work.actualHours,15.5);assert.equal(first.body.nextWork.actualHours,undefined);
 const second=await post(admin,store,{operation:'complete',id:11,expectedVersion:1});
 assert.equal(second.body.work.actualHours,8);
 await records.saveRecord('work',{id:12,title:'Bad',status:'ongoing',phase:3,pic:1,assignees:[1],phaseChecks:{},phaseTasks:{}},0,store);
 await assert.rejects(post(admin,store,{operation:'complete',id:12,expectedVersion:1,actualHours:-1}),error=>error.statusCode===400);
});

test('completed work stays in capacity for the weeks it ran, using actual hours',()=>{
 const done={status:'done',startDate:'2026-10-05',deadline:'2026-10-30',completedDate:'2026-10-09',estimatedHours:40,actualHours:10};
 assert.deepEqual(domain.allocateCapacityByWeek(done),{'2026-10-05':10});
 assert.deepEqual(domain.allocateCapacityByWeek({...done,actualHours:undefined}),{'2026-10-05':40});
 assert.deepEqual(domain.allocateCapacityByWeek({...done,completedDate:'2026-10-02'}),{'2026-09-28':10});
 const open={status:'ongoing',startDate:'2026-10-05',deadline:'2026-10-09',estimatedHours:20};
 assert.deepEqual(domain.allocateCapacityByWeek(open),domain.allocateEffortByWeek(open));
});

test('only admins can assign a creator, and only when it is missing or removed',async()=>{
 const admin=person('admin',1),manager=person('manager',2),member=person('member',3),store=seeded([admin,manager,member]);
 const items=[{id:1,name:'Legacy',createdAt:'2026-01-01'},{id:2,name:'Removed owner',createdBy:99,createdAt:'2026-01-01'},{id:3,name:'Owned',createdBy:3,createdAt:'2026-01-01'}];
 await records.saveCollection(store,'templates',items,1);
 const update=(user,changes)=>post(user,store,{operation:'collection',name:'templates',items:items.map(t=>changes[t.id]?{...t,createdBy:changes[t.id]}:t),baseItems:items,expectedVersion:2});
 assert.equal((await update(manager,{1:2})).status,403);
 assert.equal((await update(admin,{3:2})).status,403);
 assert.equal((await update(admin,{1:5})).status,403);
 const saved=await update(admin,{1:2,2:3});
 assert.equal(saved.status,200);
 assert.equal(saved.body.items.find(t=>t.id===1).createdBy,2);assert.equal(saved.body.items.find(t=>t.id===2).createdBy,3);
});

test('default tags are shared with everyone but only admins can change them',async()=>{
 const admin=person('admin',1),manager=person('manager',2),store=seeded([admin,manager]);
 assert.equal((await post(manager,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'},{id:2,name:'ifrs 17'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'A,B'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'},{id:2,name:'Reserving'}],baseItems:[],expectedVersion:1})).status,200);
 const workspace=await records.readWorkspace(store,{force:true});
 assert.deepEqual(workspace.tagOptions.map(t=>t.name),['IFRS 17','Reserving']);assert.equal(workspace.versions.tagOptions,2);
});

test('web push: subscriptions follow the latest account, review-ready and overdue alerts respect settings',async()=>{
 const push=require('../netlify/functions/lib/push');const pushHandler=require('../netlify/functions/push')._test.handle;
 const {sendOverdueAlerts}=require('../netlify/functions/overdue-alerts');
 process.env.VAPID_PUBLIC_KEY='test-public';process.env.VAPID_PRIVATE_KEY='test-private';
 const sent=[];push._setTransport(async(subscription,body)=>{if(subscription.endpoint.endsWith('gone'))throw Object.assign(new Error('gone'),{statusCode:410});sent.push([subscription.endpoint,JSON.parse(body)]);});
 try{
  const admin=person('admin',1),manager={...person('manager',2),notificationPreferences:{reviewReady:false,overdueToday:true}},member=person('member',3),store=seeded([admin,manager,member]);
  const sub=endpoint=>({endpoint:'https://push.example.test/'+endpoint,keys:{p256dh:'p',auth:'a'}});
  const subscribe=async(user,subscription)=>{const event=await sessionEvent(user,store,'POST','/api/push');event.body=JSON.stringify({operation:'subscribe',subscription});return(await pushHandler(event,store)).statusCode;};
  assert.equal(await subscribe(admin,sub('admin')),200);assert.equal(await subscribe(manager,sub('manager')),200);
  assert.equal(await subscribe(member,sub('shared')),200);assert.equal(await subscribe(admin,sub('shared')),200);
  assert.equal(await subscribe(member,sub('gone')),200);
  await assert.rejects(subscribe(member,{endpoint:'http://insecure',keys:{}}),error=>error.statusCode===400);
  assert.equal((await push.listSubscriptions(store)).find(row=>row.subscription.endpoint.endsWith('shared')).userId,1);
  // Member moves work into Review: admin is notified on both devices, manager opted out.
  await records.saveRecord('work',{id:20,title:'Reserve review',status:'ongoing',phase:1,pic:3,assignees:[3],estimatedHours:4,deadline:'2026-10-01',phaseChecks:{},phaseTasks:{}},0,store);
  const work={...(await records.currentRecord('work',20,store)),phase:2};delete work.version;
  assert.equal((await post(member,store,{operation:'upsert',work,expectedVersion:1})).status,200);
  assert.deepEqual(sent.map(([endpoint])=>endpoint.split('/').pop()).sort(),['admin','shared']);assert.equal(sent[0][1].tag,'review-20');
  sent.length=0;
  // Overdue: PIC member's only device is expired and gets removed; manager has no overdue work.
  assert.equal(await sendOverdueAlerts(store,'2026-10-14'),0);
  assert.ok(!(await push.listSubscriptions(store)).some(row=>row.subscription.endpoint.endsWith('gone')));
  await records.saveRecord('work',{id:21,title:'Old close',status:'ongoing',phase:1,pic:2,assignees:[2],deadline:'2026-10-10'},0,store);
  assert.equal(await sendOverdueAlerts(store,'2026-10-14'),1);assert.equal(sent[0][1].title,'Overdue work');
 }finally{push._setTransport(null);delete process.env.VAPID_PUBLIC_KEY;delete process.env.VAPID_PRIVATE_KEY;}
});

test('admins can correct estimate, actual hours and completion date on completed work; members cannot',async()=>{
 const admin=person('admin',1),member=person('member',3),store=seeded([admin,member]);
 await records.saveRecord('work',{id:30,title:'Done',status:'done',phase:4,pic:3,assignees:[3],estimatedHours:10,actualHours:12,completedDate:'2026-10-05',phaseChecks:{},phaseTasks:{}},0,store);
 const edit=async(user,changes,version)=>{const work={...(await records.currentRecord('work',30,store)),...changes};delete work.version;return post(user,store,{operation:'upsert',work,expectedVersion:version});};
 assert.equal((await edit(member,{actualHours:5},1)).status,403);
 assert.equal((await edit(admin,{completedDate:'2999-01-01'},1)).status,400);
 assert.equal((await edit(admin,{completedDate:'2026-02-30'},1)).status,400);
 const saved=await edit(admin,{estimatedHours:14,actualHours:9.5,completedDate:'2026-10-03'},1);
 assert.equal(saved.status,200);assert.equal(saved.body.work.estimatedHours,14);assert.equal(saved.body.work.actualHours,9.5);assert.equal(saved.body.work.completedDate,'2026-10-03');
});

test('note, phase-change, completion and due-today alerts reach the right people',async()=>{
 const push=require('../netlify/functions/lib/push');const pushHandler=require('../netlify/functions/push')._test.handle;const {sendOverdueAlerts}=require('../netlify/functions/overdue-alerts');const reads=require('../netlify/functions/reads')._test.handle;
 process.env.VAPID_PUBLIC_KEY='t';process.env.VAPID_PRIVATE_KEY='t';
 const sent=[];push._setTransport(async(sub,body)=>{sent.push([sub.endpoint.split('/').pop(),JSON.parse(body)]);});
 try{
  const admin=person('admin',1),manager=person('manager',2),a=person('member',3),b=person('member',4),c=person('member',5),store=seeded([admin,manager,a,b,c]);
  for(const [u,e] of [[a,'a'],[b,'b'],[c,'c'],[manager,'m']]){const ev=await sessionEvent(u,store,'POST','/api/push');ev.body=JSON.stringify({operation:'subscribe',subscription:{endpoint:'https://p.test/'+e,keys:{p256dh:'p',auth:'a'}}});await pushHandler(ev,store);}
  await records.saveRecord('work',{id:40,title:'Close',status:'ongoing',phase:0,pic:3,assignees:[3,4],estimatedHours:5,startDate:'2026-10-01',deadline:'2026-10-14',notes:[],phaseChecks:{},phaseTasks:{}},0,store);
  const who=()=>sent.map(([e])=>e).sort().join();
  const fresh=async()=>{const w=await records.currentRecord('work',40,store);const version=w.version;delete w.version;return {w,version};};
  // Note from member b: PIC a is alerted; b (author) and c (not involved) are not.
  let {w,version}=await fresh();
  let r=await post(b,store,{operation:'upsert',work:{...w,notes:[{authorId:4,authorName:'member 4',text:'Please check the totals',createdDate:'2026-10-14',editedDate:null}]},expectedVersion:version});
  assert.equal(r.status,200);assert.equal(who(),'a');assert.match(sent[0][1].title,/member 4/);assert.equal(sent[0][1].body,'Please check the totals');
  assert.ok((await records.currentRecord('work',40,store)).notes[0].createdAt,'server stamps the note time');
  // Phase move by member b alerts the PIC.
  sent.length=0;({w,version}=await fresh());
  r=await post(b,store,{operation:'upsert',work:{...w,phase:1},expectedVersion:version});assert.equal(who(),'a');assert.equal(sent[0][1].title,'Phase changed');
  // The PIC moving their own work to Review alerts nobody about the phase, but the manager still gets review-ready.
  sent.length=0;({w,version}=await fresh());
  await post(a,store,{operation:'upsert',work:{...w,phase:2},expectedVersion:version});
  assert.ok(!sent.some(([e])=>e==='a'),'PIC is not alerted about their own move');assert.ok(sent.some(([e])=>e==='m'),'manager gets review-ready');
  // Completion by someone else alerts the PIC.
  sent.length=0;({version}=await fresh());
  await post(b,store,{operation:'complete',id:40,expectedVersion:version,actualHours:4});assert.equal(who(),'a');assert.equal(sent[0][1].title,'Work completed');
  // Daily alert: due today and overdue in one message; future work is left out.
  sent.length=0;
  await records.saveRecord('work',{id:41,title:'Today job',status:'ongoing',phase:1,pic:4,assignees:[4],deadline:'2026-10-20',phaseChecks:{},phaseTasks:{}},0,store);
  await records.saveRecord('work',{id:42,title:'Late job',status:'ongoing',phase:1,pic:4,assignees:[4],deadline:'2026-10-18',phaseChecks:{},phaseTasks:{}},0,store);
  await records.saveRecord('work',{id:43,title:'Future job',status:'ongoing',phase:1,pic:4,assignees:[4],deadline:'2026-10-25',phaseChecks:{},phaseTasks:{}},0,store);
  await sendOverdueAlerts(store,'2026-10-20');const mine=sent.filter(([e])=>e==='b');
  assert.equal(mine.length,1);assert.match(mine[0][1].title,/1 due today, 1 overdue/);assert.ok(!mine[0][1].body.includes('Future'));
  // Unread markers only move forward and belong to one person.
  const mark=async(u,workId,seenAt)=>{const ev=await sessionEvent(u,store,'POST','/api/reads');ev.body=JSON.stringify({workId,seenAt});return JSON.parse((await reads(ev,store)).body);};
  assert.equal((await mark(a,'40','2026-10-20T05:00:00.000Z')).seen['40'],'2026-10-20T05:00:00.000Z');
  assert.equal((await mark(a,'40','2026-10-20T01:00:00.000Z')).seen['40'],'2026-10-20T05:00:00.000Z');
  const ev=await sessionEvent(b,store,'GET','/api/reads');assert.deepEqual(JSON.parse((await reads(ev,store)).body).seen,{});
 }finally{push._setTransport(null);delete process.env.VAPID_PUBLIC_KEY;delete process.env.VAPID_PRIVATE_KEY;}
});

test('recurring work is created by TeamFlow with an explanatory first note and keeps its original creator',async()=>{
 const admin=person('admin',1),member=person('member',3),store=seeded([admin,member]);
 await records.saveRecord('work',{id:50,title:'Monthly close',status:'ongoing',phase:3,pic:3,assignees:[3],createdBy:3,estimatedHours:8,recurrence:'monthly',startDate:'2026-10-01',deadline:'2026-10-31',notes:[{authorId:3,authorName:'member 3',text:'old note',createdDate:'2026-10-02'}],phaseChecks:{},phaseTasks:{}},0,store);
 const r=await post(admin,store,{operation:'complete',id:50,expectedVersion:1,actualHours:9});
 const next=r.body.nextWork;
 assert.equal(next.notes.length,1);assert.equal(next.notes[0].system,true);assert.equal(next.notes[0].authorName,'TeamFlow');
 assert.match(next.notes[0].text,/Created automatically.*Monthly close.*every month/);assert.equal(next.createdBy,3);
 const history=await require('../netlify/functions/lib/activity-log').readActivity(store,next.id);
 assert.equal(history[0].actorName,'TeamFlow (recurring work)');assert.equal(history[0].action,'created');
});

test('smart search matches people, tags, phase, notes and any word order',()=>{
 const vm=require('node:vm'),fs=require('node:fs');
 const ctx={TEAM:[{id:3,name:'Jordan Kim'},{id:4,name:'Sam Rivera'}],PHASES:['Planning','Executing','Review','Finalize'],WORK_TYPES:[{value:'regular',label:'Regular'}],RECURRENCE_OPTIONS:[],currentUser:{id:3}};
 ctx.getMember=id=>ctx.TEAM.find(m=>m.id===id);
 vm.createContext(ctx);
 const source=fs.readFileSync('public/js/work.js','utf8'),from=source.indexOf('function workSearchText'),to=source.indexOf('function applyFiltersAndSort');
 vm.runInContext(source.slice(from,to),ctx);
 const w={title:'Reserve review',desc:'Quarter end',tags:['IFRS 17'],assignees:[3],pic:4,status:'ongoing',phase:2,priority:'High',workType:'regular',notes:[{text:'Check the CSM roll-forward',authorName:'Sam Rivera'}],files:[{name:'Workpaper'}]};
 for(const q of ['jordan','SAM','ifrs','review high','roll-forward','workpaper','jordan reserve','Review'])assert.ok(ctx.workMatchesSearch(w,q),q);
 for(const q of ['taylor','jordan finalize','nothing here'])assert.ok(!ctx.workMatchesSearch(w,q),q);
});

test('notification preferences are self-editable and normalized to known switches',()=>{
 const member=team.normalizeMember({id:3,name:'Member',role:'member',username:'member',notificationPreferences:{reviewReady:false,overdueToday:'yes',extra:true}});
 assert.deepEqual(member.notificationPreferences,{reviewReady:false,overdueToday:true,workUpdates:true});
 assert.throws(()=>team.normalizeMember({id:3,name:'Member',role:'member',username:'member',notificationPreferences:[]}),/Notification settings/);
});

test('activity history says which phase moved and which tasks were checked',async()=>{
 const {appendActivity,readActivity}=require('../netlify/functions/lib/activity-log');const store=new MemoryStore();
 const before={status:'ongoing',phase:0,phaseTasks:{Planning:['Scope','Data'],Executing:['Build']},phaseChecks:{Planning:[true,false],Executing:[false]},deadline:'2026-10-20',notes:[]};
 const after={...before,phase:1,phaseChecks:{Planning:[true,true],Executing:[false]},deadline:'2026-10-25',notes:[{text:'x'}]};
 await appendActivity(store,7,{id:1,name:'Avery'},'updated',before,after);
 const [entry]=await readActivity(store,7);
 assert.deepEqual(entry.details,['Phase: Planning → Executing','Planning: checked “Data”','Deadline: 2026-10-20 → 2026-10-25','Added 1 note(s)']);
 await appendActivity(store,8,{id:1,name:'Avery'},'created',{},after);
 assert.deepEqual((await readActivity(store,8))[0].details,[]);
});

test('the notification prompt version matches the newest Changelog release',()=>{
 const source=require('node:fs').readFileSync('public/js/ui.js','utf8');
 const version=source.match(/const APP_VERSION='([\d.]+)'/)[1],newest=source.match(/\{ver:'([\d.]+)'/)[1];
 assert.equal(version,newest,'bump APP_VERSION together with the Changelog');
});

test('a quick second save never strips the written-time stamp from earlier notes',async()=>{
 const admin=person('admin',1),member=person('member',3),store=seeded([admin,member]);
 const note=(text,createdAt)=>({authorId:3,authorName:'member 3',text,createdDate:'2026-10-28',editedDate:null,...(createdAt?{createdAt}:{})});
 await records.saveRecord('work',{id:60,title:'Notes',status:'ongoing',phase:1,pic:3,assignees:[3],notes:[note('wow','2026-10-28T03:00:00.000Z')],phaseChecks:{},phaseTasks:{}},0,store);
 // The second save comes from a copy that never received the stamp on "wow".
 const w=await records.currentRecord('work',60,store);const version=w.version;delete w.version;
 const r=await post(member,store,{operation:'upsert',work:{...w,notes:[note('wow'),note('test')]},expectedVersion:version});
 assert.equal(r.status,200);
 assert.equal(r.body.work.notes[0].createdAt,'2026-10-28T03:00:00.000Z','earlier note keeps its stamp');
 assert.ok(r.body.work.notes[1].createdAt>'2026-10-28T03:00:00.000Z','new note is stamped by the server');
});
