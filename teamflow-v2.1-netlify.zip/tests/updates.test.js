'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {MemoryStore,memberRecord,sessionEvent}=require('./helpers');
const records=require('../netlify/functions/lib/records');
const works=require('../netlify/functions/works')._test;
const team=require('../netlify/functions/team')._test;
const {startDueWork}=require('../netlify/functions/auto-start');
const domain=require('../public/js/domain');
const person=(role,id)=>({id,role,name:role+' '+id,email:role+id+'@example.test',username:role+id,active:true,passwordHash:'fixture',authVersion:1});
const seeded=users=>new MemoryStore(Object.fromEntries(users.map(u=>['v2:member:'+u.id,memberRecord(u)])));
async function post(user,store,body){const event=await sessionEvent(user,store,'POST','/api/works');event.body=JSON.stringify(body);const result=await works.handle(event,store);return{status:result.statusCode,body:JSON.parse(result.body)};}

test('auto-start moves due upcoming work to Ongoing / Planning and leaves future work alone',async()=>{
 const store=new MemoryStore();
 await records.saveRecord('work',{id:1,title:'Due',status:'upcoming',phase:0,startDate:'2026-10-14'},0,store);
 await records.saveRecord('work',{id:2,title:'Late start',status:'upcoming',phase:0,startDate:'2026-10-01'},0,store);
 await records.saveRecord('work',{id:3,title:'Future',status:'upcoming',phase:0,startDate:'2026-10-15'},0,store);
 await records.saveRecord('work',{id:4,title:'No date',status:'upcoming',phase:0},0,store);
 assert.deepEqual((await startDueWork(store,'2026-10-14')).sort(),[1,2]);
 assert.equal((await records.currentRecord('work',1,store)).status,'ongoing');
 assert.equal((await records.currentRecord('work',1,store)).phase,0);
 assert.equal((await records.currentRecord('work',3,store)).status,'upcoming');
 assert.equal((await records.currentRecord('work',4,store)).status,'upcoming');
 assert.deepEqual(await startDueWork(store,'2026-10-14'),[]);
});

test('completing work records actual hours, defaulting to the estimate, and recurrences start without them',async()=>{
 const admin=person('admin',1),store=seeded([admin]);
 await records.saveRecord('work',{id:10,title:'Close',status:'ongoing',phase:3,pic:1,assignees:[1],estimatedHours:12,startDate:'2026-10-01',deadline:'2026-10-07',recurrence:'monthly',phaseChecks:{},phaseTasks:{}},0,store);
 await records.saveRecord('work',{id:11,title:'Review',status:'ongoing',phase:3,pic:1,assignees:[1],estimatedHours:8,phaseChecks:{},phaseTasks:{}},0,store);
 const first=await post(admin,store,{operation:'complete',id:10,expectedVersion:1,actualHours:15.5});
 assert.equal(first.status,200);assert.equal(first.body.work.actualHours,15.5);assert.equal(first.body.nextWork.actualHours,undefined);
 const second=await post(admin,store,{operation:'complete',id:11,expectedVersion:1});
 assert.equal(second.body.work.actualHours,8);
 await records.saveRecord('work',{id:12,title:'Bad',status:'ongoing',phase:3,pic:1,assignees:[1],phaseChecks:{},phaseTasks:{}},0,store);
 await assert.rejects(post(admin,store,{operation:'complete',id:12,expectedVersion:1,actualHours:-1}),error=>error.statusCode===400);
});

test('completed work stays in capacity for the weeks it ran, using actual hours',()=>{
 const done={status:'done',startDate:'2026-10-05',deadline:'2026-10-30',completedDate:'2026-10-09',estimatedHours:40,actualHours:10};
 assert.deepEqual(domain.allocateCapacityByWeek(done),{'2026-10-05':10});
 assert.deepEqual(domain.allocateCapacityByWeek({...done,actualHours:undefined}),{'2026-10-05':40});
 assert.deepEqual(domain.allocateCapacityByWeek({...done,completedDate:'2026-10-02'}),{'2026-09-28':10});
 const open={status:'ongoing',startDate:'2026-10-05',deadline:'2026-10-09',estimatedHours:20};
 assert.deepEqual(domain.allocateCapacityByWeek(open),domain.allocateEffortByWeek(open));
});

test('only admins can assign a creator, and only when it is missing or removed',async()=>{
 const admin=person('admin',1),manager=person('manager',2),member=person('member',3),store=seeded([admin,manager,member]);
 const items=[{id:1,name:'Legacy',createdAt:'2026-01-01'},{id:2,name:'Removed owner',createdBy:99,createdAt:'2026-01-01'},{id:3,name:'Owned',createdBy:3,createdAt:'2026-01-01'}];
 await records.saveCollection(store,'templates',items,1);
 const update=(user,changes)=>post(user,store,{operation:'collection',name:'templates',items:items.map(t=>changes[t.id]?{...t,createdBy:changes[t.id]}:t),baseItems:items,expectedVersion:2});
 assert.equal((await update(manager,{1:2})).status,403);
 assert.equal((await update(admin,{3:2})).status,403);
 assert.equal((await update(admin,{1:5})).status,403);
 const saved=await update(admin,{1:2,2:3});
 assert.equal(saved.status,200);
 assert.equal(saved.body.items.find(t=>t.id===1).createdBy,2);assert.equal(saved.body.items.find(t=>t.id===2).createdBy,3);
});

test('default tags are shared with everyone but only admins can change them',async()=>{
 const admin=person('admin',1),manager=person('manager',2),store=seeded([admin,manager]);
 assert.equal((await post(manager,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'},{id:2,name:'ifrs 17'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'A,B'}],baseItems:[],expectedVersion:1})).status,403);
 assert.equal((await post(admin,store,{operation:'collection',name:'tagOptions',items:[{id:1,name:'IFRS 17'},{id:2,name:'Reserving'}],baseItems:[],expectedVersion:1})).status,200);
 const workspace=await records.readWorkspace(store,{force:true});
 assert.deepEqual(workspace.tagOptions.map(t=>t.name),['IFRS 17','Reserving']);assert.equal(workspace.versions.tagOptions,2);
});

test('web push: subscriptions follow the latest account, review-ready and overdue alerts respect settings',async()=>{
 const push=require('../netlify/functions/lib/push');const pushHandler=require('../netlify/functions/push')._test.handle;
 const {sendOverdueAlerts}=require('../netlify/functions/overdue-alerts');
 process.env.VAPID_PUBLIC_KEY='test-public';process.env.VAPID_PRIVATE_KEY='test-private';
 const sent=[];push._setTransport(async(subscription,body)=>{if(subscription.endpoint.endsWith('gone'))throw Object.assign(new Error('gone'),{statusCode:410});sent.push([subscription.endpoint,JSON.parse(body)]);});
 try{
  const admin=person('admin',1),manager={...person('manager',2),notificationPreferences:{reviewReady:false,overdueToday:true}},member=person('member',3),store=seeded([admin,manager,member]);
  const sub=endpoint=>({endpoint:'https://push.example.test/'+endpoint,keys:{p256dh:'p',auth:'a'}});
  const subscribe=async(user,subscription)=>{const event=await sessionEvent(user,store,'POST','/api/push');event.body=JSON.stringify({operation:'subscribe',subscription});return(await pushHandler(event,store)).statusCode;};
  assert.equal(await subscribe(admin,sub('admin')),200);assert.equal(await subscribe(manager,sub('manager')),200);
  assert.equal(await subscribe(member,sub('shared')),200);assert.equal(await subscribe(admin,sub('shared')),200);
  assert.equal(await subscribe(member,sub('gone')),200);
  await assert.rejects(subscribe(member,{endpoint:'http://insecure',keys:{}}),error=>error.statusCode===400);
  assert.equal((await push.listSubscriptions(store)).find(row=>row.subscription.endpoint.endsWith('shared')).userId,1);
  // Member moves work into Review: admin is notified on both devices, manager opted out.
  await records.saveRecord('work',{id:20,title:'Reserve review',status:'ongoing',phase:1,pic:3,assignees:[3],estimatedHours:4,deadline:'2026-10-01',phaseChecks:{},phaseTasks:{}},0,store);
  const work={...(await records.currentRecord('work',20,store)),phase:2};delete work.version;
  assert.equal((await post(member,store,{operation:'upsert',work,expectedVersion:1})).status,200);
  assert.deepEqual(sent.map(([endpoint])=>endpoint.split('/').pop()).sort(),['admin','shared']);assert.equal(sent[0][1].tag,'review-20');
  sent.length=0;
  // Overdue: PIC member's only device is expired and gets removed; manager has no overdue work.
  assert.equal(await sendOverdueAlerts(store,'2026-10-14'),0);
  assert.ok(!(await push.listSubscriptions(store)).some(row=>row.subscription.endpoint.endsWith('gone')));
  await records.saveRecord('work',{id:21,title:'Old close',status:'ongoing',phase:1,pic:2,assignees:[2],deadline:'2026-10-10'},0,store);
  assert.equal(await sendOverdueAlerts(store,'2026-10-14'),1);assert.equal(sent[0][1].title,'Overdue work');
 }finally{push._setTransport(null);delete process.env.VAPID_PUBLIC_KEY;delete process.env.VAPID_PRIVATE_KEY;}
});

test('admins can correct estimate, actual hours and completion date on completed work; members cannot',async()=>{
 const admin=person('admin',1),member=person('member',3),store=seeded([admin,member]);
 await records.saveRecord('work',{id:30,title:'Done',status:'done',phase:4,pic:3,assignees:[3],estimatedHours:10,actualHours:12,completedDate:'2026-10-05',phaseChecks:{},phaseTasks:{}},0,store);
 const edit=async(user,changes,version)=>{const work={...(await records.currentRecord('work',30,store)),...changes};delete work.version;return post(user,store,{operation:'upsert',work,expectedVersion:version});};
 assert.equal((await edit(member,{actualHours:5},1)).status,403);
 assert.equal((await edit(admin,{completedDate:'2999-01-01'},1)).status,400);
 assert.equal((await edit(admin,{completedDate:'2026-02-30'},1)).status,400);
 const saved=await edit(admin,{estimatedHours:14,actualHours:9.5,completedDate:'2026-10-03'},1);
 assert.equal(saved.status,200);assert.equal(saved.body.work.estimatedHours,14);assert.equal(saved.body.work.actualHours,9.5);assert.equal(saved.body.work.completedDate,'2026-10-03');
});

test('notification preferences are self-editable and normalized to known switches',()=>{
 const member=team.normalizeMember({id:3,name:'Member',role:'member',username:'member',notificationPreferences:{reviewReady:false,overdueToday:'yes',extra:true}});
 assert.deepEqual(member.notificationPreferences,{reviewReady:false,overdueToday:true});
 assert.throws(()=>team.normalizeMember({id:3,name:'Member',role:'member',username:'member',notificationPreferences:[]}),/Notification settings/);
});
