'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {MemoryStore}=require('./helpers');
const {requestStore,checkedFetch}=require('../netlify/functions/lib/store');
const records=require('../netlify/functions/lib/records');
test('request store deduplicates parallel reads and invalidates after mutations',async()=>{
 const raw=new MemoryStore({key:'before'});let calls=0;const read=raw.get.bind(raw);raw.get=async(...args)=>{calls++;return read(...args);};const store=requestStore(raw);
 assert.deepEqual(await Promise.all([store.get('key'),store.get('key')]),['before','before']);assert.equal(calls,1);assert.equal(await store.getFresh('key'),'before');assert.equal(calls,2);
 await store.set('key','after');assert.equal(await store.get('key'),'after');assert.equal(calls,3);await store.delete('key');assert.equal(await store.get('key'),null);
});
test('failed memoized reads can be retried',async()=>{
 let calls=0;const store=requestStore({get:async()=>{if(++calls===1)throw new Error('temporary');return 'recovered';}});await assert.rejects(store.get('key'),/temporary/);assert.equal(await store.get('key'),'recovered');assert.equal(calls,2);
});
test('workspace projection avoids record scans, invalidates on writes and supports forced refresh',async()=>{
 const store=new MemoryStore();await records.saveRecord('work',{id:1,title:'before'},0,store);let scans=0;const list=store.list.bind(store);store.list=async(...args)=>{scans++;return list(...args);};
 const first=await records.readWorkspace(store);assert.equal(first.data[0].title,'before');const initial=scans;assert.ok(initial>0);
 assert.deepEqual(await records.readWorkspace(store),first);assert.equal(scans,initial);
 await records.saveRecord('work',{id:1,title:'after'},1,store);assert.equal((await records.readWorkspace(store)).data[0].title,'after');assert.ok(scans>initial);const after=scans;
 await records.readWorkspace(store,{force:true});assert.ok(scans>after);
});
test('expired workspace projections are rebuilt from authoritative records',async()=>{
 const store=new MemoryStore();await records.saveRecord('work',{id:1,title:'record'},0,store);await records.readWorkspace(store);const cached=JSON.parse(await store.get('v3:workspace-read-model'));cached.createdAt=Date.now()-300001;cached.payload.data[0].title='stale';await store.set('v3:workspace-read-model',JSON.stringify(cached));assert.equal((await records.readWorkspace(store)).data[0].title,'record');
});
test('transient storage read failures fail fast without masking missing records',async()=>{
 const previous=global.fetch;try{for(const status of [403,429,500]){global.fetch=async()=>new Response('failure',{status});await assert.rejects(checkedFetch('https://example.test',{method:'GET'}),e=>e.statusCode===503);}global.fetch=async()=>new Response(null,{status:404});assert.equal((await checkedFetch('https://example.test',{method:'GET'})).status,404);}finally{global.fetch=previous;}
});