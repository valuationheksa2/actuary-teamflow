'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),{webcrypto}=require('node:crypto');
function client(now){
 const elements=new Map();const makeElement=()=>({innerHTML:'',textContent:'',value:'',style:{},dataset:{},isConnected:true,classList:{add(){},remove(){},contains(){return false;}},setAttribute(){},removeAttribute(){},querySelector(){return null;},querySelectorAll(){return[];},appendChild(child){child.isConnected=true;return child;},remove(){this.isConnected=false;},getAnimations(){return[];},animate(){}});const element=id=>{if(!elements.has(id))elements.set(id,makeElement());return elements.get(id);};
 const team=[{id:1,name:'Audit Admin',username:'admin',email:'admin@example.test',role:'admin',color:'#5c6ef8',initials:'AA',weeklyCapacityHours:40}];
 const work={id:10,title:'Valuation',desc:'Fictional',status:'ongoing',priority:'High',phase:1,workType:'regular',startDate:'2026-10-01',deadline:'2026-10-07',estimatedHours:10,pic:1,assignees:[1],tags:[],files:[],notes:[],phaseTasks:{Planning:['A'],Executing:['B'],Review:['C'],Finalize:['D']},phaseChecks:{Planning:[true],Executing:[false],Review:[false],Finalize:[false]},version:1};
 const bundle={data:[work],feedbackItems:[],templates:[],joinRequests:[],versions:{feedbackItems:1,templates:1,joinRequests:1}};
 const storage=new Map();const ctx={getComputedStyle:()=>({gridTemplateColumns:"100px 100px 100px"}),console,crypto:webcrypto,document:{hidden:false,activeElement:null,createElement:makeElement,getElementById:id=>id==="conflict-review-overlay"?null:element(id),querySelector:()=>null,querySelectorAll:()=>[],addEventListener(){}},window:{addEventListener(){},matchMedia:()=>({matches:false})},localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)},setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,clearInterval(){},confirm:()=>true,fetch,URLSearchParams};if(now){const RealDate=Date;ctx.Date=class extends RealDate{constructor(...args){super(...(args.length?args:[now]));}static now(){return RealDate.parse(now);}};}vm.createContext(ctx);
 for(const file of ['domain','core','work','reports','meetings','absences','tutorials','admin','ui','collaboration'])vm.runInContext(fs.readFileSync('public/js/'+file+'.js','utf8'),ctx,{filename:file+'.js'});
 ctx.seedTeam=team;ctx.seedBundle=bundle;vm.runInContext('syncBaseline(seedTeam,seedBundle);currentUser=TEAM[0];',ctx);
 ctx.apiGet=async path=>path.split('?')[0]==='works'?bundle:path==='team'?team:path.startsWith('activity')?[]:{};
 ctx.showToast=()=>{};ctx.appPrompt=async()=>'<b>Template</b>';return{ctx,element,team,bundle,run:code=>vm.runInContext(code,ctx)};
}
test('all main pages render with fictional data',async()=>{const c=client();for(const name of ['renderDashboard','renderOngoing','renderUpcoming','renderHistory','renderCapacity','renderTemplates','renderAudit','renderTeam','renderRequests','renderAdmin','renderChangelog','renderHelp','renderFeedback']){if(name==='renderFeedback')c.run("currentPage='feedback'");await c.run(name+'()');assert.ok(c.element('content').innerHTML.length,name);}});
test('shared feedback is rendered as literal text with synchronized baseline',async()=>{const c=client();c.run("currentPage='feedback'");c.bundle.feedbackItems=[{id:1,author:'<img src=x>',text:'<b>literal</b>',category:'Bug Report',date:'2026-10-01',status:'open'}];c.bundle.versions.feedbackItems=4;await c.run('renderFeedback()');assert.match(c.element('content').innerHTML,/&lt;b&gt;literal/);assert.ok(!c.element('content').innerHTML.includes('<img src=x>'));assert.equal(c.run('remoteState.versions.feedbackItems'),4);});
test('feedback awaits saves, preserves failed draft and retries the same item',async()=>{const c=client();c.run("currentPage='feedback'");c.element('fb-text').value='Audit feedback';c.element('fb-cat').value='Suggestion';let resolve;c.ctx.saveRequestsNow=()=>new Promise(r=>{resolve=r;});const submission=c.run('submitFeedback()');assert.equal(c.run('feedbackBusy'),true);assert.equal(c.element('fb-text').value,'Audit feedback');resolve(false);await submission;assert.equal(c.run('feedbackItems.length'),1);const id=c.run('feedbackItems[0].id');c.ctx.saveRequestsNow=async()=>true;await c.run('submitFeedback()');assert.equal(c.run('feedbackItems.length'),1);assert.equal(c.run('feedbackItems[0].id'),id);});
test('background sync redraws changed data but never replaces an in-flight draft',async()=>{const c=client();let rendered=0;c.ctx.navigate=()=>{rendered++;};c.bundle.data=[{...c.bundle.data[0],title:'From device B',version:2}];await c.run('backgroundSync({force:true})');assert.equal(c.run('works[0].title'),'From device B');assert.equal(rendered,1);c.ctx.apiGet=async path=>{c.run('draftActive=true;editGeneration++;');return path==='team'?c.team:{...c.bundle,data:[{...c.bundle.data[0],title:'Must not overwrite'}]};};await c.run('backgroundSync({force:true})');assert.equal(c.run('works[0].title'),'From device B');});
test('record IDs are safe numeric values and do not use stale per-device counters',()=>{const c=client(),ids=new Set();for(let i=0;i<1000;i++){const id=c.run('newRecordId()');assert.ok(Number.isSafeInteger(id)&&id>0);ids.add(id);}assert.equal(ids.size,1000);});
test('member can create work and board cannot see feedback submission',async()=>{const c=client();c.run("currentUser.role='member';openAddWork()");assert.equal(c.element('modal-overlay').style.display,'flex');c.run("currentPage='feedback';currentUser.role='board'");await c.run('renderFeedback()');assert.ok(!c.element('content').innerHTML.includes('id="fb-text"'));});

test('failed work creation retries the same record without creating duplicates',async()=>{const c=client();c.ctx.getSelectedMembers=()=>[1];c.ctx.getPhaseTasks=()=>['Task'];c.element('f-title').value='Retry work';c.element('f-status').value='upcoming';c.element('f-priority').value='High';c.element('f-pic').value='1';c.element('f-start').value='2026-10-01';c.element('f-deadline').value='2026-10-07';c.ctx.saveRequestsNow=async()=>false;await c.run('saveNewWork()');const id=c.run('pendingCreationId');assert.equal(c.run('works.length'),2);c.ctx.saveRequestsNow=async()=>true;c.ctx.navigate=()=>{};await c.run('saveNewWork()');assert.equal(c.run('works.length'),2);assert.equal(c.run('works[1].id'),id);assert.equal(c.run('pendingCreationId'),null);});
test('template saving awaits shared persistence and rendered tags are escaped',async()=>{const c=client();c.ctx.prompt=()=>'<b>Template</b>';c.ctx.getPhaseTasks=()=>['Task'];c.ctx.getSelectedMembers=()=>[1];c.element('f-title').value='Valuation template';c.element('f-status').value='upcoming';c.element('f-priority').value='High';c.element('f-tags').value='<img src=x>';let saves=0;c.ctx.saveRequestsNow=async()=>{saves++;return true;};await c.run('saveAsTemplate()');assert.equal(saves,1);c.run('renderTemplates()');assert.match(c.element('content').innerHTML,/&lt;img src=x&gt;/);assert.match(c.element('content').innerHTML,/&lt;b&gt;Template/);assert.ok(!c.element('content').innerHTML.includes('<img src=x>'));});

test('saves do not close a draft modified while the network request was in flight',async()=>{const c=client();let release;c.ctx.apiPost=async path=>{if(path==='works')await new Promise(resolve=>{release=resolve;});};const saving=c.run('saveRequestsNow()');c.run('editGeneration++;draftActive=true');release();assert.equal(await saving,false);assert.equal(c.run('hasPendingChanges'),true);assert.equal(c.run('draftActive'),true);});

test('annual report embeds performance, keeps selected tab, navigates years and exports the same period',()=>{
 const c=client('2026-12-31T05:00:00Z');c.run("TEAM.push({...TEAM[0],id:2,name:'Audit Member',role:'member'});works[0].pic=2;works[0].assignees=[2];selectedAuditTab='annual';reportYearOffset=2026-Number(todayStr.slice(0,4));works.push({...works[0],id:11,title:'Year end',status:'done',completedDate:'2026-12-31',deadline:'2026-12-31'});works.push({...works[0],id:12,title:'Next year',startDate:'2027-01-01',status:'done',createdAt:'2027-01-01',completedDate:'2027-01-01'});renderAudit()");
 const html=c.element('content').innerHTML;
 assert.match(html,/Annual Report/);assert.match(html,/Member Performance · 2026/);assert.match(html,/Completed this year \(1\)/);
 assert.equal((html.match(/role="tab" /g)||[]).length,4);assert.ok(!html.includes("switchAuditTab('member'"));
 assert.ok(!c.run('renderMemberPerf()').includes('Audit Admin'));assert.match(html,/Audit Member/);assert.match(html,/2 assigned/);
 let output;c.ctx.exportToPDF=(title,body)=>{output={title,body};};c.run('exportAnnualReportPDF()');assert.match(output.title,/2026/);assert.match(output.body,/Member performance in this year/);assert.match(output.body,/Year end/);assert.ok(!output.body.includes('Next year'));
 c.run('moveReportYear(-1)');assert.match(c.element('audit-content').innerHTML,/Member Performance · 2025/);assert.match(c.element('audit-content').innerHTML,/Completed this year \(0\)/);
 c.run('exportAnnualReportPDF()');assert.match(output.title,/2025/);c.run('renderAudit()');assert.match(c.element('content').innerHTML,/Member Performance · 2025/);
 c.run('exportMonthlyReportPDF()');assert.ok(!output.body.includes('Member performance'));
});


test('pagination uses ten rows, clamps pages and keeps users and statuses isolated',()=>{
 const c=client();c.run("works=Array.from({length:24},(_,i)=>({...works[0],id:100+i,title:'Work '+i}));clearActiveWorkFilters();");
 for(const status of ['ongoing','upcoming','done']){
  c.ctx.auditStatus=status;
  const first=c.run('pagedWorkListHtml(works,auditStatus)');assert.equal((first.match(/class="work-item /g)||[]).length,10);assert.match(first,/Showing 1–10 of 24/);
  c.run('workListPages.set(workPageKey(auditStatus),3)');const last=c.run('pagedWorkListHtml(works,auditStatus)');assert.equal((last.match(/class="work-item /g)||[]).length,4);assert.match(last,/Showing 21–24 of 24/);
  assert.match(c.run('pagedWorkListHtml(works.slice(0,4),auditStatus)'),/Page 1 of 1/);
 }
 c.run("workListPages.set(workPageKey('ongoing'),3);_fSearch('Work 2','ongoing')");assert.equal(c.run("workListPages.get(workPageKey('ongoing'))"),1);
 c.run("currentUser={...currentUser,id:2}");assert.match(c.run("pagedWorkListHtml(works,'ongoing')"),/Page 1 of 3/);
});
test('monthly report and export preserve historical completion flags and current completions',()=>{
 const c=client('2026-10-05T05:00:00Z');c.run("works.push({...works[0],id:11,title:'October completion',startDate:'2026-09-28',status:'done',completedDate:'2026-10-03'});reportMonthOffset=-1;");
 const september=c.run('renderMonthlyAudit()');assert.match(september,/Completed Oct 3, 2026/);assert.match(september,/100% progress/);
 let output;c.ctx.exportToPDF=(title,body)=>{output={title,body};};c.run('exportMonthlyReportPDF()');assert.match(output.body,/Completed Oct 3, 2026/);assert.match(output.body,/100%/);
 c.run('reportMonthOffset=0');assert.match(c.run('renderMonthlyAudit()'),/Completed Work \(1\)/);c.run('exportMonthlyReportPDF()');assert.match(output.body,/Completed work \(1\)/i);assert.match(output.body,/October completion/);
});
test('team hides administrators and uses member, manager, board order',()=>{
 const c=client();c.run("TEAM.push({...TEAM[0],id:2,name:'Manager',role:'manager'},{...TEAM[0],id:3,name:'Board',role:'board'},{...TEAM[0],id:4,name:'Member',role:'member'});renderTeam()");
 assert.equal(c.run("membersInRoleOrder().map(m=>m.role).join(',')"),'admin,member,manager,board');const html=c.element('content').innerHTML;assert.ok(!html.includes('Audit Admin'));assert.ok(html.indexOf('Member')<html.indexOf('Manager'));assert.ok(html.indexOf('Manager')<html.indexOf('Board'));
});
test('unchanged workspace revision skips full workspace reads',async()=>{
 const c=client();c.run("workspaceRevisionSeen='unchanged';workspaceFullSyncAt=Date.now();workspaceSyncDay=TeamFlowDomain.dateKeyInZone();");const paths=[];c.ctx.apiGet=async path=>{paths.push(path);return {revision:'unchanged'};};await c.run('backgroundSync({force:true})');assert.deepEqual(paths,['works?check=1']);
});
test('meetings paginate ten at a time on each tab, and the page stays in range',()=>{
 const c=client();
 c.run(`meetings=Array.from({length:23},(_,i)=>({id:i+1,title:'Upcoming '+i,date:'2099-01-'+String(i%28+1).padStart(2,'0'),startTime:'10:00',durationMinutes:60,startsAt:'2099-01-'+String(i%28+1).padStart(2,'0')+'T03:00:00.000Z',attendees:[],organizerName:'A',status:'scheduled'})).concat(Array.from({length:12},(_,i)=>({id:100+i,title:'Past '+i,date:'2001-01-'+String(i+1).padStart(2,'0'),startTime:'10:00',durationMinutes:60,startsAt:'2001-01-'+String(i+1).padStart(2,'0')+'T03:00:00.000Z',attendees:[],organizerName:'A',status:'scheduled'})));renderMeetingsList();`);
 c.element('meetings-list').scrollIntoView=()=>{};
 const html=()=>c.element('meetings-list').innerHTML,count=()=>(html().match(/focus-row/g)||[]).length;
 assert.equal(count(),10);assert.match(html(),/Showing 1–10 of 23/);assert.match(html(),/Page 1 of 3/);assert.ok(html().includes('Upcoming 0'));
 c.run('changeMeetingPage(3)');assert.equal(count(),3);assert.match(html(),/Showing 21–23 of 23/);
 c.run("meetingsTab='past';renderMeetingsList()");assert.match(html(),/Showing 1–10 of 12/);assert.ok(html().includes('Past 11'));
 c.run("meetingsTab='upcoming';renderMeetingsList()");assert.match(html(),/Page 3 of 3/);
 c.run('meetings=meetings.slice(0,5);renderMeetingsList()');assert.match(html(),/Showing 1–5 of 5/);assert.match(html(),/Page 1 of 1/);
});

test('help tutorials cover every section, point at real pages, and only show what the role can do',()=>{
 const c=client();
 const sections=c.run("HELP_TUTORIALS");
 const source=require('node:fs').readFileSync('public/js/ui.js','utf8');
 const helpBlock=source.slice(source.indexOf('function renderHelp'),source.indexOf("sections.forEach",source.indexOf('function renderHelp')));
 const titles=[...helpBlock.matchAll(/title:'([^']+)',items/g)].map(match=>match[1].replace(/&amp;/g,'&'));
 assert.ok(titles.length>=10);
 for(const title of titles)assert.ok(sections[title]?.length,'no tutorials for '+title);
 const core=require('node:fs').readFileSync('public/js/core.js','utf8');
 for(const [title,tutorials] of Object.entries(sections)){
  assert.ok(titles.includes(title),'tutorials for unknown section '+title);
  for(const tutorial of tutorials){
   assert.ok(tutorial.steps.length>=2,tutorial.title);
   if(tutorial.page)assert.ok(core.includes(tutorial.page+':render')||core.includes(`'${tutorial.page}':render`),'unknown page '+tutorial.page);
  }
 }
 const shown=role=>{c.run(`currentUser={...currentUser,role:'${role}'}`);return c.run("Object.keys(HELP_TUTORIALS).map(helpTutorialsHtml).join('')");};
 assert.ok(shown('admin').includes('Add or change a team member'));
 assert.ok(!shown('member').includes('Add or change a team member'));
 assert.ok(shown('member').includes('Schedule a meeting'));
 const board=shown('board');assert.ok(!board.includes('Schedule a meeting'));assert.ok(!board.includes('Create a work item'));assert.ok(board.includes('See team performance'));
 assert.ok(!shown('member').includes('See team performance'));
});

test('template icon colours come only from the fixed set, defaulting to the first',()=>{
 const c=client();
 const first=c.run('AVATAR_COLORS[0].hex'),teal=c.run('AVATAR_COLORS[1].hex');
 assert.equal(c.run('templateIconColor({})'),first);
 assert.equal(c.run(`templateIconColor({iconColor:'${teal}'})`),teal);
 assert.equal(c.run(`templateIconColor({iconColor:'red;background:url(x)'})`),first);
 assert.ok(c.run(`templateIconHtml({iconKey:'shield',iconColor:'${teal}'})`).includes(`color:${teal}`));
 assert.ok(!c.run(`templateIconHtml({iconColor:'"><img src=x>'})`).includes('<img'));
});

test('cancelling a form or erasing a note leaves no stale draft, while real edits still count',async()=>{
 const c=client();c.element('modal-overlay').style.display='flex';
 c.run('draftActive=true');await c.run('openWorkDetail(10)');assert.equal(c.run('draftActive'),false);
 c.run('draftActive=true;hasPendingChanges=true');await c.run('openWorkDetail(10)');assert.equal(c.run('draftActive'),true);c.run('hasPendingChanges=false;draftActive=false');
 c.run("trackDraftInput({target:{id:'new-note-text',value:'Check the IBNR'}})");assert.equal(c.run('draftActive'),true);
 c.run("trackDraftInput({target:{id:'new-note-text',value:'  '}})");assert.equal(c.run('draftActive'),false);
 c.run("trackDraftInput({target:{id:'file-name',value:''}})");assert.equal(c.run('draftActive'),true);
});

test('calendar titles and work descriptions are cut between words, and mid-word only when the first word alone does not fit',()=>{
 const c=client();c.ctx.fitsCharacters=20;
 const cut=title=>c.run(`textAtWord(${JSON.stringify(title)},text=>text.length<=fitsCharacters)`);
 assert.equal(cut('Valuation review'),'Valuation review');
 assert.equal(cut('Onerous contract assessment'),'Onerous contract…');
 assert.equal(cut('Quarterly close — Life portfolio'),'Quarterly close…');
 assert.equal(cut('Actuarialvaluations assessment'),'Actuarialvaluations…');
 assert.equal(cut('Review reserves.\nThen sign off'),'Review reserves…');
 assert.equal(cut('Actuarialvaluationsss assessment'),'Actuarialvaluationsss assessment');
});
