'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const domain = require('../public/js/domain');

test('Bangkok date and Monday-Sunday week boundaries are stable across UTC day changes', () => {
  assert.equal(domain.dateKeyInZone(new Date('2026-09-28T17:30:00.000Z')), '2026-09-29');
  assert.deepEqual(domain.weekRange('2026-09-29'), { start: '2026-09-28', end: '2026-10-04' });
  assert.deepEqual(domain.weekRange('2026-10-04'), { start: '2026-09-28', end: '2026-10-04' });
  assert.deepEqual(domain.weekRange('2026-10-05'), { start: '2026-10-05', end: '2026-10-11' });
});

test('month navigation and report periods handle year boundaries and leap years', () => {
  assert.deepEqual(domain.monthRange(2024, 1), { start: '2024-02-01', end: '2024-02-29' });
  assert.deepEqual(domain.shiftMonth(2026, 0, -1), { year: 2025, month: 11 });
  assert.deepEqual(domain.shiftMonth(2026, 11, 1), { year: 2027, month: 0 });
});

test('report filters use completion date and include monthly schedule overlap', () => {
  const week = { start: '2026-09-28', end: '2026-10-04' };
  assert.equal(domain.reportCompletion({ status: 'done', completedDate: '2026-10-04' }, week), true);
  assert.equal(domain.reportCompletion({ status: 'done', completedDate: '2026-10-05' }, week), false);
  const month = domain.monthRange(2026, 8);
  assert.equal(domain.reportInMonth({ status: 'ongoing', startDate: '2026-08-30', deadline: '2026-09-03' }, month), true);
  assert.equal(domain.reportInMonth({ status: 'done', completedDate: '2026-08-31', createdAt: '2026-08-01' }, month), false);
  assert.equal(domain.reportInMonth({ status: 'done', completedDate: '2026-09-30' }, month), true);
});

test('ongoing reports include overdue carryover and exclude work starting after the period', () => {
  const week = domain.weekRange('2026-10-01');
  const month = domain.monthRange(2026, 9);
  const overdue = { status: 'ongoing', startDate: '2026-09-10', deadline: '2026-09-20' };
  assert.equal(domain.reportOngoing(overdue, week), true);
  assert.equal(domain.reportInMonth(overdue, month), true);
  assert.equal(domain.reportOngoing({ status: 'ongoing', startDate: week.end }, week), true);
  assert.equal(domain.reportOngoing({ status: 'ongoing', startDate: '2026-10-05' }, week), false);
  assert.equal(domain.reportInMonth({ status: 'ongoing', startDate: '2026-11-01' }, month), false);
  assert.equal(domain.reportOngoing({ status: 'ongoing', createdAt: '2026-10-05T01:00:00Z' }, week), false);
  assert.equal(domain.reportOngoing({ status: 'ongoing', startDate: '2026-09-01' }, week), true);
  assert.equal(domain.reportOngoing({ status: 'ongoing' }, week), true);
  assert.equal(domain.reportOngoing({ status: 'done', startDate: week.start }, week), false);
  assert.equal(domain.reportOngoing({ status: 'upcoming', startDate: week.start }, week), false);
});

test('estimated effort is distributed by scheduled weekdays across Monday weeks', () => {
  const distribution = domain.allocateEffortByWeek({ startDate: '2026-09-30', deadline: '2026-10-06', estimatedHours: 14 });
  assert.deepEqual(Object.keys(distribution), ['2026-09-28', '2026-10-05']);
  assert.equal(distribution['2026-09-28'], 8.4);
  assert.equal(distribution['2026-10-05'], 5.6);
  assert.deepEqual(domain.allocateEffortByWeek({ startDate: '2026-10-05', deadline: '2026-10-01', estimatedHours: 10 }), {});
});

test('weighted capacity gives manager reviewers 40% and PICs 150% of a member share', () => {
  const team = [{ id: 1, role: 'manager' }, { id: 2, role: 'member' }, { id: 3, role: 'member' }];
  const allocation = domain.allocateEffortByMember({ estimatedHours: 29, assignees: [1, 2, 3], pic: 2 }, team);
  assert.ok(Math.abs(allocation[1] - 4) < 1e-10);
  assert.ok(Math.abs(allocation[2] - 15) < 1e-10);
  assert.ok(Math.abs(allocation[3] - 10) < 1e-10);
  assert.ok(Math.abs(Object.values(allocation).reduce((a, b) => a + b, 0) - 29) < 1e-10);
  assert.deepEqual(domain.allocateEffortByMember({ estimatedHours: 35, assignees: [1, 2, 3], pic: 1 }, team), { 1: 15, 2: 10, 3: 10 });
});

test('capacity includes an unlisted PIC once and ignores unknown or board participants', () => {
  const team = [{ id: 1, role: 'manager' }, { id: 2, role: 'member' }, { id: 3, role: 'board' }];
  const work = { estimatedHours: 25, assignees: [2, '2', 3, 99], pic: '1' };
  assert.deepEqual(domain.allocateEffortByMember(work, team), { 1: 15, 2: 10 });
  assert.deepEqual(domain.allocateEffortByMember(work, team, 10), { 1: 6, 2: 4 });
  assert.deepEqual(domain.allocateEffortByMember(work, team, 0), {});
  assert.deepEqual(domain.allocateEffortByMember(work, team, -1), {});
  assert.deepEqual(domain.allocateEffortByMember(work, team, Infinity), {});
  assert.deepEqual(domain.allocateEffortByMember({ estimatedHours: 10, assignees: [] }, team), {});
});

test('weekend-only work has no capacity and Oct 3–7 splits across weekdays only',()=>{
  assert.deepEqual(domain.allocateEffortByWeek({startDate:'2026-10-03',deadline:'2026-10-04',estimatedHours:10}),{});
  assert.deepEqual(domain.allocateEffortByWeek({startDate:'2026-10-03',deadline:'2026-10-07',estimatedHours:10}),{'2026-10-05':10});
});

test('annual ranges include leap day and exclude adjacent year completions',()=>{
 const range=domain.yearRange(2024);
 assert.deepEqual(range,{start:'2024-01-01',end:'2024-12-31'});
 for(const date of ['2024-01-01','2024-02-29','2024-12-31'])assert.equal(domain.reportCompletion({status:'done',completedDate:date},range),true);
 for(const date of ['2023-12-31','2025-01-01'])assert.equal(domain.reportCompletion({status:'done',completedDate:date},range),false);
});
