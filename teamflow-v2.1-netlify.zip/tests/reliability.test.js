'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {MemoryStore,memberRecord,sessionEvent}=require('./helpers');
const records=require('../netlify/functions/lib/records');
const works=require('../netlify/functions/works')._test;
const {checkedFetch}=require('../netlify/functions/lib/store');
const person=(role,id)=>({id,role,name:role,email:role+'@example.test',username:role,active:true,passwordHash:'fixture',authVersion:1});
test('simultaneous record updates have one winner and one conflict',async()=>{
 const store=new MemoryStore();await records.saveRecord('work',{id:1,title:'before'},0,store);
 const results=await Promise.allSettled([records.saveRecord('work',{id:1,title:'A'},1,store),records.saveRecord('work',{id:1,title:'B'},1,store)]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(results.find(r=>r.status==='rejected').reason.statusCode,409);
});
test('simultaneous creates cannot replace each other and deleted IDs cannot be resurrected',async()=>{
 const store=new MemoryStore();const results=await Promise.allSettled([records.saveRecord('work',{id:2,title:'A'},0,store),records.saveRecord('work',{id:2,title:'B'},0,store)]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);
 await records.deleteRecord('work',2,1,store);await assert.rejects(records.saveRecord('work',{id:2,title:'again'},0,store),e=>e.statusCode===409);
});
test('collections reject overlapping updates rather than dropping entries',async()=>{
 const store=new MemoryStore();const results=await Promise.allSettled([records.saveCollection(store,'feedbackItems',[{id:1}],1),records.saveCollection(store,'feedbackItems',[{id:2}],1)]);
 assert.equal(results.filter(r=>r.status==='fulfilled').length,1);assert.equal(results.find(r=>r.status==='rejected').reason.statusCode,409);
});
test('feedback retains its category and is shared with every authenticated role',async()=>{
 const users=['admin','manager','member','board'].map((role,i)=>person(role,i+1));const store=new MemoryStore(Object.fromEntries(users.map(u=>['v2:member:'+u.id,memberRecord(u)])));
 const event=await sessionEvent(users[2],store,'POST','/api/works');event.body=JSON.stringify({operation:'collection',name:'feedbackItems',items:[{id:20,authorId:3,author:'spoofed',category:'Bug Report',text:'<b>literal feedback</b>',status:'done'}],expectedVersion:1});
 assert.equal((await works.handle(event,store)).statusCode,200);
 for(const user of users){const payload=JSON.parse((await works.handle(await sessionEvent(user,store,'GET','/api/works'),store)).body);assert.equal(payload.feedbackItems[0].category,'Bug Report');assert.equal(payload.feedbackItems[0].author,'member');assert.equal(payload.feedbackItems[0].status,'open');}
 const boardEvent=await sessionEvent(users[3],store,'POST','/api/works');boardEvent.body=event.body;assert.equal((await works.handle(boardEvent,store)).statusCode,403);
});
test('storage HTTP failures do not masquerade as successful conditional writes',async()=>{
 const previous=global.fetch;try{global.fetch=async()=>({ok:false,status:500});await assert.rejects(checkedFetch('https://example.test'),e=>e.statusCode===503);global.fetch=async()=>({ok:false,status:412});assert.equal((await checkedFetch('https://example.test')).status,412);}finally{global.fetch=previous;}
});

test('member PIC resolves membership requests, unrelated members cannot, retry is safe after partial write',async()=>{
 const pic=person('member',1),applicant=person('member',2),other=person('member',3);
 const store=new MemoryStore(Object.fromEntries([pic,applicant,other].map(u=>['v2:member:'+u.id,memberRecord(u)])));
 await records.saveRecord('work',{id:10,title:'Valuation',status:'ongoing',pic:1,assignees:[1]},0,store);
 await records.saveCollection(store,'joinRequests',[{id:20,workId:10,userId:2,type:'join',status:'pending',date:'2026-10-01'}],1);
 const denied=await sessionEvent(other,store,'POST','/api/works');denied.body=JSON.stringify({operation:'resolve-request',id:20,status:'approved',expectedVersion:2});assert.equal((await works.handle(denied,store)).statusCode,403);
 const event=await sessionEvent(pic,store,'POST','/api/works');event.body=denied.body;
 const originalSet=store.set.bind(store);let fail=true;store.set=async(key,value,options)=>{if(key==='v2:collection:joinRequests'&&fail){fail=false;throw new Error('Simulated network interruption');}return originalSet(key,value,options);};
 await assert.rejects(works.handle(event,store));assert.deepEqual((await records.currentRecord('work',10,store)).assignees,[1,2]);
 const response=await works.handle(event,store);assert.equal(response.statusCode,200);assert.equal(JSON.parse(response.body).joinRequests[0].status,'approved');assert.deepEqual((await records.currentRecord('work',10,store)).assignees,[1,2]);
 assert.equal((await works.handle(event,store)).statusCode,409);
});
test('concurrent reset completion consumes the link only once',async()=>{
 const auth=require('../netlify/functions/auth')._test,{sha256}=require('../netlify/functions/lib/auth-core');
 const user=person('member',1),store=new MemoryStore({'v2:member:1':memberRecord(user)}),token='audit-reset-token';
 await store.set('auth:reset:'+sha256(token),JSON.stringify({userId:1,expiresAt:Date.now()+60000}));
 const event={httpMethod:'POST',path:'/api/auth/reset/complete',headers:{},body:JSON.stringify({token,password:'StrongAuditPassword123!'})};
 const responses=await Promise.allSettled([auth.handle(event,store),auth.handle({...event,headers:{'x-nf-client-connection-ip':'different'}},store)]);
 assert.equal(responses.filter(r=>r.status==='fulfilled'&&r.value.statusCode===200).length,1);
 assert.equal((await records.getMember(1,store)).authVersion,2);
});
test('missing write endpoints fail rather than claiming a successful save',async()=>{const previous=global.fetch;try{global.fetch=async()=>({ok:false,status:404});await assert.rejects(checkedFetch('https://example.test',{method:'PUT'}),e=>e.statusCode===503);assert.equal((await checkedFetch('https://example.test',{method:'GET'})).status,404);}finally{global.fetch=previous;}});

test('completed work supports phase four and recurring completion is idempotent for assigned members',async()=>{
 const member=person('member',1),board=person('board',2),store=new MemoryStore({'v2:member:1':memberRecord(member),'v2:member:2':memberRecord(board)});
 await records.saveRecord('work',{id:10,title:'Month end',status:'ongoing',phase:3,pic:1,assignees:[1,2],deadline:'2026-01-31',startDate:'2026-01-29',recurrence:'monthly',workType:'adhoc',estimatedHours:12,phaseChecks:{Planning:[true],Finalize:[false]},phaseTasks:{Planning:['A'],Finalize:['B']}},0,store);
 const event=await sessionEvent(member,store,'POST','/api/works');event.body=JSON.stringify({operation:'complete',id:10,expectedVersion:1});
 const denied=await sessionEvent(board,store,'POST','/api/works');denied.body=event.body;assert.equal((await works.handle(denied,store)).statusCode,403);
 const result=JSON.parse((await works.handle(event,store)).body);assert.equal(result.work.phase,4);assert.equal(result.work.status,'done');assert.equal(result.nextWork.deadline,'2026-02-28');assert.equal(result.nextWork.startDate,'2026-02-26');assert.equal(result.nextWork.estimatedHours,12);assert.equal(result.nextWork.workType,'adhoc');
 const retry=JSON.parse((await works.handle(event,store)).body);assert.equal(retry.nextWork.id,result.nextWork.id);assert.equal((await records.listWorks(store)).data.length,2);
 assert.doesNotThrow(()=>works.normalizeWork(result.work));
});

test('reminders load, persist preferences, and share read state between sessions',async()=>{
 const notifications=require('../netlify/functions/notifications')._test,{todayInZone}=require('../netlify/functions/digest');
 const member=person('member',1),store=new MemoryStore({'v2:member:1':memberRecord(member)});
 await records.saveRecord('work',{id:10,title:'Due today',status:'ongoing',deadline:todayInZone(),assignees:[1]},0,store);
 const event=await sessionEvent(member,store,'GET','/api/notifications');let r=JSON.parse((await notifications.handle(event,store)).body);assert.equal(r.notifications.length,1);assert.equal(r.unreadCount,1);
 const read={...event,httpMethod:'POST',body:JSON.stringify({operation:'read',ids:[r.notifications[0].id]})};assert.equal((await notifications.handle(read,store)).statusCode,200);
 const another=await sessionEvent(member,store,'GET','/api/notifications');r=JSON.parse((await notifications.handle(another,store)).body);assert.equal(r.unreadCount,0);
 const preferences={...event,httpMethod:'POST',body:JSON.stringify({operation:'preferences',reminderDays:[1,7]})};assert.equal((await notifications.handle(preferences,store)).statusCode,200);r=JSON.parse((await notifications.handle(another,store)).body);assert.deepEqual(r.preferences.reminderDays,[7,1]);
});
