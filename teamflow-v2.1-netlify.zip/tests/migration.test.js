'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { MemoryStore } = require('./helpers');
const { migrateLegacyData } = require('../scripts/migration-core');

function decryptBackup(encoded, key) {
  const backup = JSON.parse(encoded);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(backup.iv, 'base64'));
  decipher.setAuthTag(Buffer.from(backup.tag, 'base64'));
  return JSON.parse(Buffer.concat([
    decipher.update(Buffer.from(backup.ciphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8'));
}

test('migration rehearsal backs up fixtures, resets credentials, verifies v2 records, then clears legacy keys', async () => {
  const key = crypto.randomBytes(32);
  const rawTeam = JSON.stringify([
    { id: 7, name: 'Fictional Admin', email: 'admin@example.test', role: 'admin', password: 'legacy-secret' },
    { id: 8, name: 'Fictional Member', email: 'member@example.test', role: 'member', passwordHash: 'old-hash' },
  ]);
  const rawWorks = JSON.stringify({ data: [{ id: 30, title: 'Fictional reserving review', estimatedHours: 6 }], joinRequests: [], templates: [{ id: 1, name: 'Quarter-end' }], feedbackItems: [] });
  const store = new MemoryStore({
    team: rawTeam,
    works: rawWorks,
    'auth:session:old-session': 'session-data',
    'auth:reset:old-reset': 'reset-data',
  });
  let encrypted = '';
  const result = await migrateLegacyData(store, {
    apply: true,
    backupKey: key.toString('hex'),
    now: () => new Date('2026-09-29T03:00:00.000Z'),
    writeBackup: async value => { encrypted = value; return 'fixture-backup.json.enc'; },
  });

  assert.deepEqual(result.counts, { members: 2, works: 1, joinRequests: 0, templates: 1, feedbackItems: 0 });
  assert.equal(result.applied, true);
  assert.equal(decryptBackup(encrypted, key).rawTeam, rawTeam);
  assert.equal(encrypted.includes('legacy-secret'), false);
  const admin = JSON.parse(await store.get('v2:member:7')).data;
  assert.equal(admin.password, undefined);
  assert.equal(admin.passwordHash, null);
  assert.equal(admin.mustResetPassword, true);
  assert.equal(admin.username, 'admin@example.test');
  assert.equal(JSON.parse(await store.get('v2:work:30')).data.estimatedHours, 6);
  assert.equal(JSON.parse(await store.get('v2:collection:templates')).items[0].name, 'Quarter-end');
  assert.equal(await store.get('team'), null);
  assert.equal(await store.get('works'), null);
  assert.equal(await store.get('auth:session:old-session'), null);
  assert.equal(await store.get('auth:reset:old-reset'), null);
});

test('dry-run migration rehearsal reports fixture counts without changing the store', async () => {
  const store = new MemoryStore({ team: '[{"id":1}]', works: '{"data":[{"id":2}]}' });
  const before = new Map(store.values);
  const result = await migrateLegacyData(store);
  assert.deepEqual(result.counts, { members: 1, works: 1, joinRequests: 0, templates: 0, feedbackItems: 0 });
  assert.equal(result.applied, false);
  assert.deepEqual(store.values, before);
});
