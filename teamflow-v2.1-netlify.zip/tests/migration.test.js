'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { MemoryStore } = require('./helpers');
const { migrateLegacyData, finalizeMigration } = require('../scripts/migration-core');
const { passwordHash, verifyPassword } = require('../netlify/functions/lib/auth-core');

function decryptBackup(encoded, key) {
  const backup = JSON.parse(encoded);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(backup.iv, 'base64'));
  decipher.setAuthTag(Buffer.from(backup.tag, 'base64'));
  return JSON.parse(Buffer.concat([
    decipher.update(Buffer.from(backup.ciphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8'));
}

test('migration rehearsal backs up fixtures, preserves credentials, verifies records, then finalizes legacy keys', async () => {
  const key = crypto.randomBytes(32);
  const existingHash = await passwordHash('fixture-password');
  const rawTeam = JSON.stringify([
    { id: 0, name: 'Fictional Admin', email: 'admin@example.test', role: 'admin', password: 'legacy-secret' },
    { id: 8, name: 'Fictional Member', email: 'member@example.test', role: 'member', passwordHash: existingHash },
  ]);
  const rawWorks = JSON.stringify({ data: [{ id: 30, title: 'Fictional reserving review', estimatedHours: 6, createdBy: 0 }], joinRequests: [], templates: [{ id: 1, name: 'Quarter-end' }], feedbackItems: [] });
  const store = new MemoryStore({
    team: rawTeam,
    works: rawWorks,
    'auth:session:old-session': 'session-data',
    'auth:reset:old-reset': 'reset-data',
  });
  let encrypted = '';
  const inspected = await migrateLegacyData(store);
  const result = await migrateLegacyData(store, {
    apply: true,
    maintenanceConfirmed: true,
    expectedSourceHash: inspected.sourceHash,
    backupKey: key.toString('hex'),
    now: () => new Date('2026-09-29T03:00:00.000Z'),
    writeBackup: async value => { encrypted = value; return 'fixture-backup.json.enc'; },
  });

  assert.deepEqual(result.counts, { members: 2, works: 1, joinRequests: 0, templates: 1, feedbackItems: 0 });
  assert.equal(result.applied, true);
  const snapshot = decryptBackup(encrypted, key);
  assert.equal(Buffer.from(snapshot.entries.find(row => row.key === 'team').data, 'base64').toString('utf8'), rawTeam);
  assert.equal(encrypted.includes('legacy-secret'), false);
  const admin = JSON.parse(await store.get('v2:member:1')).data;
  assert.equal(admin.password, undefined);
  assert.equal(await verifyPassword('legacy-secret', admin.passwordHash), true);
  assert.equal(admin.mustResetPassword, false);
  assert.equal(admin.username, 'admin@example.test');
  assert.equal(JSON.parse(await store.get('v2:member:8')).data.passwordHash, existingHash);
  assert.equal(JSON.parse(await store.get('v2:work:30')).data.createdBy, 1);
  assert.equal(JSON.parse(await store.get('v2:work:30')).data.estimatedHours, 6);
  assert.equal(JSON.parse(await store.get('v2:collection:templates')).items[0].name, 'Quarter-end');
  assert.equal(await store.get('team'), rawTeam);
  assert.equal(await store.get('works'), rawWorks);
  await finalizeMigration(store, snapshot);
  assert.equal(await store.get('team'), null);
  assert.equal(await store.get('works'), null);
  assert.equal(await store.get('auth:session:old-session'), null);
  assert.equal(await store.get('auth:reset:old-reset'), null);
});

test('dry-run migration rehearsal reports fixture counts without changing the store', async () => {
  const store = new MemoryStore({ team: JSON.stringify([{ id: 1, name: 'Fixture Admin', username: 'admin', role: 'admin', password: 'fixture-password' }]), works: JSON.stringify({ data: [{ id: 2, title: 'Fixture work' }] }) });
  const before = new Map(store.values);
  const result = await migrateLegacyData(store);
  assert.deepEqual(result.counts, { members: 1, works: 1, joinRequests: 0, templates: 0, feedbackItems: 0 });
  assert.equal(result.applied, false);
  assert.deepEqual(store.values, before);
});
