'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const {MemoryStore,memberRecord,sessionEvent}=require('./helpers');
const records=require('../netlify/functions/lib/records');
const works=require('../netlify/functions/works')._test;
const team=require('../netlify/functions/team')._test;
const notifications=require('../netlify/functions/notifications')._test;
const {todayInZone}=require('../netlify/functions/digest');
const {mergeCollectionChanges}=require('../public/js/domain');

class ConcurrentStore extends MemoryStore{
  async get(...args){await new Promise(resolve=>setImmediate(resolve));return super.get(...args);}
  async getWithMetadata(...args){await new Promise(resolve=>setImmediate(resolve));return super.getWithMetadata(...args);}
  async set(...args){await new Promise(resolve=>setImmediate(resolve));return super.set(...args);}
  async list(...args){await new Promise(resolve=>setImmediate(resolve));return super.list(...args);}
}
const person=(id,role='member')=>({id,role,name:`Tester ${id}`,email:`tester${id}@example.test`,username:`tester${id}`,active:true,passwordHash:'fixture',authVersion:1,weeklyCapacityHours:40});
async function fixture(role='member'){
  const users=Array.from({length:10},(_,i)=>person(i+1,role)),admin=person(100,'admin');
  const store=new ConcurrentStore(Object.fromEntries([...users,admin].map(user=>[`v2:member:${user.id}`,memberRecord(user)])));
  const events=await Promise.all(users.map(user=>sessionEvent(user,store,'POST','/api/works')));
  return{users,admin,store,events};
}
async function invoke(handler,event,body,store){
  try{return await handler({...event,body:JSON.stringify(body)},store);}
  catch(error){return{statusCode:error.statusCode||500,body:JSON.stringify({error:error.message})};}
}
function work(id,pic=100,assignees=[100]){
  return{id,title:`Reserve review ${id}`,desc:'Concurrency fixture',status:'ongoing',phase:1,priority:'Medium',pic,assignees,workType:'regular',estimatedHours:10,startDate:todayInZone(),deadline:todayInZone(),tags:[],files:[],notes:[],phaseTasks:{Planning:['Scope'],Executing:['Calculate'],Review:['Review'],Finalize:['Archive']},phaseChecks:{Planning:[true],Executing:[false],Review:[false],Finalize:[false]}};
}

test('10 users submit feedback simultaneously; all entries survive and all roles can read them',async()=>{
  const{users,store,events}=await fixture();
  const responses=await Promise.all(events.map((event,i)=>invoke(works.handle,event,{operation:'collection',name:'feedbackItems',baseItems:[],expectedVersion:1,items:[{id:1000+i,authorId:users[i].id,category:'Suggestion',text:`Feedback ${i}`,status:'open'}]},store)));
  assert.deepEqual(responses.map(r=>r.statusCode),Array(10).fill(200));
  const saved=await records.collection(store,'feedbackItems');assert.equal(saved.items.length,10);
  for(const role of ['admin','manager','member','board']){
    const user=person(200+['admin','manager','member','board'].indexOf(role),role);await records.saveRecord('member',user,0,store);
    const response=await works.handle(await sessionEvent(user,store,'GET','/api/works'),store);
    assert.equal(JSON.parse(response.body).feedbackItems.length,10);
  }
});

test('10 managers create templates simultaneously without deleting other templates',async()=>{
  const{store,events}=await fixture('manager');
  const responses=await Promise.all(events.map((event,i)=>invoke(works.handle,event,{operation:'collection',name:'templates',baseItems:[],expectedVersion:1,items:[{id:1000+i,name:`Template ${i}`}]},store)));
  assert.deepEqual(responses.map(r=>r.statusCode),Array(10).fill(200));assert.equal((await records.collection(store,'templates')).items.length,10);
});

test('10 simultaneous join requests survive; duplicate pending requests are rejected',async()=>{
  const{store,events}=await fixture();await records.saveRecord('work',work(500),0,store);
  const items=events.map((event,i)=>({id:1000+i,userId:i+1,workId:500,type:'join',status:'pending',date:todayInZone()}));
  const responses=await Promise.all(events.map((event,i)=>invoke(works.handle,event,{operation:'collection',name:'joinRequests',baseItems:[],expectedVersion:1,items:[items[i]]},store)));
  assert.deepEqual(responses.map(r=>r.statusCode),Array(10).fill(200));assert.equal((await records.collection(store,'joinRequests')).items.length,10);
  const current=await records.collection(store,'joinRequests');
  const duplicate=await invoke(works.handle,events[0],{operation:'collection',name:'joinRequests',baseItems:current.items,items:[...current.items,{...items[0],id:2000}],expectedVersion:current.version},store);
  assert.equal(duplicate.statusCode,409);
});

test('10 simultaneous leave requests and approvals on separate work items preserve every resolution',async()=>{
  const{store,events,admin}=await fixture();
  await Promise.all(events.map((event,i)=>records.saveRecord('work',work(500+i,100,[100,i+1]),0,store)));
  const items=events.map((event,i)=>({id:1000+i,userId:i+1,workId:500+i,type:'leave',status:'pending',date:todayInZone()}));
  const submitted=await Promise.all(events.map((event,i)=>invoke(works.handle,event,{operation:'collection',name:'joinRequests',baseItems:[],expectedVersion:1,items:[items[i]]},store)));
  assert.deepEqual(submitted.map(r=>r.statusCode),Array(10).fill(200));
  const current=await records.collection(store,'joinRequests'),adminEvent=await sessionEvent(admin,store,'POST','/api/works');
  const approved=await Promise.all(items.map(item=>invoke(works.handle,adminEvent,{operation:'resolve-request',id:item.id,status:'approved',expectedVersion:current.version},store)));
  assert.deepEqual(approved.map(r=>r.statusCode),Array(10).fill(200));
  assert.equal((await records.collection(store,'joinRequests')).items.filter(item=>item.status==='approved').length,10);
  for(let i=0;i<10;i++)assert.deepEqual((await records.currentRecord('work',500+i,store)).assignees,[100]);
});

test('10 users change separate work items simultaneously',async()=>{
  const{store,events}=await fixture('manager');
  const initial=await Promise.all(events.map((event,i)=>records.saveRecord('work',work(500+i),0,store)));
  const responses=await Promise.all(events.map((event,i)=>invoke(works.handle,event,{operation:'upsert',expectedVersion:1,work:{...initial[i],title:`Updated ${i}`}},store)));
  assert.deepEqual(responses.map(r=>r.statusCode),Array(10).fill(200));
  assert.equal((await records.listWorks(store)).data.filter(item=>item.title.startsWith('Updated')).length,10);
});

test('10 conflicting edits to the same work have one winner and nine explicit conflicts',async()=>{
  const{store,events}=await fixture('manager'),initial=await records.saveRecord('work',work(500),0,store);
  const responses=await Promise.all(events.map((event,i)=>invoke(works.handle,event,{operation:'upsert',expectedVersion:1,work:{...initial,title:`User ${i}`}},store)));
  assert.equal(responses.filter(r=>r.statusCode===200).length,1);assert.equal(responses.filter(r=>r.statusCode===409).length,9);
  assert.equal((await records.currentRecord('work',500,store)).version,2);
});

test('10 independent profile edits preserve all accounts, passwords and individual reminder preferences',async()=>{
  const{users,store,events}=await fixture();
  const responses=await Promise.all(events.map((event,i)=>invoke(team.handle,event,{operation:'upsert',expectedVersion:1,member:{...users[i],passwordHash:undefined,name:`Updated Tester ${i}`,reminderPreferences:{reminderDays:[i]}}},store)));
  assert.deepEqual(responses.map(r=>r.statusCode),Array(10).fill(200));
  for(let i=0;i<10;i++){const member=await records.getMember(i+1,store);assert.equal(member.name,`Updated Tester ${i}`);assert.equal(member.passwordHash,'fixture');assert.deepEqual(member.reminderPreferences.reminderDays,[i]);}
});

test('concurrent account creation cannot claim duplicate usernames or remove both remaining administrators',async()=>{
  const store=new ConcurrentStore();await records.saveRecord('member',person(100,'admin'),0,store);
  const created=await Promise.allSettled(Array.from({length:10},(_,i)=>records.saveRecord('member',{...person(i+1),username:'same-user'},0,store)));
  assert.equal(created.filter(result=>result.status==='fulfilled').length,1);assert.ok(created.filter(result=>result.status==='rejected').every(result=>result.reason.statusCode===409));
  await records.saveRecord('member',person(101,'admin'),0,store);
  const removed=await Promise.allSettled([records.deleteRecord('member',100,1,store),records.deleteRecord('member',101,1,store)]);
  assert.equal(removed.filter(result=>result.status==='fulfilled').length,1);assert.equal((await records.listMembers(store)).filter(member=>member.role==='admin').length,1);
});

test('10 reminder read updates from sessions of one account merge without losing read IDs',async()=>{
  const{users,store}=await fixture();
  const sessions=await Promise.all(Array.from({length:10},()=>sessionEvent(users[0],store,'POST','/api/notifications')));
  const responses=await Promise.all(sessions.map((event,i)=>invoke(notifications.handle,event,{operation:'read',ids:[`notice-${i}`]},store)));
  assert.deepEqual(responses.map(r=>r.statusCode),Array(10).fill(200));assert.equal(JSON.parse(await store.get('v2:notification-state:1')).read.length,10);
});

test('10 reminder preference updates stay separate between users',async()=>{
  const{store,events}=await fixture();
  const responses=await Promise.all(events.map((event,i)=>invoke(notifications.handle,event,{operation:'preferences',reminderDays:[i]},store)));
  assert.deepEqual(responses.map(r=>r.statusCode),Array(10).fill(200));
  for(let i=0;i<10;i++)assert.deepEqual((await records.getMember(i+1,store)).reminderPreferences.reminderDays,[i]);
});

test('independent entry changes merge; competing changes to one entry remain conflicts',()=>{
  const base=[{id:1,status:'open'},{id:2,status:'open'}];
  assert.deepEqual(mergeCollectionChanges([{id:1,status:'done'},base[1]],base,[base[0],{id:2,status:'noted'}]),[{id:1,status:'done'},{id:2,status:'noted'}]);
  assert.throws(()=>mergeCollectionChanges([{id:1,status:'done'}],[base[0]],[{id:1,status:'noted'}]),error=>error.statusCode===409);
});

test('10 users sign in from the same office IP with independent sessions and logout',async()=>{
  const auth=require('../netlify/functions/auth')._test;
  const {passwordHash}=require('../netlify/functions/lib/auth-core');
  const hash=await passwordHash('ConcurrentOffice!2026');
  const users=Array.from({length:10},(_,i)=>({...person(i+1),passwordHash:hash}));
  const store=new ConcurrentStore(Object.fromEntries(users.map(user=>[`v2:member:${user.id}`,memberRecord(user)])));
  const event={httpMethod:'POST',path:'/api/auth/login',headers:{'x-nf-client-connection-ip':'192.0.2.10'}};
  const results=await Promise.all(users.map(user=>invoke(auth.handle,event,{identifier:user.email,password:'ConcurrentOffice!2026'},store)));
  assert.deepEqual(results.map(result=>result.statusCode),Array(10).fill(200));
  const cookies=results.map(result=>result.headers['Set-Cookie'].split(';')[0]);
  assert.equal(new Set(cookies).size,10);
  await auth.handle({...event,path:'/api/auth/logout',headers:{cookie:cookies[0]}},store);
  const sessions=await Promise.all(cookies.map(cookie=>invoke(auth.handle,{httpMethod:'GET',path:'/api/auth/me',headers:{cookie}},undefined,store)));
  assert.equal(sessions[0].statusCode,401);
  assert.deepEqual(sessions.slice(1).map(result=>result.statusCode),Array(9).fill(200));
});

test('concurrent rate limit retries preserve the configured attempt limit',async()=>{
  const {rateLimit}=require('../netlify/functions/auth')._test,store=new ConcurrentStore();
  const event={headers:{'x-nf-client-connection-ip':'192.0.2.11'}};
  const results=await Promise.allSettled(Array.from({length:10},()=>rateLimit(store,event,'failed-account',8)));
  assert.equal(results.filter(result=>result.status==='fulfilled').length,8);
  assert.equal(results.filter(result=>result.status==='rejected'&&result.reason.statusCode===429).length,2);
});
