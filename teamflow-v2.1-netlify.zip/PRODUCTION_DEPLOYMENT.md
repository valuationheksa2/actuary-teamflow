# Production deployment with existing accounts and work

This release preserves current account passwords by converting them to scrypt hashes. The original Admin ID `0` receives a new unused positive ID; known account references in work, notes, assignments, templates, requests, and feedback are updated. The migration retains all source fields except obsolete credential/version fields. Missing work type defaults to `regular` (the existing UI fallback); missing estimates default to zero. No email, account reset, or administrator bootstrap is needed.

Prepared tools have received static validation only. Run the local rehearsal before migration, then perform hosted sign-in and feature checks before reopening production to users. No production data was changed while preparing this release.

## 1. Prepare the latest release and tools

Use the latest `teamflow-v2.1-netlify.zip` and matching `prepare-release.cjs`. Keep all six normal GitHub upload files together. Do not upload backups or migration passphrases to GitHub.

The complete extracted release is already available locally at:

```powershell
Set-Location 'D:\GPT Projects\Actuary Team Flow\Netlify Upload\teamflow-v2.1'
npm ci --omit=dev
```

Use Node.js 22 or newer. These commands use the Netlify Blobs SDK directly; they do not launch Netlify CLI. If corporate security blocks Node/npm/PowerShell, stop and use an IT-approved execution environment. Do not disable security software or bypass script execution policy.

Find the PRODUCTION Project ID in Netlify: Project configuration > General > Project information. Obtain an existing authorized Netlify access token with access to that project. Do not use the staging Project ID.

Choose a backup recovery passphrase of at least 16 characters and save it in your password manager. This is separate from TeamFlow account passwords. The script prompts for secrets with hidden input, uses them only in its process, and restores previous environment variables when it finishes. It never displays account passwords or hashes. Keep the passphrase separate from the encrypted backups.

## 2. Read-only inspection

```powershell
.\scripts\run-migration.ps1 -Action Inspect
```

Supply the production Project ID, `https://actuaryteamflow.netlify.app`, and the hidden Netlify token when prompted. The script checks that the Project ID and address belong to the same Netlify project.

Compare counts with the latest production state. The previous review observed 8 users, 29 work items, 9 requests, 6 templates, and 1 feedback entry, but these may have changed. Save the printed `sourceHash` and `idRemap` with your migration notes. Read-only inspection does not change production records; password conversions are prepared in memory only.

If validation stops, resolve the reported compatibility issue before any deployment or live migration. The tool refuses an already-versioned store, conflicting identities, unsupported credentials, or work that would exceed the new app limits.

## 3. Create the first encrypted backup

```powershell
.\scripts\run-migration.ps1 -Action Backup
```

Enter the same project details and your recovery passphrase. Record `backupLocation` and `sourceHash`. Copy the `.json.enc` file to a second secure location and retain the passphrase separately. Encryption and decryption are checked locally before the backup is accepted.

The backup includes all blobs in `teamflow-data`, their original bytes, metadata, source hash, and target Project ID. Passwords remain plaintext only inside the encrypted legacy backup. This first backup is for rehearsal; Apply later creates a separate final backup before writing.

If users are editing during capture, the tool may stop when it detects a changed key or ETag. Ask users to pause edits and repeat. Blobs has no transaction across these two source records, so the maintenance window below is still essential.

## 4. Rehearse using the encrypted backup

```powershell
.\scripts\run-migration.ps1 -Action Rehearse
```

Enter the backup passphrase and full `backupLocation` from Step 3. Rehearse decrypts the copy in memory, performs the conversion, verifies written records, finalizes the memory-only migration, and discards the local records on exit. It makes no network calls and writes no live Blobs. It does not replace the regular staging data.

Confirm the user/work/collection counts match, passwordsConverted plus hashesPreserved equals the user count, and idRemap contains only the expected Admin remap. A successful rehearsal is not proof of hosted browser behavior; plan the final sign-in and role checks below.

For a hosted rehearsal using production data, first arrange a separately protected migration project and an authorized data import. Do not copy production credentials into the normal staging project or a public deploy preview.

## 5. Prepare a production branch with maintenance mode

Production currently uses Netlify Drop. The ZIP upload kit requires a Git-connected Netlify build; dragging this ZIP into Netlify Drop will not correctly deploy the functions.

In GitHub:

1. Create a `production` branch from the verified staging release on `main`.
2. On the `production` branch, upload the two files from `Netlify Upload\Production Maintenance Upload`: `netlify.toml` and `prepare-maintenance.cjs`.
3. This replaces the normal root `netlify.toml` with maintenance build settings. Keep the other release files present.
4. Verify the `production` branch now contains the maintenance configuration BEFORE connecting the existing production Netlify project to GitHub.

Staging remains on `main`. Do not commit the maintenance configuration to `main`.

## 6. Start the maintenance window

Tell all users to finish saving, stop edits, and close every TeamFlow tab and installed-app window. Include users with old browser sessions. Do not use old deploy permalink pages during migration; those old function deployments may still reference production storage.

In the existing production Netlify project, connect the GitHub repository and select the `production` branch. Verify the project still owns `actuaryteamflow.netlify.app`; do not rename staging or create a replacement project that loses the production Blobs identity.

The supplied maintenance root config builds:

- Command: `node prepare-maintenance.cjs`
- Publish: `maintenance/public`
- Functions: `maintenance/functions`
- Base directory: empty; Node 22.

Wait until the maintenance deploy is PUBLISHED. Its page says TeamFlow is being updated; its API returns HTTP 503 with `X-TeamFlow-Maintenance: migration-v1`. Existing cached PWAs may still display old screens, but current-origin API writes are blocked by the maintenance deploy. The migration automatically checks the maintenance API guards before any write.

Do not publish the normal release yet. Record the old production deploy ID: `6aae1da40d26a5386cd4a5e3` (verify it is still the pre-upgrade version you intend to retain).

## 7. Configure production environment variables

Set these in the production project, not the staging project:

| Key | Value |
|---|---|
| APP_URL | https://actuaryteamflow.netlify.app |
| APP_ORIGINS | https://actuaryteamflow.netlify.app |
| NETLIFY_SITE_ID | Production Project ID |
| NETLIFY_TOKEN | Private token with access to production Blobs |

Include Functions scope or All scopes. Mark NETLIFY_TOKEN as secret. Do not copy staging's site ID. SMTP variables and ADMIN_BOOTSTRAP_TOKEN are not required for migrated accounts. Do not set a new bootstrap token or run `/?setup=1`.

Save changes. The subsequent normal release build will pick them up. If an existing production credential is being replaced, record the old configuration securely for rollback.

## 8. Inspect the frozen source and apply

Run Inspect again while maintenance is active:

```powershell
.\scripts\run-migration.ps1 -Action Inspect
```

Copy the new `sourceHash`. Then:

```powershell
.\scripts\run-migration.ps1 -Action Apply
```

Supply the production credentials, recovery passphrase, latest `sourceHash`, and the exact typed migration confirmation requested by the script.

Apply creates a FINAL encrypted backup before writing; verifies the source ETags and fingerprint; creates versioned accounts/work/collections using create-only writes; activates the canonical team directory last; and verifies every imported record. It retains the two legacy blobs until Finalize.

Record the NEW `backupLocation` printed by Apply. Use this APPLY backup for Finalize or Restore, not an earlier snapshot that may contain different data.

If Apply fails, KEEP MAINTENANCE ENABLED and follow Restore below. Do not rerun Apply over partially migrated data and do not publish the normal release.

## 9. Finalize while maintenance remains active

Check the successful Apply output and counts. Then:

```powershell
.\scripts\run-migration.ps1 -Action Finalize
```

Enter the APPLY backup path and its passphrase. Read the confirmation: Finalize removes the original `team` and `works` blobs (including old plaintext credentials), retains the verified new account/work/collection records, and invalidates old session/reset links. The encrypted original backup remains available for recovery. It checks imported-record hashes and legacy source equality before removing originals.

This intentionally signs users out; their passwords stay the same. Do not reopen the site if Finalize fails.

## 10. Publish the normal production release

In GitHub, remain on the `production` branch. Upload all six normal files from `Netlify Upload\GitHub File Upload`, replacing the root maintenance `netlify.toml` with the normal one. The unused `prepare-maintenance.cjs` can remain; it is not executed by the normal configuration.

Normal configuration:

- Base directory: empty.
- Build: `npm run build`.
- Publish: `app/public`.
- Functions: `app/netlify/functions`.
- Node: 22.

Wait for the normal production deploy to publish and check that all six application functions deployed. Environment-variable changes take effect on this new deploy. Leave staging on `main`.

## 11. Validate before announcing completion

Admin and one member should sign in using their EXISTING usernames and passwords. Do not use administrator bootstrap. Ask other role holders to verify their own accounts; do not collect or share their passwords.

Check current counts against the frozen migration snapshot, all 34 original notes and 17 original links if unchanged since review, task checks, assignments/PICs, templates, request history, feedback, and authorship. The rejected request whose work was deleted remains historical. Weekly/member performance reports intentionally exclude Admin and Board.

Check two accounts viewing the same work, changes refreshing within the visible-page polling interval, successful saves, a Windows-path copy, and an HTTP/HTTPS link. Capacity estimates default to zero until real estimates are entered.

Close all old TeamFlow tabs/app windows and reopen so the new service worker/assets activate. The migration preserves business data; old login sessions are intentionally expired. Give users the production URL after these checks succeed.

## Rollback during the maintenance window

If migration fails, keep the maintenance deployment published. If the normal release has already published, first republish the maintenance deployment and ask everyone to stop edits again.

```powershell
.\scripts\run-migration.ps1 -Action Restore
```

Select the APPLY backup and enter its passphrase. Restore is restricted to a migration created from that exact backup and project. It verifies the restored source bytes, removes migration-created records, and refuses unknown new records or edited migrated records to avoid discarding subsequent work. If users have resumed edits, stop and reconcile the newer data instead of forcing rollback.

After successful data restore, restore the OLD production deployment `6aae1da40d26a5386cd4a5e3` and any changed old environment configuration. Lock publishing or otherwise stop new Git builds from immediately replacing the rollback. Restoring the old deploy alone does not restore account data.

The old deploy again uses the old plaintext-credential format; retain it only as a temporary recovery measure. Keep the backups secure and handle their retention with your organization's policy.
