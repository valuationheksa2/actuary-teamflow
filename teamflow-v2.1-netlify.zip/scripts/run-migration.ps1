param(
    [ValidateSet('Inspect', 'Backup', 'Rehearse', 'Apply', 'Finalize', 'Restore')]
    [string]$Action = 'Inspect'
)

$ErrorActionPreference = 'Stop'
$savedEnvironment = @{}
$environmentNames = @('NETLIFY_SITE_ID', 'NETLIFY_TOKEN', 'APP_URL', 'MIGRATION_BACKUP_PASSPHRASE', 'MIGRATION_BACKUP_KEY')
foreach ($name in $environmentNames) { $savedEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }

function Read-PrivateValue([string]$Label) {
    $secureValue = Read-Host $Label -AsSecureString
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureValue)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
}

try {
    $null = Get-Command node -ErrorAction Stop
    $nodeMajor = [int]((& node -p 'process.versions.node.split(String.fromCharCode(46))[0]') | Select-Object -First 1)
    if ($nodeMajor -lt 22) { throw 'Install Node.js 22 or newer from nodejs.org before continuing.' }
    $arguments = @((Join-Path $PSScriptRoot 'migrate-data.js'))
    if ($Action -ne 'Rehearse') {
        $targetSiteID = (Read-Host 'Target Netlify Project ID (verify production versus staging)').Trim()
        $targetSiteURL = (Read-Host 'Target HTTPS site address').Trim().TrimEnd('/')
        $targetToken = Read-PrivateValue 'Netlify access token (hidden; do not paste it into chat)'
        [Environment]::SetEnvironmentVariable('NETLIFY_SITE_ID', $targetSiteID, 'Process')
        [Environment]::SetEnvironmentVariable('NETLIFY_TOKEN', $targetToken, 'Process')
        [Environment]::SetEnvironmentVariable('APP_URL', $targetSiteURL, 'Process')
        $arguments += @('--expect-site-id', $targetSiteID, '--site-url', $targetSiteURL)
    }
    if ($Action -ne 'Inspect') {
        $passphrase = Read-PrivateValue 'Backup recovery passphrase (16+ characters; save it in your password manager)'
        if ($passphrase.Length -lt 16) { throw 'Backup passphrase must contain at least 16 characters.' }
        [Environment]::SetEnvironmentVariable('MIGRATION_BACKUP_PASSPHRASE', $passphrase, 'Process')
        [Environment]::SetEnvironmentVariable('MIGRATION_BACKUP_KEY', $null, 'Process')
    }
    switch ($Action) {
        'Inspect' { $arguments += '--dry-run' }
        'Backup' { $arguments += '--backup' }
        'Rehearse' {
            $backupFile = (Read-Host 'Full path of encrypted backup').Trim().Trim('"')
            $arguments += @('--rehearse', '--backup-file', $backupFile)
        }
        'Apply' {
            $sourceHash = (Read-Host 'sourceHash from the latest maintenance-mode Inspect').Trim()
            $confirmation = Read-Host ('Type MIGRATE ' + $targetSiteID + ' to approve writes during maintenance')
            if ($confirmation -ne ('MIGRATE ' + $targetSiteID)) { throw 'Migration cancelled.' }
            $arguments += @('--apply', '--source-hash', $sourceHash, '--maintenance-confirmed')
        }
        'Finalize' {
            $backupFile = (Read-Host 'Full path of backupLocation printed by successful Apply').Trim().Trim('"')
            Write-Host 'Finalize removes the two old plaintext credential/work blobs and expires old sessions. The verified new records and encrypted backup remain.'
            $confirmation = Read-Host ('Type FINALIZE ' + $targetSiteID + ' to approve legacy removal')
            if ($confirmation -ne ('FINALIZE ' + $targetSiteID)) { throw 'Finalize cancelled.' }
            $arguments += @('--finalize', '--backup-file', $backupFile, '--maintenance-confirmed')
        }
        'Restore' {
            $backupFile = (Read-Host 'Full path of the APPLY backup for the migration being reverted').Trim().Trim('"')
            Write-Host 'Restore replaces data with the backup and removes migration-created records. Do not use it after users resume editing; newer data requires reconciliation.'
            $confirmation = Read-Host ('Type RESTORE ' + $targetSiteID + ' to approve rollback during maintenance')
            if ($confirmation -ne ('RESTORE ' + $targetSiteID)) { throw 'Restore cancelled.' }
            $arguments += @('--restore', '--backup-file', $backupFile, '--maintenance-confirmed')
        }
    }
    & node @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Operation failed. Follow the displayed message; keep maintenance active after a failed live write.' }
}
finally {
    foreach ($name in $environmentNames) { [Environment]::SetEnvironmentVariable($name, $savedEnvironment[$name], 'Process') }
    $targetToken = $null
    $passphrase = $null
}
