'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { createHash } = require('node:crypto');

const root = path.resolve(__dirname, '..');
const publicDir = path.join(root, 'public');
const functionDir = path.join(root, 'netlify', 'functions');
const htmlPath = path.join(publicDir, 'index.html');
const { transformSync } = require('esbuild');
let html = fs.readFileSync(htmlPath, 'utf8');
let sourceBytes=0,outputBytes=0;
// Preserve global names and all features referenced by inline event handlers.
for(const directory of ['js','css']){
  const folder=path.join(publicDir,directory),extension=directory==='js'?'.js':'.css';
  for(const name of fs.readdirSync(folder).filter(name=>name.endsWith(extension)&&!name.endsWith('.min'+extension))){
    const source=fs.readFileSync(path.join(folder,name),'utf8');
    const output=transformSync(source,{loader:directory==='js'?'js':'css',minifyWhitespace:true,minifySyntax:false,minifyIdentifiers:false,treeShaking:false,charset:'utf8',legalComments:'inline'}).code;
    const generated=name.slice(0,-extension.length)+'.min'+extension;
    fs.writeFileSync(path.join(folder,generated),output);
    sourceBytes+=Buffer.byteLength(source);outputBytes+=Buffer.byteLength(output);
    html=html.replaceAll('/'+directory+'/'+name,'/'+directory+'/'+generated);
  }
}
fs.writeFileSync(htmlPath,html);
process.stdout.write('Static asset minification: '+sourceBytes+' → '+outputBytes+' bytes ('+Math.round((1-outputBytes/sourceBytes)*100)+'% smaller).\n');

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const file = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(file) : [file];
  });
}

const javascript = [...walk(functionDir), ...walk(publicDir), ...walk(path.join(root,'scripts'))].filter(file => /\.(?:js|cjs)$/.test(file));
// A changed shell creates a new cache without forcing an open app to reload.
const workerPath = path.join(publicDir, 'sw.js');
const worker = fs.readFileSync(workerPath, 'utf8').replace(/(\/js\/[^'\s]+?)(?:\.min)?\.js/g,'$1.min.js').replace('/css/app.css','/css/app.min.css');
const digest = createHash('sha256');
for (const file of walk(publicDir).filter(file => file !== workerPath).sort()) {
  digest.update(path.relative(publicDir, file));
  digest.update(fs.readFileSync(file));
}
digest.update(worker.replace(/const CACHE_NAME = '[^']+';/, ''));
fs.writeFileSync(workerPath, worker.replace(/const CACHE_NAME = '[^']+';/,
  `const CACHE_NAME = 'teamflow-shell-v21-${digest.digest('hex').slice(0, 16)}';`));
for (const file of javascript) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) throw new Error(`${path.relative(root, file)}: ${result.stderr || result.stdout}`);
}
for (const asset of html.matchAll(/(?:src|href)="(\/(?:css|js)\/[^\"]+)"/g)) {
  const localPath = path.join(publicDir, asset[1].slice(1));
  if (!fs.existsSync(localPath)) throw new Error(`Missing referenced asset: ${asset[1]}`);
}
if (!html.includes('<title>') || !html.includes('id="content"')) throw new Error('Required app shell markup is missing.');
process.stdout.write(`Static app validation passed (${javascript.length} JavaScript files).\n`);
