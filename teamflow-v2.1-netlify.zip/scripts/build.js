'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { createHash } = require('node:crypto');

const root = path.resolve(__dirname, '..');
const publicDir = path.join(root, 'public');
const functionDir = path.join(root, 'netlify', 'functions');
const htmlPath = path.join(publicDir, 'index.html');
const html = fs.readFileSync(htmlPath, 'utf8');

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
    const file = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(file) : [file];
  });
}

const javascript = [...walk(functionDir), ...walk(publicDir), ...walk(path.join(root,'scripts'))].filter(file => /\.(?:js|cjs)$/.test(file));
// A changed shell creates a new cache without forcing an open app to reload.
const workerPath = path.join(publicDir, 'sw.js');
const worker = fs.readFileSync(workerPath, 'utf8');
const digest = createHash('sha256');
for (const file of walk(publicDir).filter(file => file !== workerPath).sort()) {
  digest.update(path.relative(publicDir, file));
  digest.update(fs.readFileSync(file));
}
digest.update(worker.replace(/const CACHE_NAME = '[^']+';/, ''));
fs.writeFileSync(workerPath, worker.replace(/const CACHE_NAME = '[^']+';/,
  `const CACHE_NAME = 'teamflow-shell-v21-${digest.digest('hex').slice(0, 16)}';`));
for (const file of javascript) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) throw new Error(`${path.relative(root, file)}: ${result.stderr || result.stdout}`);
}
for (const asset of html.matchAll(/(?:src|href)="(\/(?:css|js)\/[^\"]+)"/g)) {
  const localPath = path.join(publicDir, asset[1].slice(1));
  if (!fs.existsSync(localPath)) throw new Error(`Missing referenced asset: ${asset[1]}`);
}
if (!html.includes('<title>') || !html.includes('id="content"')) throw new Error('Required app shell markup is missing.');
process.stdout.write(`Static app validation passed (${javascript.length} JavaScript files).\n`);
