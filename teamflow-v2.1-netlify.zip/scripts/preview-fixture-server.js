'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const publicDir = path.resolve(__dirname, '..', 'public');
const host = '127.0.0.1';
const port = Number(process.env.PORT || 8890);
process.env.APP_ORIGINS=[process.env.APP_ORIGINS,`http://${host}:${port}`].filter(Boolean).join(',');
const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const dateOffset = (value, amount) => {
  const date = new Date(`${value}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + amount);
  return date.toISOString().slice(0, 10);
};

const user = { id: 1, name: 'Avery Tan', email: 'avery@example.test', username: 'avery', role: 'admin', color: '#5c6ef8', initials: 'AT', active: true, weeklyCapacityHours: 40, reminderPreferences: { reminderDays: [3, 0] } };
const team = [
  user,
  { id: 2, name: 'Morgan Lee', email: 'morgan@example.test', username: 'morgan', role: 'manager', color: '#22c55e', initials: 'ML', active: true, weeklyCapacityHours: 36 },
  { id: 3, name: 'Jordan Kim', email: 'jordan@example.test', username: 'jordan', role: 'member', color: '#f59e0b', initials: 'JK', active: true, weeklyCapacityHours: 32 },
  { id: 4, name: 'Sam Rivera', email: 'sam@example.test', username: 'sam', role: 'member', color: '#a855f7', initials: 'SR', active: true, weeklyCapacityHours: 40 },
];
const phaseTasks = {
  Planning: ['Confirm scope and assumptions', 'Review source data'],
  Executing: ['Build the valuation movement', 'Reconcile outputs'],
  Review: ['Complete peer review', 'Resolve findings'],
  Finalize: ['Obtain sign-off', 'Archive workpapers'],
};
const makeWork = (id, title, startDate, deadline, status, assignees, estimatedHours, phase = 1) => ({
  id, title, desc: 'Fictional local-preview work item for checking schedule, dashboard, and capacity layouts.',
  status, priority: id % 2 ? 'High' : 'Medium', phase, workType: id % 2 ? 'regular' : 'adHoc',
  startDate, deadline, completedDate: null, assignees, pic: assignees[0], createdBy: user.id,
  createdAt: today, tags: ['IFRS 17', 'Reserving'], files: [], notes: [], phaseTasks,
  phaseChecks: { Planning: [true, true], Executing: [true, false], Review: [false, false], Finalize: [false, false] },
  estimatedHours, version: 1,
});
let works = [
  makeWork(101, 'Quarter-end reserve review', today, dateOffset(today, 3), 'ongoing', [2, 3], 28),
  makeWork(102, 'IFRS 17 assumption refresh', dateOffset(today, 1), dateOffset(today, 5), 'upcoming', [3], 18, 0),
  makeWork(103, 'Claims movement reconciliation', dateOffset(today, -2), dateOffset(today, 1), 'ongoing', [4], 12, 2),
  makeWork(104, 'Monthly close workpapers', dateOffset(today, -6), dateOffset(today, -1), 'ongoing', [2, 4], 20, 1),
];
let workVersion = 1;
let teamVersion = 1;
let notifications = [
  { id: 'fixture-101', workId: 101, title: 'Quarter-end reserve review', deadline: dateOffset(today, 3), days: 3, kind: 'due-soon', read: false },
  { id: 'fixture-104', workId: 104, title: 'Monthly close workpapers', deadline: dateOffset(today, -1), days: -1, kind: 'overdue', read: false },
];
const activity = [{ workId: 101, actorId: user.id, actorName: user.name, action: 'updated', changedFields: { phase: true }, createdAt: new Date().toISOString() }];

function send(res, status, payload, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => { raw += chunk; if (raw.length > 100_000) reject(new Error('Request is too large.')); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Invalid JSON.')); } });
    req.on('error', reject);
  });
}

const {MemoryStore}=require('./memory-store');
const {createSession}=require('../netlify/functions/lib/auth-core');
const {withoutSecrets}=require('../netlify/functions/lib/records');
const handlers={works:require('../netlify/functions/works')._test.handle,team:require('../netlify/functions/team')._test.handle,notifications:require('../netlify/functions/notifications')._test.handle,activity:require('../netlify/functions/activity')._test.handle,digest:require('../netlify/functions/digest')._test.handle};
team.push({id:5,name:'Taylor Board',email:'board@example.test',username:'board',role:'board',active:true,color:'#64748b',initials:'TB',weeklyCapacityHours:0});
const fixtureStore=new MemoryStore(Object.fromEntries([
 ...team.map(member=>['v2:member:'+member.id,JSON.stringify({data:{...member,passwordHash:'fixture-only',authVersion:1},version:1})]),
 ...works.map(work=>['v2:work:'+work.id,JSON.stringify({data:work,version:1})]),
]));
const fixtureSessions=new Map();
async function handleApi(req,res,url){
 if(req.method==='OPTIONS')return send(res,204,{});
 const selected=Number((req.headers.cookie||'').match(/(?:^|;\s*)fixture_user=(\d+)/)?.[1]||1);
 const account=await require('../netlify/functions/lib/records').getMember(selected,fixtureStore)||user;
 if(url.pathname==='/api/auth/me')return send(res,200,{user:withoutSecrets(account)});
 if(url.pathname==='/api/auth/logout')return send(res,200,{ok:true});
 if(!fixtureSessions.has(account.id))fixtureSessions.set(account.id,await createSession({...account,authVersion:1},fixtureStore));
 const session=fixtureSessions.get(account.id);
 const event={httpMethod:req.method,path:url.pathname,queryStringParameters:Object.fromEntries(url.searchParams),headers:{...req.headers,cookie:session.cookie['Set-Cookie'].split(';')[0]},body:req.method==='POST'?JSON.stringify(await readBody(req)):''};
 const handler=handlers[url.pathname.split('/')[2]];
 if(!handler)return send(res,404,{error:'Fixture endpoint not available.'});
 try{const result=await handler(event,fixtureStore);res.writeHead(result.statusCode,result.headers);res.end(result.body);}
 catch(error){send(res,error.statusCode||500,{error:error.statusCode?error.message:'Fixture request failed.'});}
}

const mime = { '.css': 'text/css; charset=utf-8', '.html': 'text/html; charset=utf-8', '.ico': 'image/x-icon', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${host}:${port}`);
  if(url.pathname==='/fixture-login'){
    const selected=Number(url.searchParams.get('user'));
    if(!team.some(member=>member.id===selected))return send(res,400,{error:'Unknown fictional account.'});
    res.writeHead(302,{'Location':'/','Set-Cookie':'fixture_user='+selected+'; Path=/; SameSite=Lax'});res.end();return;
  }
  if (url.pathname.startsWith('/api/')) {
    try { await handleApi(req, res, url); }
    catch (error) { send(res, 400, { error: error.message }); }
    return;
  }
  const requested = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  const file = path.resolve(publicDir, `.${requested}`);
  if (!file.startsWith(publicDir + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404); res.end('Not found'); return;
  }
  res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  fs.createReadStream(file).pipe(res);
});

server.listen(port, host, () => process.stdout.write(`Fictional TeamFlow preview at http://${host}:${port} (memory-only data)\n`));
server.on('error', error => { process.stderr.write(`${error.message}\n`); process.exitCode = 1; });
