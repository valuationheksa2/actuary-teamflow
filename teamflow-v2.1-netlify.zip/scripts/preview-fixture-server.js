'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const publicDir = path.resolve(__dirname, '..', 'public');
const host = '127.0.0.1';
const port = Number(process.env.PORT || 8890);
process.env.APP_ORIGINS=[process.env.APP_ORIGINS,`http://${host}:${port}`].filter(Boolean).join(',');
const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const dateOffset = (value, amount) => {
  const date = new Date(`${value}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + amount);
  return date.toISOString().slice(0, 10);
};

const user = { id: 1, name: 'Avery Tan', email: 'avery@example.test', username: 'avery', role: 'admin', color: '#5c6ef8', initials: 'AT', active: true, weeklyCapacityHours: 40, reminderPreferences: { reminderDays: [3, 0] } };
const team = [
  user,
  { id: 2, name: 'Morgan Lee', email: 'morgan@example.test', username: 'morgan', role: 'manager', color: '#22c55e', initials: 'ML', active: true, weeklyCapacityHours: 36 },
  { id: 3, name: 'Jordan Kim', email: 'jordan@example.test', username: 'jordan', role: 'member', color: '#f59e0b', initials: 'JK', active: true, weeklyCapacityHours: 32 },
  { id: 4, name: 'Sam Rivera', email: 'sam@example.test', username: 'sam', role: 'member', color: '#a855f7', initials: 'SR', active: true, weeklyCapacityHours: 40 },
  { id: 6, name: 'Casey Chen', email: 'casey@example.test', username: 'casey', role: 'member', color: '#06b6d4', initials: 'CC', active: true, weeklyCapacityHours: 36 },
  { id: 7, name: 'Alex Patel', email: 'alex@example.test', username: 'alex', role: 'member', color: '#ef4444', initials: 'AP', active: true, weeklyCapacityHours: 28 },
  { id: 8, name: 'Riley Santos', email: 'riley@example.test', username: 'riley', role: 'manager', color: '#f97316', initials: 'RS', active: true, weeklyCapacityHours: 32 },
  { id: 9, name: 'Jamie Brooks', email: 'jamie@example.test', username: 'jamie', role: 'member', color: '#ec4899', initials: 'JB', active: true, weeklyCapacityHours: 40 },
  { id: 10, name: 'Quinn Park', email: 'quinn@example.test', username: 'quinn', role: 'member', color: '#14b8a6', initials: 'QP', active: true, weeklyCapacityHours: 24 },
];
const phaseTasks = {
  Planning: ['Confirm scope and assumptions', 'Review source data'],
  Executing: ['Build the valuation movement', 'Reconcile outputs'],
  Review: ['Complete peer review', 'Resolve findings'],
  Finalize: ['Obtain sign-off', 'Archive workpapers'],
};
const makeWork = (id, title, startDate, deadline, status, assignees, estimatedHours, phase = 1) => ({
  id, title, desc: 'Fictional local-preview work item for checking schedule, dashboard, and capacity layouts.',
  status, priority: id % 2 ? 'High' : 'Medium', phase, workType: id % 2 ? 'regular' : 'adHoc',
  startDate, deadline, completedDate: null, assignees, pic: assignees[0], createdBy: user.id,
  createdAt: today, tags: ['IFRS 17', 'Reserving'], files: [], notes: [], phaseTasks,
  phaseChecks: { Planning: [true, true], Executing: [true, false], Review: [false, false], Finalize: [false, false] },
  estimatedHours, version: 1,
});
let works = [
  makeWork(101, 'Quarter-end reserve review', today, dateOffset(today, 3), 'ongoing', [2, 3], 28),
  makeWork(102, 'IFRS 17 assumption refresh', dateOffset(today, 1), dateOffset(today, 5), 'upcoming', [3], 18, 0),
  makeWork(103, 'Claims movement reconciliation', dateOffset(today, -2), dateOffset(today, 1), 'ongoing', [4], 12, 2),
  makeWork(104, 'Monthly close workpapers', dateOffset(today, -6), dateOffset(today, -1), 'ongoing', [2, 4], 20, 1),
];
const scenarios = [
  ['IFRS 17 monthly close', 32, 'Closing'],
  ['Life reserve adequacy review', 24, 'Reserving'],
  ['Premium and claims reconciliation', 12, 'Reconciliation'],
  ['Mortality assumption study', 40, 'Assumptions'],
  ['CSM movement analysis', 20, 'IFRS 17'],
  ['Cash flow projection — term life', 36, 'Modeling'],
  ['Reinsurance recoverable review', 16, 'Reinsurance'],
  ['Policy data quality checks', 8, 'Data'],
  ['Lapse and surrender experience study', 28, 'Experience'],
  ['Expense allocation review', 10, 'Expenses'],
  ['Risk adjustment calibration', 24, 'Risk'],
  ['Investment return reconciliation', 6, 'Finance'],
  ['Quarterly regulatory reporting', 18, 'Reporting'],
  ['Product profitability dashboard', 16, 'Analytics'],
  ['New business pricing review', 32, 'Pricing'],
  ['Onerous contract assessment', 14, 'IFRS 17'],
  ['Solvency stress scenario analysis', 30, 'Risk'],
  ['Annual actuarial report', 48, 'Reporting'],
];
const memberIds = [3, 4, 6, 7, 9, 10];
for (let index = 0; index < 36; index += 1) {
  const [title, hours, tag] = scenarios[index % scenarios.length];
  const status = ['ongoing', 'upcoming', 'done'][index % 3];
  const deadlineOffset = status === 'done' ? -4-index : status === 'upcoming' ? 7+index : index % 4 === 0 ? -2 : 2+index%10;
  const assignees = [memberIds[index % memberIds.length], memberIds[(index+1) % memberIds.length]];
  const work = makeWork(105+index, `${title} — ${index < 18 ? 'Life portfolio' : 'Protection portfolio'}`, dateOffset(today, deadlineOffset-10), dateOffset(today, deadlineOffset), status, assignees, hours, status === 'done' ? 4 : status === 'upcoming' ? 0 : index%4);
  work.createdBy = memberIds[(index+2) % memberIds.length];
  work.createdAt = dateOffset(work.startDate, -2);
  work.priority = ['High', 'Medium', 'Low'][index%3];
  work.tags = [tag, 'Fictional data'];
  work.desc = `Fictional ${title.toLowerCase()} assignment. Review source data, document assumptions, reconcile movements and prepare peer-review evidence. All amounts and account details in this local preview are illustrative.`;
  work.phaseTasks = Object.fromEntries(Object.entries(phaseTasks).map(([phase, tasks])=>[phase, [...tasks]]));
  work.phaseChecks = Object.fromEntries(Object.entries(work.phaseTasks).map(([phase, tasks], phaseIndex)=>[phase, tasks.map((_, taskIndex)=>status==='done'||status==='ongoing'&&(phaseIndex<work.phase||phaseIndex===work.phase&&taskIndex===0))]));
  if (status === 'done') work.completedDate = dateOffset(work.deadline, index%2 ? -1 : 2);
  // Most fictional completed work records actual hours; a few are left blank like older records.
  if (status === 'done' && index%4 !== 3) work.actualHours = Math.round(hours*[0.85,1.1,1.25][Math.floor(index/3)%3]*2)/2;
  if (status !== 'done' && index%5 === 0) work.recurrence = 'monthly';
  work.notes = [{ authorId: assignees[0], authorName: team.find(member=>member.id===assignees[0]).name, text: 'Fictional review note: source totals reconciled; assumptions ready for peer review.', createdDate: work.startDate, editedDate: null }];
  work.files = [{ name: 'Fictional workpaper reference', url: `https://example.test/workpapers/${work.id}`, type: 'doc', icon: '📄' }];
  works.push(work);
}
// Jordan owns this work without being assigned; Sam is the PIC.
Object.assign(works.find(work=>work.id===105), { title: 'Creator / PIC assignment permissions demo', createdBy: 3, pic: 4, assignees: [4, 6], status: 'ongoing', phase: 1, deadline: dateOffset(today, 8) });
const templates = Array.from({length:24}, (_, index)=>{
  const [title, hours, tag] = scenarios[index % scenarios.length];
  const creatorId = [3, 4, 1, 2, 6, 7][index%6];
  const template = {
    id: 501+index, name: `${title}${index>=18?' — quarterly variant':''}`, title,
    icon: ['📋', '📊', '🧮', '💼', '🔍', '📈'][index%6],
    desc: `Fictional reusable ${title.toLowerCase()} workflow for reviewing saved effort, creator ownership and phase tasks.`,
    workType: index%4===0?'adHoc':'regular', status: 'upcoming', priority: ['High', 'Medium', 'Low'][index%3],
    estimatedHours: index===22?0:hours, pic: creatorId===1?2:creatorId,
    assignees: creatorId===1?[3, 4]:[creatorId], tags: [tag, 'Fictional template'],
    recurrence: index%3===0?'monthly':index%3===1?'quarterly':'', customDays: '7',
    createdBy: creatorId, createdAt: dateOffset(today, -index-2),
    phaseTasks: Object.fromEntries(Object.entries(phaseTasks).map(([phase, tasks])=>[phase, [...tasks]])),
  };
  if (index===23) { template.name='Legacy template — creator not recorded'; delete template.createdBy; delete template.estimatedHours; }
  // More fictional templates for trying Admin → Assign creator.
  if (index===21) { template.name='Imported template — creator not recorded'; delete template.createdBy; }
  if (index===20) { template.name='Template from a removed account'; template.createdBy=99; }
  return template;
});
const joinRequests = [
  {id:801,workId:101,userId:4,type:'join',status:'pending',date:dateOffset(today,-1)},
  {id:802,workId:103,userId:3,type:'join',status:'pending',date:today},
  {id:803,workId:105,userId:6,type:'leave',status:'pending',date:today},
  {id:804,workId:101,userId:7,type:'join',status:'approved',date:dateOffset(today,-4),approvedBy:2,approvedByName:'Morgan Lee',resolvedDate:dateOffset(today,-3)},
  {id:805,workId:103,userId:10,type:'join',status:'rejected',date:dateOffset(today,-3),approvedBy:4,approvedByName:'Sam Rivera',resolvedDate:dateOffset(today,-2)},
  {id:806,workId:104,userId:4,type:'leave',status:'pending',date:today},
];
works.find(work=>work.id===101).assignees.push(7);
const feedbackItems = Array.from({length:12}, (_, index)=>{
  const author = team.find(member=>member.id===memberIds[index%memberIds.length]);
  return {id:901+index,category:['Suggestion','Bug Report','Compliment','Other'][index%4],author:author.name,authorId:author.id,text:`Fictional feedback ${index+1}: ${['Show estimated hours in template cards.','Keep the page position when shared data refreshes.','The capacity view helps plan the monthly valuation close.','Review the workflow with different creator and PIC accounts.'][index%4]}`,date:dateOffset(today,-index),status:['open','noted','inprogress','done'][index%4]};
});

function send(res, status, payload, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => { raw += chunk; if (raw.length > 100_000) reject(new Error('Request is too large.')); });
    req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error('Invalid JSON.')); } });
    req.on('error', reject);
  });
}

const {MemoryStore}=require('./memory-store');
const {createSession}=require('../netlify/functions/lib/auth-core');
const {withoutSecrets}=require('../netlify/functions/lib/records');
const handlers={works:require('../netlify/functions/works')._test.handle,team:require('../netlify/functions/team')._test.handle,activity:require('../netlify/functions/activity')._test.handle,digest:require('../netlify/functions/digest')._test.handle,push:require('../netlify/functions/push')._test.handle,reads:require('../netlify/functions/reads')._test.handle,meetings:require('../netlify/functions/meetings')._test.handle,absences:require('../netlify/functions/absences')._test.handle};
team.push({id:5,name:'Taylor Board',email:'board@example.test',username:'board',role:'board',active:true,color:'#64748b',initials:'TB',weeklyCapacityHours:0});
// Optional local snapshot preserves fictional review edits across a server restart.
if(process.env.TEAMFLOW_FIXTURE_SNAPSHOT){
 const snapshot=JSON.parse(fs.readFileSync(process.env.TEAMFLOW_FIXTURE_SNAPSHOT,'utf8'));
 if(!Array.isArray(snapshot.team)||!Array.isArray(snapshot.bundle?.data))throw new Error('Invalid fictional preview snapshot.');
 team.splice(0,team.length,...snapshot.team);works=snapshot.bundle.data;
 for(const [name,collection] of Object.entries({templates,joinRequests,feedbackItems})){
  if(Array.isArray(snapshot.bundle[name]))collection.splice(0,collection.length,...snapshot.bundle[name]);
 }
}
// Fictional phase timelines so Performance Analysis has something to show: a smooth run, a slow review with a send-back, and phases all moved at once.
function fixturePerformanceEntries(){
 const done=works.filter(work=>work.status==='done'&&work.startDate&&work.completedDate&&work.completedDate>work.startDate).slice(0,10);
 const rows=[];
 done.forEach((work,index)=>{
  const actor=team.find(member=>member.id===work.pic)||user,reviewer=team.find(member=>member.role==='manager'&&member.id!==work.pic)||user;
  const begin=Date.parse(work.startDate+'T02:00:00Z'),span=Date.parse(work.completedDate+'T08:00:00Z')-begin;
  const at=share=>new Date(begin+span*share).toISOString();
  const add=(id,person,action,createdAt,details,changedFields={phase:true})=>{const entry={id:`fixture-perf-${work.id}-${id}`,workId:work.id,actorId:person.id,actorName:person.name,action,changedFields,details,createdAt};rows.push([`v2:activity:${work.id}:${createdAt}:${entry.id}`,JSON.stringify(entry)]);};
  const decide=(decision,person,createdAt,comment)=>{work.reviews=[...(work.reviews||[]),{decision,actorId:person.id,actorName:person.name,selfReview:person.id===work.pic,comment,date:createdAt.slice(0,10),createdAt}];};
  add('start',actor,'started',work.startDate+'T01:00:00.000Z',['Status: Upcoming → Ongoing'],{status:true});
  if(index%3===0){
   add('1',actor,'updated',at(.15),['Phase: Planning → Executing']);add('2',actor,'updated',at(.7),['Phase: Executing → Review']);
   add('3',reviewer,'approved',at(.8),['Approved: “Reconciles to the valuation output.”'],{reviews:true});decide('approved',reviewer,at(.8),'Reconciles to the valuation output.');
   add('4',actor,'updated',at(.85),['Phase: Review → Finalize']);
  }else if(index%3===1){
   add('1',actor,'updated',at(.05),['Phase: Planning → Executing']);add('2',actor,'updated',at(.25),['Phase: Executing → Review']);
   add('d',actor,'updated',at(.3),[`Deadline: ${dateOffset(work.deadline,-4)} → ${work.deadline}`],{deadline:true});
   add('3',reviewer,'sent back',at(.55),['Phase: Review → Executing','Sent back to Executing: “Reconcile the CSM roll-forward.”'],{reviews:true,phase:true});decide('sent_back',reviewer,at(.55),'Reconcile the CSM roll-forward.');
   add('4',actor,'updated',at(.65),['Phase: Executing → Review']);
   add('5',reviewer,'approved',at(.9),['Approved'],{reviews:true});decide('approved',reviewer,at(.9),'');
   add('6',actor,'updated',at(.95),['Phase: Review → Finalize']);
  }else{
   const end=Date.parse(work.completedDate+'T08:00:00Z'),soon=minutes=>new Date(end-minutes*60000).toISOString();
   add('1',actor,'updated',soon(9),['Phase: Planning → Executing']);add('2',actor,'updated',soon(6),['Phase: Executing → Review']);
   add('3',actor,'approved',soon(5),['Approved (PIC self-review)'],{reviews:true});decide('approved',actor,soon(5),'');
   add('4',actor,'updated',soon(3),['Phase: Review → Finalize']);
  }
  add('end',actor,'completed',work.completedDate+'T08:00:00.000Z',['Status: Ongoing → Completed'],{status:true});
 });
 return rows;
}
const performanceRows=fixturePerformanceEntries();
// Fictional meetings, including one about to start so the reminder banner shows in the preview.
function fixtureMeetingRows(){
 const domain=require('../public/js/domain'),zone=process.env.TEAM_TIME_ZONE||'Asia/Bangkok',now=Date.now();
 const local=at=>{const parts=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:zone,hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).formatToParts(new Date(at)).map(part=>[part.type,part.value]));return{date:`${parts.year}-${parts.month}-${parts.day}`,startTime:`${parts.hour}:${parts.minute}`};};
 const today=local(now).date,linked=works.filter(work=>work.status==='ongoing').slice(0,2).map(work=>work.id);
 const at=(date,startTime)=>({date,startTime,startsAt:domain.zonedTimeToIso(date,startTime,zone)});
 const soon=local(now+40*60000);
 const rows=[
  {id:9001,title:'IFRS 17 results review',...at(soon.date,soon.startTime),durationMinutes:60,location:'Room 3B',organizerId:2,organizerName:'Morgan Lee',attendees:[1,2,3,4],linkedWorkIds:linked.slice(0,1),agenda:'Walk through the CSM roll-forward and the movement in the loss component.',status:'scheduled',files:[{name:'Fictional results pack',url:'https://example.test/results-pack',type:'doc',icon:'📄'},{name:'Fictional working folder',url:'//fileserver/ifrs17/q3',type:'folder',icon:'📁'}]},
  {id:9002,title:'Team monthly',...at(domain.addDays(today,1),'09:30'),durationMinutes:90,location:'https://meet.example.test/team-monthly',organizerId:1,organizerName:'Avery Tan',attendees:[1,2,3,4,6,7],linkedWorkIds:[],agenda:'Capacity for next month and open sign-offs.',status:'scheduled'},
  {id:9003,title:'Reserve assumption walkthrough',...at(domain.addDays(today,5),'13:00'),durationMinutes:60,location:'Room 2A',organizerId:3,organizerName:'Jordan Kim',attendees:[2,3,4],linkedWorkIds:linked,agenda:'',status:'scheduled'},
  {id:9004,title:'Q3 assumptions sign-off',...at(domain.addDays(today,-7),'10:00'),durationMinutes:60,location:'Room 3B',organizerId:2,organizerName:'Morgan Lee',attendees:[1,2,3],linkedWorkIds:linked.slice(0,1),agenda:'',status:'scheduled',minutes:'Lapse assumption kept at the current level.',minutesBy:'Morgan Lee',actions:[{id:1,text:'Document the rationale for the lapse assumption',ownerId:3,workId:null}],reminderSentAt:new Date(now-8*86400000).toISOString()},
 ];
 return rows.map(meeting=>['v2:meeting:'+meeting.id,JSON.stringify({data:meeting,version:1})]);
}
const meetingRows=fixtureMeetingRows();
// Fictional review ages and time off, so the sign-off queue and Capacity show them.
works.filter(work=>work.status==='ongoing'&&work.phase===2).forEach((work,index)=>{work.reviewEnteredAt=new Date(Date.now()-(index*2+1)*86400000).toISOString();});
function fixtureAbsenceRows(){
 const domain=require('../public/js/domain'),week=domain.weekRange(domain.dateKeyInZone(new Date(),'Asia/Bangkok'),0).start;
 return [
  {id:9101,type:'holiday',label:'Fictional public holiday',startDate:domain.addDays(week,4),endDate:domain.addDays(week,4)},
  {id:9102,type:'leave',memberId:3,label:'Annual leave',startDate:domain.addDays(week,2),endDate:domain.addDays(week,3)},
 ].map(entry=>['v2:absence:'+entry.id,JSON.stringify({data:entry,version:1})]);
}
const fixtureStore=new MemoryStore(Object.fromEntries([
 ...performanceRows,
 ...meetingRows,
 ...fixtureAbsenceRows(),
 ...team.map(member=>['v2:member:'+member.id,JSON.stringify({data:{...member,passwordHash:'fixture-only',authVersion:1},version:1})]),
 ...works.map(work=>['v2:work:'+work.id,JSON.stringify({data:work,version:1})]),
 ...Object.entries({templates,joinRequests,feedbackItems}).map(([name,items])=>['v2:collection:'+name,JSON.stringify({items,version:1})]),
 ...works.map(work=>{const actor=team.find(member=>member.id===work.createdBy)||user;const entry={id:'fixture-created-'+work.id,workId:work.id,actorId:actor.id,actorName:actor.name,action:'created',changedFields:{title:true,assignees:true,estimatedHours:true},createdAt:work.createdAt+'T09:00:00.000Z'};return['v2:activity:'+work.id+':'+entry.createdAt+':'+entry.id,JSON.stringify(entry)];}),
]));
// Mirror the hourly Netlify schedule so upcoming work starts on its start date in the preview too.
const {startDueWork}=require('../netlify/functions/auto-start');
const runAutoStart=()=>startDueWork(fixtureStore).then(ids=>{if(ids.length)process.stdout.write(`Auto-start moved ${ids.length} fictional work item(s) to Ongoing.\n`);}).catch(error=>process.stderr.write(`Auto-start failed: ${error.message}\n`));
runAutoStart();setInterval(runAutoStart,60*60*1000).unref();
const PREVIEW_PASSWORD='preview-pass-2026';
let slowNextWorks=false;
const fixtureSessions=new Map();
async function handleApi(req,res,url){
 if(req.method==='OPTIONS')return send(res,204,{});
 const signedOut=/(?:^|;\s*)fixture_signed_out=1/.test(req.headers.cookie||'');
 // Local-only test sign-in so the real Sign Out -> Sign In flow can be tried with the fictional accounts (see PREVIEW-LOGIN.md).
 if(url.pathname==='/api/auth/login'&&req.method==='POST'){
  const body=await readBody(req);await new Promise(done=>setTimeout(done,900));
  const who=String(body.identifier||'').trim().toLowerCase(),member=team.find(item=>item.username===who||item.email===who);
  if(!member||body.password!==PREVIEW_PASSWORD)return send(res,401,{error:'Invalid sign-in details.'});
  slowNextWorks=true;
  return send(res,200,{user:withoutSecrets(member)},{'Set-Cookie':['fixture_user='+member.id+'; Path=/; SameSite=Lax','fixture_signed_out=; Path=/; Max-Age=0']});
 }
 if(url.pathname==='/api/auth/logout')return send(res,200,{ok:true},{'Set-Cookie':'fixture_signed_out=1; Path=/; SameSite=Lax'});
 if(signedOut&&url.pathname!=='/api/auth/status')return send(res,401,{error:'Sign in to continue.'});
 if(url.pathname==='/api/works'&&req.method==='GET'&&slowNextWorks){slowNextWorks=false;await new Promise(done=>setTimeout(done,1200));}
 const selected=Number((req.headers.cookie||'').match(/(?:^|;\s*)fixture_user=(\d+)/)?.[1]||1);
 const account=await require('../netlify/functions/lib/records').getMember(selected,fixtureStore)||user;
 if(url.pathname==='/api/auth/me')return send(res,200,{user:withoutSecrets(account)});
 if(!fixtureSessions.has(account.id))fixtureSessions.set(account.id,await createSession({...account,authVersion:1},fixtureStore));
 const session=fixtureSessions.get(account.id);
 const event={httpMethod:req.method,path:url.pathname,queryStringParameters:Object.fromEntries(url.searchParams),headers:{...req.headers,cookie:session.cookie['Set-Cookie'].split(';')[0]},body:req.method==='POST'?JSON.stringify(await readBody(req)):''};
 const handler=handlers[url.pathname.split('/')[2]];
 if(!handler)return send(res,404,{error:'Fixture endpoint not available.'});
 try{const result=await handler(event,fixtureStore);res.writeHead(result.statusCode,result.headers);res.end(result.body);}
 catch(error){send(res,error.statusCode||500,{error:error.statusCode?error.message:'Fixture request failed.'});}
}

const mime = { '.css': 'text/css; charset=utf-8', '.html': 'text/html; charset=utf-8', '.ico': 'image/x-icon', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${host}:${port}`);
  if(url.pathname==='/fixture-login'){
    const selected=Number(url.searchParams.get('user'));
    if(!team.some(member=>member.id===selected))return send(res,400,{error:'Unknown fictional account.'});
    res.writeHead(302,{'Location':'/','Set-Cookie':['fixture_user='+selected+'; Path=/; SameSite=Lax','fixture_signed_out=; Path=/; Max-Age=0']});res.end();return;
  }
  // Local push check: sends a real web push to the chosen account's devices (needs VAPID_* variables).
  if(url.pathname==='/fixture-push'){
    const selected=Number(url.searchParams.get('user')||1);
    try{const delivered=await require('../netlify/functions/lib/push').sendToUsers(fixtureStore,[selected],()=>({title:'TeamFlow test alert',body:'Web push reached this device while TeamFlow was closed.',tag:'teamflow-test-'+Date.now(),workId:works[0]?.id??null}));return send(res,200,{delivered});}
    catch(error){return send(res,500,{error:error.message});}
  }
  if (url.pathname.startsWith('/api/')) {
    try { await handleApi(req, res, url); }
    catch (error) { send(res, 400, { error: error.message }); }
    return;
  }
  // The preview installs as a separate "Actuarial TeamFlow Dev" app with DEV icons, like ActuarialPro Dev.
  if (url.pathname === '/manifest.json') {
    const manifest = JSON.parse(fs.readFileSync(path.join(publicDir, 'manifest.json'), 'utf8'));
    Object.assign(manifest, { name: 'Actuarial TeamFlow Dev', short_name: 'ATF Dev', description: 'Local development preview with fictional data' });
    res.writeHead(200, { 'Content-Type': 'application/manifest+json; charset=utf-8', 'Cache-Control': 'no-cache' }); res.end(JSON.stringify(manifest, null, 2)); return;
  }
  // Local preview: the service worker keeps push alerts but never serves cached app files, and a new version
  // takes over at once, so every reload shows the files on disk (no manual cache clearing).
  if (url.pathname === '/sw.js') {
    const prefix = "'use strict';\n// Preview-only prefix added by preview-fixture-server.js\n"
      + "self.addEventListener('install', () => self.skipWaiting());\n"
      + "self.addEventListener('activate', event => event.waitUntil(caches.keys().then(names => Promise.all(names.map(name => caches.delete(name)))).then(() => self.clients.claim())));\n"
      + "self.addEventListener('fetch', event => event.stopImmediatePropagation());\n";
    const worker = fs.readFileSync(path.join(publicDir, 'sw.js'), 'utf8').replace(/^'use strict';\s*/, '');
    res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache', 'Service-Worker-Allowed': '/' }); res.end(prefix + worker); return;
  }
  const devAsset = /^\/(favicon\.ico|icon-(16|32|48|192|512)\.png)$/.test(url.pathname) && path.join(__dirname, 'preview-assets', url.pathname.slice(1));
  if (devAsset && fs.existsSync(devAsset)) {
    res.writeHead(200, { 'Content-Type': mime[path.extname(devAsset)], 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' }); fs.createReadStream(devAsset).pipe(res); return;
  }
  const requested = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  const file = path.resolve(publicDir, `.${requested}`);
  if (!file.startsWith(publicDir + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404); res.end('Not found'); return;
  }
  res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
  fs.createReadStream(file).pipe(res);
});

server.listen(port, host, () => process.stdout.write(`Fictional TeamFlow preview at http://${host}:${port} (memory-only data)\n`));
server.on('error', error => { process.stderr.write(`${error.message}\n`); process.exitCode = 1; });
