'use strict';
class MemoryStore {
  constructor(entries = {}) { this.values = new Map(Object.entries(entries)); this.etags = new Map(Object.keys(entries).map(key=>[key,1])); }
  async get(key) { return this.values.has(key) ? this.values.get(key) : null; }
  async getWithMetadata(key, options = {}) {
    if (!this.values.has(key)) return null;
    const raw = this.values.get(key);
    return { data: options.type === 'json' ? JSON.parse(raw) : raw, etag: String(this.etags.get(key)), metadata: {} };
  }
  async set(key, value, options = {}) {
    if ((options.onlyIfNew && this.values.has(key)) || (options.onlyIfMatch && String(this.etags.get(key)) !== options.onlyIfMatch)) return { modified: false };
    this.values.set(key, value); this.etags.set(key, (this.etags.get(key) || 0) + 1);
    return { modified: true, etag: String(this.etags.get(key)) };
  }
  async delete(key) { this.values.delete(key); }
  async list({ prefix = '' } = {}) {
    return { blobs: [...this.values.keys()].filter(key => key.startsWith(prefix)).map(key => ({ key })) };
  }
}


module.exports={MemoryStore};
