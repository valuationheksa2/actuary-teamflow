'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const core = require('./migration-core');
const { checkedFetch } = require('../netlify/functions/lib/store');

function argumentsFor(argv) {
  const flags = new Set(['--dry-run', '--backup', '--rehearse', '--apply', '--finalize', '--restore', '--maintenance-confirmed']);
  const values = new Set(['--expect-site-id', '--source-hash', '--backup-file', '--backup-dir', '--site-url']);
  const result = {};
  for (let index = 0; index < argv.length; index++) {
    const key = argv[index];
    if (flags.has(key)) result[key] = true;
    else if (values.has(key) && argv[index + 1] && !argv[index + 1].startsWith('--')) result[key] = argv[++index];
    else throw new Error('Unknown argument or missing value. See PRODUCTION_DEPLOYMENT.md.');
  }
  const modes = [...flags].filter(key => key !== '--maintenance-confirmed' && result[key]);
  if (modes.length > 1) throw new Error('Choose one operation at a time.');
  result.mode = modes[0] || '--dry-run';
  return result;
}

function writeBackup(folder, siteID) {
  return async (encrypted, createdAt) => {
    fs.mkdirSync(folder, { recursive: true });
    const file = path.join(folder, `teamflow-${siteID || 'local'}-${createdAt.replace(/[:.]/g, '-')}-${crypto.randomBytes(4).toString('hex')}.json.enc`);
    fs.writeFileSync(file, encrypted, { flag: 'wx', mode: 0o600 });
    if (fs.readFileSync(file, 'utf8') !== encrypted) throw new Error('Backup file write verification failed.');
    return file;
  };
}

async function requireMaintenance(siteURL) {
  const origin = new URL(siteURL).origin;
  for (const pathname of ['/api/team', '/api/works', '/.netlify/functions/team', '/.netlify/functions/works']) {
    const result = await fetch(origin + pathname, { redirect: 'manual', signal: AbortSignal.timeout(15000) });
    const marked = result.status === 503 && result.headers.get('X-TeamFlow-Maintenance') === 'migration-v1';
    if (!marked && !(pathname.startsWith('/.netlify/functions/') && result.status === 404)) throw new Error('Maintenance API guard is not active. Publish the supplied maintenance deployment first.');
  }
}

async function openCheckedStore(args) {
  const siteID = process.env.NETLIFY_SITE_ID, token = process.env.NETLIFY_TOKEN;
  if (!siteID || !token || args['--expect-site-id'] !== siteID) throw new Error('Set site credentials and explicitly confirm the same Project ID.');
  const siteURL = args['--site-url'] || process.env.APP_URL;
  if (!siteURL || new URL(siteURL).protocol !== 'https:') throw new Error('Set the target HTTPS site address.');
  const result = await fetch(`https://api.netlify.com/api/v1/sites/${encodeURIComponent(siteID)}`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(15000) });
  if (!result.ok) throw new Error('Cannot verify the Netlify project. Check access credentials.');
  const project = await result.json(), origin = new URL(siteURL).origin;
  const addresses = [project.ssl_url, project.url, project.custom_domain && `https://${project.custom_domain}`].filter(Boolean).map(value => new URL(value).origin);
  if (project.id !== siteID || !addresses.includes(origin)) throw new Error('Project ID and site address do not match. No write was attempted.');
  if (['--apply', '--finalize', '--restore'].includes(args.mode)) {
    if (!args['--maintenance-confirmed']) throw new Error('Confirm the maintenance window before live writes.');
    await requireMaintenance(siteURL);
  }
  const { getStore } = require('@netlify/blobs');
  return getStore({ name: core.STORE_NAME, siteID, token, consistency: 'strong', fetch: checkedFetch });
}

async function main(argv = process.argv.slice(2)) {
  const args = argumentsFor(argv), mode = args.mode;
  const recovery = { passphrase: process.env.MIGRATION_BACKUP_PASSPHRASE, backupKey: process.env.MIGRATION_BACKUP_KEY };
  const folder = path.resolve(args['--backup-dir'] || path.join(__dirname, '..', 'backups'));
  let snapshot;
  if (['--rehearse', '--finalize', '--restore'].includes(mode)) {
    if (!args['--backup-file']) throw new Error('Select an encrypted backup file.');
    snapshot = await core.decryptBackup(fs.readFileSync(path.resolve(args['--backup-file']), 'utf8'), recovery);
    if (snapshot.format !== 2 || core.fingerprint(snapshot.entries) !== snapshot.sourceHash) throw new Error('Backup format or fingerprint is invalid.');
  }
  if (mode === '--rehearse') {
    const { MemoryStore } = require('./memory-store');
    const local = new MemoryStore(Object.fromEntries(snapshot.entries.map(row => [row.key, Buffer.from(row.data, 'base64')])));
    const localGet = local.get.bind(local);
    local.get = async (...parameters) => {
      const value = await localGet(...parameters);
      return Buffer.isBuffer(value) ? value.toString('utf8') : value;
    };
    const localRead = local.getWithMetadata.bind(local);
    local.getWithMetadata = async (key, options) => {
      const row = await localRead(key, options);
      if (row) row.metadata = snapshot.entries.find(entry => entry.key === key)?.metadata || {};
      return row;
    };
    const rehearsal = await core.migrateLegacyData(local, { ...recovery, apply: true, maintenanceConfirmed: true, expectedSourceHash: snapshot.sourceHash, siteID: snapshot.siteID, writeBackup: async () => 'Original encrypted backup retained; rehearsal data is memory-only.' });
    await core.finalizeMigration(local, snapshot);
    process.stdout.write(JSON.stringify({ ...rehearsal, rehearsal: 'local memory only; no network calls or live writes' }, null, 2) + '\n');
    return;
  }
  const store = await openCheckedStore(args), siteID = process.env.NETLIFY_SITE_ID;
  if (snapshot && snapshot.siteID !== siteID) throw new Error('Backup belongs to a different Netlify project.');
  let result;
  if (mode === '--backup') {
    snapshot = await core.readSnapshot(store, { siteID });
    result = { backupLocation: await core.backupSnapshot(snapshot, { ...recovery, writeBackup: writeBackup(folder, siteID) }), sourceHash: snapshot.sourceHash, entries: snapshot.entries.length, liveWrites: false };
  } else if (mode === '--finalize') result = await core.finalizeMigration(store, snapshot);
  else if (mode === '--restore') result = await core.restoreSnapshot(store, snapshot);
  else result = await core.migrateLegacyData(store, { ...recovery, siteID, apply: mode === '--apply', maintenanceConfirmed: Boolean(args['--maintenance-confirmed']), expectedSourceHash: args['--source-hash'], writeBackup: writeBackup(folder, siteID) });
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  if (mode === '--dry-run') process.stdout.write('Read-only inspection. No live records changed.\n');
  if (mode === '--apply') process.stdout.write('Passwords preserved. Keep maintenance enabled. Finalize with the APPLY backup before publishing the normal release. No administrator bootstrap or member resets are required.\n');
}

if (require.main === module) main().catch(error => {
  const message = String(error.message || '');
  const safe = /^(Unknown argument|Choose one|Supply a backup|Backup key|Use a backup|Cannot decrypt|Storage|Source data|A stored|Both legacy|Missing or duplicate|Invalid .* collection|Versioned data|No active|Member IDs|Account |An account|Password conversion|Work \d+|An encrypted|Encrypted backup|Migration writes|Fingerprint|Another migration|Migration did not finish|Verified migration|An imported|Legacy data|Finalize marker|Legacy removal|Unsupported or damaged|Restore requires|New data exists|Restore verification|Set site|Set the target|Cannot verify|Project ID|Maintenance API|Confirm the maintenance|Select an encrypted|Backup format|Backup belongs|Backup file)/.test(message);
  process.stderr.write((safe ? message : 'Operation failed. Check file paths, connectivity, credentials, and the deployment guide. Keep maintenance enabled if a write was started.') + '\n');
  process.exitCode = 1;
});
module.exports = { argumentsFor, main, requireMaintenance };
