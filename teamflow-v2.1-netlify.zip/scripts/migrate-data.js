'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { STORE_NAME, migrateLegacyData } = require('./migration-core');

async function main() {
  if (!process.env.NETLIFY_SITE_ID || !process.env.NETLIFY_TOKEN) throw new Error('Set NETLIFY_SITE_ID and NETLIFY_TOKEN for the intended Netlify site.');
  const { getStore } = require('@netlify/blobs');
  const store = getStore({ name: STORE_NAME, siteID: process.env.NETLIFY_SITE_ID, token: process.env.NETLIFY_TOKEN, consistency: 'strong' });
  const apply = process.argv.includes('--apply');
  const result = await migrateLegacyData(store, {
    apply,
    backupKey: process.env.MIGRATION_BACKUP_KEY,
    writeBackup: async (encrypted, createdAt) => {
      const backupFolder = path.resolve(__dirname, '..', 'backups');
      fs.mkdirSync(backupFolder, { recursive: true });
      const timestamp = createdAt.replace(/[:.]/g, '-');
      const backupPath = path.join(backupFolder, `teamflow-legacy-${timestamp}.json.enc`);
      fs.writeFileSync(backupPath, encrypted, { flag: 'wx' });
      return backupPath;
    },
  });
  const counts = result.counts;
  process.stdout.write(`Found ${counts.members} members, ${counts.works} work items, and ${counts.joinRequests + counts.templates + counts.feedbackItems} supporting records.\n`);
  if (!result.applied) {
    process.stdout.write('Dry run only. No Netlify Blobs were changed. Re-run with --apply only after an explicit migration approval.\n');
    return;
  }
  process.stdout.write(`Migration verified. Encrypted backup: ${result.backupLocation}\n`);
  process.stdout.write('Imported accounts require password reset. Bootstrap an administrator using ADMIN_BOOTSTRAP_TOKEN, then issue member invitations.\n');
}

if (require.main === module) {
  main().catch(error => {
    process.stderr.write(`${error.message}\n`);
    process.exitCode = 1;
  });
}

module.exports = { main };
