'use strict';

const crypto = require('node:crypto');

const STORE_NAME = 'teamflow-data';
const LEGACY_KEYS = ['team', 'works'];
const COLLECTIONS = ['joinRequests', 'templates', 'feedbackItems'];

function parse(raw, fallback) {
  if (!raw) return fallback;
  try { return JSON.parse(raw); }
  catch { throw new Error('A legacy data record is not valid JSON; no data was changed.'); }
}

function decodeBackupKey(value) {
  if (!value) throw new Error('Set MIGRATION_BACKUP_KEY to a 32-byte key (64 hexadecimal characters) before applying migration.');
  const key = /^[a-f0-9]{64}$/i.test(value) ? Buffer.from(value, 'hex') : Buffer.from(value, 'base64');
  if (key.length !== 32) throw new Error('MIGRATION_BACKUP_KEY must decode to exactly 32 bytes.');
  return key;
}

function encryptedBackup(payload, key) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(payload), 'utf8'), cipher.final()]);
  return JSON.stringify({ algorithm: 'aes-256-gcm', iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), ciphertext: ciphertext.toString('base64') });
}

function legacyRecords(rawTeam, rawWorks) {
  const legacyTeam = parse(rawTeam, []);
  const bundle = parse(rawWorks, {});
  const members = Array.isArray(legacyTeam) ? legacyTeam : [];
  const works = Array.isArray(bundle) ? bundle : (Array.isArray(bundle.data) ? bundle.data : []);
  const metadata = Array.isArray(bundle) ? {} : bundle;
  for (const member of members) if (!member || member.id == null) throw new Error('A legacy member is missing its ID; no data was changed.');
  for (const work of works) if (!work || work.id == null) throw new Error('A legacy work item is missing its ID; no data was changed.');
  return { members, works, metadata };
}

async function migrateLegacyData(store, options = {}) {
  const [rawTeam, rawWorks] = await Promise.all(LEGACY_KEYS.map(key => store.get(key, { consistency: 'strong' })));
  const { members, works, metadata } = legacyRecords(rawTeam, rawWorks);
  const counts = { members: members.length, works: works.length, joinRequests: (metadata.joinRequests || []).length, templates: (metadata.templates || []).length, feedbackItems: (metadata.feedbackItems || []).length };
  if (!options.apply) return { counts, applied: false };

  const key = decodeBackupKey(options.backupKey);
  const createdAt = (options.now || (() => new Date()))().toISOString();
  const backup = encryptedBackup({ rawTeam: rawTeam || null, rawWorks: rawWorks || null, createdAt }, key);
  if (typeof options.writeBackup !== 'function') throw new Error('An encrypted backup writer is required before migration can run.');
  const backupLocation = await options.writeBackup(backup, createdAt);

  for (const member of members) {
    const data = { ...member, username: member.username || member.email || '', passwordHash: null, mustResetPassword: true, authVersion: (Number(member.authVersion) || 1) + 1, active: member.active !== false, weeklyCapacityHours: Number(member.weeklyCapacityHours) || 40, version: undefined };
    delete data.password;
    delete data.version;
    await store.set(`v2:member:${member.id}`, JSON.stringify({ data, version: 1, updatedAt: createdAt }));
  }
  for (const work of works) {
    const data = { ...work, estimatedHours: Number(work.estimatedHours) || 0, version: undefined };
    delete data.version;
    await store.set(`v2:work:${work.id}`, JSON.stringify({ data, version: 1, updatedAt: createdAt }));
  }
  for (const name of COLLECTIONS) {
    await store.set(`v2:collection:${name}`, JSON.stringify({ items: Array.isArray(metadata[name]) ? metadata[name] : [], version: 1, updatedAt: createdAt }));
  }

  const [memberKeys, workKeys] = await Promise.all([store.list({ prefix: 'v2:member:' }), store.list({ prefix: 'v2:work:' })]);
  if (memberKeys.blobs.length !== counts.members || workKeys.blobs.length !== counts.works) {
    throw new Error(`Migration verification failed. Encrypted backup is saved at ${backupLocation}; legacy keys were retained.`);
  }
  await store.set('v2:meta:migratedAt', JSON.stringify({ at: createdAt, counts }));
  for (const prefix of ['auth:session:', 'auth:reset:']) {
    const { blobs = [] } = await store.list({ prefix });
    await Promise.all(blobs.map(blob => store.delete(blob.key)));
  }
  for (const keyName of LEGACY_KEYS) await store.delete(keyName);
  return { counts, applied: true, backupLocation };
}

module.exports = { COLLECTIONS, LEGACY_KEYS, STORE_NAME, decodeBackupKey, encryptedBackup, legacyRecords, migrateLegacyData, parse };
