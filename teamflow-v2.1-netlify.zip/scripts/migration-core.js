'use strict';

const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { passwordHash, verifyPassword } = require('../netlify/functions/lib/auth-core');
const { normalizeWork } = require('../netlify/functions/works')._test;
const scrypt = promisify(crypto.scrypt);
const STORE_NAME = 'teamflow-data';
const LEGACY_KEYS = ['team', 'works'];
const COLLECTIONS = ['joinRequests', 'templates', 'feedbackItems'];
const MARKER_KEY = 'v2:meta:migratedAt';
const REFERENCE_FIELDS = new Set(['userId', 'memberId', 'authorId', 'actorId', 'ownerId', 'pic', 'createdBy', 'updatedBy', 'completedBy', 'approvedBy', 'requestedBy', 'resolvedBy', 'assignedBy']);
const REFERENCE_ARRAYS = new Set(['assignees', 'memberIds', 'userIds']);

function parse(raw, fallback) {
  if (raw == null) return fallback;
  try { return JSON.parse(raw); } catch { throw new Error('A stored record is not valid JSON. Migration stopped.'); }
}

function decodeBackupKey(value) {
  if (!value) throw new Error('Supply a backup recovery key.');
  const key = /^[a-f0-9]{64}$/i.test(value) ? Buffer.from(value, 'hex') : Buffer.from(value, 'base64');
  if (key.length !== 32) throw new Error('Backup key must decode to exactly 32 bytes.');
  return key;
}

function encryptedBackup(payload, key, extra = {}) {
  const iv = crypto.randomBytes(12), cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(payload), 'utf8'), cipher.final()]);
  return JSON.stringify({ algorithm: 'aes-256-gcm', ...extra, iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), ciphertext: ciphertext.toString('base64') });
}

async function sealBackup(payload, options) {
  if (!options.passphrase) return encryptedBackup(payload, decodeBackupKey(options.backupKey), { format: 2 });
  if (options.passphrase.length < 16) throw new Error('Use a backup passphrase of at least 16 characters, separate from account passwords.');
  const salt = crypto.randomBytes(16);
  const key = await scrypt(options.passphrase, salt, 32, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
  return encryptedBackup(payload, key, { kdf: 'scrypt', salt: salt.toString('base64'), format: 2 });
}

async function decryptBackup(encoded, options) {
  try {
    const e = JSON.parse(encoded);
    if (e.algorithm !== 'aes-256-gcm') throw new Error('Unsupported backup.');
    const key = e.kdf === 'scrypt' ? await scrypt(options.passphrase || '', Buffer.from(e.salt, 'base64'), 32, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }) : decodeBackupKey(options.backupKey);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(e.iv, 'base64'));
    decipher.setAuthTag(Buffer.from(e.tag, 'base64'));
    return JSON.parse(Buffer.concat([decipher.update(Buffer.from(e.ciphertext, 'base64')), decipher.final()]).toString('utf8'));
  } catch { throw new Error('Cannot decrypt backup. Check its integrity and recovery passphrase/key.'); }
}

function fingerprint(entries) {
  const hash = crypto.createHash('sha256');
  for (const row of [...entries].sort((a, b) => a.key.localeCompare(b.key))) hash.update(JSON.stringify([row.key, row.data, row.metadata || {}]));
  return hash.digest('hex');
}

async function readSnapshot(store, options = {}) {
  const entries = [];
  for (const blob of (await store.list()).blobs || []) {
    const row = await store.getWithMetadata(blob.key, { type: 'arrayBuffer', consistency: 'strong' });
    if (!row || !row.etag) throw new Error('Storage changed while reading. Stop edits and retry.');
    entries.push({ key: blob.key, data: Buffer.from(row.data).toString('base64'), metadata: row.metadata || {}, etag: row.etag });
  }
  const keys = ((await store.list()).blobs || []).map(row => row.key).sort();
  if (JSON.stringify(keys) !== JSON.stringify(entries.map(row => row.key).sort())) throw new Error('Storage keys changed while reading. Stop edits and retry.');
  await assertSourceUnchanged(store, { entries });
  return { format: 2, storeName: STORE_NAME, siteID: options.siteID || null, createdAt: new Date().toISOString(), entries, sourceHash: fingerprint(entries) };
}

function rawValue(snapshot, key) {
  const entry = snapshot.entries.find(row => row.key === key);
  return entry ? Buffer.from(entry.data, 'base64').toString('utf8') : null;
}

function legacyRecords(rawTeam, rawWorks) {
  const members = parse(rawTeam, null), bundle = parse(rawWorks, null);
  if (!Array.isArray(members) || (!Array.isArray(bundle) && (!bundle || !Array.isArray(bundle.data)))) throw new Error('Both legacy team and works must exist with the expected structure.');
  const works = Array.isArray(bundle) ? bundle : bundle.data, metadata = Array.isArray(bundle) ? {} : bundle;
  for (const [type, rows] of [['member', members], ['work', works]]) {
    const ids = new Set();
    for (const row of rows) {
      if (!row || row.id == null || ids.has(String(row.id))) throw new Error(`Missing or duplicate ${type} ID.`);
      ids.add(String(row.id));
    }
  }
  for (const name of COLLECTIONS) if (metadata[name] != null && !Array.isArray(metadata[name])) throw new Error(`Invalid ${name} collection.`);
  return { members, works, metadata };
}

function remapReferences(value, idMap, field = '') {
  if (REFERENCE_FIELDS.has(field) && (typeof value === 'number' || typeof value === 'string')) return idMap.get(String(value)) ?? value;
  if (REFERENCE_ARRAYS.has(field) && Array.isArray(value)) return value.map(id => idMap.get(String(id)) ?? id);
  if (Array.isArray(value)) return value.map(item => remapReferences(item, idMap));
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, remapReferences(item, idMap, key)]));
  return value;
}

async function prepareMigration(snapshot) {
  const { members, works, metadata } = legacyRecords(rawValue(snapshot, 'team'), rawValue(snapshot, 'works'));
  if (snapshot.entries.some(row => /^(v2:|v3:)/.test(row.key))) throw new Error('Versioned data already exists. Inspect or restore the previous migration before proceeding.');
  if (!members.some(row => row.role === 'admin' && row.active !== false)) throw new Error('No active administrator found.');
  const used = new Set(members.map(row => String(row.id))), idMap = new Map();
  let nextID = 1;
  for (const member of members) {
    if (!Number.isSafeInteger(member.id) || member.id < 0) throw new Error('Member IDs need manual review.');
    if (member.id === 0) {
      while (used.has(String(nextID))) nextID++;
      idMap.set('0', nextID); used.add(String(nextID));
    }
  }
  const identifiers = new Map(), accounts = [];
  let passwordsConverted = 0, hashesPreserved = 0;
  for (const original of members) {
    const member = remapReferences(original, idMap);
    member.id = idMap.get(String(original.id)) ?? original.id;
    member.username = String(member.username || member.email || '').trim().toLowerCase();
    member.email = String(member.email || '').trim().toLowerCase();
    if (!member.name || !['admin', 'board', 'manager', 'member'].includes(member.role)) throw new Error('An account name or role needs review.');
    if (!/^(?:[a-z0-9._-]{1,64}|[^\s@]+@[^\s@]+\.[^\s@]+)$/.test(member.username)) throw new Error(`Account ${member.id} has an unsupported username.`);
    if (member.email && !/^\S+@\S+\.\S+$/.test(member.email)) throw new Error(`Account ${member.id} has an invalid email.`);
    for (const identifier of new Set([member.username, member.email].filter(Boolean))) {
      if (identifiers.has(identifier) && identifiers.get(identifier) !== member.id) throw new Error('Account identifiers collide.');
      identifiers.set(identifier, member.id);
    }
    if (/^scrypt\$[a-f0-9]{32}\$[a-f0-9]{128}$/i.test(member.passwordHash || '')) hashesPreserved++;
    else {
      if (typeof member.password !== 'string' || !member.password.length || member.password.length > 128) throw new Error(`Account ${member.id} has no supported password to preserve.`);
      member.passwordHash = await passwordHash(member.password);
      if (!await verifyPassword(member.password, member.passwordHash)) throw new Error('Password conversion verification failed.');
      passwordsConverted++;
    }
    member.mustResetPassword = false;
    member.active = member.active !== false;
    member.authVersion = (Number(member.authVersion) || 1) + 1;
    member.weeklyCapacityHours = member.weeklyCapacityHours == null ? 40 : Number(member.weeklyCapacityHours);
    if (!Number.isFinite(member.weeklyCapacityHours) || member.weeklyCapacityHours < 0 || member.weeklyCapacityHours > 168) throw new Error('An account capacity needs manual review.');
    delete member.password; delete member.resetToken; delete member.version;
    accounts.push(member);
  }
  const newWorks = works.map(original => {
    const work = remapReferences(original, idMap);
    if (Array.isArray(work.notes)) work.notes = work.notes.map(note => {
      const matches = accounts.filter(member => member.name === (note.authorName || note.author));
      return { ...note, ...(note.authorId == null && matches.length === 1 ? { authorId: matches[0].id } : {}), authorName: note.authorName || note.author || 'Unknown', createdDate: note.createdDate || note.date || null };
    });
    work.estimatedHours = work.estimatedHours == null || work.estimatedHours === '' ? 0 : Number(work.estimatedHours);
    work.workType = work.workType || 'regular';
    normalizeWork(work); // Validate only; retain all original note/file metadata.
    if ((work.assignees || []).some(id => !Number.isFinite(id)) || (work.tags || []).length > 30 || (work.notes || []).length > 500 || (work.files || []).length > 200 || String(work.desc || '').length > 10000 || (work.notes || []).some(n => String(n.text || '').length > 5000 || String(n.authorName || '').length > 120) || Object.keys(work.phaseTasks || {}).length > 4 || Object.values(work.phaseTasks || {}).some(tasks => !Array.isArray(tasks) || tasks.length > 50 || tasks.some(t => String(t).length > 240))) throw new Error(`Work ${work.id} exceeds current limits; manual review is required to preserve it.`);
    delete work.version;
    return work;
  });
  const mappedMetadata = remapReferences(metadata, idMap);
  const collections = Object.fromEntries(COLLECTIONS.map(name => [name, mappedMetadata[name] || []]));
  collections.feedbackItems = collections.feedbackItems.map(item => {
    const matches = accounts.filter(member => member.name === item.author);
    return item.authorId == null && matches.length === 1 ? { ...item, authorId: matches[0].id } : item;
  });
  const counts = { members: accounts.length, works: newWorks.length, ...Object.fromEntries(COLLECTIONS.map(name => [name, collections[name].length])) };
  return { accounts, works: newWorks, collections, extraMetadata: Object.fromEntries(Object.entries(mappedMetadata).filter(([key]) => key !== 'data' && !COLLECTIONS.includes(key))), counts, passwordsConverted, hashesPreserved, idRemap: Object.fromEntries(idMap) };
}

async function backupSnapshot(snapshot, options) {
  if (typeof options.writeBackup !== 'function') throw new Error('An encrypted local backup writer is required.');
  const encrypted = await sealBackup(snapshot, options), restored = await decryptBackup(encrypted, options);
  if (fingerprint(restored.entries) !== snapshot.sourceHash) throw new Error('Encrypted backup verification failed.');
  return options.writeBackup(encrypted, snapshot.createdAt);
}

async function assertSourceUnchanged(store, snapshot) {
  for (const entry of snapshot.entries) {
    const current = await store.getWithMetadata(entry.key, { type: 'arrayBuffer', consistency: 'strong' });
    if (!current || current.etag !== entry.etag) throw new Error('Source data changed during migration. Keep maintenance enabled and review/restore the backup.');
  }
}

async function migrateLegacyData(store, options = {}) {
  const snapshot = await readSnapshot(store, options), plan = await prepareMigration(snapshot);
  const summary = { counts: plan.counts, sourceHash: snapshot.sourceHash, passwordsConverted: plan.passwordsConverted, hashesPreserved: plan.hashesPreserved, idRemap: plan.idRemap };
  if (!options.apply) return { ...summary, applied: false };
  if (!options.maintenanceConfirmed) throw new Error('Migration writes require maintenance confirmation.');
  if (options.expectedSourceHash !== snapshot.sourceHash) throw new Error('Fingerprint differs from the reviewed dry run. Inspect again.');
  const backupLocation = await backupSnapshot(snapshot, options);
  await assertSourceUnchanged(store, snapshot);
  const createdAt = new Date().toISOString(), writes = new Map();
  for (const member of plan.accounts) writes.set(`v2:member:${member.id}`, JSON.stringify({ data: member, version: 1, updatedAt: createdAt }));
  for (const work of plan.works) writes.set(`v2:work:${work.id}`, JSON.stringify({ data: work, version: 1, updatedAt: createdAt }));
  for (const name of COLLECTIONS) writes.set(`v2:collection:${name}`, JSON.stringify({ items: plan.collections[name], version: 1, updatedAt: createdAt }));
  // Activate the canonical account directory last.
  writes.set('v3:team-directory', JSON.stringify({ records: Object.fromEntries(plan.accounts.map(member => [String(member.id), { data: member, version: 1 }])), updatedAt: createdAt }));
  const recordHashes = Object.fromEntries([...writes].map(([key, value]) => [key, crypto.createHash('sha256').update(value).digest('hex')]));
  const marker = { format: 2, state: 'preparing', at: createdAt, ...summary, siteID: options.siteID || null, createdKeys: [...writes.keys(), MARKER_KEY], recordHashes, originalKeys: snapshot.entries.map(row => row.key), extraMetadata: plan.extraMetadata };
  const claimed = await store.set(MARKER_KEY, JSON.stringify(marker), { onlyIfNew: true });
  if (!claimed.modified) throw new Error('Another migration exists. No records were overwritten.');
  try {
    for (const [key, value] of writes) if (!(await store.set(key, value, { onlyIfNew: true })).modified) throw new Error('A target record exists.');
    for (const [key, value] of writes) if (await store.get(key, { consistency: 'strong' }) !== value) throw new Error('Record verification failed.');
    await assertSourceUnchanged(store, snapshot);
    marker.state = 'verified';
    if (!(await store.set(MARKER_KEY, JSON.stringify(marker), { onlyIfMatch: claimed.etag })).modified) throw new Error('Marker changed.');
  } catch { throw new Error(`Migration did not finish. Keep maintenance enabled and use Restore with this backup: ${backupLocation}. Do not publish the normal release.`); }
  return { ...summary, applied: true, backupLocation, legacyRetained: true };
}

async function finalizeMigration(store, snapshot) {
  const row = await store.getWithMetadata(MARKER_KEY, { type: 'json', consistency: 'strong' }), marker = row?.data;
  if (!marker || marker.format !== 2 || marker.state !== 'verified' || marker.sourceHash !== snapshot.sourceHash) throw new Error('Verified migration does not match this backup.');
  for (const key of marker.createdKeys.filter(key => key !== MARKER_KEY)) {
    const value = await store.get(key, { consistency: 'strong' });
    if (!value || crypto.createHash('sha256').update(value).digest('hex') !== marker.recordHashes?.[key]) throw new Error('An imported record changed or is missing. Keep maintenance enabled and review it.');
  }
  for (const key of LEGACY_KEYS) {
    const raw = await store.get(key, { consistency: 'strong' });
    if (raw != null && raw !== rawValue(snapshot, key)) throw new Error('Legacy data changed. Keep maintenance enabled.');
  }
  for (const key of LEGACY_KEYS) await store.delete(key);
  for (const { key } of (await store.list()).blobs || []) if (/^auth:(session|reset|account-link):/.test(key)) await store.delete(key);
  marker.state = 'finalized';
  if (!(await store.set(MARKER_KEY, JSON.stringify(marker), { onlyIfMatch: row.etag })).modified) throw new Error('Finalize marker changed. Keep maintenance enabled.');
  for (const key of LEGACY_KEYS) if (await store.get(key, { consistency: 'strong' }) !== null) throw new Error('Legacy removal verification failed.');
  return { finalized: true, counts: marker.counts };
}

async function restoreSnapshot(store, snapshot) {
  if (snapshot.format !== 2 || fingerprint(snapshot.entries) !== snapshot.sourceHash) throw new Error('Unsupported or damaged backup.');
  const marker = parse(await store.get(MARKER_KEY, { consistency: 'strong' }), null);
  if (!marker || marker.format !== 2 || marker.sourceHash !== snapshot.sourceHash) throw new Error('Restore requires the migration created from this exact backup.');
  const allowed = new Set([...snapshot.entries.map(r => r.key), ...marker.createdKeys]);
  for (const { key } of (await store.list()).blobs || []) if (!allowed.has(key) && !/^auth:/.test(key)) throw new Error('New data exists after the backup. Manual reconciliation is required before rollback.');
  for (const key of marker.createdKeys.filter(key => key !== MARKER_KEY)) {
    const value = await store.get(key, { consistency: 'strong' });
    if (value && crypto.createHash('sha256').update(value).digest('hex') !== marker.recordHashes?.[key]) throw new Error('New data exists in an edited migration record. Manual reconciliation is required before rollback.');
  }
  for (const entry of snapshot.entries) {
    await store.set(entry.key, Buffer.from(entry.data, 'base64'), { metadata: entry.metadata || {} });
    const read = await store.getWithMetadata(entry.key, { type: 'arrayBuffer', consistency: 'strong' });
    if (!read || Buffer.from(read.data).toString('base64') !== entry.data) throw new Error('Restore verification failed. Keep maintenance enabled.');
  }
  for (const key of marker.createdKeys.filter(key => key !== MARKER_KEY)) await store.delete(key);
  for (const { key } of (await store.list()).blobs || []) if (/^auth:/.test(key) && !snapshot.entries.some(row => row.key === key)) await store.delete(key);
  await store.delete(MARKER_KEY);
  return { restored: true, entries: snapshot.entries.length };
}

module.exports = { COLLECTIONS, LEGACY_KEYS, STORE_NAME, backupSnapshot, decodeBackupKey, decryptBackup, encryptedBackup, finalizeMigration, fingerprint, legacyRecords, migrateLegacyData, parse, prepareMigration, rawValue, readSnapshot, remapReferences, restoreSnapshot };
