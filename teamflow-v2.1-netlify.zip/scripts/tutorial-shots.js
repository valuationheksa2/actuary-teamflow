'use strict';
// Generates the Help tutorial pictures from the local preview (fictional fixture data only).
// Usage: start the preview (PORT=8890 node scripts/preview-fixture-server.js), then: node scripts/tutorial-shots.js [title filter]
// Every tutorial step with a target in HELP_TUTORIALS (public/js/tutorials.js) gets a picture: the page opens, the step's
// setup below runs, the target is spotlit with the same finder the in-app "Show me" button uses (tutFind), and a JPEG is
// saved to public/img/tutorials/<tutorial-slug>-<step>.jpg.
const path = require('path');
const { chromium } = require('playwright');
const BASE = process.env.PREVIEW_URL || 'http://127.0.0.1:8890';
const OUT = path.join(__dirname, '..', 'public', 'img', 'tutorials');
const W = 1280, H = 800;

// Setup per tutorial title and step (0-based), run in the page after it opens. Helpers live in HELPERS below.
const ADD = 'openAddWork()';
const PLAN = "H.work(w=>w.status==='ongoing'&&w.phase===0)";
const EXEC = "H.work(w=>w.status==='ongoing'&&w.phase===1)";
const REVIEW = "H.work(w=>w.status==='ongoing'&&w.phase===2)";
const FINAL = "H.work(w=>w.status==='ongoing'&&w.phase===3)";
const DONE = "H.work(w=>w.status==='done')";
const FILES = "H.work(w=>w.status==='ongoing'&&(w.files||[]).length)||" + PLAN;
const PROFILE = 'openMyProfile()';
const MEETING = "H.meeting(m=>m.status!=='cancelled'&&new Date(m.startsAt)>new Date())";
const PAST_MEETING = "H.meetingTab('Past');H.meeting(m=>m.status!=='cancelled'&&new Date(m.startsAt)<new Date())";
const SETUP = {
  'Create a work item': [null, ADD, ADD, ADD, ADD, ADD],
  'Move work through its phases': [null, PLAN, PLAN, EXEC, REVIEW],
  'Approve or send back work in Review': [null, REVIEW, REVIEW, REVIEW, REVIEW, "H.selfReview()"],
  'Add notes and file links': [null, PLAN + ";H.tab('Notes')", PLAN, PLAN + ";openAddFile(H.pick(w=>w.status==='ongoing'&&w.phase===0).id)", FILES],
  'Change who is working on it': [PLAN, "H.asMember();H.work(w=>w.status==='ongoing'&&!w.assignees.includes(currentUser.id)&&!joinRequests.some(r=>r.workId===w.id&&r.userId===currentUser.id&&r.status==='pending'))", "H.asMember();H.work(w=>w.status==='ongoing'&&w.assignees.includes(currentUser.id)&&w.pic!==currentUser.id)", null],
  'Complete work': [FINAL, FINAL, "openCompleteWork(H.pick(w=>w.status==='ongoing'&&w.phase===3).id)", "openCompleteWork(H.pick(w=>w.status==='ongoing'&&w.phase===3).id)", DONE],
  'Read the Performance tab on completed work': [DONE, DONE + ";H.tab('Performance')", DONE + ";H.tab('Performance')", DONE + ";H.tab('Performance')", DONE + ";H.tab('Performance')"],
  'Find work quickly': [null, null, null, null, null],
  'Update your profile': [null, PROFILE, PROFILE, PROFILE],
  'Turn on notifications': [PROFILE, PROFILE + ";H.click('Notifications')", PROFILE + ";H.click('Notifications')", PROFILE + ";H.click('Notifications')"],
  'Add or change a team member': [null, 'openAddMember()', null, null],
  'Use the calendar': [null, null, null, "H.dayWithWork()"],
  'Schedule a meeting': [null, 'openMeetingForm()', 'openMeetingForm()', 'openMeetingForm()', 'openMeetingForm()', 'openMeetingForm()'],
  'Get reminded': [PROFILE + ";H.click('Notifications')", null, 'H.showBanners()', MEETING],
  'Record minutes and action points': [null, PAST_MEETING, PAST_MEETING, PAST_MEETING, PAST_MEETING],
  'Change or cancel a meeting': [null, MEETING, MEETING],
  'Check who has room': [null, null, "document.querySelectorAll('.cap-row')[1].querySelector('.cap-toggle').click()", null],
  'Open a teammate’s profile': [null, "openMemberProfile(TEAM.find(m=>m.role==='member').id)", "openMemberProfile(TEAM.find(m=>m.role==='member').id)"],
  'Record leave and public holidays': [null, 'openAbsences()', 'openAbsences()', null, 'openAbsences()'],
  'Look at past work and the team': [null, DONE + ";H.tab('History')", null],
  'Create a template': [null, ADD, ADD + ";H.saveAsTemplate()"],
  'Use or edit a template': [null, null, null],
  'Set up recurring work': [ADD, null, null],
  'Search from the title bar': ['H.wco()', "H.wco();H.qo('')", "H.wco();H.qo('overdue')", "H.wco();H.qo('')", "H.wco();H.qo('ifrs')"],
  'Use the installed app’s title bar': ['H.wco()', 'H.wco()', "H.wco();H.menu('View')", 'H.wco()', 'H.wco()'],
  'Record a meeting that already happened': [null, 'openMeetingForm();H.heldMeeting()', 'openMeetingForm();H.heldMeeting()', 'openMeetingForm();H.heldMeeting()', PAST_MEETING],
  'See team performance': [null, "H.click('Performance')", "H.click('Performance')", "H.click('Performance')", "H.click('Performance')", "H.click('Performance')", "H.click('Performance')"],
};
// Some steps show a different page from the tutorial's own.
const PAGE = {
  'Change who is working on it': [null, null, null, 'requests'],
  'Look at past work and the team': [null, null, 'team'],
  'Set up recurring work': [null, null, 'templates'],
  'Update your profile': ['dashboard'],
  'Turn on notifications': ['dashboard', 'dashboard', 'dashboard', 'dashboard'],
  'Get reminded': [null, null, 'dashboard'],
};

const HELPERS = () => {
  const vis = el => el && el.offsetParent !== null;
  window.H = {
    pick: pred => works.find(pred),
    work: pred => { const w = works.find(pred); if (w) openWorkDetail(w.id); return !!w; },
    tab: label => { const t = [...document.querySelectorAll('#modal-overlay .tab, #modal-overlay [role=tab]')].find(el => vis(el) && el.textContent.trim().startsWith(label)); t && t.click(); },
    click: label => { const b = [...document.querySelectorAll('#modal-overlay button, #modal-overlay .tab, #content button, #content .tab, #content [role=tab]')].find(el => vis(el) && el.textContent.replace(/\s+/g, ' ').trim() === label); b && b.click(); },
    asMember: () => { window.__admin = window.__admin || currentUser; currentUser = TEAM.find(m => m.role === 'member'); },
    selfReview: () => { const w = works.find(x => x.status === 'ongoing' && x.phase === 2); window.__admin = window.__admin || currentUser; currentUser = TEAM.find(m => m.id === w.pic) || currentUser; openSignOff(w.id, 'approve'); },
    meetingTab: label => H.click(label),
    meeting: pred => { const list = (typeof meetings !== 'undefined' ? meetings : []).filter(pred).sort((a, b) => String(a.startsAt).localeCompare(String(b.startsAt))); const m = list[0]; if (m) openMeetingDetail(m.id); return !!m; },
    dayWithWork: () => { const w = works.find(x => x.status === 'upcoming' && x.startDate); if (w) showDayEvents(w.startDate); },
    showBanners: () => document.getElementById('tut-shot-hide')?.remove(),
    // The title bar only shows in the installed app (window controls overlay). For its pictures the bar's CSS is
    // switched on in the page and a few teammates are marked online; H.unwco() restores it between pictures.
    wco: () => {
      document.querySelectorAll('style').forEach(s => {
        if (s.dataset.wcoOrig || !s.textContent.includes('display-mode: window-controls-overlay')) return;
        s.dataset.wcoOrig = s.textContent;
        s.textContent = s.textContent.replace(/@media not \(display-mode: window-controls-overlay\)\{[^}]*\}\}/, '').split('@media (display-mode: window-controls-overlay){').join('@media all{');
      });
      teamPresence = Object.fromEntries(TEAM.filter(m => m.id !== currentUser.id).slice(0, 3).map(m => [String(m.id), Date.now()]));
      window.dispatchEvent(new CustomEvent('tf-session'));
    },
    unwco: () => document.querySelectorAll('style[data-wco-orig]').forEach(s => { s.textContent = s.dataset.wcoOrig; delete s.dataset.wcoOrig; }),
    qo: text => { const input = document.querySelector('.tb-search input'); input.focus(); if (text) { input.value = text; input.dispatchEvent(new Event('input')); } },
    menu: label => { const b = [...document.querySelectorAll('.app-titlebar .tb-menu')].find(el => el.textContent.trim() === label); b && b.click(); },
    heldMeeting: () => {
      const d = new Date(Date.now() - 86400000), ymd = d.toISOString().slice(0, 10);
      const set = (id, v) => { const el = document.getElementById(id); if (el) { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); } };
      set('mf-title', 'Reserving assumptions catch-up'); set('mf-date', ymd); set('mf-time', '10:00');
    },
    saveAsTemplate: () => { const t = document.getElementById('f-title'); if (t && !t.value) t.value = 'Monthly reserve roll-forward'; H.click('Save as Template'); },
  };
};

(async () => {
  const filter = (process.argv[2] || '').toLowerCase();
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1.5, reducedMotion: 'reduce' });
  page.on('pageerror', e => console.warn('page error:', e.message));
  page.on('dialog', d => d.dismiss());
  // Report the installed-app display mode so the title bar is built; its CSS stays hidden until H.wco() switches it on.
  await page.addInitScript(() => { const mm = window.matchMedia.bind(window); window.matchMedia = q => /display-mode:\s*(standalone|window-controls-overlay)/.test(q) ? mm('all') : mm(q); });
  await page.goto(BASE + '/fixture-login?user=1');
  await page.waitForTimeout(2500);
  await page.evaluate(HELPERS);
  const list = await page.evaluate(() => Object.values(HELP_TUTORIALS).flat().filter(t => t.targets).map(t => ({ title: t.title, page: t.page || 'dashboard', targets: t.targets, shots: t.shots })));
  let saved = 0;
  for (const tutorial of list) {
    if (filter && !tutorial.title.toLowerCase().includes(filter)) continue;
    for (let i = 0; i < tutorial.targets.length; i++) {
      const target = tutorial.targets[i], name = tutorial.shots[i];
      if (!target) continue;
      await page.evaluate(() => {
        document.querySelectorAll('dialog.app-dialog[open] [data-cancel]').forEach(b => b.click());
        if (window.__admin) { currentUser = window.__admin; window.__admin = null; }
        for (let n = 0; n < 3 && document.getElementById('modal-overlay').style.display === 'flex'; n++) closeModal();
        if (typeof closeTutorial === 'function') closeTutorial();
        document.activeElement && document.activeElement.blur && document.activeElement.blur();
        document.querySelectorAll('.app-menu-panel').forEach(p => { p.hidden = true; });
        if (window.H) H.unwco();
        if (!document.getElementById('tut-shot-hide')) { const s = document.createElement('style'); s.id = 'tut-shot-hide'; s.textContent = '.meeting-banner,#meeting-banner,.update-banner,#toast{display:none!important}'; document.head.appendChild(s); }
      });
      await page.waitForTimeout(250);
      const pageName = (PAGE[tutorial.title] || [])[i] || tutorial.page;
      await page.evaluate(p => navigate(p), pageName);
      await page.waitForTimeout(700);
      const setup = (SETUP[tutorial.title] || [])[i];
      if (setup) { await page.evaluate(code => (0, eval)(code), setup).catch(e => console.warn('setup failed', name, e.message)); await page.waitForTimeout(/Performance/.test(setup) ? 2500 : 900); }
      const box = await page.evaluate(target => {
        const el = tutFind(target);
        if (!el) return null;
        el.scrollIntoView({ block: 'center' });
        const r = el.getBoundingClientRect(), pad = 6;
        const spot = document.createElement('div');
        spot.id = 'tut-spot';
        spot.style.cssText = `position:fixed;left:${r.left - pad}px;top:${r.top - pad}px;width:${r.width + pad * 2}px;height:${r.height + pad * 2}px;border-radius:10px;box-shadow:0 0 0 3px #f59e0b,0 0 0 9999px rgba(15,23,42,.38);z-index:2147483647;pointer-events:none`;
        document.body.appendChild(spot);
        return true;
      }, target);
      if (!box) { console.warn('MISSING target', name, target); continue; }
      await page.waitForTimeout(200);
      // Crop to a 16:10 window around the highlight so the text stays readable in the tutorial panel.
      const r = await page.evaluate(() => { const b = document.getElementById('tut-spot').getBoundingClientRect(); return { x: Math.max(0, b.left), y: Math.max(0, b.top), w: Math.min(b.width, innerWidth), h: Math.min(b.height, innerHeight) }; });
      let cw = Math.min(W, Math.max(760, r.w + 200)), ch = Math.round(cw * 10 / 16);
      if (ch < r.h + 120) { ch = Math.min(H, r.h + 120); cw = Math.min(W, Math.round(ch * 16 / 10)); }
      const cx = Math.max(0, Math.min(W - cw, r.x + r.w / 2 - cw / 2)), cy = Math.max(0, Math.min(H - ch, r.y + r.h / 2 - ch / 2));
      await page.screenshot({ path: path.join(OUT, name + '.jpg'), type: 'jpeg', quality: 78, clip: { x: cx, y: cy, width: cw, height: ch } });
      await page.evaluate(() => document.getElementById('tut-spot')?.remove());
      saved++;
    }
  }
  console.log('saved', saved, 'pictures');
  await browser.close();
})();
