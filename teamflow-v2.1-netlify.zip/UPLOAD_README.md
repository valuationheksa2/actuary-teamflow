# Actuary TeamFlow v2.1 — Netlify release

This is the complete source release, prepared on 1 October 2026. No deployment or production data migration has been performed.

## Package structure

```text
teamflow-v2.1/
  public/                Website assets
  netlify/functions/     Authenticated API and storage handlers
  scripts/               Validation, local fixture preview, migration
  tests/                 Automated regression tests
  netlify.toml           Build, functions, API routes, security headers
  package.json
  package-lock.json
  .node-version          Node 22
  .env.example           Environment variable names; no credentials
  SETUP_GUIDE.md          Accounts, SMTP, storage, migration instructions
  VALIDATION_REPORT.md    Local audit results and limitations
```

## Deploy the complete app

Use a separate staging Netlify project first. Upload this folder to a Git repository and import that repository into Netlify, or deploy it using Netlify CLI. Dashboard drag-and-drop of `public/` only publishes static assets; it does not deploy the API required for accounts and shared data.

### Git deployment settings

- Base directory: repository root (the directory containing `netlify.toml`).
- Build command: `npm run build`.
- Publish directory: `public`.
- Functions directory: `netlify/functions`.
- Node version: 22, provided by `.node-version`.

### Local checks and CLI upload

Install Node 22, then open PowerShell in this folder:

```powershell
npm ci
npm run build
npm test
npx netlify login
npx netlify link
```

Link a **separate staging project**, configure its environment variables, then upload:

```powershell
npm run deploy
```

The upload command creates a draft deployment by default and bundles the functions. It does not publish to the main site URL. A draft on a production project can still access that project's data, so use a separate staging project for testing.

## Configure before testing accounts

Set environment variables in Netlify with Functions/runtime access. Use `.env.example` as the reference; do not upload a real `.env` or commit credentials.

- `APP_URL`: the staging URL used for invitation and reset links.
- `APP_ORIGINS`: exact staging site and draft URL origins. Include each URL used to test.
- `TEAM_TIME_ZONE`: `Asia/Bangkok`.
- SMTP host, port, user, password, secure setting and sender: required for invitation/reset email delivery.
- `ADMIN_BOOTSTRAP_TOKEN`: a strong temporary secret for first administrator setup.
- Blobs credentials, if needed: use only staging credentials. See `SETUP_GUIDE.md`.

For a fresh staging site, open `/?setup=1`, create an administrator, and remove the bootstrap token afterward. Fictional local-preview accounts are not deployed accounts.

## Existing production data

This release changes authentication and storage. Existing v2.0 data/accounts need the separately reviewed backup and migration process in `SETUP_GUIDE.md`; copying website files is not a data migration. No migration runs automatically during build or upload. Keep production deployment and migration on hold until approved.

## Validation boundary

Local regression tests and static build checks passed. Real Netlify Blobs, hosted function routing, SMTP delivery, and synchronization between physical devices still require staging verification. See `VALIDATION_REPORT.md`.

Netlify references: [CLI deploy](https://cli.netlify.com/commands/deploy/) and [deployment methods](https://docs.netlify.com/deploy/create-deploys/).
