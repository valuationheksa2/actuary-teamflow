# Current v2.1 release preparation — 3 October 2026

The report below records earlier checks on 1 October. It does not validate all subsequent changes.

Current preparation: static validation passes for 26 JavaScript files. The release contains six API functions. ZIP contents and the upload copy match the prepared source and checksum helper. No actual environment files, preview snapshots, or encrypted backups are included; .env.example contains empty credential fields.

Latest user-supplied Lighthouse desktop report: Performance 100, Accessibility 96, Best Practices 100, SEO 100, Agentic Browsing 100. The subsequent profile-label and darker-blue Pro contrast changes have not been re-audited. The final mobile report has not been rerun.

Hosted sign-in, production migration, profile photo upload, edited feedback names, app confirmations, and the final mobile interface remain to be checked. No production publish or data migration was performed during this preparation. Build and archive checks alone do not establish production readiness.

---
# TeamFlow v2.1 — Fixes and Final Local Verification

Date: 1 October 2026

## Result

The issues identified in the local audit have been corrected in the editable source. Local automated checks and the browser flows listed below pass. The live Netlify application was not changed or deployed, and production data and sessions were not touched. The original release ZIP remains intact.

## Corrections

- Shared feedback saves are awaited, canonical versions advance together with their baselines, failed drafts remain available, and retries reuse the same record. Feedback is visible to Admin, Manager, Member, and Board accounts; Board remains read-only.
- User-entered feedback, work titles, template fields, tags, notes, and account labels are escaped when rendered. Feedback categories match the form, and the server supplies the authenticated author.
- Background synchronization refreshes the displayed page when shared data changes. It checks drafts both before and after fetching, refreshes on focus/visibility changes, and does not close drafts edited during a save.
- Record and collection saves use Netlify Blobs ETag conditional writes. Competing same-version writes produce a conflict instead of silently replacing each other. IDs are collision-resistant; deleted IDs cannot be recreated accidentally. Storage HTTP failures cannot be reported as successful conditional saves.
- Work, note, file, member, template, and feedback actions await persistence before reporting success. Work/member creation and note/file retries preserve their pending item. Template create/edit/delete now persist to shared storage. Duplicate template render/action definitions were removed.
- Permissions in the UI match the server. Members cannot create work or manage templates; Board cannot mutate work even if listed as an assignee. Member PICs can approve/reject join/leave requests through a dedicated server operation. Resolution markers allow retry after a partial save.
- Work completion accepts the completed phase. Recurring completion creates its next occurrence on the server, preserves effort/work type, clamps month-end dates, and safely reuses the next occurrence on retry. Assigned members can complete recurring work.
- Reset tokens are claimed conditionally so simultaneous completion cannot reuse one link. Rate-limit counters and notification read-state writes also use conditional writes.
- Notifications now load through the actual handler; its date helpers were previously unavailable at runtime. Preferences and read states persist across sessions.
- The daily rolling-deadline section is labelled "Due in the Next 7 Days". Weekday capacity tests reflect the current Monday-Friday allocation rule.
- Invalid calendar dates, reversed date ranges, invalid recurrence settings, and invalid IDs are rejected. The last active administrator cannot demote themselves.
- Narrow-screen headers avoid wrapping the full date and Add Work button. Dynamic forms have associated labels, phase editor keyboard controls, dialog focus entry/restoration and Tab containment, and accessible save status announcements.
- Build validation now includes preview/migration scripts and public JavaScript. The safe fixture preview uses real work/team/reminder handlers with simulated sessions rather than reporting unconditional save success.

## Verification

| Check | Result |
|---|---|
| Automated tests | 40 passed, 0 failed |
| Build / syntax / referenced assets | Passed; 24 JavaScript files checked |
| Runtime dependency audit | 0 reported vulnerabilities (`npm audit --omit=dev`) |
| Main page render functions | All 14 passed against fictional data and a simulated DOM |
| Shared feedback API | Same saved feedback retrieved through five fictional accounts covering all four roles |
| Shared work API | Create/update/delete visible to other account sessions; stale edit returned HTTP 409 |
| Concurrent record/collection writes | One winning save and one conflict |
| Password reset concurrency | Exactly one successful use of a token |
| PIC approvals | Unrelated member denied; member PIC approved; retry after simulated partial save succeeded without duplicate membership |
| Recurring completion | Assigned member succeeded; assigned Board denied; month-end dates and retry verified |
| Reminder API | Load, preferences, and shared read-state checks passed |
| Browser feedback | Submission saved; harmless markup displayed as literal text; Board saw it without submission/edit controls |
| Browser work creation | Created work returned version 1 and appeared in Schedule |
| Browser reminders | Saved preference and Mark all read worked |
| Browser schedule | Oct 3 showed two work items spanning that date |
| Browser reports and capacity | Weekly/monthly ongoing lists and weekday capacity rendered with matching navigation arrows |
| Phone schedule and dashboard | No document overflow at 320, 360, 390, and 430px; seven equal calendar columns |
| Browser console | No errors in the final Board feedback check |

Evidence: `test-results.txt`, `build-results.txt`, `dependency-results.txt`, `http-results.txt`, `schedule-390.jpg`, and `feedback-board.jpg`, and `responsive-results.json` in this folder. `AUDIT-v2.1.md` records the original findings before fixes and is retained as historical evidence.

## Validation boundaries before production release

- These are local checks using fictional, disposable in-memory data. Real Netlify Blobs conditional writes, cold starts, hosting redirects/security headers, SMTP invitations/reset delivery, and production migration still require a dedicated staging site.
- The synchronization checks use independent account sessions and browser simulation, not two physical phones. Network interruption/offline/reconnection and PWA installation should be rehearsed on real devices in staging.
- Blobs conditional writes protect an individual key; they do not provide transactions across multiple records. PIC resolution and recurring completion use durable retry markers. Other operations spanning team/work/activity keys can still be partially committed if a later storage request fails; the UI retains edits and reports failure for reconciliation.
- The check list is evidence for the exercised functionality, not a claim that every possible input, device, export/print dialog, or infrastructure failure has been exhaustively tested.

## Local preview

The updated fixture preview is running at http://127.0.0.1:8890/.

From the source folder:

```powershell
npm ci
npm test
npm run build
npm run preview:fixture
```

Dedicated staging testing and deployment remain separate actions. No production deployment was performed.


## Annual reporting update — 1 October 2026

- Report tabs: Weekly, Monthly, Annual; removed the standalone Member Performance tab.
- Annual report covers January–December with previous/next-year navigation, ongoing work, completions, period totals, priority/tag breakdowns, and member performance.
- Annual member statistics include assignee and PIC responsibilities once per work item; the export includes member performance and completed-work details.
- Updated Help & Guide and v2.1 changelog. Existing report tab/year selections remain intact during background redraws.
- Static build validation passed (24 JavaScript files); all 42 regression tests passed, including leap-year/year-boundary and annual navigation/export checks. Browser fixture preview confirmed all three tabs and embedded annual performance.
- No production deployment or data migration. Staging infrastructure checks remain required as described above.
