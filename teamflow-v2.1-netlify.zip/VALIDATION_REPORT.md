# TeamFlow v2.1 — live audit and production comparison

Date: 5 October 2026. Candidate: local source and rebuilt release. Production: https://actuaryteamflow.netlify.app/ (read-only).

## Result

- 61/61 automated tests pass, including security, 10-user concurrency, migrations, report dates, retry/draft protection, pagination and cache correctness.
- Build validates the JavaScript and generated assets. No browser errors were captured in the exercised local workflows.
- One application defect repaired during this audit: completed legacy records without a start date were omitted from report totals. Completed-period eligibility now uses the actual completion date.
- Updated stale tests to reflect approved member creation, editable feedback display name, removed reminder preferences, and actual creator/PIC permissions. Browser mocks now model revision/refresh requests, absent conflict overlays and a fixed annual-report clock. These were test corrections, not permission relaxations.

## Lighthouse 13.4.1 — local fictional dashboard

| Device | Performance | Accessibility | Best practices | SEO | FCP | LCP | TBT | CLS |
|---|---:|---:|---:|---:|---|---|---|---|
| Desktop final | 100 | 100 | 100 | 100 | 0.3 s | 0.7 s | 0 ms | 0 |
| Mobile final, sequential | 91 | 100 | 100 | 100 | 1.1 s | 3.5 s | 0 ms | 0 |

An earlier mobile run scored 96 (LCP 2.7 s). Mobile results varied from 91–96; the repeat sequential run also scored 91. The desktop/mobile final run and repeat used rebuilt assets. These are simulated navigation measurements against a local in-memory preview, not authenticated Netlify cold-start timings or a like-for-like production benchmark.

Remaining mobile opportunities: render-blocking CSS (about 455 ms reported in the repeat), unused CSS and JavaScript from other app pages. Static minification reduces the current source asset set from 306,044 to 282,689 bytes (7.6%, uncompressed). This is a before/after build comparison, not a measured production download reduction. The fixture does not reproduce Netlify CDN compression and storage latency.

## Browser checks

- Ongoing: 10 of 14 on page one, remaining four on page two; title search resets paging.
- Upcoming: 10 of 14, then four. History: 10 of 13 initially. Automated tests cover final pages, empty results, clamping after changes and isolation by user/status.
- Templates: nine visible cards at three desktop columns, expand to 24 and collapse to nine; three rows calculated from the active column count.
- Team: desktop first-row cards are equal width/height (531.328 by 438 CSS pixels); at 1280px the two cards in each row match; at 390px cards fit a single column. No content horizontal overflow at these checked widths.
- Team excludes administrators and orders member, manager, board. Admin panel orders admin, member, manager, board.
- Daily Report renders its digest and work lists. Profile opens by selecting the sidebar identity; photo-upload controls remain available.
- October monthly report reconciles 15 work items = one completed + 14 ongoing in the fixture. September keeps the October 3 completion in its historical ongoing list, flags its completion date and shows 100% progress.
- Monthly export button produced the app's report-downloaded message. Automated tests verify the export HTML contains completed rows and historical flags. Browser download-event capture timed out; a newly downloaded file and a printed PDF were not independently verified. The existing export produces printable HTML, then the user saves PDF through Print.

Screenshots: output/live-audit/team-desktop.jpg and team-mobile.jpg.

## Confirmed changes versus the currently deployed production

Live public assets were fetched on 5 October; their headers and byte sizes are saved in production-assets.json. The authenticated production tab was inspected without changing production data.

| Area | Deployed production | Candidate v2.1 |
|---|---|---|
| Background polling | Full team and works reads every 30 seconds; badges also request notifications | Small revision check; full reads on change and every five minutes; one polling leader shares updates across tabs |
| Notifications | Bell, notification requests and preferences present | Feature and its function removed; help/changelog references removed |
| Storage execution | Backend cannot be inspected from public assets | Request-level read deduplication; five-minute revision-keyed workspace projection; direct work lookup; bounded storage reads; parallel independent auth checks |
| Function inventory | Notification endpoint referenced by deployed frontend | Five function entry points: auth, team, works, digest, activity |
| Work lists | No ten-item pagination helper in deployed work.js | History, ongoing and upcoming show ten items per page; paging is client-side |
| Templates | No three-row expansion state in deployed admin.js | Three rows initially, expandable, searchable |
| Monthly report/export | No dedicated completed-work section in deployed monthly renderer | Completed-work list and completed rows in export |
| Team/admin presentation | No shared role-order helper in deployed code | Stable role order, admin hidden from Team, responsive equal cards |
| Static files | Browser loads unminified .js and app.css assets | Browser and service worker load generated .min assets; readable source retained |
| Avatar contrast | Previous text-color behavior | Text color selected for accessible contrast while preserving photos/background colors |
| PWA appearance | Manifest theme #3b6fd4 | Manifest theme #e8f0fa, matching the lighter approved appearance |
| Topbar | Previous spacing | Compact, vertically aligned sync status and date divider |

Previously approved branding, profile pictures, ActuarialPro link, confirmations and report navigation already exist in production; they are not all new in this candidate.

## Compute expectation

For one visible tab, unchanged data and no open draft, deployed steady polling makes about six function calls/minute (team + works + notifications twice). Candidate steady polling averages about 2.4/minute (two revision checks plus two full reads every five minutes): approximately 60% fewer calls. Workspace writes trigger earlier refreshes; active edits, failures, browser capabilities and extra tabs change this model.

Revision checks also avoid repeatedly scanning/serializing the full workspace. Tests confirm unchanged revisions skip full client reads, cached projections avoid record scans, writes invalidate projections, forced refresh bypasses them, failed memoized reads can retry, and expired projections rebuild from records. API responses remain no-store; private data is not moved to a public CDN cache.

No GB-hour or credit saving percentage has been measured. Function memory, Netlify cold starts, Blob latency and real user traffic still determine billing. Pagination and CSS minification mainly reduce browser work; they do not themselves remove function invocations.

## HTTP / PWA checks

- Local auth/me, team, works revision check, works, forced works refresh and digest returned 200 with no-store; single warm fixture samples took 2–28 ms.
- Production anonymous team, works and digest returned 401 with no-store (single samples 579–822 ms). These do not measure authenticated sign-in or full refresh speed.
- Manifest icon files are actually 192x192 and 512x512. Standalone display and app scope/id remain configured.
- Service worker uses versioned static-shell assets and excludes API/authentication traffic; registration runs after page load.
- Installed PWA lifecycle, offline switching and authenticated production login were not exercised. Lighthouse's four scored categories here do not certify PWA installation.

## Release boundary

Production was not deployed or modified. Tests used fictional local data and isolated storage. No source changes after the final build/test/package verification should be treated as verified until those checks run again. The candidate remains v2.1. Real Netlify function timing/GB-hours must be measured after the user deploys it.