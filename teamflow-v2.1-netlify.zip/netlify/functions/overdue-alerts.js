'use strict';

const { openStore, requestStore } = require('./lib/store');
const { listWorks, listMembers } = require('./lib/records');
const push = require('./lib/push');
const { dateKeyInZone } = require('../../public/js/domain');

// Scheduled daily in netlify.toml: one push per person summarising work due today and overdue work they are PIC or assignee on.
const formatDate = key => new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' }).format(new Date(key + 'T00:00:00Z'));
const titles = list => list.slice(0, 3).map(work => work.title).join(', ') + (list.length > 3 ? ` and ${list.length - 3} more` : '');
function deadlinePayload(dueToday, overdue, today) {
  const tag = 'deadlines-' + today;
  if (dueToday.length + overdue.length === 1) {
    const [work] = [...dueToday, ...overdue];
    return dueToday.length
      ? { title: 'Due today', body: `${work.title} is due today.`, tag, workId: work.id }
      : { title: 'Overdue work', body: `${work.title} was due ${formatDate(work.deadline)}.`, tag, workId: work.id };
  }
  const parts = [dueToday.length && `${dueToday.length} due today`, overdue.length && `${overdue.length} overdue`].filter(Boolean);
  return { title: parts.join(', ').replace(/^./, c => c.toUpperCase()), body: titles([...dueToday, ...overdue]), tag, workId: null };
}
async function sendOverdueAlerts(store = openStore(), today = dateKeyInZone(new Date(), process.env.TEAM_TIME_ZONE || 'Asia/Bangkok')) {
  store = requestStore(store);
  const [{ data: works }, members] = await Promise.all([listWorks(store), listMembers(store)]);
  const open = works.filter(work => work.status !== 'done' && /^\d{4}-\d{2}-\d{2}$/.test(String(work.deadline || '')) && work.deadline <= today);
  const byMember = new Map();
  for (const member of members.filter(member => push.wantsNotification(member, 'overdueToday'))) {
    const mine = open.filter(work => String(work.pic) === String(member.id) || (work.assignees || []).some(id => String(id) === String(member.id)));
    if (mine.length) byMember.set(String(member.id), { dueToday: mine.filter(work => work.deadline === today), overdue: mine.filter(work => work.deadline < today) });
  }
  return push.sendToUsers(store, [...byMember.keys()], userId => {
    const { dueToday, overdue } = byMember.get(String(userId));
    return deadlinePayload(dueToday, overdue, today);
  });
}

exports.handler = async () => {
  const delivered = await sendOverdueAlerts();
  console.log(`Deadline alerts: ${delivered} push notification${delivered === 1 ? '' : 's'} sent.`);
  return { statusCode: 200, body: JSON.stringify({ delivered }) };
};

exports.sendOverdueAlerts = sendOverdueAlerts;
