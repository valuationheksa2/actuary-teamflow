'use strict';

const { openStore, requestStore } = require('./lib/store');
const { listWorks, listMembers } = require('./lib/records');
const push = require('./lib/push');
const { dateKeyInZone } = require('../../public/js/domain');

// Scheduled daily in netlify.toml: one push per person summarising overdue work they are PIC or assignee on.
async function sendOverdueAlerts(store = openStore(), today = dateKeyInZone(new Date(), process.env.TEAM_TIME_ZONE || 'Asia/Bangkok')) {
  store = requestStore(store);
  const [{ data: works }, members] = await Promise.all([listWorks(store), listMembers(store)]);
  const overdue = works.filter(work => work.status !== 'done' && /^\d{4}-\d{2}-\d{2}$/.test(String(work.deadline || '')) && work.deadline < today);
  const byMember = new Map();
  for (const member of members.filter(member => push.wantsNotification(member, 'overdueToday'))) {
    const mine = overdue.filter(work => String(work.pic) === String(member.id) || (work.assignees || []).some(id => String(id) === String(member.id)));
    if (mine.length) byMember.set(String(member.id), mine);
  }
  return push.sendToUsers(store, [...byMember.keys()], userId => {
    const mine = byMember.get(String(userId));
    if (mine.length === 1) return { title: 'Overdue work', body: `${mine[0].title} was due ${new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' }).format(new Date(mine[0].deadline + 'T00:00:00Z'))}.`, tag: 'overdue-' + today, workId: mine[0].id };
    const titles = mine.slice(0, 3).map(work => work.title).join(', ') + (mine.length > 3 ? ` and ${mine.length - 3} more` : '');
    return { title: `${mine.length} overdue items`, body: titles, tag: 'overdue-' + today, workId: null };
  });
}

exports.handler = async () => {
  const delivered = await sendOverdueAlerts();
  console.log(`Overdue alerts: ${delivered} push notification${delivered === 1 ? '' : 's'} sent.`);
  return { statusCode: 200, body: JSON.stringify({ delivered }) };
};

exports.sendOverdueAlerts = sendOverdueAlerts;
