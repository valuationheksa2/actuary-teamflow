'use strict';

const { openStore, requestStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, methodNotAllowed, originAllowed } = require('./lib/http');
const { currentRecord, deleteRecord, getMember, listRecords, saveRecord } = require('./lib/records');
const { requireUser, requireRole } = require('./lib/auth-core');
const domain = require('../../public/js/domain');

// Public holidays and individual leave, used to reduce available hours on the Capacity page.
const isManager = user => ['admin', 'manager'].includes(user.role);
function canChange(user, entry) { return isManager(user) || (entry.type === 'leave' && String(entry.memberId) === String(user.id)); }
const validDate = value => { const parsed = domain.parseDateKey(String(value || '')); return Boolean(parsed) && parsed.toISOString().slice(0, 10) === value; };

async function handle(event, store = openStore()) {
  store = requestStore(store);
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const user = await requireUser(event, store);
  if (event.httpMethod === 'GET') return response(event, 200, { items: await listRecords('absence', [], store) });
  if (event.httpMethod !== 'POST') return methodNotAllowed(event, 'GET, POST, OPTIONS');
  requireRole(user, ['admin', 'manager', 'member']);
  const body = parseBody(event);

  if (body.operation === 'upsert') {
    const input = body.absence || {};
    if (!Number.isSafeInteger(input.id) || input.id <= 0) return response(event, 400, { error: 'Entry requires a valid record ID.' });
    if (!['holiday', 'leave'].includes(input.type)) return response(event, 400, { error: 'Choose leave or public holiday.' });
    if (!validDate(input.startDate) || !validDate(input.endDate) || input.endDate < input.startDate) return response(event, 400, { error: 'Choose a valid date range.' });
    const span = (domain.parseDateKey(input.endDate) - domain.parseDateKey(input.startDate)) / 86400000;
    if (span > 366) return response(event, 400, { error: 'An entry can cover at most one year.' });
    const label = String(input.label || '').trim().slice(0, 120);
    if (input.type === 'holiday' && !label) return response(event, 400, { error: 'Name the public holiday.' });
    const entry = { id: input.id, type: input.type, startDate: input.startDate, endDate: input.endDate, label };
    if (input.type === 'leave') {
      const member = await getMember(input.memberId, store);
      if (!member || member.role === 'board') return response(event, 400, { error: 'Choose a team member.' });
      entry.memberId = member.id;
    }
    const current = await currentRecord('absence', input.id, store);
    if (!canChange(user, entry) || (current && !canChange(user, current))) return response(event, 403, { error: 'Only managers and administrators can add holidays or change someone else’s leave.' });
    entry.createdBy = current?.createdBy ?? user.id;
    return response(event, current ? 200 : 201, { absence: await saveRecord('absence', entry, body.expectedVersion, store) });
  }

  if (body.operation === 'delete') {
    const current = await currentRecord('absence', body.id, store);
    if (!current) return response(event, 404, { error: 'Entry not found.' });
    if (!canChange(user, current)) return response(event, 403, { error: 'Only managers and administrators can remove this entry.' });
    await deleteRecord('absence', body.id, body.expectedVersion, store);
    return response(event, 200, { ok: true });
  }
  return response(event, 400, { error: 'Choose a supported operation.' });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { handle };
