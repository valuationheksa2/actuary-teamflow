'use strict';

const { openStore, requestStore } = require('./lib/store');
const { currentRecord, listMembers, listRecords, saveRecord } = require('./lib/records');
const push = require('./lib/push');
const domain = require('../../public/js/domain');

// Scheduled hourly in netlify.toml: reminds attendees of meetings starting within the next hour.
// The window runs a little past the hour, because a job that starts slightly early must not skip a meeting; the sent marker stops a second reminder.
async function sendMeetingReminders(store = openStore(), now = Date.now()) {
  store = requestStore(store);
  const [meetings, members] = await Promise.all([listRecords('meeting', [], store), listMembers(store)]);
  let delivered = 0;
  for (const meeting of meetings) {
    const starts = Date.parse(meeting.startsAt);
    if (meeting.status === 'cancelled' || meeting.reminderSentAt || !(starts > now) || starts - now > domain.MEETING_REMINDER_WINDOW_MS) continue;
    const ids = [...new Set([meeting.organizerId, ...(meeting.attendees || [])].filter(id => id != null).map(String))]
      .filter(id => push.wantsNotification(members.find(member => String(member.id) === id), 'meetings'));
    const minutes = Math.max(1, Math.round((starts - now) / 60000));
    delivered += await push.sendToUsers(store, ids, () => ({ title: 'Meeting soon', body: `${meeting.title} starts at ${meeting.startTime} (in ${minutes} min)${meeting.location ? ' · ' + meeting.location : ''}`, tag: 'meeting-' + meeting.id, meetingId: meeting.id }));
    // An edit landing between the read and this save must not lose the marker, so retry once on the latest version.
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const latest = attempt ? await currentRecord('meeting', meeting.id, store) : meeting;
        if (latest) await saveRecord('meeting', { ...latest, reminderSentAt: new Date(now).toISOString() }, latest.version, store);
        break;
      } catch (error) {
        if (error.statusCode !== 409 || attempt === 1) console.warn('Meeting reminder marker failed:', error.message);
      }
    }
  }
  return delivered;
}

exports.handler = async () => {
  const delivered = await sendMeetingReminders();
  console.log(`Meeting reminders: ${delivered} push notification${delivered === 1 ? '' : 's'} sent.`);
  return { statusCode: 200, body: JSON.stringify({ delivered }) };
};

exports.sendMeetingReminders = sendMeetingReminders;
