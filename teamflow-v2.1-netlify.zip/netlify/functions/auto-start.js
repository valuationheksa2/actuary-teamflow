'use strict';

const { openStore, requestStore } = require('./lib/store');
const { listWorks, saveRecord } = require('./lib/records');
const { appendActivity } = require('./lib/activity-log');
const { dateKeyInZone } = require('../../public/js/domain');

// Scheduled hourly in netlify.toml. Upcoming work moves to Ongoing / Planning once its start date arrives.
const SYSTEM_ACTOR = { id: 0, name: 'TeamFlow auto-start' };

async function startDueWork(store = openStore(), today = dateKeyInZone(new Date(), process.env.TEAM_TIME_ZONE || 'Asia/Bangkok')) {
  store = requestStore(store);
  const { data } = await listWorks(store);
  const started = [];
  for (const work of data) {
    if (work.status !== 'upcoming' || !/^\d{4}-\d{2}-\d{2}$/.test(String(work.startDate || '')) || work.startDate > today) continue;
    const { version, ...current } = work;
    try {
      const saved = await saveRecord('work', { ...current, status: 'ongoing', phase: 0 }, version, store);
      await appendActivity(store, saved.id, SYSTEM_ACTOR, 'started', work, saved);
      started.push(saved.id);
    } catch (error) {
      // A concurrent edit wins; the next hourly run retries with the latest version.
      if (error.statusCode !== 409) throw error;
    }
  }
  return started;
}

exports.handler = async () => {
  const started = await startDueWork();
  console.log(`Auto-start: ${started.length} work item${started.length === 1 ? '' : 's'} moved to Ongoing.`);
  return { statusCode: 200, body: JSON.stringify({ started: started.length }) };
};

exports.startDueWork = startDueWork;
