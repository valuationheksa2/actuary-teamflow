'use strict';

const { openStore, requestStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, methodNotAllowed, originAllowed } = require('./lib/http');
const { currentRecord, listMembers, listRecords, saveRecord } = require('./lib/records');
const { requireUser, requireRole } = require('./lib/auth-core');
const push = require('./lib/push');
const domain = require('../../public/js/domain');

const TIME_ZONE = () => process.env.TEAM_TIME_ZONE || 'Asia/Bangkok';
const failure = (message, statusCode = 400) => Object.assign(new Error(message), { statusCode });
const attendeesOf = meeting => [...new Set([meeting.organizerId, ...(meeting.attendees || [])].filter(id => id != null).map(String))];

function canManage(user, meeting) { return user.role === 'admin' || String(meeting.organizerId) === String(user.id); }

function normalizeMeeting(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw failure('Meeting details are missing.');
  if (!Number.isSafeInteger(input.id) || input.id <= 0) throw failure('Meeting requires a valid record ID.');
  const title = String(input.title || '').trim(), date = String(input.date || ''), startTime = String(input.startTime || '');
  if (!title || title.length > 200) throw failure('Meeting title is required and must be 200 characters or fewer.');
  const parsed = domain.parseDateKey(date);
  if (!parsed || parsed.toISOString().slice(0, 10) !== date) throw failure('Choose a valid meeting date.');
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)) throw failure('Choose a valid start time.');
  const durationMinutes = Number(input.durationMinutes);
  if (!Number.isInteger(durationMinutes) || durationMinutes < 5 || durationMinutes > 480) throw failure('Duration must be between 5 minutes and 8 hours.');
  const attendees = Array.isArray(input.attendees) ? [...new Set(input.attendees)] : [];
  if (attendees.some(id => !Number.isSafeInteger(id) || id <= 0)) throw failure('Choose attendees from the team.');
  const linkedWorkIds = Array.isArray(input.linkedWorkIds) ? [...new Set(input.linkedWorkIds)] : [];
  if (linkedWorkIds.length > 20 || linkedWorkIds.some(id => !Number.isSafeInteger(id) || id <= 0)) throw failure('Link at most 20 valid work items.');
  return {
    id: input.id, title, date, startTime, durationMinutes, attendees, linkedWorkIds,
    location: String(input.location || '').trim().slice(0, 300), agenda: String(input.agenda || '').trim().slice(0, 5000),
    startsAt: domain.zonedTimeToIso(date, startTime, TIME_ZONE()),
  };
}

function meetingWhen(meeting) {
  const day = new Intl.DateTimeFormat('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' }).format(domain.parseDateKey(meeting.date));
  return `${day}, ${meeting.startTime}${meeting.location ? ' · ' + meeting.location : ''}`;
}

async function notifyMeeting(store, meeting, actor, audiences) {
  try {
    const members = await listMembers(store);
    const payloads = new Map();
    for (const [ids, title] of audiences) {
      for (const id of ids) {
        const member = members.find(row => String(row.id) === String(id));
        if (String(id) === String(actor.id) || payloads.has(String(id)) || !push.wantsNotification(member, 'meetings')) continue;
        payloads.set(String(id), { title, body: `${meeting.title} · ${meetingWhen(meeting)}`, tag: 'meeting-' + meeting.id, meetingId: meeting.id });
      }
    }
    await push.sendToUsers(store, [...payloads.keys()], userId => payloads.get(String(userId)));
  } catch (error) { console.warn('Meeting push failed:', error.message); }
}

async function handle(event, store = openStore()) {
  store = requestStore(store);
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const user = await requireUser(event, store);
  if (event.httpMethod === 'GET') return response(event, 200, { items: await listRecords('meeting', [], store) });
  if (event.httpMethod !== 'POST') return methodNotAllowed(event, 'GET, POST, OPTIONS');
  requireRole(user, ['admin', 'manager', 'member']);
  const body = parseBody(event);

  if (body.operation === 'upsert') {
    const meeting = normalizeMeeting(body.meeting);
    const current = await currentRecord('meeting', meeting.id, store);
    if (current && !canManage(user, current)) return response(event, 403, { error: 'Only the organizer or an administrator can edit this meeting.' });
    if (current?.status === 'cancelled') return response(event, 409, { error: 'This meeting has been cancelled.' });
    const timeChanged = !current || current.startsAt !== meeting.startsAt;
    if (timeChanged && Date.parse(meeting.startsAt) <= Date.now()) return response(event, 400, { error: 'Choose a start time in the future.' });
    const members = await listMembers(store);
    const allowed = new Set(members.filter(member => member.active !== false).map(member => member.id));
    if (meeting.attendees.some(id => !allowed.has(id) && !(current?.attendees || []).includes(id))) return response(event, 400, { error: 'Choose active team members as attendees.' });
    for (const id of meeting.linkedWorkIds) if (!await currentRecord('work', id, store)) return response(event, 400, { error: 'A linked work item no longer exists.' });
    const next = { ...(current || {}), ...meeting, organizerId: current?.organizerId ?? user.id, organizerName: current?.organizerName ?? user.name, status: 'scheduled' };
    // Inside the reminder window the invite or change alert already gives the time, so the hourly job shouldn't repeat it.
    if (timeChanged) {
      if (Date.parse(next.startsAt) - Date.now() <= domain.MEETING_REMINDER_WINDOW_MS) next.reminderSentAt = new Date().toISOString();
      else delete next.reminderSentAt;
    }
    const saved = await saveRecord('meeting', next, body.expectedVersion, store);
    const before = current ? attendeesOf(current) : [], after = attendeesOf(saved);
    const details = !current || timeChanged || current.location !== saved.location;
    await notifyMeeting(store, saved, user, [
      [after.filter(id => !before.includes(id)), 'Meeting invite'],
      [before.filter(id => !after.includes(id)), 'Removed from meeting'],
      [details ? after : [], 'Meeting changed'],
    ]);
    return response(event, current ? 200 : 201, { meeting: saved });
  }

  const current = await currentRecord('meeting', body.id, store);
  if (!current) return response(event, 404, { error: 'Meeting not found.' });

  if (body.operation === 'minutes') {
    if (user.role !== 'admin' && !attendeesOf(current).includes(String(user.id))) return response(event, 403, { error: 'Only attendees, the organizer or an administrator can write the minutes.' });
    const minutes = String(body.minutes || '').trim();
    if (minutes.length > 10000) return response(event, 400, { error: 'Keep the minutes to 10,000 characters or fewer.' });
    const saved = await saveRecord('meeting', { ...current, minutes, minutesBy: user.name, minutesAt: new Date().toISOString() }, body.expectedVersion, store);
    return response(event, 200, { meeting: saved });
  }

  if (body.operation === 'actions') {
    if (user.role !== 'admin' && !attendeesOf(current).includes(String(user.id))) return response(event, 403, { error: 'Only attendees, the organizer or an administrator can change action points.' });
    if (current.status === 'cancelled') return response(event, 409, { error: 'This meeting has been cancelled.' });
    if (!Array.isArray(body.actions) || body.actions.length > 100) return response(event, 400, { error: 'Keep to 100 action points or fewer.' });
    const members = await listMembers(store), linked = new Set(current.linkedWorkIds || []), known = new Set((current.actions || []).map(action => action.workId).filter(Boolean));
    const actions = [];
    for (const input of body.actions) {
      const text = String(input?.text || '').trim();
      if (!Number.isSafeInteger(input?.id) || !text || text.length > 500) return response(event, 400, { error: 'Each action point needs text of 500 characters or fewer.' });
      const ownerId = input.ownerId == null ? null : input.ownerId;
      if (ownerId != null && !members.some(member => member.id === ownerId)) return response(event, 400, { error: 'Choose an owner from the team.' });
      const workId = input.workId == null ? null : input.workId;
      if (workId != null && !known.has(workId)) {
        if (!Number.isSafeInteger(workId) || !await currentRecord('work', workId, store)) return response(event, 400, { error: 'That work item no longer exists.' });
        linked.add(workId);
      }
      actions.push({ id: input.id, text, ownerId, workId });
    }
    const saved = await saveRecord('meeting', { ...current, actions, linkedWorkIds: [...linked] }, body.expectedVersion, store);
    return response(event, 200, { meeting: saved });
  }

  if (body.operation === 'files') {
    if (user.role !== 'admin' && !attendeesOf(current).includes(String(user.id))) return response(event, 403, { error: 'Only attendees, the organizer or an administrator can change linked files.' });
    if (current.status === 'cancelled') return response(event, 409, { error: 'This meeting has been cancelled.' });
    if (!Array.isArray(body.files) || body.files.length > 50) return response(event, 400, { error: 'Keep to 50 file links or fewer.' });
    const files = [];
    for (const input of body.files) {
      const name = String(input?.name || '').trim(), url = String(input?.url || '').trim();
      if (!name || name.length > 200) return response(event, 400, { error: 'Each file link needs a name of 200 characters or fewer.' });
      if (!domain.fileLocationKind(url)) return response(event, 400, { error: 'Enter an HTTP or HTTPS link, a Windows drive path, or a network path.' });
      const type = Object.hasOwn(domain.FILE_ICONS, input.type) ? input.type : 'others';
      files.push({ name, url, type, icon: domain.FILE_ICONS[type] });
    }
    return response(event, 200, { meeting: await saveRecord('meeting', { ...current, files }, body.expectedVersion, store) });
  }

  if (body.operation === 'cancel') {
    if (!canManage(user, current)) return response(event, 403, { error: 'Only the organizer or an administrator can cancel this meeting.' });
    if (current.status === 'cancelled') return response(event, 200, { meeting: current });
    const saved = await saveRecord('meeting', { ...current, status: 'cancelled', cancelledBy: user.name, cancelledAt: new Date().toISOString() }, body.expectedVersion, store);
    await notifyMeeting(store, saved, user, [[attendeesOf(saved), 'Meeting cancelled']]);
    return response(event, 200, { meeting: saved });
  }
  return response(event, 400, { error: 'Choose a supported meeting operation.' });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { handle };
