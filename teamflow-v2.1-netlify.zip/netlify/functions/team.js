'use strict';

const { openStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, methodNotAllowed, originAllowed } = require('./lib/http');
const { listMembers, currentRecord, saveRecord, deleteRecord, withoutSecrets } = require('./lib/records');
const { requireUser, requireRole } = require('./lib/auth-core');

const SELF_EDITABLE = new Set(['name', 'username', 'email', 'color', 'initials', 'weeklyCapacityHours', 'reminderPreferences']);

function changedFields(before, after) {
  const keys = new Set([...Object.keys(before || {}), ...Object.keys(after || {})]);
  return [...keys].filter(key => !['version', 'passwordHash', 'mustResetPassword'].includes(key) && JSON.stringify(before?.[key] ?? null) !== JSON.stringify(after?.[key] ?? null));
}

function normalizeMember(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw Object.assign(new Error('Member must be an object.'), { statusCode: 400 });
  if ('password' in input || 'passwordHash' in input) throw Object.assign(new Error('Password fields cannot be sent through the team API.'), { statusCode: 400 });
  const member = { ...input };
  if (!Number.isSafeInteger(member.id)||member.id<=0) throw Object.assign(new Error('Member ID must be a positive integer.'), { statusCode: 400 });
  if (typeof member.name !== 'string' || !member.name.trim() || member.name.length > 120) throw Object.assign(new Error('Member name is required.'), { statusCode: 400 });
  if (typeof member.email !== 'string' || !/^\S+@\S+\.\S+$/.test(member.email) || member.email.length > 254) throw Object.assign(new Error('Enter a valid email address.'), { statusCode: 400 });
  if (!['admin', 'manager', 'member', 'board'].includes(member.role)) throw Object.assign(new Error('Choose a valid team role.'), { statusCode: 400 });
  member.name = member.name.trim();
  member.email = member.email.trim().toLowerCase();
  member.username = String(member.username || member.email).trim().toLowerCase();
  if (!/^(?:[a-z0-9._-]{1,64}|[^\s@]+@[^\s@]+\.[^\s@]+)$/.test(member.username)) throw Object.assign(new Error('Username must use letters, numbers, dots, underscores, or hyphens.'), { statusCode: 400 });
  member.color = /^#[0-9a-f]{6}$/i.test(String(member.color || '')) ? member.color : '#5c6ef8';
  member.initials = member.name.split(/\s+/).filter(Boolean).map(part => part[0]).join('').toUpperCase().slice(0, 2);
  member.weeklyCapacityHours = Number.isFinite(Number(member.weeklyCapacityHours)) ? Math.max(0, Math.min(168, Number(member.weeklyCapacityHours))) : 40;
  return member;
}

async function handle(event, store = openStore()) {
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const actor = await requireUser(event, store);
  if (event.httpMethod === 'GET') return response(event, 200, (await listMembers(store)).map(withoutSecrets));
  if (event.httpMethod !== 'POST') return methodNotAllowed(event, 'GET, POST, OPTIONS');

  const body = parseBody(event);
  if (body.operation === 'upsert') {
    const member = normalizeMember(body.member);
    const current = await currentRecord('member', member.id, store);
    const allMembers = await listMembers(store);
    if (allMembers.some(item => String(item.id) !== String(member.id)
      && (String(item.email || '').toLowerCase() === member.email || String(item.username || '').toLowerCase() === member.username))) {
      return response(event, 409, { error: 'That email or username is already in use.' });
    }
    if (current) {
      if(current.role==='admin'&&member.role!=='admin'&&allMembers.filter(item=>item.role==='admin'&&item.active!==false).length<=1)return response(event,409,{error:'The last active administrator cannot change roles.'});
      const changed = changedFields(current, member);
      if (actor.role !== 'admin' && (String(actor.id) !== String(member.id) || changed.some(key => !SELF_EDITABLE.has(key)))) {
        return response(event, 403, { error: 'You do not have permission to edit these member details.' });
      }
      if (actor.role !== 'admin' && current.role !== member.role) return response(event, 403, { error: 'Only an administrator can change roles.' });
    } else {
      requireRole(actor, ['admin']);
      member.mustResetPassword = true;
      member.active = true;
    }
    const persisted = current ? { ...member, passwordHash: current.passwordHash || null, mustResetPassword: current.mustResetPassword || false, active: current.active !== false, authVersion: current.authVersion || 1 } : member;
    const saved = await saveRecord('member', persisted, body.expectedVersion, store);
    return response(event, current ? 200 : 201, { member: withoutSecrets(saved) });
  }
  if (body.operation === 'delete') {
    requireRole(actor, ['admin']);
    const member = await currentRecord('member', body.id, store);
    if (!member) return response(event, 404, { error: 'Member not found.' });
    if (member.role === 'admin') {
      const admins = (await listMembers(store)).filter(item => item.role === 'admin' && item.active !== false);
      if (admins.length <= 1) return response(event, 409, { error: 'The last active administrator cannot be removed.' });
    }
    const result = await deleteRecord('member', body.id, body.expectedVersion, store);
    return response(event, 200, { ok: true, ...result });
  }
  return response(event, 400, { error: 'Choose a supported team operation.' });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { changedFields, handle, normalizeMember };
