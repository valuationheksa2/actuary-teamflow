'use strict';

const crypto = require('node:crypto');
const { openStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, cookieValue, sessionCookie, originAllowed } = require('./lib/http');
const { listMembers, getMember, saveRecord, withoutSecrets } = require('./lib/records');
const { createSession, loginMember, newToken, passwordHash, requireRole, requireUser, sha256, validatePassword, verifyPassword } = require('./lib/auth-core');
const { sendAccountLink } = require('./lib/mailer');

const TOKEN_SESSION_COOKIE = 'teamflow_session';

function routeName(event) {
  const path = event.path || '';
  const authIndex = path.indexOf('/auth/');
  if (authIndex >= 0) return path.slice(authIndex + 6).replace(/\/$/, '');
  return String(event.queryStringParameters?.route || '').replace(/^\/+|\/+$/g, '');
}

function equalSecret(left, right) {
  if (typeof left !== 'string' || typeof right !== 'string' || !left || !right) return false;
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

async function rateLimit(store, event, subject, limit = 8, windowMs = 15 * 60 * 1000) {
  const ip = event.headers?.['x-nf-client-connection-ip'] || event.headers?.['x-forwarded-for']?.split(',')[0] || 'unknown';
  const key = `auth:rate:${sha256(`${ip}:${String(subject || '').toLowerCase()}`)}`;
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const snapshot=await store.getWithMetadata(key,{type:'json',consistency:'strong'});
    const raw = snapshot?.data ? JSON.stringify(snapshot.data) : null;
    let entry = null;
    try { entry = raw ? JSON.parse(raw) : null; } catch { entry = null; }
    const now = Date.now();
    const record = entry && entry.resetAt > now ? entry : { attempts: 0, resetAt: now + windowMs };
    record.attempts += 1;
    const saved=await store.set(key,JSON.stringify(record),snapshot?{onlyIfMatch:snapshot.etag}:{onlyIfNew:true});
    if(!saved.modified) continue;
    if (record.attempts > limit) {
      const error = new Error('Too many attempts. Try again later.');
      error.statusCode = 429;
      throw error;
    }
    return key;
  }
  throw Object.assign(new Error('Too many simultaneous attempts. Try again later.'),{statusCode:429});
}

async function readResetToken(store, token) {
  if (!token || typeof token !== 'string' || token.length > 256) return null;
  const key = `auth:reset:${sha256(token)}`;
  const snapshot=await store.getWithMetadata(key,{type:'json',consistency:'strong'});
  const raw = snapshot?.data ? JSON.stringify(snapshot.data) : null;
  if (!raw) return null;
  let entry;
  try { entry = JSON.parse(raw); } catch { await store.delete(key); return null; }
  if (entry.expiresAt <= Date.now() || entry.usedAt) {
    await store.delete(key);
    return null;
  }
  const pointerKey=`auth:account-link:${entry.userId}`;
  const pointer=await store.getWithMetadata(pointerKey,{type:'json',consistency:'strong'});
  if(pointer){
    if(pointer.data.tokenHash!==sha256(token)||pointer.data.usedAt||pointer.data.expiresAt<=Date.now())return null;
    return{key:pointerKey,entry:pointer.data,etag:pointer.etag};
  }
  return { key, entry, etag:snapshot.etag };
}

async function generateAccountLink(store,member,purpose){
  if(!process.env.APP_URL)throw Object.assign(new Error('Set APP_URL to the HTTPS address of this TeamFlow site before generating links.'),{statusCode:400});
  let url;
  try{url=new URL('/',process.env.APP_URL);}catch{throw Object.assign(new Error('APP_URL must be the HTTPS address of this TeamFlow site.'),{statusCode:400});}
  if(url.protocol!=='https:')throw Object.assign(new Error('APP_URL must be the HTTPS address of this TeamFlow site.'),{statusCode:400});
  const token=newToken(),tokenHash=sha256(token),expiresAt=Date.now()+(purpose==='invite'?24*60*60*1000:30*60*1000);
  const entry={userId:member.id,purpose,tokenHash,expiresAt,authVersion:Number(member.authVersion)||1};
  const key=`auth:reset:${tokenHash}`;
  await store.set(key,JSON.stringify(entry));
  try{await store.set(`auth:account-link:${member.id}`,JSON.stringify(entry));}
  catch(error){await store.delete(key);throw error;}
  url.searchParams.set(purpose==='invite'?'invite':'reset',token);
  return{url:url.href,expiresAt:new Date(expiresAt).toISOString(),purpose};
}

async function createLink(store, member, purpose) {
  const token = newToken();
  const ttl = purpose === 'invite' ? 24 * 60 * 60 * 1000 : 30 * 60 * 1000;
  const key = `auth:reset:${sha256(token)}`;
  await store.set(key, JSON.stringify({ userId: member.id, purpose, expiresAt: Date.now() + ttl }));
  try { await sendAccountLink(member, token, purpose); }
  catch (error) { await store.delete(key); throw error; }
}

async function handle(event, store = openStore()) {
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const route = routeName(event);

  if (route === 'login' && event.httpMethod === 'POST') {
    const body = parseBody(event, 16 * 1024);
    const identifier = String(body.identifier || body.email || '').trim();
    await rateLimit(store, event, 'login-by-ip', 30, 15 * 60 * 1000);
    const rateKey = await rateLimit(store, event, identifier);
    const member = await loginMember(identifier, String(body.password || ''), store);
    if (!member) return response(event, 401, { error: 'Invalid sign-in details. If your account needs setup, request a secure invitation link.' });
    await store.delete(rateKey);
    const session = await createSession(member, store);
    return response(event, 200, { user: withoutSecrets(member) }, session.cookie);
  }

  if (route === 'me' && event.httpMethod === 'GET') {
    const user = await requireUser(event, store);
    return response(event, 200, { user: withoutSecrets(user) });
  }

  if (route === 'logout' && event.httpMethod === 'POST') {
    const token = cookieValue(event, TOKEN_SESSION_COOKIE);
    if (token) await store.delete(`auth:session:${sha256(token)}`);
    return response(event, 200, { ok: true }, sessionCookie('', 0));
  }

  if (route === 'reset/request' && event.httpMethod === 'POST') {
    return response(event,200,{ok:true,message:'Contact your administrator to verify your identity and receive a one-time password reset link.'});
  }

  if (route === 'reset/complete' && event.httpMethod === 'POST') {
    const body = parseBody(event, 16 * 1024);
    await rateLimit(store, event, 'reset-complete', 10, 15 * 60 * 1000);
    validatePassword(body.password);
    const reset = await readResetToken(store, body.token);
    if (!reset) return response(event, 400, { error: 'This link has expired or has already been used.' });
    const member = await getMember(reset.entry.userId, store);
    if (!member || member.active === false) return response(event, 400, { error: 'This link has expired or has already been used.' });
    if(reset.entry.authVersion!==undefined&&reset.entry.authVersion!==(Number(member.authVersion)||1))return response(event,400,{error:'This link has expired or has already been used.'});
    const claimed=await store.set(reset.key, JSON.stringify({ ...reset.entry, usedAt: Date.now() }),{onlyIfMatch:reset.etag});
    if(!claimed.modified)return response(event,400,{error:'This link has expired or has already been used.'});
    const updated = { ...member, passwordHash: await passwordHash(body.password), mustResetPassword: false, authVersion: (Number(member.authVersion) || 1) + 1, passwordUpdatedAt: new Date().toISOString() };
    delete updated.password;
    await saveRecord('member', updated, member.version, store);
    const session = await createSession(updated, store);
    return response(event, 200, { user: withoutSecrets(updated) }, session.cookie);
  }

  if (route === 'change-password' && event.httpMethod === 'POST') {
    const actor = await requireUser(event, store);
    const body = parseBody(event, 16 * 1024);
    if (!(await verifyPassword(String(body.currentPassword || ''), actor.passwordHash))) {
      return response(event, 400, { error: 'Current password is incorrect.' });
    }
    validatePassword(body.password);
    const updated = {
      ...actor,
      passwordHash: await passwordHash(body.password),
      mustResetPassword: false,
      authVersion: (Number(actor.authVersion) || 1) + 1,
      passwordUpdatedAt: new Date().toISOString(),
    };
    delete updated.password;
    const saved = await saveRecord('member', updated, actor.version, store);
    const session = await createSession(saved, store);
    return response(event, 200, { user: withoutSecrets(saved) }, session.cookie);
  }

  if (route === 'invitations' && event.httpMethod === 'POST') {
    const actor = await requireUser(event, store);
    requireRole(actor, ['admin']);
    await rateLimit(store, event, `account-link:${actor.id}`, 30, 60 * 60 * 1000);
    const body = parseBody(event, 16 * 1024);
    const member = await getMember(body.userId, store);
    if (!member || member.active === false) return response(event, 404, { error: 'Member not found.' });
    if(body.purpose!==undefined&&!['invite','reset'].includes(body.purpose))return response(event,400,{error:'Choose setup or password reset.'});
    const purpose=body.purpose==='reset'?'reset':'invite';
    if(purpose==='invite'&&member.passwordHash&&!member.mustResetPassword)return response(event,400,{error:'This account is already active. Generate a reset link instead.'});
    const link=await generateAccountLink(store,member,purpose);
    return response(event,200,{ok:true,...link});
  }

  if (route === 'bootstrap' && event.httpMethod === 'POST') {
    const expected = process.env.ADMIN_BOOTSTRAP_TOKEN;
    const supplied = event.headers?.['x-bootstrap-token'] || event.headers?.['X-Bootstrap-Token'] || '';
    if (!equalSecret(supplied, expected)) return response(event, 403, { error: 'Bootstrap access is not available.' });
    const body = parseBody(event, 16 * 1024);
    const email = String(body.email || '').trim().toLowerCase();
    validatePassword(body.password);
    const members = await listMembers(store);
    if (members.some(item => item.role === 'admin' && item.passwordHash)) return response(event, 409, { error: 'Administrator setup has already been completed.' });
    const administrators = members.filter(item => item.role === 'admin');
    let admin = administrators.find(item => String(item.email || '').toLowerCase() === email);
    if (!admin && administrators.length) return response(event, 403, { error: 'Bootstrap email must match an existing administrator.' });
    if (!admin) admin = { id: Date.now(), name: String(body.name || 'Administrator').trim(), email, username: email, role: 'admin', color: '#5c6ef8', initials: 'AD', active: true, weeklyCapacityHours: 40 };
    if (!email || email.length > 254) return response(event, 400, { error: 'Enter a valid email address.' });
    admin = { ...admin, passwordHash: await passwordHash(body.password), mustResetPassword: false, authVersion: (Number(admin.authVersion) || 0) + 1, active: true };
    delete admin.password;
    const saved = await saveRecord('member', admin, admin.version || 0, store);
    const session = await createSession(saved, store);
    return response(event, 200, { user: withoutSecrets(saved), setupComplete: true }, session.cookie);
  }

  return response(event, 404, { error: 'Endpoint not found.' });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { createLink, generateAccountLink, handle, rateLimit, readResetToken, routeName };
