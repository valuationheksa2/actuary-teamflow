'use strict';

const { openStore, requestStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, methodNotAllowed, originAllowed } = require('./lib/http');
const { requireUser } = require('./lib/auth-core');

// Per-person "last read" markers for work notes, so unread badges follow the account across devices.
// `since` is set on first use: notes written before then count as already read.
const key = userId => `v2:reads:${userId}`;
const ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$/;

async function readMarkers(store, userId) {
  const raw = await store.get(key(userId), { consistency: 'strong' });
  try { const parsed = raw ? JSON.parse(raw) : null; if (parsed?.since && parsed.seen) return parsed; } catch {}
  const fresh = { since: new Date().toISOString(), seen: {} };
  await store.set(key(userId), JSON.stringify(fresh));
  return fresh;
}

async function handle(event, store = openStore()) {
  store = requestStore(store);
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const user = await requireUser(event, store);
  if (event.httpMethod === 'GET') return response(event, 200, await readMarkers(store, user.id));
  if (event.httpMethod !== 'POST') return methodNotAllowed(event, 'GET, POST, OPTIONS');
  const body = parseBody(event);
  const workId = String(body.workId || '');
  if (!/^\d{1,20}$/.test(workId) || !ISO.test(String(body.seenAt || ''))) return response(event, 400, { error: 'Choose a work item and a valid time.' });
  const markers = await readMarkers(store, user.id);
  // Markers only move forward, so an older tab can't mark notes unread again.
  if (!markers.seen[workId] || markers.seen[workId] < body.seenAt) {
    markers.seen[workId] = body.seenAt;
    const entries = Object.entries(markers.seen);
    if (entries.length > 2000) markers.seen = Object.fromEntries(entries.sort((a, b) => b[1].localeCompare(a[1])).slice(0, 2000));
    await store.set(key(user.id), JSON.stringify(markers));
  }
  return response(event, 200, markers);
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { handle };
