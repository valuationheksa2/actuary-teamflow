'use strict';

const { openStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, methodNotAllowed, originAllowed } = require('./lib/http');
const { listWorks, saveRecord } = require('./lib/records');
const { requireUser } = require('./lib/auth-core');
const { todayInZone, daysBetween } = require('./digest');

async function handle(event, store = openStore()) {
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const user = await requireUser(event, store);
  const stateKey = `v2:notification-state:${user.id}`;
  const stateSnapshot=await store.getWithMetadata(stateKey,{type:'json',consistency:'strong'});
  const rawState = stateSnapshot?.data ? JSON.stringify(stateSnapshot.data) : null;
  let savedState;
  try { savedState = rawState ? JSON.parse(rawState) : null; } catch { savedState = null; }
  savedState ||= { read: [], preferences: { reminderDays: [3, 0] } };

  if (event.httpMethod === 'GET') {
    const { data: works } = await listWorks(store);
    const today = todayInZone();
    const reminderDays = Array.isArray(user.reminderPreferences?.reminderDays) ? user.reminderPreferences.reminderDays : savedState.preferences.reminderDays;
    const visibleToUser = work => ['admin', 'manager'].includes(user.role) || work.pic === user.id || (Array.isArray(work.assignees) && work.assignees.includes(user.id));
    const notifications = works.filter(work => work.status !== 'done' && work.deadline && visibleToUser(work)).map(work => {
      const days = daysBetween(work.deadline, today);
      if (days === null || (days >= 0 && !reminderDays.some(limit => days === Number(limit)))) return null;
      const kind = days < 0 ? 'overdue' : days === 0 ? 'due-today' : 'due-soon';
      const id = `work-${work.id}-${work.deadline}-${kind}-${days}`;
      return { id, workId: work.id, title: work.title, deadline: work.deadline, days, kind, read: savedState.read.includes(id) };
    }).filter(Boolean).sort((a, b) => a.days - b.days);
    return response(event, 200, { notifications, unreadCount: notifications.filter(item => !item.read).length, preferences: { reminderDays } });
  }

  if (event.httpMethod !== 'POST') return methodNotAllowed(event, 'GET, POST, OPTIONS');
  const body = parseBody(event, 32 * 1024);
  if (body.operation === 'read') {
    const ids = Array.isArray(body.ids) ? body.ids.filter(id => typeof id === 'string').slice(0, 500) : [];
    for(let attempt=0;attempt<20;attempt++){
      const snapshot=attempt?await store.getWithMetadata(stateKey,{type:'json',consistency:'strong'}):stateSnapshot;
      const state=snapshot?.data||savedState;
      const read=[...new Set([...(state.read||[]),...ids])].slice(-1000);
      const saved=await store.set(stateKey,JSON.stringify({...state,read,updatedAt:new Date().toISOString()}),snapshot?{onlyIfMatch:snapshot.etag}:{onlyIfNew:true});
      if(saved.modified)return response(event,200,{ok:true});
    }
    return response(event,409,{error:'Reminders changed elsewhere. Refresh and try again.'});
  }
  if (body.operation === 'preferences') {
    const days = Array.isArray(body.reminderDays) ? body.reminderDays.map(Number).filter(day => Number.isInteger(day) && day >= 0 && day <= 30) : [3, 0];
    const unique = [...new Set(days)].sort((a, b) => b - a);
    const member = { ...user, reminderPreferences: { reminderDays: unique }, version: undefined };
    delete member.version;
    const saved = await saveRecord('member', member, user.version, store);
    const { withoutSecrets } = require('./lib/records');
    return response(event, 200, { preferences: saved.reminderPreferences, member: withoutSecrets(saved) });
  }
  return response(event, 400, { error: 'Choose a supported notification operation.' });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { handle };
