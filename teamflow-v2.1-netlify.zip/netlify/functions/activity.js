'use strict';

const { openStore } = require('./lib/store');
const { preflight, response, safeError, methodNotAllowed, originAllowed } = require('./lib/http');
const { currentRecord } = require('./lib/records');
const { requireUser, requireRole, canEditWork } = require('./lib/auth-core');
const { readActivity } = require('./lib/activity-log');

async function handle(event, store = openStore()) {
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  if (event.httpMethod !== 'GET') return methodNotAllowed(event, 'GET, OPTIONS');
  const user = await requireUser(event, store);
  const workId = event.queryStringParameters?.workId;
  if (!workId) return response(event, 400, { error: 'A work ID is required.' });
  const work = await currentRecord('work', workId, store);
  if (!work) return response(event, 404, { error: 'Work item not found.' });
  if (user.role !== 'board' && !canEditWork(user, work)) requireRole(user, ['admin', 'manager']);
  return response(event, 200, await readActivity(store, workId));
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { handle };
