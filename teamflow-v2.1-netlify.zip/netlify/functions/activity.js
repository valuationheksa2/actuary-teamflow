'use strict';

const { openStore, requestStore } = require('./lib/store');
const { preflight, response, safeError, methodNotAllowed, originAllowed } = require('./lib/http');
const { currentRecord, listWorks } = require('./lib/records');
const domain = require('../../public/js/domain');
const { requireUser, requireRole, canEditWork } = require('./lib/auth-core');
const { readActivity, readActivityPage } = require('./lib/activity-log');

async function handle(event, store = openStore()) {
  store = requestStore(store);
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  if (event.httpMethod !== 'GET') return methodNotAllowed(event, 'GET, OPTIONS');
  const user = await requireUser(event, store);
  if (event.queryStringParameters?.bottlenecks === '1') {
    requireRole(user, ['admin', 'manager', 'board']);
    const zone = process.env.TEAM_TIME_ZONE || 'Asia/Bangkok', days = Math.max(7, Math.min(730, Number(event.queryStringParameters.days) || 90));
    const since = domain.addDays(domain.dateKeyInZone(new Date(), zone), -days);
    const { data } = await listWorks(store);
    const done = data.filter(work => work.status === 'done' && String(work.completedDate || '') >= since).sort((a, b) => String(b.completedDate).localeCompare(String(a.completedDate))).slice(0, 150);
    const rows = [];
    for (let index = 0; index < done.length; index += 6) {
      rows.push(...await Promise.all(done.slice(index, index + 6).map(async work => ({ id: work.id, title: work.title, perf: domain.workPerformance(work, await readActivity(store, work.id), zone) }))));
    }
    return response(event, 200, domain.summarizePerformance(rows));
  }
  const workId = event.queryStringParameters?.workId;
  if (!workId) return response(event, 400, { error: 'A work ID is required.' });
  const work = await currentRecord('work', workId, store);
  if (!work) return response(event, 404, { error: 'Work item not found.' });
  if (user.role !== 'board' && !canEditWork(user, work)) requireRole(user, ['admin', 'manager']);
  if (event.queryStringParameters?.page === '1') return response(event, 200, await readActivityPage(store, workId, { limit: event.queryStringParameters.limit, cursor: event.queryStringParameters.cursor }));
  return response(event, 200, await readActivity(store, workId));
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { handle };
