'use strict';

const { openStore, requestStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, methodNotAllowed, originAllowed } = require('./lib/http');
const { requireUser } = require('./lib/auth-core');
const push = require('./lib/push');

async function handle(event, store = openStore()) {
  store = requestStore(store);
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const user = await requireUser(event, store);
  if (event.httpMethod === 'GET') return response(event, 200, { publicKey: push.publicKey() });
  if (event.httpMethod !== 'POST') return methodNotAllowed(event, 'GET, POST, OPTIONS');
  const body = parseBody(event);
  if (body.operation === 'subscribe') {
    if (!push.configured()) return response(event, 503, { error: 'Push notifications are not configured on this site.' });
    await push.saveSubscription(store, user.id, body.subscription);
    return response(event, 200, { ok: true });
  }
  if (body.operation === 'test') {
    const delivered = await push.sendToUsers(store, [user.id], () => ({ title: 'TeamFlow push is working', body: 'Alerts will reach this device even when TeamFlow is closed.', tag: 'teamflow-test-' + Date.now(), workId: null }));
    return response(event, 200, { delivered });
  }
  if (body.operation === 'unsubscribe') {
    await push.removeSubscription(store, user.id, String(body.endpoint || ''));
    return response(event, 200, { ok: true });
  }
  return response(event, 400, { error: 'Choose a supported push operation.' });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { handle };
