'use strict';

const crypto = require('node:crypto');
const { openStore } = require('./lib/store');
const { preflight, response, safeError, methodNotAllowed, originAllowed } = require('./lib/http');
const { listWorks, listMembers } = require('./lib/records');
const { requireUser, requireRole } = require('./lib/auth-core');

function todayInZone(date = new Date(), timeZone = process.env.TEAM_TIME_ZONE || 'Asia/Bangkok') {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function daysBetween(dateString, todayString) {
  if (!dateString) return null;
  const start = Date.parse(`${todayString}T00:00:00Z`);
  const end = Date.parse(`${dateString}T00:00:00Z`);
  return Number.isFinite(start) && Number.isFinite(end) ? Math.round((end - start) / 86400000) : null;
}

function bearerToken(event) {
  const header = event.headers?.authorization || event.headers?.Authorization || '';
  return header.startsWith('Bearer ') ? header.slice(7) : '';
}

function safeEqual(a, b) {
  if (!a || !b) return false;
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}

async function handle(event, store = openStore()) {
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  if (event.httpMethod !== 'GET') return methodNotAllowed(event, 'GET, OPTIONS');
  const configuredToken = process.env.DIGEST_API_TOKEN;
  if (!configuredToken || !safeEqual(bearerToken(event), configuredToken)) {
    const user = await requireUser(event, store);
    requireRole(user, ['admin', 'manager']);
  }
  const [{ data: works }, team] = await Promise.all([listWorks(store), listMembers(store)]);
  const today = todayInZone();
  const daysUntil = deadline => daysBetween(deadline, today);
  const getMemberName = id => team.find(member => member.id === id)?.name || 'Unknown';
  const phases = ['Planning', 'Executing', 'Review', 'Finalize'];
  const ongoing = works.filter(work => work.status === 'ongoing');
  const upcoming = works.filter(work => work.status === 'upcoming');
  const overdue = works.filter(work => work.status !== 'done' && daysUntil(work.deadline) < 0);
  const reviewReady = works.filter(work => work.status === 'ongoing' && work.phase === 2);
  const dueSoon = works.filter(work => work.status !== 'done' && daysUntil(work.deadline) >= 0 && daysUntil(work.deadline) <= 7);
  const assignees = work => (Array.isArray(work.assignees) ? work.assignees : []).map(getMemberName);
  return response(event, 200, {
    generatedAt: new Date().toISOString(), date: today,
    summary: { ongoing: ongoing.length, upcoming: upcoming.length, reviewReady: reviewReady.length, overdue: overdue.length, dueSoon: dueSoon.length },
    reviewReady: reviewReady.map(work => ({ id: work.id, title: work.title, deadline: work.deadline, daysLeft: daysUntil(work.deadline), assignees: assignees(work) })),
    overdue: overdue.map(work => ({ id: work.id, title: work.title, deadline: work.deadline, daysOverdue: Math.abs(daysUntil(work.deadline)), phase: work.status === 'ongoing' ? phases[work.phase] : 'Upcoming', assignees: assignees(work) })),
    ongoing: ongoing.map(work => ({ id: work.id, title: work.title, phase: phases[work.phase], deadline: work.deadline, daysLeft: daysUntil(work.deadline), priority: work.priority, assignees: assignees(work) })),
    dueSoon: dueSoon.sort((a, b) => String(a.deadline).localeCompare(String(b.deadline))).map(work => ({ id: work.id, title: work.title, deadline: work.deadline, daysLeft: daysUntil(work.deadline), assignees: assignees(work) })),
  });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { daysBetween, handle, todayInZone };
exports.daysBetween=daysBetween;
exports.todayInZone=todayInZone;
