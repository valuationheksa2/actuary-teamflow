'use strict';

const { openStore } = require('./lib/store');
const { preflight, response, safeError, parseBody, methodNotAllowed, originAllowed } = require('./lib/http');
const { listMembers, listWorks, currentRecord, saveRecord, deleteRecord, saveCollection, collection } = require('./lib/records');
const { requireUser, requireRole, canEditWork } = require('./lib/auth-core');
const { appendActivity } = require('./lib/activity-log');

function normalizeWork(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw Object.assign(new Error('Work item must be an object.'), { statusCode: 400 });
  const work = { ...input };
  if(!Number.isSafeInteger(work.id)||work.id<=0)throw Object.assign(new Error('Work requires a valid record ID.'),{statusCode:400});
  if(work.startDate&&work.deadline&&work.deadline<work.startDate)throw Object.assign(new Error('Deadline must not precede start date.'),{statusCode:400});
  if (typeof work.title !== 'string' || !work.title.trim() || work.title.length > 200) throw Object.assign(new Error('Work title is required and must be 200 characters or fewer.'), { statusCode: 400 });
  work.title = work.title.trim();
  if (work.status && !['upcoming', 'ongoing', 'done'].includes(work.status)) throw Object.assign(new Error('Choose a valid work status.'), { statusCode: 400 });
  if (work.priority && !['High', 'Medium', 'Low'].includes(work.priority)) throw Object.assign(new Error('Choose a valid priority.'), { statusCode: 400 });
  if (work.phase !== undefined && (!Number.isInteger(Number(work.phase)) || Number(work.phase) < 0 || Number(work.phase) > (work.status==='done'?4:3))) throw Object.assign(new Error('Choose a valid project phase.'), { statusCode: 400 });
  if (work.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(work.startDate)) throw Object.assign(new Error('Start date must use YYYY-MM-DD.'), { statusCode: 400 });
  if (work.deadline && !/^\d{4}-\d{2}-\d{2}$/.test(work.deadline)) throw Object.assign(new Error('Deadline must use YYYY-MM-DD.'), { statusCode: 400 });
  for(const key of ['startDate','deadline'])if(work[key]){const date=new Date(work[key]+'T00:00:00Z');if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==work[key])throw Object.assign(new Error('Choose a valid calendar date.'),{statusCode:400});}
  if(work.recurrence&&!['weekly','biweekly','monthly','quarterly','custom'].includes(work.recurrence))throw Object.assign(new Error('Choose a valid recurrence.'),{statusCode:400});
  if(work.recurrence==='custom'&&(!Number.isInteger(Number(work.customDays))||Number(work.customDays)<1||Number(work.customDays)>365))throw Object.assign(new Error('Custom recurrence requires 1 to 365 days.'),{statusCode:400});
  work.desc = String(work.desc || '').slice(0, 10000);
  work.assignees = Array.isArray(work.assignees) ? work.assignees.filter(Number.isFinite) : [];
  work.tags = Array.isArray(work.tags) ? work.tags.filter(tag => typeof tag === 'string').slice(0, 30) : [];
  work.notes = Array.isArray(work.notes) ? work.notes.slice(0, 500).map(note => {
    if (!note || typeof note !== 'object' || Array.isArray(note)) throw Object.assign(new Error('Notes must be valid objects.'), { statusCode: 400 });
    return { ...note, authorName: String(note.authorName || '').slice(0, 120), text: String(note.text || '').slice(0, 5000) };
  }) : [];
  work.phaseTasks = work.phaseTasks && typeof work.phaseTasks === 'object' ? Object.fromEntries(Object.entries(work.phaseTasks).slice(0, 4).map(([phase, tasks]) => [phase, Array.isArray(tasks) ? tasks.slice(0, 50).map(task => String(task).slice(0, 240)) : []])) : {};
  work.phaseChecks = work.phaseChecks && typeof work.phaseChecks === 'object' ? work.phaseChecks : {};
  work.files = Array.isArray(work.files) ? work.files.slice(0, 200).map(file => {
    if (!file || typeof file !== 'object' || Array.isArray(file)) throw Object.assign(new Error('File links must be valid objects.'), { statusCode: 400 });
    // Older stored categories remain valid so unrelated edits retain their metadata.
    const type = ['folder', 'doc', 'dashboard', 'workspace', 'others', 'notes', 'design', 'sheet', 'checklist', 'internal', 'media', 'archive'].includes(file.type) ? file.type : 'others';
    const url = String(file.url || '').trim();
    const validUrl = require('../../public/js/domain').fileLocationKind(url);
    if (!validUrl) throw Object.assign(new Error('Enter an HTTP or HTTPS link, a Windows drive path, or a network path.'), { statusCode: 400 });
    const icons = { folder: '📁', doc: '📄', dashboard: '📊', workspace: '🏢', others: '🔖', notes: '📝', design: '🎨', sheet: '📊', checklist: '✅', internal: '🔗', media: '🖼', archive: '📦' };
    return { name: String(file.name || '').slice(0, 200), url, type, icon: icons[type] };
  }) : [];
  work.estimatedHours = work.estimatedHours == null || work.estimatedHours === '' ? 0 : Number(work.estimatedHours);
  if (!Number.isFinite(work.estimatedHours) || work.estimatedHours < 0 || work.estimatedHours > 10000) throw Object.assign(new Error('Estimated hours must be between 0 and 10,000.'), { statusCode: 400 });
  return work;
}

function sameValue(left, right) {
  return JSON.stringify(left ?? null) === JSON.stringify(right ?? null);
}

async function collectionPermissionError(user, name, before, after, store) {
  const managers = ['admin', 'manager'].includes(user.role);
  if (name === 'templates') {
    if (!managers && user.role !== 'member') return 'Board accounts have read-only access.';
    const oldById = new Map(before.map(item => [String(item.id), item]));
    const seen = new Set();
    for (const item of after) {
      if (!item || !Number.isSafeInteger(item.id) || item.id <= 0 || seen.has(String(item.id))) return 'Templates require unique valid IDs.';
      seen.add(String(item.id));
      const old = oldById.get(String(item.id));
      if (!old || !sameValue(old, item)) {
        if (typeof item.name !== 'string' || !item.name.trim() || item.name.length > 200) return 'Template names are required and must be 200 characters or fewer.';
        if (item.estimatedHours != null && (!Number.isFinite(Number(item.estimatedHours)) || Number(item.estimatedHours) < 0 || Number(item.estimatedHours) > 10000)) return 'Template estimated hours must be between 0 and 10,000.';
      }
      if (old) {
        if (!sameValue(old.createdBy, item.createdBy) || !sameValue(old.createdAt, item.createdAt)) return 'Template ownership and creation date cannot be changed.';
        if (!sameValue(old, item) && !managers && (old.createdBy == null || String(old.createdBy) !== String(user.id))) return 'You can only edit templates you created.';
        oldById.delete(String(item.id));
      } else if (String(item.createdBy) !== String(user.id)) return 'New templates must belong to the signed-in account.';
    }
    if (oldById.size && !managers) return 'Only managers and administrators can delete templates.';
    return null;
  }
  if (managers) return null;
  if (user.role === 'board') return 'Board accounts have read-only access.';
  if (name === 'feedbackItems') {
    const oldById = new Map(before.map(item => [String(item.id), item]));
    for (const item of after) {
      if (oldById.has(String(item.id))) {
        if (!sameValue(item, oldById.get(String(item.id)))) return 'Only managers can edit or remove feedback.';
        oldById.delete(String(item.id));
      } else if (String(item.authorId) !== String(user.id)) return 'Feedback must belong to the signed-in account.';
    }
    if (oldById.size) return 'Only managers can edit or remove feedback.';
    return null;
  }
  if (name === 'joinRequests') {
    const oldById = new Map(before.map(item => [String(item.id), item]));
    const { data: works } = await listWorks(store);
    for (const item of after) {
      const old = oldById.get(String(item.id));
      if (!old) {
        const work = works.find(row => String(row.id) === String(item.workId));
        const assigned = work?.assignees?.some(id => String(id) === String(user.id));
        const validType = item.type === 'join' || item.type === 'leave';
        const validStatus = item.status === 'pending';
        const validMembership = item.type === 'join' ? !assigned : assigned && String(work?.pic) !== String(user.id);
        if (user.role !== 'member' || String(item.userId) !== String(user.id) || !validType || !validStatus || !work || work.status === 'done' || !validMembership) {
          return 'You may only request to join or leave eligible work items.';
        }
        continue;
      }
      if (sameValue(item, old)) { oldById.delete(String(item.id)); continue; }
      return 'Resolve requests using the approval action.';
    }
    if (oldById.size) return 'Only managers and administrators can remove requests.';
    return null;
  }
  return 'You do not have permission to update this collection.';
}

function canManageAssignments(user, work) {
  return ['admin', 'manager'].includes(user.role) || (user.role === 'member' && [work.createdBy, work.pic].some(id => id != null && String(id) === String(user.id)));
}

function memberWorkPermissionError(user, current, next) {
  if (['admin', 'manager'].includes(user.role)) return null;
  for (const field of ['id', 'pic', 'createdBy', 'createdAt', 'requestResolutions']) {
    if (!sameValue(current[field], next[field])) return 'Only managers can change this work field.';
  }
  if (!sameValue(current.assignees, next.assignees) && !canManageAssignments(user, current)) return 'Only the work creator, PIC, managers and administrators can change assignees.';
  const beforeNotes = Array.isArray(current.notes) ? current.notes : [];
  const afterNotes = Array.isArray(next.notes) ? next.notes : [];
  const length = Math.max(beforeNotes.length, afterNotes.length);
  for (let index = 0; index < length; index += 1) {
    const oldNote = beforeNotes[index];
    const newNote = afterNotes[index];
    if (sameValue(oldNote, newNote)) continue;
    if (oldNote && String(oldNote.authorId) !== String(user.id)) return 'You can only change your own notes.';
    if (newNote && String(newNote.authorId) !== String(user.id)) return 'Notes must belong to the signed-in account.';
  }
  return null;
}

async function handle(event, store = openStore()) {
  if (event.httpMethod === 'OPTIONS') return preflight(event);
  if (!originAllowed(event)) return response(event, 403, { error: 'Origin is not allowed.' });
  const user = await requireUser(event, store);

  if (event.httpMethod === 'GET') {
    const bundle = await listWorks(store);
    const [requests, templates, feedback] = await Promise.all([
      collection(store, 'joinRequests'), collection(store, 'templates'), collection(store, 'feedbackItems'),
    ]);
    return response(event, 200, {
      data: bundle.data,
      joinRequests: requests.items,
      templates: templates.items,
      feedbackItems: feedback.items,
      versions: { joinRequests: requests.version, templates: templates.version, feedbackItems: feedback.version },
    });
  }
  if (event.httpMethod !== 'POST') return methodNotAllowed(event, 'GET, POST, OPTIONS');
  const body = parseBody(event);

  if (body.operation === 'assign') {
    const current = await currentRecord('work', body.id, store);
    if (!current) return response(event, 404, { error: 'Work item not found.' });
    if (!canManageAssignments(user, current)) return response(event, 403, { error: 'Only the work creator, PIC, managers and administrators can change assignees.' });
    if (!Array.isArray(body.assignees) || !body.assignees.length || body.assignees.some(id => !Number.isSafeInteger(id) || id <= 0)) return response(event, 400, { error: 'Assign at least one member using valid account IDs.' });
    const eligible = new Set((await listMembers(store)).filter(member => (member.active !== false && ['member', 'manager'].includes(member.role)) || current.assignees.includes(member.id)).map(member => member.id));
    if (body.assignees.some(id => !eligible.has(id))) return response(event, 400, { error: 'Choose active members or managers from the team.' });
    if (body.expectedVersion !== current.version) return response(event, 409, { error: 'Work changed elsewhere. Close this form, refresh, and retry.' });
    const next = { ...current, assignees: [...new Set(body.assignees)] };
    const saved = await saveRecord('work', next, current.version, store);
    await appendActivity(store, saved.id, user, 'assignments updated', current, saved);
    return response(event, 200, { work: saved });
  }

  if(body.operation==='complete') {
    let work=await currentRecord('work',body.id,store);
    if(!work)return response(event,404,{error:'Work item not found.'});
    if(!canEditWork(user,work))return response(event,403,{error:'You cannot complete this work item.'});
    if(work.status!=='done') {
      if(Number(body.expectedVersion)!==work.version)return response(event,409,{error:'Work changed elsewhere. Refresh before completing.'});
      const next={...work,status:'done',phase:4,completedDate:new Intl.DateTimeFormat('en-CA',{timeZone:process.env.TEAM_TIME_ZONE||'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date()),phaseChecks:Object.fromEntries(Object.entries(work.phaseChecks||{}).map(([phase,tasks])=>[phase,tasks.map(()=>true)]))};
      if(work.recurrence)next.nextOccurrenceId=require('node:crypto').randomInt(1,2**48-1);
      const before=work;work=await saveRecord('work',next,work.version,store);await appendActivity(store,work.id,user,'completed',before,work);
    }
    let nextWork=null;
    if(work.nextOccurrenceId) {
      nextWork=await currentRecord('work',work.nextOccurrenceId,store);
      if(nextWork&&nextWork.recurringFrom!==work.id)return response(event,409,{error:'Recurring record conflict. Please contact your administrator.'});
      if(!nextWork){
        const domain=require('../../public/js/domain');
        let deadline=work.deadline||work.completedDate;
        if(['monthly','quarterly'].includes(work.recurrence)) {
          const date=domain.parseDateKey(deadline),day=date.getUTCDate();date.setUTCDate(1);date.setUTCMonth(date.getUTCMonth()+(work.recurrence==='monthly'?1:3));const last=new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth()+1,0)).getUTCDate();date.setUTCDate(Math.min(day,last));deadline=date.toISOString().slice(0,10);
        }else deadline=domain.addDays(deadline,work.recurrence==='biweekly'?14:work.recurrence==='custom'?Math.max(1,Math.min(365,Number(work.customDays)||7)):7);
        const duration=work.startDate&&work.deadline?Math.round((domain.parseDateKey(work.deadline)-domain.parseDateKey(work.startDate))/86400000):0;
        const next={...work,id:work.nextOccurrenceId,status:'upcoming',phase:0,deadline,startDate:domain.addDays(deadline,-duration),completedDate:null,files:[],notes:[],createdAt:work.completedDate,createdBy:user.id,recurringFrom:work.id,phaseChecks:Object.fromEntries(Object.entries(work.phaseChecks||{}).map(([phase,tasks])=>[phase,tasks.map(()=>false)]))};
        delete next.version;delete next.nextOccurrenceId;delete next.requestResolutions;
        nextWork=await saveRecord('work',next,0,store);await appendActivity(store,nextWork.id,user,'created',{},nextWork);
      }
    }
    return response(event,200,{work,nextWork});
  }

  if(body.operation==='resolve-request') {
    requireRole(user,['admin','manager','member']);
    if(!['approved','rejected'].includes(body.status))return response(event,400,{error:'Choose an approval or rejection.'});
    const requests=await collection(store,'joinRequests');
    const request=requests.items.find(item=>String(item.id)===String(body.id));
    if(!request)return response(event,404,{error:'Request not found.'});
    let work=await currentRecord('work',request.workId,store);
    if(!work)return response(event,404,{error:'Work item not found.'});
    if(!['admin','manager'].includes(user.role)&&String(work.pic)!==String(user.id))return response(event,403,{error:'Only the PIC or a manager can resolve this request.'});
    if(request.status!=='pending')return response(event,409,{error:'This request has already been processed.'});
    if(body.expectedVersion!==requests.version)return response(event,409,{error:'Requests changed elsewhere. Refresh before resolving.'});
    // A durable work marker makes retries safe if the collection write fails.
    const previous=work.requestResolutions?.[String(request.id)];
    if(previous&&previous.status!==body.status)return response(event,409,{error:'This request already has a different resolution.'});
    if(!previous){
      if(work.status==='done')return response(event,400,{error:'Completed work cannot change membership.'});
      if(request.type==='leave'&&String(work.pic)===String(request.userId))return response(event,400,{error:'Transfer the PIC before approving a leave request.'});
      if(!['join','leave'].includes(request.type))return response(event,400,{error:'Invalid request type.'});
      const next={...work,requestResolutions:{...work.requestResolutions,[String(request.id)]:{status:body.status,actorId:user.id,actorName:user.name,date:new Intl.DateTimeFormat('en-CA',{timeZone:process.env.TEAM_TIME_ZONE||'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())}}};
      if(body.status==='approved')next.assignees=request.type==='join'?[...new Set([...(work.assignees||[]),request.userId])]:(work.assignees||[]).filter(id=>String(id)!==String(request.userId));
      work=await saveRecord('work',next,work.version,store);
      await appendActivity(store,work.id,user,'request resolved',{},work);
    }
    const resolution=work.requestResolutions[String(request.id)];
    const items=requests.items.map(item=>String(item.id)===String(request.id)?{...item,status:resolution.status,approvedBy:resolution.actorId,approvedByName:resolution.actorName,resolvedDate:resolution.date}:item);
    for(let attempt=0;attempt<20;attempt++){
      const latest=attempt?await collection(store,'joinRequests'):requests;
      const merged=require('../../public/js/domain').mergeCollectionChanges(latest.items,requests.items,items);
      try{
        const saved=await saveCollection(store,'joinRequests',merged,latest.version);
        return response(event,200,{work,joinRequests:saved.items,version:saved.version});
      }catch(error){if(error.statusCode!==409||attempt===19)throw error;}
    }
  }

  if (body.operation === 'collection') {
    if (!['joinRequests', 'templates', 'feedbackItems'].includes(body.name)) return response(event, 400, { error: 'Unknown collection.' });
    if (!Array.isArray(body.items)) return response(event, 400, { error: 'Collection items must be a list.' });
    const current = await collection(store, body.name);
    if (body.name === 'templates') {
      const existingIds = new Set(current.items.map(item => String(item.id)));
      body.items = body.items.map(item => {
        if (!item || typeof item !== 'object' || Array.isArray(item)) throw Object.assign(new Error('Templates must be valid objects.'), { statusCode: 400 });
        return existingIds.has(String(item.id)) ? item : { ...item, createdBy: user.id, createdAt: new Intl.DateTimeFormat('en-CA', { timeZone: process.env.TEAM_TIME_ZONE || 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date()) };
      });
    }
    if (body.name === 'feedbackItems') {
      const existingIds = new Set(current.items.map(item => String(item.id)));
      body.items = body.items.map(item => {
        if (existingIds.has(String(item.id))) {
          if(!Number.isSafeInteger(Number(item.id))||typeof item.text!=='string'||item.text.length>3000||!['open','noted','inprogress','done'].includes(item.status))throw Object.assign(new Error('Invalid feedback entry.'),{statusCode:400});
          return item;
        }
        const text = String(item.text || '').trim();
        const categories = ['Bug Report', 'Suggestion', 'Compliment', 'Other'];
        if (!Number.isSafeInteger(Number(item.id)) || !text || text.length > 3000) {
          throw Object.assign(new Error('Feedback must have an ID and text of 3,000 characters or fewer.'), { statusCode: 400 });
        }
        return { id: Number(item.id), category: categories.includes(item.category) ? item.category : 'Other', author: (String(item.author || '').trim() || user.name).slice(0, 120), authorId: user.id, text, date: new Intl.DateTimeFormat('en-CA', { timeZone: process.env.TEAM_TIME_ZONE || 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date()), status: 'open' };
      });
    }
    for(let attempt=0;attempt<20;attempt++){
      const latest=attempt?await collection(store,body.name):current;
      const items=Array.isArray(body.baseItems)?require('../../public/js/domain').mergeCollectionChanges(latest.items,body.baseItems,body.items):body.items;
      const denied=await collectionPermissionError(user,body.name,latest.items,items,store);
      if(denied)return response(event,403,{error:denied});
      if(body.name==='joinRequests'){
        const pending=new Set();
        for(const request of items){
          if(request.status!=='pending')continue;
          const key=`${request.workId}:${request.userId}`;
          if(pending.has(key))return response(event,409,{error:'That user already has a pending request for this work.'});
          pending.add(key);
        }
      }
      try{
        const saved=await saveCollection(store,body.name,items,Array.isArray(body.baseItems)?latest.version:body.expectedVersion);
        return response(event,200,{ok:true,...saved});
      }catch(error){if(error.statusCode!==409||!Array.isArray(body.baseItems)||attempt===19)throw error;}
    }
  }
  if (body.operation === 'upsert') {
    const work = normalizeWork(body.work);
    const current = await currentRecord('work', work.id, store);
    if(!sameValue(current?.requestResolutions,work.requestResolutions)||!sameValue(current?.nextOccurrenceId,work.nextOccurrenceId))return response(event,403,{error:'Workflow resolution fields are managed by the server.'});
    if (current && !canEditWork(user, current)) return response(event, 403, { error: 'You do not have permission to edit this work item.' });
    if (current) {
      const denied = memberWorkPermissionError(user, current, work);
      if (denied) return response(event, 403, { error: denied });
    }
    if (!current) {
      requireRole(user, ['admin', 'manager', 'member']);
      work.createdBy = user.id;
      work.createdAt = new Intl.DateTimeFormat('en-CA', { timeZone: process.env.TEAM_TIME_ZONE || 'Asia/Bangkok', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
      if (user.role === 'member') work.assignees = [...new Set([...work.assignees, user.id])];
    }
    const saved = await saveRecord('work', work, body.expectedVersion, store);
    await appendActivity(store, saved.id, user, current ? 'updated' : 'created', current || {}, saved);
    return response(event, current ? 200 : 201, { work: saved });
  }
  if (body.operation === 'delete') {
    const current = await currentRecord('work', body.id, store);
    if (!current) return response(event, 404, { error: 'Work item not found.' });
    requireRole(user, ['admin', 'manager']);
    const deleted = await deleteRecord('work', body.id, body.expectedVersion, store);
    await appendActivity(store, body.id, user, 'deleted', current, {});
    return response(event, 200, { ok: true, ...deleted });
  }
  return response(event, 400, { error: 'Choose a supported work operation.' });
}

exports.handler = async event => {
  try { return await handle(event); }
  catch (error) { return safeError(event, error); }
};

exports._test = { collectionPermissionError, handle, memberWorkPermissionError, normalizeWork };
